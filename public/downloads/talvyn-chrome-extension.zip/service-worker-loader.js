import './assets/index.ts-0fb2AKxl.js';
