import{j as I}from"./jobsService-BuEU-K8d.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const s of n)if(s.type==="childList")for(const d of s.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&r(d)}).observe(document,{childList:!0,subtree:!0});function i(n){const s={};return n.integrity&&(s.integrity=n.integrity),n.referrerPolicy&&(s.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?s.credentials="include":n.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(n){if(n.ep)return;n.ep=!0;const s=i(n);fetch(n.href,s)}})();let u="loading",L=null,T=!1;const v=document.getElementById("app");function h(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/logotalvyn.png")}catch{}return"/icons/logotalvyn.png"}function m(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/icon48.png")}catch{}return"/icons/icon48.png"}async function y(e){var t;if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage))try{return await chrome.runtime.sendMessage(e)}catch(i){throw console.warn("[Talvyn Popup] Background message failed:",i),i}throw new Error("Chrome runtime unavailable")}async function b(e){try{await y({type:"OPEN_DASHBOARD_ROUTE",route:e})}catch{const t={dashboard:"https://talvyn.vercel.app/dashboard",profile:"https://talvyn.vercel.app/profile",tracker:"https://talvyn.vercel.app/tracker",settings:"https://talvyn.vercel.app/extensions"};window.open(t[e]||"https://talvyn.vercel.app/dashboard","_blank")}}async function w(){var e;try{await y({type:"CONNECT_TALVYN"})}catch{const t=typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.id)?chrome.runtime.id:"",i=t?`https://talvyn.vercel.app/extension/connect?extId=${encodeURIComponent(t)}`:"https://talvyn.vercel.app/extension/connect";window.open(i,"_blank")}}async function N(){try{await y({type:"DISCONNECT_TALVYN"})}catch(e){console.warn("[Talvyn Popup] Failed to disconnect via background:",e)}u="disconnected",L=null,A()}async function j(){var e,t,i,r,n,s,d;console.log("[Talvyn] Analyze button clicked"),console.log("[Talvyn Popup] Triggering floating intelligence panel on active tab...");try{let a=null;if(typeof chrome<"u"&&((e=chrome.tabs)!=null&&e.query)){const l=await chrome.tabs.query({active:!0,lastFocusedWindow:!0});if((t=l[0])!=null&&t.id)a=l[0];else{const o=await chrome.tabs.query({active:!0,currentWindow:!0});if((i=o[0])!=null&&i.id)a=o[0];else{const c=await chrome.tabs.query({active:!0});(r=c[0])!=null&&r.id&&(a=c[0])}}}if(!(a!=null&&a.id)){console.warn("[Talvyn Popup] Active tab not found directly via tabs.query; delegating to background worker...");try{const l=await y({type:"TRIGGER_ACTIVE_TAB_PANEL"});console.log("[Talvyn] Background panel trigger response:",l)}catch(l){console.error("[Talvyn Popup] Background panel trigger failed:",l)}return}const p=a.url||"",f=a.title||"";console.log(`[Talvyn] Active tab: ${p||`tabId ${a.id}`}`),console.log("[Talvyn] Sending TALVYN_OPEN_INTELLIGENCE_PANEL");try{const l=await chrome.tabs.sendMessage(a.id,{type:"TALVYN_OPEN_INTELLIGENCE_PANEL",tabUrl:p,tabTitle:f});console.log("[Talvyn] TALVYN_OPEN_INTELLIGENCE_PANEL acknowledged by content script:",l)}catch(l){if(console.warn("[Talvyn] chrome.tabs.sendMessage failed directly on active tab:",(l==null?void 0:l.message)||l),console.log(`[Talvyn] Content script not reachable on tab ${a.id}. Attempting injection & background delegation...`),typeof chrome<"u"&&((n=chrome.scripting)!=null&&n.executeScript))try{const c=((d=(s=chrome.runtime.getManifest().content_scripts)==null?void 0:s[0])==null?void 0:d.js)||[];if(c.length>0){console.log("[Talvyn] Programmatically injecting content script files from popup:",c),await chrome.scripting.executeScript({target:{tabId:a.id},files:c});for(let g=1;g<=3;g++){await new Promise(x=>setTimeout(x,g*150));try{const x=await chrome.tabs.sendMessage(a.id,{type:"TALVYN_OPEN_INTELLIGENCE_PANEL",tabUrl:p,tabTitle:f});console.log("[Talvyn] TALVYN_OPEN_INTELLIGENCE_PANEL retry succeeded after direct injection:",x);return}catch{}}}}catch(o){console.warn("[Talvyn] Popup-level script injection error:",(o==null?void 0:o.message)||o)}try{const o=await y({type:"TRIGGER_ACTIVE_TAB_PANEL",tabId:a.id,tabUrl:p,tabTitle:f});console.log("[Talvyn] Background panel trigger response:",o),o!=null&&o.success||console.error("[Talvyn] Failed to trigger panel via background worker:",o==null?void 0:o.error)}catch(o){console.error("[Talvyn] Background panel trigger exception:",(o==null?void 0:o.message)||o)}}}catch(a){console.error("[Talvyn Popup] Failed to trigger active tab floating window:",(a==null?void 0:a.message)||a)}}async function z(){console.log("[Talvyn] POPUP_AUTH_CHECK_STARTED"),B();try{const e=await y({type:"GET_AUTH_STATUS"});if(!e||!e.success){u="error",E((e==null?void 0:e.error)||"Could not verify connection status.");return}e.state==="connected"&&e.user?(console.log("[Talvyn] SESSION_FOUND"),console.log("[Talvyn] SESSION_VALID"),u="connected",L=e.user,T=!!e.isOffline,C(e.user,{isOffline:T})):e.state==="expired"?(console.log("[Talvyn] SESSION_EXPIRED"),u="expired",P()):(u="disconnected",A())}catch(e){console.error("[Talvyn Popup] Error communicating with background worker:",e),u="error",E((e==null?void 0:e.message)||"Unable to connect to extension service worker.")}}function B(){const e=h(),t=m();v.innerHTML=`
    <div style="padding:28px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
      <img
        src="${e}"
        alt="Talvyn"
        onerror="this.onerror=null;this.src='${t}';"
        style="width:48px;height:48px;border-radius:12px;box-shadow:0 4px 12px rgba(99,102,241,0.25);margin-bottom:16px;object-fit:contain;"
      />
      <div style="font-weight:700;font-size:15px;color:#0f172a;margin-bottom:4px;">Talvyn</div>
      <div style="font-size:12px;color:#64748b;margin-bottom:20px;">Connecting...</div>
      <div style="width:26px;height:26px;border:2.5px solid #e2e8f0;border-top-color:#4f46e5;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
      <style>
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      </style>
    </div>
  `}function A(){var i,r;const e=h(),t=m();v.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#f1f5f9;
            color:#64748b;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#94a3b8;display:inline-block;"></span>
            Not connected
          </div>
        </div>

        <!-- Connection Notice Card -->
        <div style="
          padding:14px;background:linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
          border:1px solid #e0e7ff;border-radius:12px;margin-bottom:16px;text-align:center;
        ">
          <div style="font-size:13px;font-weight:700;color:#1e1b4b;margin-bottom:4px;">
            Connect your Talvyn Account
          </div>
          <div style="font-size:11.5px;color:#475569;line-height:1.45;">
            Authorize the extension to capture jobs, sync profile data, and manage your applications seamlessly.
          </div>
        </div>

        <!-- Primary Connect Action Button -->
        <button type="button" id="connect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          <span>Connect Talvyn</span>
        </button>

        <div style="font-size:11px;color:#64748b;text-align:center;line-height:1.4;">
          Opens your Talvyn dashboard to link your account securely.
        </div>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Don't have an account?</span>
        <button type="button" id="signup-btn" style="
          background:none;border:none;padding:0;font-size:10px;color:#4f46e5;font-weight:600;cursor:pointer;
        ">Create Free Account →</button>
      </div>
    </div>
  `,(i=document.getElementById("connect-account-btn"))==null||i.addEventListener("click",()=>{w()}),(r=document.getElementById("signup-btn"))==null||r.addEventListener("click",()=>{w()})}function P(){var i,r;const e=h(),t=m();v.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#fef3c7;
            color:#b45309;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#f59e0b;display:inline-block;"></span>
            Session expired
          </div>
        </div>

        <!-- Expired Notice Box -->
        <div style="
          margin-bottom:14px;padding:12px;background:#fffbeb;
          border:1px solid #fef3c7;border-radius:10px;font-size:11.5px;color:#b45309;
          display:flex;align-items:flex-start;gap:8px;line-height:1.45;
        ">
          <span style="font-size:14px;">⚠️</span>
          <div>
            <div style="font-weight:700;margin-bottom:2px;">Session Expired</div>
            Your Talvyn session has expired. Please reconnect your account to continue capturing and tracking jobs.
          </div>
        </div>

        <!-- Reconnect Action Button -->
        <button type="button" id="reconnect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>Reconnect Talvyn</span>
        </button>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Need help?</span>
        <button type="button" id="open-dash-footer-btn" style="
          background:none;border:none;padding:0;font-size:10px;color:#4f46e5;font-weight:600;cursor:pointer;
        ">Open Dashboard →</button>
      </div>
    </div>
  `,(i=document.getElementById("reconnect-account-btn"))==null||i.addEventListener("click",()=>{w()}),(r=document.getElementById("open-dash-footer-btn"))==null||r.addEventListener("click",()=>{b("dashboard")})}function E(e){var r,n;const t=h(),i=m();v.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${t}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${i}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#fee2e2;
            color:#b91c1c;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#ef4444;display:inline-block;"></span>
            Unable to connect
          </div>
        </div>

        <!-- Error Notice Box -->
        <div style="
          margin-bottom:14px;padding:12px;background:#fef2f2;
          border:1px solid #fee2e2;border-radius:10px;font-size:11.5px;color:#b91c1c;
          display:flex;align-items:flex-start;gap:8px;line-height:1.45;
        ">
          <span style="font-size:14px;">⚠️</span>
          <div>
            <div style="font-weight:700;margin-bottom:2px;">Connection Issue</div>
            ${e}
          </div>
        </div>

        <!-- Retry Button -->
        <button type="button" id="retry-btn" style="
          width:100%;padding:12px 14px;background:#f1f5f9;color:#334155;
          border:1px solid #e2e8f0;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:10px;transition:all 0.15s;
        ">
          <span>Try Again</span>
        </button>

        <button type="button" id="connect-fallback-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <span>Connect Talvyn</span>
        </button>
      </div>

      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;text-align:center;">
        <span style="font-size:10px;color:#64748b;">Ensure your Talvyn backend is running.</span>
      </div>
    </div>
  `,(r=document.getElementById("retry-btn"))==null||r.addEventListener("click",()=>{z()}),(n=document.getElementById("connect-fallback-btn"))==null||n.addEventListener("click",()=>{w()})}function C(e,t={}){var a,p,f,l,o,c,g,x,k;const i=h(),r=m(),n=((a=e.profile)==null?void 0:a.preferredName)||((p=e.profile)==null?void 0:p.givenName)||((f=e.profile)==null?void 0:f.legalFullName)||e.email.split("@")[0],s=(l=e.profile)==null?void 0:l.avatarUrl;v.innerHTML=`
    <div style="padding:16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Top Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <img
              src="${i}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${r}';"
              style="width:30px;height:30px;border-radius:8px;box-shadow:0 2px 4px rgba(99,102,241,0.2);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:13px;color:#0f172a;">Talvyn</div>
              <div style="font-size:10px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:${t.isOffline?"#fef3c7":"#ecfdf5"};
            color:${t.isOffline?"#b45309":"#059669"};font-size:10px;font-weight:700;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:${t.isOffline?"#f59e0b":"#10b981"};display:inline-block;"></span>
            ${t.isOffline?"Offline":"Connected"}
          </div>
        </div>

        <!-- User Identity Card -->
        <div style="
          display:flex;align-items:center;gap:10px;padding:10px 12px;
          background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:12px;
        ">
          ${s?`<img src="${s}" alt="${n}" style="width:34px;height:34px;border-radius:50%;object-fit:cover;border:1px solid #cbd5e1;flex-shrink:0;" />`:`<div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg, #6366f1, #8b5cf6);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex-shrink:0;">${(n[0]||"U").toUpperCase()}</div>`}
          <div style="min-width:0;flex:1;">
            <div style="font-weight:700;font-size:12.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${n}</div>
            <div style="font-size:11px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${e.email}</div>
          </div>
        </div>

        <!-- Primary Action Button: Analyze This Page -->
        <button type="button" id="btn-analyze-page" style="
          width:100%;margin-bottom:12px;padding:11px 14px;background:linear-gradient(135deg, #4f46e5, #6366f1);
          color:white;border:none;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;
          display:flex;align-items:center;justify-content:center;gap:7px;box-shadow:0 2px 6px rgba(79,70,229,0.3);
          transition:opacity 0.15s;
        ">
          <svg style="width:14px;height:14px;" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          <span>Analyze This Page</span>
        </button>

        <!-- 4 Core Navigation Route Buttons: Dashboard, Profile, Tracker, Settings -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
          <button type="button" id="btn-open-dashboard" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Dashboard</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>

          <button type="button" id="btn-open-profile" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Profile</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>

          <button type="button" id="btn-open-tracker" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Tracker</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
          </button>

          <button type="button" id="btn-open-settings" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Settings</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>
        </div>

        <!-- Recent Saved Jobs Section -->
        <div>
          <div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">
            Recent Saved Jobs
          </div>
          <div id="recent-jobs" style="min-height:60px;">
            <div style="font-size:11px;color:#94a3b8;text-align:center;padding:12px 0;">Loading jobs...</div>
          </div>
        </div>
      </div>

      <!-- Footer / Disconnect Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <button type="button" id="disconnect-btn" style="
          background:none;border:none;color:#94a3b8;font-size:11px;cursor:pointer;padding:0;
          font-weight:500;transition:color 0.15s;
        ">
          Disconnect Account
        </button>

        <span style="font-size:10px;color:#cbd5e1;">Talvyn v1.1</span>
      </div>
    </div>
  `;const d=document.getElementById("btn-analyze-page")||document.getElementById("btn-open-floating");d==null||d.addEventListener("click",async()=>{await j()}),(o=document.getElementById("btn-open-dashboard"))==null||o.addEventListener("click",()=>{b("dashboard")}),(c=document.getElementById("btn-open-profile"))==null||c.addEventListener("click",()=>{b("profile")}),(g=document.getElementById("btn-open-tracker"))==null||g.addEventListener("click",()=>{b("tracker")}),(x=document.getElementById("btn-open-settings"))==null||x.addEventListener("click",()=>{b("settings")}),(k=document.getElementById("disconnect-btn"))==null||k.addEventListener("click",async()=>{confirm("Disconnect extension from your Talvyn account?")&&await N()}),S()}async function S(){const e=document.getElementById("recent-jobs");if(e)try{const t=await I.getJobs();if(!t||t.length===0){e.innerHTML=`
        <div style="padding:10px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;text-align:center;">
          <div style="font-size:11px;color:#64748b;margin-bottom:2px;">No jobs saved yet</div>
          <div style="font-size:10px;color:#94a3b8;">Browse any job board to capture listings with 1 click.</div>
        </div>
      `;return}const i=t.slice(0,3);e.innerHTML=i.map(r=>`
        <div style="
          display:flex;align-items:center;justify-content:space-between;
          padding:6px 10px;background:#f8fafc;border:1px solid #f1f5f9;border-radius:8px;margin-bottom:4px;
        ">
          <div style="min-width:0;flex:1;">
            <div style="font-weight:600;font-size:11.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${r.title}
            </div>
            <div style="font-size:10.5px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${r.company}
            </div>
          </div>
          <span style="
            font-size:9.5px;padding:2px 6px;border-radius:999px;font-weight:600;text-transform:capitalize;
            background:${r.status==="APPLIED"?"#e0f2fe":"#f1f5f9"};
            color:${r.status==="APPLIED"?"#0369a1":"#475569"};
          ">
            ${r.status.toLowerCase()}
          </span>
        </div>
      `).join("")}catch{e.innerHTML=`
      <div style="font-size:11px;color:#94a3b8;text-align:center;padding:10px 0;">
        Saved jobs will appear here
      </div>
    `}}z().catch(console.error);
