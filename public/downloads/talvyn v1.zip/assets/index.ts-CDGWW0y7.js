import{a as it,C as ce,d as Fe,i as K,o as Mt,e as $t,f as Dt,h as It,j as Jt}from"./apiClient-CDeLsrBN.js";import{j as Ce}from"./jobsService-BuEU-K8d.js";const Bt=[{domain:"youtube.com"},{domain:"youtu.be"},{domain:"google.com",allowedSubdomains:["careers.google.com"]},{domain:"facebook.com",allowedSubdomains:["metacareers.com"]},{domain:"instagram.com"},{domain:"twitter.com"},{domain:"x.com"},{domain:"reddit.com"},{domain:"wikipedia.org"},{domain:"amazon.com",allowedSubdomains:["amazon.jobs"]},{domain:"netflix.com",allowedSubdomains:["jobs.netflix.com"]},{domain:"nytimes.com"},{domain:"cnn.com"},{domain:"bbc.com"},{domain:"medium.com"},{domain:"substack.com"},{domain:"twitch.tv"},{domain:"vimeo.com"},{domain:"tiktok.com"},{domain:"quora.com"}];function re(s){var e;try{const t=new URL(s),i=t.hostname.toLowerCase().replace(/^www\./,""),n=t.pathname.toLowerCase();for(const a of Bt)if(i===a.domain||i.endsWith(`.${a.domain}`))return!((e=a.allowedSubdomains)!=null&&e.some(l=>i===l||i.endsWith(`.${l}`))||a.domain==="google.com"&&n.startsWith("/about/careers"));return!1}catch{return!1}}const Le=/\b(engineer|developer|designer|analyst|scientist|manager|executive|intern|internship|trainee|architect|consultant|specialist|coordinator|lead|director|recruiter|associate|accountant|marketing|sales|product|software|data|cloud|devops|full[ -]?stack|front[ -]?end|back[ -]?end|mobile|qa|tester|security|ai|ml|administrator|technician|officer|representative|expert|writer|editor|strategist|assistant|operator|fellow|advisor|counsel|counselor|supervisor|head|vp|president|founder|staff|principal|chief)\b/i,Vt=[/\/jobs?\/\d+/i,/\/jobs?\/[a-zA-Z0-9_-]+-[a-zA-Z0-9_-]+/i,/\/careers?\/[a-zA-Z0-9_-]+/i,/\/positions?\/[a-zA-Z0-9_-]+/i,/\/openings?\/[a-zA-Z0-9_-]+/i,/\/vacancies?\/[a-zA-Z0-9_-]+/i,/\/opportunities?\/[a-zA-Z0-9_-]+/i,/\/viewjob/i,/linkedin\.com\/jobs/i,/indeed\.com\/(viewjob|rc\/clk|jobs)/i,/unstop\.com\/(job|jobs|internships)/i,/glassdoor\.com\/job-listing/i,/boards\.greenhouse\.io/i,/jobs\.lever\.co/i,/jobs\.ashbyhq\.com/i,/myworkdayjobs\.com/i,/smartrecruiters\.com/i,/workable\.com/i];function Wt(s){var t;const e=((t=s.querySelectorAll)==null?void 0:t.call(s,'script[type="application/ld+json"]'))||[];for(const i of Array.from(e))try{const n=JSON.parse(i.textContent||"{}"),a=Array.isArray(n)?n:[n],l=[];for(const c of a)(c==null?void 0:c["@type"])==="JobPosting"&&l.push(c),Array.isArray(c==null?void 0:c["@graph"])&&l.push(...c["@graph"].filter(o=>(o==null?void 0:o["@type"])==="JobPosting"));const r=l.find(c=>typeof(c==null?void 0:c.title)=="string"&&c.title.trim().length>=3);if(r)return{valid:!0,title:r.title.trim()}}catch{}return{valid:!1}}function Gt(s,e){var M,C,j,z,_,$,I,P,W,F,D,U,J,q,B,O,se,ne,V,Z;const t=[],i=[];let n=0;if(re(e))return{score:0,isConfidentJob:!1,signals:t,disqualifiers:["Known non-job platform"],rejectionReason:"Page is on a known non-job domain."};(M=s.querySelector)!=null&&M.call(s,"ytd-watch-flexy, ytd-search, #movie_player, video.html5-main-video, .vjs-tech")&&(i.push("Contains primary video player / stream elements"),n-=50),(C=s.querySelector)!=null&&C.call(s,"#rso, #search, .g .rc, div[data-sokoban-container]")&&(i.push("Contains search engine SERP elements"),n-=50),(j=s.querySelector)!=null&&j.call(s,'#add-to-cart-button, [name="submit.add-to-cart"], button[class*="add-to-cart" i], [class*="product-price" i]')&&(i.push("Contains e-commerce shopping cart elements"),n-=50),(z=s.querySelector)!=null&&z.call(s,'[data-testid="tweet"], [data-testid="primaryColumn"], article[role="article"] button[aria-label*="Like" i]')&&(i.push("Contains social media feed elements"),n-=40),(_=s.querySelector)!=null&&_.call(s,'.article-body, article.article, .byline, [rel="author"]')&&!(($=s.querySelector)!=null&&$.call(s,'button[class*="apply" i], a[class*="apply" i], [data-automation-id="applyButton"]'))&&(i.push("Identified as news or editorial article"),n-=40);const a=(()=>{try{return new URL(e)}catch{return null}})();a&&(a.pathname==="/"||a.pathname==="")&&!((I=s.querySelector)!=null&&I.call(s,'[class*="job" i], [data-automation-id*="job" i], script[type="application/ld+json"]'))&&(i.push("Generic root homepage without job postings"),n-=30);const l=Wt(s);l.valid&&(n+=80,t.push(`Schema.org JobPosting found with title: "${l.title}"`));const r=(P=s.querySelector)==null?void 0:P.call(s,'h1, [class*="job-title" i], [class*="jobTitle" i], [class*="posting-header" i], [data-automation-id="jobPostingHeader"], [class*="app-title" i]'),c=((F=(W=s.querySelector)==null?void 0:W.call(s,'meta[property="og:title"]'))==null?void 0:F.content)||"",o=((D=r==null?void 0:r.textContent)==null?void 0:D.trim())||c,d=(U=s.querySelector)==null?void 0:U.call(s,'[class*="company" i], [class*="employer" i], [class*="org" i], [data-automation-id="companyName"]'),p=((q=(J=s.querySelector)==null?void 0:J.call(s,'meta[property="og:site_name"]'))==null?void 0:q.content)||"",f=((B=d==null?void 0:d.textContent)==null?void 0:B.trim())||p,u=!!(o&&o.length>=3&&o.length<=140&&!/^(home|careers|jobs|search|about|login|sign in)$/i.test(o))&&!!(f&&f.length>=2);u&&(n+=25,t.push(`Valid job title and company detected: "${o}" / "${f}"`));const m=((O=s.body)==null?void 0:O.textContent)||"",y=Array.from(((se=s.querySelectorAll)==null?void 0:se.call(s,'a, button, input[type="submit"], input[type="button"], [role="button"], [data-automation-id="applyButton"]'))||[]),h=/^(apply(\s+now|\s+online|\s+for\s+this\s+job|\s+here)?|submit\s+application|easy\s+apply|start\s+application|application\s+form|apply\s+with\s+talvyn)$/i,x=y.some(N=>{var R,we;return h.test(((R=N.textContent)==null?void 0:R.trim())||((we=N.value)==null?void 0:we.trim())||"")||N.getAttribute("data-automation-id")==="applyButton"})||!!((ne=s.querySelector)!=null&&ne.call(s,'button[class*="apply" i], a[class*="apply" i], button[class*="register" i], a[class*="register" i], form[id*="application" i], form[id*="apply" i], form[action*="apply" i], [data-automation-id="applyButton"], .apply-button, .apply-btn'))||/\b(apply\s+now|apply\s+online|submit\s+application)\b/i.test(m);x&&(n+=20,t.push("Apply control found"));const g=Array.from(((V=s.querySelectorAll)==null?void 0:V.call(s,'h1, h2, h3, h4, h5, [class*="heading" i], [class*="title" i], strong'))||[]),b=g.some(N=>{var R;return/qualifications|requirements|eligibility|what you('ll| will) need|who you are|required skills|minimum qualifications/i.test(((R=N.textContent)==null?void 0:R.trim())||"")})||/\b(qualifications|requirements|eligibility|what you('ll| will) need|who you are|required skills|minimum qualifications)\b/i.test(m);b&&(n+=15,t.push("Requirements/Qualifications section found"));const v=g.some(N=>{var R;return/responsibilities|what you('ll| will) do|duties|role overview|key responsibilities|about the (role|position|job)|primary duties/i.test(((R=N.textContent)==null?void 0:R.trim())||"")})||/\b(responsibilities|what you('ll| will) do|key responsibilities|about the (role|position|job)|primary duties)\b/i.test(m);v&&(n+=15,t.push("Responsibilities section found"));const w=/\b(\d+\+?\s*years?(\s+(of\s+)?experience|\s+exp)?|\d+\s*-\s*\d+\s*years?(\s+(of\s+)?experience|\s+exp)?|fresher|freshers|entry[ -]level|bachelor'?s|master'?s|b\.?tech|b\.?e\.)\b/i.test(m),T=/\b(full[ -]time|part[ -]time|internship|contract|temporary|permanent|remote|hybrid|on-site)\b/i.test(m),S=/([$€£₹]\s*[\d,]+|\b\d+\s*-\s*\d+\s*(lpa|k|usd|eur|gbp|inr)\b|\bper\s+(year|annum|month|hour)\b|\b(salary|stipend|compensation)\b)/i.test(m),L=!!((Z=s.querySelector)!=null&&Z.call(s,'[class*="location" i], [data-automation-id*="location" i], [itemprop="addressLocality"]'))||/\b(remote|work from home|hybrid|office location)\b/i.test(m);w&&(n+=10,t.push("Experience requirement mentioned")),T&&(n+=10,t.push("Employment type detected")),S&&(n+=10,t.push("Salary/stipend detected")),L&&(n+=10,t.push("Location detected")),Vt.some(N=>N.test(e))&&(n+=10,t.push("Verified career/ATS URL pattern"));const A=[l.valid,u,x,b,v,w,T,S,L].filter(Boolean).length,E=i.length===0&&n>=50&&(l.valid||A>=2);return{score:n,isConfidentJob:E,signals:t,disqualifiers:i,rejectionReason:E?void 0:i.join("; ")||"Insufficient verified job signals."}}function fe(s,e){return!re(e)&&Gt(s,e).isConfidentJob}function nt(s){var b,v,w,T,S,L,A,E,M,C,j,z,_,$,I,P,W,F,D,U,J;const e=((b=s.textContent)==null?void 0:b.replace(/\s+/g," ").trim())||"";if(e.length<15)return{isValid:!1,signals:[],reason:"Card content too brief"};if(/\b\d+(\.\d+)?[KM]?\s+views\b|\b(subscribers?|playlist|episodes?|season\s+\d+)\b/i.test(e)||(v=s.querySelector)!=null&&v.call(s,"ytd-thumbnail, ytd-video-renderer, #video-title"))return{isValid:!1,signals:[],reason:"Video/media indicators"};if(/\b(add to cart|buy now|in stock|free delivery)\b/i.test(e)||(w=s.querySelector)!=null&&w.call(s,'[class*="add-to-cart" i]'))return{isValid:!1,signals:[],reason:"E-commerce indicators"};if(/\b(hackathons?|competitions?|quizzes?|coding\s+challenge|workshops?|webinars?|festivals?|conferences?)\b/i.test(e)&&!/\b(jobs?|internships?|hiring|recruitment|trainee|developer|engineer|analyst|executive|consultant)\b/i.test(e))return{isValid:!1,signals:[],reason:"Competition/event card"};if(/\b(sponsored|advertisement|promoted)\b/i.test(e)||(T=s.querySelector)!=null&&T.call(s,'[class*="sponsored" i], [class*="ad-" i], [data-ad]'))return{isValid:!1,signals:[],reason:"Advertisement"};const t=(S=s.querySelector)==null?void 0:S.call(s,'h1, h2, h3, h4, h5, [class*="job-title" i], [class*="jobTitle" i], [class*="title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="role" i], [class*="position" i], [class*="heading" i], [class*="name" i], a[class*="job" i], [data-testid*="title" i], [data-automation-id*="title" i], strong, b'),i=(t==null?void 0:t.tagName)==="A"?t:(L=s.querySelector)==null?void 0:L.call(s,"a");let n=((A=t==null?void 0:t.textContent)==null?void 0:A.replace(/\s+/g," ").trim())||((E=i==null?void 0:i.textContent)==null?void 0:E.replace(/\s+/g," ").trim())||"";if(!n||/^(home|about|careers|jobs|login|sign in|privacy|terms|menu|search|share|watch|video|playlist|trending|apply|apply now|save|bookmark|filters|details|view all)$/i.test(n)){const q=Array.from(((M=s.querySelectorAll)==null?void 0:M.call(s,"a"))||[]);for(const B of q){const O=((C=B.textContent)==null?void 0:C.replace(/\s+/g," ").trim())||"";if(O.length>=3&&O.length<=140&&Le.test(O)){n=O;break}}}if(!n||n.length<3||n.length>140||/^(home|about|careers|jobs|login|sign in|privacy|terms|menu|search|share|watch|video|playlist|trending|apply|apply now|save|bookmark|filters|details|view all)$/i.test(n))return{isValid:!1,signals:[],reason:"No valid job title"};const a=(j=s.querySelector)==null?void 0:j.call(s,'[class*="company" i], [class*="employer" i], [class*="organization" i], [class*="organisation" i], [class*="org" i], [class*="hiring" i], [class*="recruiter" i], [class*="sub-title" i], [class*="subtitle" i], [class*="c-name" i], [class*="brand" i], [data-automation-id*="company" i]'),l=((z=a==null?void 0:a.textContent)==null?void 0:z.replace(/\s+/g," ").trim())||"",r=[],c=!!((_=s.querySelector)!=null&&_.call(s,'[class*="location" i], [class*="city" i], [class*="place" i], [class*="region" i]'))||/\b(remote|hybrid|on[ -]?site|in[ -]?office|work from home|bengaluru|bangalore|hyderabad|pune|mumbai|delhi|gurgaon|gurugram|noida|chennai|kolkata|london|new york|san francisco|singapore|berlin|toronto|austin|seattle|dublin|chicago|boston)\b/i.test(e),o=/\b(\d+\+?\s*years?(\s+(of\s+)?exp(erience)?)?|\d+\s*-\s*\d+\s*years?|fresher|freshers|entry[ -]level|mid[ -]level|senior|lead|years?\s+exp)\b/i.test(e),d=!!(($=s.querySelector)!=null&&$.call(s,'[class*="salary" i], [class*="stipend" i], [class*="pay" i], [class*="ctc" i], [class*="wage" i], [class*="compensation" i]'))||/([$€£₹]\s*[\d,]+|\b\d+(\.\d+)?\s*-\s*\d+(\.\d+)?\s*(lpa|k|lac|lakh|cr)\b|\b\d+(\.\d+)?\s*(lpa|lac|lakh|k)\b|\bper\s+(month|year|annum|hr|hour)\b|\b\d+k\s*-\s*\d+k\b)/i.test(e),p=/\b(full[ -]?time|part[ -]?time|contract|internship|intern|campus\s+ambassador|freelance|permanent|temporary|trainee)\b/i.test(e),f=(i==null?void 0:i.href)||((P=(I=s.querySelector)==null?void 0:I.call(s,"a"))==null?void 0:P.href)||"",u=/\/jobs?(\/|\?|#|$)/i.test(f)||/\/careers?(\/|\?|#|$)/i.test(f)||/\/positions?(\/|\?|#|$)/i.test(f)||/\/openings?(\/|\?|#|$)/i.test(f)||/\/opportunities?(\/|\?|#|$)/i.test(f)||/\/apply/i.test(f)||/viewjob/i.test(f)||/boards\.greenhouse\.io|jobs\.lever\.co|myworkdayjobs\.com|ashbyhq\.com/i.test(f)||((W=s.hasAttribute)==null?void 0:W.call(s,"data-job-id"))||((F=s.hasAttribute)==null?void 0:F.call(s,"data-id"))||((D=s.hasAttribute)==null?void 0:D.call(s,"data-item-id"))||/selectedItem=|oppstatus=|jobId=/i.test(f),m=!!((U=s.querySelector)!=null&&U.call(s,'[class*="snippet" i], [class*="summary" i], [class*="description" i]'))||/\b(responsibilities|qualifications|skills|requirements|eligibility|apply\s+by)\b/i.test(e),y=/\b(bachelor'?s|master'?s|b\.?tech|b\.?e\.?|m\.?tech|degree|phd|diploma)\b/i.test(e),h=!!((J=s.querySelector)!=null&&J.call(s,'button[class*="apply" i], a[class*="apply" i], button[class*="register" i], a[class*="register" i]'))||/\b(apply|easy apply|apply now|register now|quick apply|view details)\b/i.test(e);c&&r.push("location"),o&&r.push("experience"),d&&r.push("salary"),p&&r.push("jobType"),u&&r.push("jobLink"),m&&r.push("jobSnippet"),y&&r.push("education"),h&&r.push("applyAction");const x=l.length>=2;return x&&r.length>=1||!x&&r.length>=2&&(u||p||d||o||c||h)||Le.test(n)&&r.length>=1?{isValid:!0,title:n,company:l||"Unknown Company",signals:r}:{isValid:!1,title:n,company:l,signals:r,reason:`Insufficient job evidence (${r.length} signals)`}}function _e(s,e){var c,o,d,p,f,u;if(re(e))return!1;const t=((c=s.querySelectorAll)==null?void 0:c.call(s,'script[type="application/ld+json"]'))||[];for(const m of Array.from(t))try{const y=JSON.parse(m.textContent||"{}"),h=Array.isArray(y)?y:[y];for(const x of h)if((x==null?void 0:x["@type"])==="ItemList"&&Array.isArray(x.itemListElement)&&x.itemListElement.filter(b=>{var v;return((v=(b==null?void 0:b.item)||b)==null?void 0:v["@type"])==="JobPosting"}).length>=1)return!0}catch{}const i=[],n=['[class*="job-card" i]','[class*="jobCard" i]','[class*="job_card" i]','[class*="job-listing" i]','[class*="job-item" i]','[class*="job_item" i]',"[data-job-id]",'[data-testid*="job" i]','[data-automation-id*="job" i]','[data-automation-id*="composite" i]','article[class*="job" i]','li[class*="job" i]','.card[class*="job" i]','[class*="opportunity_card" i]','[class*="opp-card" i]','[class*="opp_card" i]','[class*="c-card" i]','[class*="listing_card" i]',".single_opportunity",'[class*="opportunity" i]','[class*="opening" i]','[class*="vacancy" i]','[class*="position" i]',".job_seen_beacon",".resultContent",'div[class*="cardOutline"]'];for(const m of n)for(const y of Array.from(((o=s.querySelectorAll)==null?void 0:o.call(s,m))||[])){const h=y;h.children&&h.children.length>25&&((d=h.querySelectorAll)==null?void 0:d.call(h,'[class*="opportunity" i]').length)>1||i.push(h)}const a=Array.from(((p=s.querySelectorAll)==null?void 0:p.call(s,"a[href]"))||[]);for(const m of a){const y=m.href||"",h=((f=m.textContent)==null?void 0:f.replace(/\s+/g," ").trim())||"",x=/\/jobs?(\/|\?|#|$)/i.test(y)||/\/careers?(\/|\?|#|$)/i.test(y)||/\/positions?(\/|\?|#|$)/i.test(y)||/\/openings?(\/|\?|#|$)/i.test(y)||/\/opportunities?(\/|\?|#|$)/i.test(y)||/\/apply(?:\/|\?|$)/i.test(y)||/viewjob|boards\.greenhouse\.io|jobs\.lever\.co|myworkdayjobs\.com|ashbyhq\.com|selectedItem=|oppstatus=/i.test(y),g=!!(h&&h.length>=3&&h.length<=140&&Le.test(h));if(x||g){let b=m.parentElement,v=0;for(;b&&v<5;){const w=((u=b.textContent)==null?void 0:u.replace(/\s+/g," ").trim())||"";if(w.length>=25&&w.length<=1800){i.push(b);break}b=b.parentElement,v++}}}const l=Array.from(new Set(i));let r=0;for(const m of l)if(nt(m).isValid&&(r++,r>=1))return!0;return!1}class qt{constructor(){this.name="Generic"}canHandle(){return!0}isJobDetailPage(e,t){return re(e)?!1:fe(t,e)}isJobListingPage(e,t){return re(e)?!1:_e(t,e)}extractJobList(e){var d,p,f;const t=typeof window<"u"?window.location.href:"";if(re(t))return[];const i=[],n=new Set,a=new Set,l=u=>{const m=u.title.toLowerCase().trim().replace(/[^a-z0-9]/g,""),y=u.company.toLowerCase().trim().replace(/[^a-z0-9]/g,""),h=`${m}|${y}`;if(a.has(h))return!0;if(a.add(h),u.jobUrl&&u.jobUrl!==t){if(n.has(u.jobUrl))return!0;n.add(u.jobUrl)}return!1},r=u=>{u&&u.title&&!l(u)&&i.push(u)};for(const u of this.extractFromJsonLd(e))r(u);const c=['[class*="job-card" i]','[class*="jobCard" i]','[class*="job_card" i]','[class*="job-listing" i]','[class*="job-item" i]','[class*="job_item" i]','[class*="job-result" i]',"[data-job-id]",'[data-testid*="job" i]','[data-automation-id*="job" i]','[data-automation-id*="composite" i]','article[class*="job" i]','li[class*="job" i]','div[class*="opening" i]','div[class*="posting" i]','div[class*="vacancy" i]','div[class*="position" i]','div[class*="career" i]','div[class*="role" i]','.card[class*="job" i]','tr[class*="job" i]',"tr.job",".resultContent",".job-search-card",".base-card",'[class*="opportunity_card" i]','[class*="opp-card" i]','[class*="opp_card" i]','[class*="c-card" i]','[class*="listing_card" i]',".single_opportunity",'[class*="opportunity" i]'];for(const u of c)for(const m of Array.from(e.querySelectorAll(u))){const y=m;y.children&&y.children.length>25&&((d=y.querySelectorAll)==null?void 0:d.call(y,'[class*="opportunity" i]').length)>1||nt(y).isValid&&r(this.extractCardData(y))}const o=Array.from(e.querySelectorAll("a[href]"));for(const u of o){const m=u.href||"",y=((p=u.textContent)==null?void 0:p.replace(/\s+/g," ").trim())||"";if(y.length<3||y.length>140)continue;const h=/\/jobs?(\/|\?|#|$)/i.test(m)||/\/careers?(\/|\?|#|$)/i.test(m)||/\/positions?(\/|\?|#|$)/i.test(m)||/\/openings?(\/|\?|#|$)/i.test(m)||/\/opportunities?(\/|\?|#|$)/i.test(m)||/\/apply(?:\/|\?|$)/i.test(m)||/viewjob|greenhouse\.io|lever\.co|ashbyhq\.com|myworkdayjobs\.com|selectedItem=|oppstatus=/i.test(m),x=Le.test(y);if(!h&&!x)continue;let g=u.parentElement;for(let b=0;g&&b<5;b++,g=g.parentElement){const v=((f=g.textContent)==null?void 0:f.replace(/\s+/g," ").trim())||"";if(v.length>=20&&v.length<=1800&&nt(g).isValid){r(this.extractCardData(g,u));break}}}return i}extractSingleJob(e){var f,u,m,y,h,x,g,b,v,w,T,S,L,A;const t=typeof window<"u"?window.location.href:"";if(t&&re(t))return null;const i=this.extractFromJsonLd(e);if(i.length===1&&i[0].title){const E=i[0];if(!E.description){const M=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main');M&&(E.description=(f=M.textContent)==null?void 0:f.replace(/\s+/g," ").trim().slice(0,3e3))}return E}const n=e.querySelector('h1, [class*="job-title" i], [class*="app-title" i]');let a=((u=n==null?void 0:n.textContent)==null?void 0:u.trim())||"";if((!a||a.length<3||a.length>150)&&(a=((m=e.querySelector('meta[property="og:title"], meta[name="title"]'))==null?void 0:m.content)||""),!a||a.length<3||a.length>150)return null;const l=((h=(y=e.querySelector('[class*="company-name" i], [class*="companyName" i], [class*="employer-name" i], [class*="employer" i], [class*="org-name" i], [class*="company" i], [class*="org" i]'))==null?void 0:y.textContent)==null?void 0:h.trim())||((g=(x=e.querySelector('meta[property="og:site_name"]'))==null?void 0:x.content)==null?void 0:g.trim())||"Unknown Company",r=(v=(b=e.querySelector('[class*="location" i], [class*="city" i], [class*="workplace" i], [itemprop="addressLocality"]'))==null?void 0:b.textContent)==null?void 0:v.trim(),c=(T=(w=e.querySelector('[class*="salary" i], [class*="compensation" i], [class*="stipend" i], [class*="pay" i]'))==null?void 0:w.textContent)==null?void 0:T.trim(),o=(L=(S=e.querySelector('[class*="job-type" i], [class*="employment-type" i], [class*="work-type" i]'))==null?void 0:S.textContent)==null?void 0:L.trim(),d=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main'),p=(A=d==null?void 0:d.textContent)==null?void 0:A.replace(/\s+/g," ").trim().slice(0,3e3);return{title:a,company:l,location:r,salary:c,jobType:o,description:p,jobUrl:t,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}extractFromJsonLd(e){const t=[],i=e.querySelectorAll?e.querySelectorAll('script[type="application/ld+json"]'):[];for(const n of Array.from(i))try{const a=JSON.parse(n.textContent||"{}"),l=Array.isArray(a)?a:[a];for(const r of l)if(r["@type"]==="ItemList"&&Array.isArray(r.itemListElement))for(const c of r.itemListElement){const o=c.item||c;(o["@type"]==="JobPosting"||o.title)&&t.push(this.formatJsonLdJob(o))}else r["@type"]==="JobPosting"&&t.push(this.formatJsonLdJob(r))}catch{}return t}formatJsonLdJob(e){var t,i,n,a,l,r,c,o,d,p,f;return{title:e.title||e.name||"Untitled Position",company:((t=e.hiringOrganization)==null?void 0:t.name)||e.employerOverview||"Unknown Company",location:typeof e.jobLocation=="string"?e.jobLocation:((n=(i=e.jobLocation)==null?void 0:i.address)==null?void 0:n.addressLocality)||((l=(a=e.jobLocation)==null?void 0:a.address)==null?void 0:l.addressRegion),salary:((c=(r=e.baseSalary)==null?void 0:r.value)==null?void 0:c.value)||((d=(o=e.baseSalary)==null?void 0:o.value)!=null&&d.minValue&&((f=(p=e.baseSalary)==null?void 0:p.value)!=null&&f.maxValue)?`${e.baseSalary.value.minValue}–${e.baseSalary.value.maxValue} ${e.baseSalary.value.unitText||""}`:void 0),jobType:e.employmentType,jobUrl:e.url||(typeof window<"u"?window.location.href:""),sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"HIGH"}}extractCardData(e,t){var u,m,y,h,x,g,b,v,w,T,S,L,A,E,M;const i=e.querySelector('h1, h2, h3, h4, h5, [class*="job-title" i], [class*="jobTitle" i], [class*="title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="role" i], [class*="position" i], [class*="heading" i], a[class*="job" i]')||t,n=(i==null?void 0:i.tagName)==="A"?i:t||e.querySelector("a");let a=((u=i==null?void 0:i.textContent)==null?void 0:u.replace(/\s+/g," ").trim())||((m=n==null?void 0:n.textContent)==null?void 0:m.replace(/\s+/g," ").trim())||"";if(!a||/^(home|about|careers|jobs|login|sign in|privacy|terms|menu|search|share|watch|video|playlist|trending|apply|apply now|save|bookmark|filters|details|view all)$/i.test(a)){const C=Array.from(((y=e.querySelectorAll)==null?void 0:y.call(e,"a"))||[]);for(const j of C){const z=((h=j.textContent)==null?void 0:h.replace(/\s+/g," ").trim())||"";if(z.length>=3&&z.length<=140&&Le.test(z)){a=z;break}}}if(!a||a.length<3||a.length>150)return null;const l=((x=e.textContent)==null?void 0:x.replace(/\s+/g," ").trim())||"",r=((b=(g=e.querySelector('[class*="company" i], [class*="employer" i], [class*="organisation" i], [class*="organization" i], [class*="org" i], [class*="sub-title" i], [class*="subtitle" i], [class*="c-name" i], [class*="brand" i], [class*="recruiter" i]'))==null?void 0:g.textContent)==null?void 0:b.replace(/\s+/g," ").trim())||"Unknown Company";let c=(w=(v=e.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="region" i]'))==null?void 0:v.textContent)==null?void 0:w.replace(/\s+/g," ").trim();if(!c){const C=l.match(/\b(remote|hybrid|on[ -]?site|in[ -]?office|work from home|bengaluru|bangalore|hyderabad|pune|mumbai|delhi|gurgaon|gurugram|noida|chennai|kolkata|london|new york|san francisco|singapore|berlin|toronto|austin|seattle|dublin|chicago|boston)\b/i);C&&(c=C[0])}let o=(S=(T=e.querySelector('[class*="salary" i], [class*="stipend" i], [class*="compensation" i], [class*="pay" i], [class*="wage" i], [class*="ctc" i]'))==null?void 0:T.textContent)==null?void 0:S.replace(/\s+/g," ").trim();if(!o){const C=l.match(/([$€£₹]\s*[\d,]+|\b\d+(\.\d+)?\s*-\s*\d+(\.\d+)?\s*(lpa|k|lac|lakh|cr)\b|\b\d+(\.\d+)?\s*(lpa|lac|lakh|k)\b|\bper\s+(month|year|annum|hr|hour)\b|\b\d+k\s*-\s*\d+k\b)/i);C&&(o=C[0])}let d=(A=(L=e.querySelector('[class*="job-type" i], [class*="employment" i], [class*="work-type" i], [class*="timing" i]'))==null?void 0:L.textContent)==null?void 0:A.replace(/\s+/g," ").trim();if(!d){const C=l.match(/\b(full[ -]?time|part[ -]?time|contract|internship|intern|campus\s+ambassador|freelance|permanent|temporary|trainee)\b/i);C&&(d=C[0])}const p=(M=(E=e.querySelector('[class*="snippet" i], [class*="description" i], [class*="summary" i], p'))==null?void 0:E.textContent)==null?void 0:M.replace(/\s+/g," ").trim().slice(0,1e3);let f=(n==null?void 0:n.href)||"";return(!f||typeof window<"u"&&f===window.location.href||f==="#"||f.startsWith("javascript:"))&&(f=`${typeof window<"u"&&window.location.origin?window.location.origin:"https://careers.company.com"}/jobs/${encodeURIComponent(a)}-${encodeURIComponent(r)}`),{title:a,company:r,location:c,salary:o,jobType:d,description:p,jobUrl:f,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}}class Yt{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isJobDetailPage(e,t){return/\/jobs\/view\//i.test(e)||/\/jobs\/collections\//i.test(e)||!!t.querySelector(".job-details-jobs-unified-top-card__job-title")}isJobListingPage(e,t){return this.isJobDetailPage(e,t)?!1:/\/jobs\/search/i.test(e)||/\/jobs\/collections/i.test(e)||t.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card").length>=2}extractJobList(e){var a,l,r;const t=[],i=new Set,n=Array.from(e.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card, div[data-job-id]"));for(const c of n){const o=c.querySelector(".job-card-list__title, .base-search-card__title, .job-card-container__link, h3"),d=c.querySelector("a"),p=c.querySelector(".job-card-container__primary-description, .base-search-card__subtitle, .job-card-container__company-name"),f=c.querySelector(".job-card-container__metadata-item, .job-search-card__location, .job-card-container__metadata-wrapper"),u=(a=o==null?void 0:o.textContent)==null?void 0:a.trim(),m=(d==null?void 0:d.href)||(typeof window<"u"?window.location.href:"");u&&u.length>2&&!i.has(m)&&(i.add(m),t.push({title:u,company:((l=p==null?void 0:p.textContent)==null?void 0:l.trim())||"LinkedIn Poster",location:(r=f==null?void 0:f.textContent)==null?void 0:r.trim(),jobUrl:m,sourceWebsite:"LinkedIn",confidence:"HIGH"}))}return t}extractSingleJob(e){var l,r,c,o,d,p,f,u;const t=(r=(l=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:l.textContent)==null?void 0:r.trim();if(!t)return null;const i=((o=(c=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:c.textContent)==null?void 0:o.trim())||"LinkedIn Poster",n=(p=(d=e.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(u=(f=e.querySelector(".jobs-description__content, #job-details"))==null?void 0:f.textContent)==null?void 0:u.trim();return{title:t,company:i,location:n,description:a,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"LinkedIn",confidence:"HIGH"}}}function Qt(s){var e,t,i,n,a;try{const l=s.querySelectorAll('script[type="application/ld+json"]');for(const r of Array.from(l)){const c=r.textContent;if(!c)continue;const o=JSON.parse(c),d=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((i=o==null?void 0:o.author)==null?void 0:i.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(n=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:n.hiringOrganization)==null?void 0:a.name);if(d&&typeof d=="string"&&d.trim().length>0)return d.trim()}}catch{}}class Kt{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isJobDetailPage(e,t){return/\/viewjob/i.test(e)||/\/rc\/clk/i.test(e)||!!t.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')||!!t.querySelector("h1.jobsearch-JobInfoHeader-title")}isJobListingPage(e,t){return this.isJobDetailPage(e,t)?!1:/\/jobs/i.test(e)||t.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]').length>=2}extractJobList(e){var a,l,r,c;const t=[],i=new Set,n=Array.from(e.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]'));for(const o of n){const d=o.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h2.jobTitle, a[data-jk], a[id^="job_"], span[id^="jobTitle"]'),p=(d==null?void 0:d.tagName)==="A"?d:o.querySelector('a[data-jk], a[id^="job_"], a[href*="viewjob" i], a[href*="/rc/clk" i], a'),f=o.querySelector('[data-testid="company-name"], [data-testid="inlineHeader-companyName"], span[data-testid="company-name"], a[data-testid="company-name"], .companyName, .company-name, [class*="companyName"], [class*="company_location"] span, .icl-u-lg-mr--sm'),u=o.querySelector('[data-testid="text-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation, [class*="companyLocation"]'),m=o.querySelector('[data-testid="attribute_snippet_testid"], .salary-snippet-container, [class*="salary-snippet"], #salaryInfoAndJobType'),y=(a=d==null?void 0:d.textContent)==null?void 0:a.trim(),h=(l=f==null?void 0:f.textContent)==null?void 0:l.trim(),x=h&&h.length>0?h:"Unknown Company",b=(p==null?void 0:p.href)||(typeof window<"u"?window.location.href:"")||`https://www.indeed.com/viewjob?key=${encodeURIComponent(y||"")}-${encodeURIComponent(x)}`;y&&y.length>2&&!i.has(b)&&(i.add(b),t.push({title:y,company:x,location:(r=u==null?void 0:u.textContent)==null?void 0:r.trim(),salary:(c=m==null?void 0:m.textContent)==null?void 0:c.trim(),jobUrl:b,sourceWebsite:"Indeed",confidence:"HIGH"}))}return t}extractSingleJob(e){var c,o,d,p,f,u,m,y,h;const t=(o=(c=e.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"], h1'))==null?void 0:c.textContent)==null?void 0:o.trim();if(!t)return null;const i=e.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="inlineHeader-companyName"] span, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, div[data-testid="jobsearch-CompanyInfoContainer"] span, .jobsearch-CompanyInfoContainer, [class*="CompanyInfo" i], .companyName, .icl-u-lg-mr--sm, [class*="companyName"]'),n=((d=i==null?void 0:i.textContent)==null?void 0:d.trim())||Qt(e)||"Unknown Company",a=(f=(p=e.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:p.textContent)==null?void 0:f.trim(),l=(m=(u=e.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:u.textContent)==null?void 0:m.trim(),r=(h=(y=e.querySelector('#jobDescriptionText, [data-testid="jobsearch-JobComponent-description"]'))==null?void 0:y.textContent)==null?void 0:h.trim();return{title:t,company:n,location:a,salary:l,description:r,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Indeed",confidence:"HIGH"}}}class Zt{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isJobDetailPage(e,t){return/\/jobs\/\d+/i.test(e)||!!t.querySelector(".app-title, #app_body, form#application_form")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll(".opening, tr.job, div.level-0").length>=1}extractJobList(e){var l,r,c,o;const t=[],i=new Set,n=((r=(l=e.querySelector(".company-name, #header .logo span, h1"))==null?void 0:l.textContent)==null?void 0:r.trim())||"Greenhouse Employer",a=Array.from(e.querySelectorAll('.opening, tr.job, div[class*="opening"]'));for(const d of a){const p=d.querySelector("a"),f=(c=p==null?void 0:p.textContent)==null?void 0:c.trim(),u=d.querySelector(".location"),m=(p==null?void 0:p.href)||(typeof window<"u"?window.location.href:"");f&&f.length>2&&!i.has(m)&&(i.add(m),t.push({title:f,company:n,location:(o=u==null?void 0:u.textContent)==null?void 0:o.trim(),jobUrl:m,sourceWebsite:"Greenhouse",confidence:"HIGH"}))}return t}extractSingleJob(e){var l,r,c,o,d,p,f,u;const t=(r=(l=e.querySelector(".app-title, h1.heading"))==null?void 0:l.textContent)==null?void 0:r.trim();if(!t)return null;const i=((o=(c=e.querySelector(".company-name, .logo span"))==null?void 0:c.textContent)==null?void 0:o.trim())||"Greenhouse Employer",n=(p=(d=e.querySelector(".location"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(u=(f=e.querySelector("#content"))==null?void 0:f.textContent)==null?void 0:u.trim();return{title:t,company:i,location:n,description:a,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Greenhouse",confidence:"HIGH"}}}class Xt{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isJobDetailPage(e,t){return/\/jobs\.lever\.co\/[^/]+\/[a-zA-Z0-9_-]{10,}/i.test(e)||/\/apply\/?$/i.test(e)||!!t.querySelector(".posting-header h2, .application-page")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll('.posting, div[data-qa="posting-category"]').length>=1}extractJobList(e){var l,r,c,o,d,p,f;const t=[],i=new Set,n=((l=e.querySelector(".main-header-logo img"))==null?void 0:l.getAttribute("alt"))||((c=(r=e.querySelector(".posting-headline .sort-by-team"))==null?void 0:r.textContent)==null?void 0:c.trim())||"Lever Employer",a=Array.from(e.querySelectorAll(".posting"));for(const u of a){const m=u.querySelector(".posting-title, a.posting-btn-submit, a"),y=u.querySelector('h5[data-qa="posting-name"], .posting-title h5, h5'),h=u.querySelector(".sort-by-location, .posting-categories .location"),x=u.querySelector(".sort-by-commitment, .posting-categories .commitment"),g=((o=y==null?void 0:y.textContent)==null?void 0:o.trim())||((d=m==null?void 0:m.textContent)==null?void 0:d.trim()),b=(m==null?void 0:m.href)||(typeof window<"u"?window.location.href:"");g&&g.length>2&&!i.has(b)&&(i.add(b),t.push({title:g,company:n,location:(p=h==null?void 0:h.textContent)==null?void 0:p.trim(),jobType:(f=x==null?void 0:x.textContent)==null?void 0:f.trim(),jobUrl:b,sourceWebsite:"Lever",confidence:"HIGH"}))}return t}extractSingleJob(e){var r,c,o,d,p,f,u,m,y;const t=(c=(r=e.querySelector(".posting-headline h2"))==null?void 0:r.textContent)==null?void 0:c.trim();if(!t)return null;const i=((o=e.querySelector(".main-header-logo img"))==null?void 0:o.getAttribute("alt"))||"Lever Employer",n=(p=(d=e.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(u=(f=e.querySelector(".commitment, .posting-categories .sort-by-commitment"))==null?void 0:f.textContent)==null?void 0:u.trim(),l=(y=(m=e.querySelector(".section-wrapper, .posting-page"))==null?void 0:m.textContent)==null?void 0:y.trim();return{title:t,company:i,location:n,jobType:a,description:l,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Lever",confidence:"HIGH"}}}class ei{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const a=new URL(e,"https://jobs.ashbyhq.com").pathname.split("/").filter(Boolean).length>=2,l=!!t.querySelector('form, [data-ashby-job-posting], [class*="applicationForm" i]'),r=!!t.querySelector('h1, [class*="jobTitle" i], [class*="heading" i]');return a&&r||l}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]').length>=2:!1}extractJobList(e){var l,r;const t=[],i=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",n=this.extractCompanyFromUrl(i)||"Company",a=Array.from(e.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]'));for(const c of a){const o=c.tagName==="A"?c:c.querySelector("a"),d=c.querySelector('h2, h3, h4, [class*="title" i], strong')||o,p=c.querySelector('[class*="location" i], [class*="metadata" i]'),f=(l=d==null?void 0:d.textContent)==null?void 0:l.trim(),u=(o==null?void 0:o.href)||i,m=(r=p==null?void 0:p.textContent)==null?void 0:r.trim();f&&f.length>2&&t.push({title:f,company:n,jobUrl:u,sourceWebsite:"Ashby",location:m||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var f,u,m,y,h;const t=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",i=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'),n=(f=i==null?void 0:i.textContent)==null?void 0:f.trim();if(!n)return null;const a=this.extractCompanyFromUrl(t)||((u=e.querySelector('[class*="company" i], header img'))==null?void 0:u.getAttribute("alt"))||"Company",l=e.querySelector('[class*="location" i], [data-testid="job-location"]'),r=((m=l==null?void 0:l.textContent)==null?void 0:m.trim())||void 0,c=e.querySelector('[class*="compensation" i], [class*="salary" i]'),o=((y=c==null?void 0:c.textContent)==null?void 0:y.trim())||void 0,d=e.querySelector('[class*="description" i], [class*="jobBody" i], main'),p=((h=d==null?void 0:d.textContent)==null?void 0:h.trim())||void 0;return{title:n,company:a,jobUrl:t,sourceWebsite:"Ashby",location:r,salary:o,description:p,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const i=new URL(e).pathname.split("/").filter(Boolean);if(i.length>0)return i[0].replace(/[-_]/g," ")}catch{}return null}}class ti{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const i=!!t.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),n=!!t.querySelector('a[href*="/apply"], button[data-qa="apply-button"], .st-apply'),a=/\/jobs\/[a-zA-Z0-9_-]+/i.test(e);return i&&n||a}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('.opening-job, .job-item, li.opening, a[href*="smartrecruiters.com/"][href*="/"]').length>=2:!1}extractJobList(e){var l,r,c,o;const t=[],i=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",n=((r=(l=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:l.textContent)==null?void 0:r.trim())||"Company",a=Array.from(e.querySelectorAll('.opening-job, .job-item, li.opening, [class*="job-item" i]'));for(const d of a){const p=d.querySelector("a"),f=d.querySelector('h3, h4, .job-title, [data-qa="job-title"]')||p,u=d.querySelector('.job-location, .location, [data-qa="job-location"]'),m=(c=f==null?void 0:f.textContent)==null?void 0:c.trim(),y=(p==null?void 0:p.href)||i,h=(o=u==null?void 0:u.textContent)==null?void 0:o.trim();m&&m.length>2&&t.push({title:m,company:n,jobUrl:y,sourceWebsite:"SmartRecruiters",location:h||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var p,f,u,m;const t=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",i=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),n=(p=i==null?void 0:i.textContent)==null?void 0:p.trim();if(!n)return null;const a=e.querySelector('.company-name, [data-qa="company-name"], .job-header .company'),l=((f=a==null?void 0:a.textContent)==null?void 0:f.trim())||this.extractCompanyFromUrl(t)||"Company",r=e.querySelector('.job-location, [data-qa="job-location"], .spl-location'),c=((u=r==null?void 0:r.textContent)==null?void 0:u.trim())||void 0,o=e.querySelector(".job-sections, #job-details, .job-detail"),d=((m=o==null?void 0:o.textContent)==null?void 0:m.trim())||void 0;return{title:n,company:l,jobUrl:t,sourceWebsite:"SmartRecruiters",location:c,description:d,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const i=new URL(e).pathname.split("/").filter(Boolean);if(i.length>0&&i[0]!=="jobs")return i[0].replace(/[-_]/g," ")}catch{}return null}}class ii{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}isJobDetailPage(e,t){return this.canHandle(e)?/\/job\/[^/?#]+/i.test(e)||!!t.querySelector('[data-automation-id="jobPostingHeader"], [data-automation-id="jobPostingDescription"]'):!1}isJobListingPage(e,t){return!this.canHandle(e)||this.isJobDetailPage(e,t)?!1:t.querySelectorAll('[data-automation-id="compositeHeader"], [data-automation-id="jobCard"], li[class*="css-"], a[href*="/job/"]').length>=1}extractJobList(e){var r,c,o,d,p,f,u;const t=[],i=new Set,n=typeof window<"u"?window.location.href:"https://company.myworkdayjobs.com",a=((r=e.querySelector('meta[property="og:site_name"]'))==null?void 0:r.content)||((o=(c=e.querySelector('[data-automation-id="companyName"]'))==null?void 0:c.textContent)==null?void 0:o.trim())||"Workday Employer",l=Array.from(e.querySelectorAll('[data-automation-id="compositeHeader"], [data-automation-id="jobCard"], li[class*="css-"], div[data-automation-id="jobPostingHeader"]'));for(const m of l){const y=m.tagName==="A"?m:m.querySelector("a"),h=m.querySelector('[data-automation-id="jobPostingHeader"], h3, h4, a')||y,x=m.querySelector('[data-automation-id="locations"], [data-automation-id="jobLocation"]'),g=m.querySelector('[data-automation-id="timeType"]'),b=(d=h==null?void 0:h.textContent)==null?void 0:d.trim(),v=(y==null?void 0:y.href)||n;b&&b.length>2&&!i.has(v)&&(i.add(v),t.push({title:b,company:a,location:(p=x==null?void 0:x.textContent)==null?void 0:p.trim(),jobType:(f=g==null?void 0:g.textContent)==null?void 0:f.trim(),jobUrl:v,sourceWebsite:"Workday",confidence:"HIGH"}))}if(t.length===0){const m=Array.from(e.querySelectorAll('a[href*="/job/"]'));for(const y of m){const h=(u=y.textContent)==null?void 0:u.trim(),x=y.href||n;h&&h.length>3&&!i.has(x)&&(i.add(x),t.push({title:h,company:a,jobUrl:x,sourceWebsite:"Workday",confidence:"HIGH"}))}}return t}extractSingleJob(e){var r,c,o,d,p,f,u,m,y,h,x;const t=(c=(r=e.querySelector('[data-automation-id="jobPostingHeader"], h2[data-automation-id="jobPostingHeader"], h1'))==null?void 0:r.textContent)==null?void 0:c.trim();if(!t)return null;const i=((o=e.querySelector('meta[property="og:site_name"]'))==null?void 0:o.content)||((p=(d=e.querySelector('[data-automation-id="companyName"]'))==null?void 0:d.textContent)==null?void 0:p.trim())||"Workday Employer",n=(u=(f=e.querySelector('[data-automation-id="locations"], [data-automation-id="jobLocation"]'))==null?void 0:f.textContent)==null?void 0:u.trim(),a=(y=(m=e.querySelector('[data-automation-id="timeType"]'))==null?void 0:m.textContent)==null?void 0:y.trim(),l=(x=(h=e.querySelector('[data-automation-id="jobPostingDescription"]'))==null?void 0:h.textContent)==null?void 0:x.trim();return{title:t,company:i,location:n,jobType:a,description:l,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Workday",confidence:"HIGH"}}}function yt(s){try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const i of t)e.searchParams.delete(i);return e.toString()}catch{return s}}function ni(s){var e,t,i,n,a;try{const l=s.querySelectorAll('script[type="application/ld+json"]');for(const r of Array.from(l)){const c=r.textContent;if(!c)continue;const o=JSON.parse(c),d=(o==null?void 0:o["@type"])==="JobPosting"?o:Array.isArray(o==null?void 0:o["@graph"])?o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"):o;if(d){const p=((e=d==null?void 0:d.hiringOrganization)==null?void 0:e.name)||((t=d==null?void 0:d.hiringOrganization)==null?void 0:t.legalName)||((i=d==null?void 0:d.author)==null?void 0:i.name),f=((n=d==null?void 0:d.jobLocation)==null?void 0:n.address)||(d==null?void 0:d.jobLocation);let u="";typeof f=="string"?u=f:f&&(u=[f.addressLocality,f.addressRegion,f.addressCountry].filter(Boolean).join(", "));let m="";const y=((a=d==null?void 0:d.baseSalary)==null?void 0:a.value)||(d==null?void 0:d.baseSalary);return y&&(typeof y=="string"||typeof y=="number"?m=String(y):y.minValue&&y.maxValue?m=`${y.minValue} - ${y.maxValue} ${y.unitText||""}`.trim():y.value&&(m=String(y.value))),{company:p==null?void 0:p.trim(),location:(u==null?void 0:u.trim())||void 0,salary:(m==null?void 0:m.trim())||void 0,description:(d==null?void 0:d.description)||void 0,title:(d==null?void 0:d.title)||void 0}}}}catch{}return{}}class ai{constructor(){this.name="Unstop"}canHandle(e){return e.includes("unstop.com")}isJobDetailPage(e,t){var o,d,p,f;const i=e.toLowerCase(),n=((d=(o=t==null?void 0:t.querySelectorAll)==null?void 0:o.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], [class*="opportunity" i], .single_opportunity'))==null?void 0:d.length)||0;if(n>=2)return!1;const a=/\/(job|jobs)\/?(\?.*)?$/i.test(i)||/\/jobs?\/search/i.test(i)||/\/internships\/?(\?.*)?$/i.test(i)||i.includes("selecteditem=")||i.includes("oppstatus=")||i.includes("opportunity=");if(a&&n>=1)return!1;const l=/\/jobs\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/internships\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/competitions\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/hackathons\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/workshops\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/conferences\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/quizzes\/[a-zA-Z0-9_-]+-\d+/i.test(i)||/\/p\/[a-zA-Z0-9_-]+/i.test(i)||/\/(jobs|internships|competitions)\/[a-zA-Z0-9_-]{4,}/i.test(i)&&!/\/(jobs|internships|competitions)\/(search|all|\?|$)/i.test(i),r=!!((p=t==null?void 0:t.querySelector)!=null&&p.call(t,'h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i]')),c=!!((f=t==null?void 0:t.querySelector)!=null&&f.call(t,'button[class*="apply" i], a[class*="apply" i], button[class*="register" i], a[class*="register" i]'));return l&&!a?!0:!!(r&&c&&!a)}isJobListingPage(e,t){var l,r;const i=e.toLowerCase(),n=/\/(job|jobs)\/?(\?.*)?$/i.test(i)||/\/jobs?\/search/i.test(i)||/\/internships\/?(\?.*)?$/i.test(i)||/\/internships\/search/i.test(i)||/\/competitions\/?(\?.*)?$/i.test(i)||/\/all-opportunities/i.test(i)||i.includes("opportunity=")||i.includes("oppstatus=")||i.includes("selecteditem="),a=((r=(l=t==null?void 0:t.querySelectorAll)==null?void 0:l.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], [class*="opportunity" i], .single_opportunity'))==null?void 0:r.length)||0;return n||a>=2?!0:(this.isJobDetailPage(e,t),!1)}extractJobList(e){var l,r,c,o,d,p,f,u;const t=[],i=new Set,n=Array.from(e.querySelectorAll('[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], .single_opportunity, [class*="opportunity" i]'));let a=0;for(const m of n){if(a++,m.children.length>25&&m.querySelectorAll('[class*="opportunity" i]').length>1)continue;const y=m.querySelector('h2, h3, h4, h5, h1, [class*="title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="heading" i], a'),h=(y==null?void 0:y.tagName)==="A"?y:m.querySelector("a"),x=m.querySelector('[class*="company" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub-title" i], [class*="subtitle" i], [class*="brand" i]'),g=m.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="meta_item" i], [aria-label*="location" i]'),b=m.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="pay" i], [class*="compensation" i]'),v=m.querySelector('[class*="job-type" i], [class*="opp-type" i], [class*="timing" i], [class*="type" i]'),T=(((l=y==null?void 0:y.textContent)==null?void 0:l.trim())||"").replace(/\s+/g," ").trim(),S=(r=x==null?void 0:x.textContent)==null?void 0:r.trim(),L=S&&S.length>0?S:"Unknown Company",A=((c=m.getAttribute)==null?void 0:c.call(m,"data-id"))||((o=m.getAttribute)==null?void 0:o.call(m,"data-item-id"))||((d=m.getAttribute)==null?void 0:d.call(m,"id"));let E=(h==null?void 0:h.href)||(A?`https://unstop.com/jobs/${A}`:"");(!E||typeof window<"u"&&E===window.location.href||E==="#"||E.startsWith("javascript:"))&&(E=`https://unstop.com/jobs/${encodeURIComponent(T||"")}-${encodeURIComponent(L||"")}-${a}`);const M=yt(E);let C=((p=g==null?void 0:g.textContent)==null?void 0:p.trim())||void 0;C&&(C.includes("Bengaluru")||C.includes("Bangalore"))&&(C=C.replace(/\s+/g," ").trim());const j=`${T.toLowerCase()}|${L.toLowerCase()}`;T&&T.length>2&&!i.has(j)&&!i.has(M)&&(i.add(j),i.add(M),t.push({title:T,company:L,location:C,salary:((f=b==null?void 0:b.textContent)==null?void 0:f.trim())||void 0,jobType:((u=v==null?void 0:v.textContent)==null?void 0:u.trim())||void 0,jobUrl:M,sourceWebsite:"Unstop",confidence:"HIGH"}))}return t}extractSingleJob(e){var x,g,b,v,w,T,S,L,A;const t=ni(e),i=e.querySelector('h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="header" i] h1, [class*="main_title" i]'),n=((x=i==null?void 0:i.textContent)==null?void 0:x.trim())||t.title;if(!n||n.length<2)return null;const a=e.querySelector('[class*="company_name" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub_title" i], [class*="sub-title" i], [class*="org" i], [class*="employer" i], [class*="brand" i], h2'),l=((g=a==null?void 0:a.textContent)==null?void 0:g.trim())||t.company||"Unknown Company",r=e.querySelector('[class*="location" i], [class*="place" i], [class*="city" i], [class*="job_location" i], [aria-label*="location" i], .job_details_item_location, .other_details .location');let c=((b=r==null?void 0:r.textContent)==null?void 0:b.trim())||t.location;if(!c){const E=Array.from(e.querySelectorAll('[class*="chip" i], [class*="badge" i], [class*="meta" i], [class*="detail" i]'));for(const M of E){const C=((v=M.textContent)==null?void 0:v.trim())||"";if(/\b(Bangalore|Bengaluru|Hyderabad|Pune|Mumbai|Delhi|Gurgaon|Gurugram|Noida|Chennai|Kolkata|Remote|Work from home|Hybrid)\b/i.test(C)&&C.length<50){c=C;break}}}c&&(c=c.replace(/\s+/g," ").trim());const o=e.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="compensation" i], [class*="pay" i]'),d=((w=o==null?void 0:o.textContent)==null?void 0:w.trim())||t.salary||void 0,p=e.querySelector('[class*="job-type" i], [class*="job_type" i], [class*="opp_type" i], [class*="opp-type" i], [class*="timing" i], [class*="work_type" i]'),f=((T=p==null?void 0:p.textContent)==null?void 0:T.trim())||void 0,u=e.querySelector('#description, [class*="description" i], [class*="details" i], [class*="about" i], [class*="eligibility" i], [class*="overview" i]'),m=((L=(S=u==null?void 0:u.textContent)==null?void 0:S.trim())==null?void 0:L.slice(0,2e3))||((A=t.description)==null?void 0:A.slice(0,2e3))||void 0,y=typeof window<"u"?window.location.href:"",h=yt(y);return console.log(`[Talvyn] UNSSTOP_JOB_EXTRACTED: ${n} at ${l} (URL: ${h}, Location: ${c||"N/A"})`),{title:n,company:l,location:c,salary:d,jobType:f,description:m,jobUrl:h,sourceWebsite:"Unstop",confidence:"HIGH"}}}class si{constructor(){this.adapters=[],this.genericAdapter=new qt,this.adapters=[new Yt,new Kt,new ai,new Zt,new Xt,new ei,new ti,new ii]}getAdapter(e,t){for(const i of this.adapters)if(i.canHandle(e,t))return i;return this.genericAdapter}}const Je=new si,oi={intern:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"intern"},internship:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"internship"},trainee:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"trainee"},apprentice:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"apprentice"},fellow:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"fellow"},junior:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"junior"},"jr.":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr."},jr:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr"},"entry level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry level"},"entry-level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry-level"},associate:{level:"ENTRY",yearsMin:0,yearsMax:3,matchedTerm:"associate"},graduate:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"graduate"},level1:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level 1":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level i"}," i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"i"},mid:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid"},"mid-level":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid-level"},intermediate:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"intermediate"},level2:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level 2":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level ii"}," ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"ii"},senior:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"senior"},"sr.":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr."},sr:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr"},level3:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level 3":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level iii"}," iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"iii"},experienced:{level:"SENIOR",yearsMin:4,yearsMax:8,matchedTerm:"experienced"},lead:{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"lead"},"team lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"team lead"},"tech lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"tech lead"},principal:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"principal"},staff:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"staff"},distinguished:{level:"STAFF_PLUS",yearsMin:12,matchedTerm:"distinguished"},fellow2:{level:"STAFF_PLUS",yearsMin:15,matchedTerm:"fellow"},"executive director":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"executive director"},"vice president":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vice president"},vp:{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vp"},director:{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"director"},"head of":{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"head of"},chief:{level:"DIRECTOR_PLUS",yearsMin:12,matchedTerm:"chief"}},ri=["senior","sr.","sr","junior","jr.","jr","entry-level","entry level","lead","principal","staff","intern","internship","trainee","apprentice","graduate","experienced","mid-level","level 1","level 2","level 3","level i","level ii","level iii"],li=[/\b(urgent|urgently hiring|immediate hiring|hiring now|we're hiring|apply now|remote|hybrid|onsite|on-site|full-time|part-time|contract|temporary|wfh|work from home|multiple openings|100% remote)\b/gi,/\b(\[.*?\]|\(.*?\))\b/g,/\s+[-–|•#]\s+.*$/g,/[^\w\s/]/g,/\//g,/\s+/g],ci=[{canonical:"data analyst",domain:"Data",synonyms:["analytics associate","reporting analyst","bi analyst","business intelligence analyst","data analytics specialist","product analyst","operations data analyst","sql data analyst","insights analyst","metrics analyst"],broaderRelated:["data scientist","business analyst","data engineer","analytics engineer","quantitative analyst"]},{canonical:"data scientist",domain:"Data",synonyms:["machine learning scientist","applied scientist","ai scientist","decision scientist","ml researcher","statistical modeler","data science specialist"],broaderRelated:["data analyst","machine learning engineer","ai engineer","quantitative researcher","statistician"]},{canonical:"data engineer",domain:"Data",synonyms:["big data engineer","etl developer","data platform engineer","data warehouse engineer","analytics engineer","data pipeline engineer","sql developer"],broaderRelated:["data analyst","data scientist","backend engineer","database administrator","cloud data architect"]},{canonical:"machine learning engineer",domain:"Data",synonyms:["ml engineer","ai engineer","mlops engineer","deep learning engineer","nlp engineer","computer vision engineer","ai developer"],broaderRelated:["data scientist","data engineer","software engineer","backend engineer"]},{canonical:"business intelligence analyst",domain:"Data",synonyms:["bi analyst","bi developer","power bi developer","tableau developer","bi specialist","reporting specialist"],broaderRelated:["data analyst","business analyst","data engineer"]},{canonical:"software engineer",domain:"Software",synonyms:["software developer","programmer","application developer","systems developer","software architect","sde","swe"],broaderRelated:["fullstack developer","frontend developer","backend developer","devops engineer","mobile developer"]},{canonical:"frontend developer",domain:"Software",synonyms:["frontend engineer","front end developer","front-end engineer","ui developer","ui engineer","web developer","react developer","javascript developer","client side engineer"],broaderRelated:["software engineer","fullstack developer","ui designer","product designer"]},{canonical:"backend developer",domain:"Software",synonyms:["backend engineer","back end developer","back-end engineer","server side developer","api developer","node developer","python developer","java developer","golang developer"],broaderRelated:["software engineer","fullstack developer","data engineer","devops engineer","cloud engineer"]},{canonical:"fullstack developer",domain:"Software",synonyms:["fullstack engineer","full stack developer","full-stack engineer","web application engineer"],broaderRelated:["software engineer","frontend developer","backend developer","mobile developer"]},{canonical:"mobile developer",domain:"Software",synonyms:["mobile engineer","ios developer","android developer","ios engineer","android engineer","flutter developer","react native developer","mobile app developer"],broaderRelated:["software engineer","frontend developer"]},{canonical:"devops engineer",domain:"Software",synonyms:["site reliability engineer","sre","cloud engineer","platform engineer","infrastructure engineer","cloud architect","systems engineer","sysadmin"],broaderRelated:["backend developer","software engineer","security engineer","network engineer"]},{canonical:"qa engineer",domain:"Software",synonyms:["quality assurance engineer","sdet","software development engineer in test","automation test engineer","test engineer","qa automation engineer","tester"],broaderRelated:["software engineer","devops engineer"]},{canonical:"cybersecurity analyst",domain:"Security",synonyms:["security analyst","information security analyst","infosec engineer","security engineer","soc analyst","penetration tester","threat analyst"],broaderRelated:["devops engineer","systems engineer","network engineer"]},{canonical:"product manager",domain:"Product",synonyms:["technical product manager","tpm","associate product manager","apm","group product manager","product lead","product owner","digital product manager"],broaderRelated:["project manager","program manager","business analyst","scrum master","product marketing manager"]},{canonical:"project manager",domain:"Project Management",synonyms:["technical project manager","it project manager","scrum master","agile coach","delivery manager","project coordinator","pmo analyst"],broaderRelated:["program manager","product manager","operations manager"]},{canonical:"program manager",domain:"Project Management",synonyms:["technical program manager","tpm","strategic program manager","transformation manager"],broaderRelated:["project manager","product manager","operations director"]},{canonical:"business analyst",domain:"Business",synonyms:["business systems analyst","it business analyst","requirements analyst","functional analyst","strategy analyst","process analyst"],broaderRelated:["product manager","data analyst","project manager","operations analyst"]},{canonical:"product designer",domain:"Design",synonyms:["ux designer","ui designer","ui ux designer","ui/ux designer","user experience designer","interaction designer","digital designer","experience designer"],broaderRelated:["ux researcher","visual designer","graphic designer","frontend developer","design system engineer"]},{canonical:"ux researcher",domain:"Design",synonyms:["user researcher","design researcher","user experience researcher","usability analyst","cx researcher"],broaderRelated:["product designer","data analyst","product manager"]},{canonical:"graphic designer",domain:"Design",synonyms:["visual designer","brand designer","creative designer","marketing designer","illustrator","motion designer"],broaderRelated:["product designer","content creator","art director"]},{canonical:"digital marketer",domain:"Marketing",synonyms:["marketing specialist","growth marketer","performance marketer","online marketing specialist","demand generation specialist","paid media specialist","sem specialist","media buyer"],broaderRelated:["content marketer","seo specialist","social media manager","product marketing manager","brand manager"]},{canonical:"product marketing manager",domain:"Marketing",synonyms:["pmm","product marketer","go-to-market specialist","gtm manager","solution marketing manager"],broaderRelated:["product manager","digital marketer","content marketer","brand manager"]},{canonical:"content marketer",domain:"Marketing",synonyms:["content strategist","copywriter","content writer","technical writer","editorial specialist","blog writer","communications specialist"],broaderRelated:["social media manager","seo specialist","digital marketer","pr specialist"]},{canonical:"seo specialist",domain:"Marketing",synonyms:["seo manager","search engine optimization analyst","organic growth specialist","seo strategist"],broaderRelated:["content marketer","digital marketer","web analyst"]},{canonical:"social media manager",domain:"Marketing",synonyms:["community manager","social media strategist","social media specialist","influencer marketing manager"],broaderRelated:["content marketer","digital marketer","brand manager"]},{canonical:"recruiter",domain:"HR",synonyms:["technical recruiter","talent acquisition specialist","talent acquisition partner","headhunter","talent sourcer","recruiting specialist","staffing consultant"],broaderRelated:["hr generalist","hr business partner","people operations specialist"]},{canonical:"hr generalist",domain:"HR",synonyms:["hr specialist","human resources coordinator","people operations specialist","hr officer","human resources manager","hr administrator"],broaderRelated:["recruiter","hr business partner","compensation analyst","payroll specialist"]},{canonical:"hr business partner",domain:"HR",synonyms:["hrbp","people partner","strategic hr partner","senior hr consultant"],broaderRelated:["hr generalist","recruiter","operations manager"]},{canonical:"financial analyst",domain:"Finance",synonyms:["fpa analyst","fp&a analyst","finance associate","investment analyst","budget analyst","financial planning analyst","commercial finance analyst","treasury analyst"],broaderRelated:["accountant","business analyst","risk analyst","data analyst","portfolio manager"]},{canonical:"accountant",domain:"Finance",synonyms:["staff accountant","senior accountant","certified public accountant","cpa","bookkeeper","tax accountant","audit associate","financial accountant","cost accountant"],broaderRelated:["financial analyst","controller","finance manager"]},{canonical:"controller",domain:"Finance",synonyms:["financial controller","comptroller","accounting director","head of finance"],broaderRelated:["accountant","financial analyst","cfo"]},{canonical:"account executive",domain:"Sales",synonyms:["ae","sales executive","enterprise account executive","sales representative","commercial sales representative","sales manager","closing rep"],broaderRelated:["sales development representative","business development manager","account manager","partnerships manager"]},{canonical:"sales development representative",domain:"Sales",synonyms:["sdr","bdr","business development representative","inside sales representative","outbound sales specialist","lead generation specialist"],broaderRelated:["account executive","business development manager","sales specialist"]},{canonical:"account manager",domain:"Sales",synonyms:["client manager","key account manager","client relationship manager","strategic account manager","client partner"],broaderRelated:["customer success manager","account executive","customer support specialist"]},{canonical:"business development manager",domain:"Sales",synonyms:["bdm","partnerships manager","strategic partnerships lead","alliance manager","channel sales manager"],broaderRelated:["account executive","sales development representative","product manager"]},{canonical:"customer success manager",domain:"Customer Success",synonyms:["csm","client success specialist","customer success specialist","client relationship specialist","customer onboarding specialist","implementation consultant"],broaderRelated:["account manager","customer support specialist","project manager","sales engineer"]},{canonical:"customer support specialist",domain:"Customer Support",synonyms:["support engineer","technical support specialist","help desk analyst","customer service representative","client support specialist","service desk analyst"],broaderRelated:["customer success manager","operations specialist","qa engineer"]},{canonical:"operations manager",domain:"Operations",synonyms:["business operations manager","bizops manager","operations lead","chief of staff","general manager","operations supervisor"],broaderRelated:["project manager","program manager","supply chain analyst","business analyst"]},{canonical:"supply chain analyst",domain:"Operations",synonyms:["logistics analyst","procurement specialist","inventory analyst","demand planning analyst","operations analyst"],broaderRelated:["operations manager","data analyst","financial analyst"]}];function ht(s){if(!s)return{raw:"",normalized:"",seniority:{level:"UNSPECIFIED",yearsMin:0},tokens:[]};let e=s.toLowerCase().trim(),t={level:"UNSPECIFIED",yearsMin:0};for(const[n,a]of Object.entries(oi))if(new RegExp(`\\b${gt(n)}\\b`,"i").test(e)){t=a;break}for(const n of li)e=e.replace(n," ");for(const n of ri){const a=new RegExp(`\\b${gt(n)}\\b`,"gi");e=e.replace(a," ")}e=e.replace(/\s+/g," ").trim();const i=e.split(" ").filter(n=>n.length>1);return{raw:s,normalized:e,seniority:t,tokens:i}}function gt(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function di(s,e){const t=s.normalized,i=e.normalized;if(t===i||s.raw.toLowerCase().trim()===e.raw.toLowerCase().trim())return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:1,reason:`Exact match for preferred role "${e.raw}"`};if(t.length>2&&i.length>2&&(t.includes(i)||i.includes(t)))return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:.95,reason:`Direct title match for preferred role "${e.raw}"`};const n=bt(i),a=bt(t);for(const c of n){if(c.canonical===t)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${c.domain}`};const o=c.synonyms.find(p=>p===t||t.includes(p)||p.includes(t));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`};const d=c.broaderRelated.find(p=>p===t||t.includes(p)||p.includes(t));if(d)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.6,reason:`Related career path (${d}) for "${e.raw}"`}}for(const c of a){if(c.canonical===i)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${c.domain}`};const o=c.synonyms.find(d=>d===i||i.includes(d)||d.includes(i));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`}}const l=new Set(s.tokens),r=new Set(e.tokens);if(l.size>0&&r.size>0){let c=0;for(const p of r)l.has(p)&&c++;const o=c/r.size,d=c/(l.size+r.size-c);if(o>=.75)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.75,reason:`Key skill/role tokens match "${e.raw}"`};if(o>=.5||d>=.4)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.55,reason:`Partial keyword overlap with preferred role "${e.raw}"`};if(c>=1&&(l.size<=3||r.size<=3))return{preferredRole:e.raw,jobTitle:s.raw,level:"WEAK_MATCH",score:.3,reason:`Minor keyword match with "${e.raw}"`}}return{preferredRole:e.raw,jobTitle:s.raw,level:"NO_MATCH",score:0,reason:`Role does not match "${e.raw}"`}}function bt(s){if(!s||s.length<3)return[];const e=[];for(const t of ci)(t.canonical===s||Be(t.canonical,s)||t.synonyms.some(i=>i===s||Be(i,s))||t.broaderRelated.some(i=>i===s||Be(i,s)))&&e.push(t);return e}function Be(s,e){if(s===e)return!0;const t=new RegExp(`\\b${xt(s)}\\b`,"i"),i=new RegExp(`\\b${xt(e)}\\b`,"i");return t.test(e)||i.test(s)}function xt(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function jt(s,e,t=.45){const i=ht(s);if(!e||e.length===0)return{level:"RELATED",score:.5,weight:t,weightedScore:.5*t*100,reason:"No preferred roles specified in profile",rawTitle:s,normalizedTitle:i.normalized};let n={preferredRole:e[0],level:"NO_MATCH",score:0,reason:"Role did not match your preferred roles"};for(const a of e){const l=ht(a),r=di(i,l);if(r.score>n.score&&(n=r),n.score===1)break}return{level:n.level,matchedRole:n.preferredRole,score:n.score,weight:t,weightedScore:Math.round(n.score*t*100*10)/10,reason:n.reason,rawTitle:s,normalizedTitle:i.normalized}}const pi={role:.3,experience:.25,education:.2,skills:.2,location:.05},ui={javascript:"JavaScript",typescript:"TypeScript",react:"React","react native":"React Native","node.js":"Node.js",nodejs:"Node.js",node:"Node.js",python:"Python",java:"Java","c++":"C++","c#":"C#",".net":".NET",aws:"AWS","amazon web services":"AWS",docker:"Docker",kubernetes:"Kubernetes",sql:"SQL",mysql:"MySQL",postgresql:"PostgreSQL",postgres:"PostgreSQL",mongodb:"MongoDB",graphql:"GraphQL","rest api":"REST APIs",rest:"REST APIs",git:"Git",github:"GitHub",html:"HTML5",css:"CSS3",tailwind:"Tailwind CSS","next.js":"Next.js",nextjs:"Next.js",vue:"Vue.js",angular:"Angular",django:"Django",fastapi:"FastAPI",flask:"Flask","spring boot":"Spring Boot",spring:"Spring Boot",go:"Golang",golang:"Golang",rust:"Rust",ruby:"Ruby","ruby on rails":"Rails",rails:"Rails",php:"PHP",laravel:"Laravel",flutter:"Flutter",swift:"Swift",kotlin:"Kotlin",figma:"Figma",jira:"Jira",agile:"Agile","ci/cd":"CI/CD",linux:"Linux",azure:"Azure",gcp:"GCP",redis:"Redis",kafka:"Kafka",microservices:"Microservices",devops:"DevOps",pandas:"Pandas",numpy:"NumPy","machine learning":"Machine Learning",ai:"AI",tableau:"Tableau",excel:"Excel",powerbi:"PowerBI","power bi":"PowerBI","financial modeling":"Financial Modeling",budgeting:"Budgeting",prototyping:"Prototyping","user research":"User Research"};function mi(s="",e="",t=""){const i=`${s} ${t} ${e||""}`.toLowerCase(),n=i.match(/\b(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||i.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)?/i);if(n){const c=parseInt(n[1],10),o=parseInt(n[2],10);return{minYears:c,maxYears:o,isFresher:c===0,rawText:`${c}–${o} years`}}const a=i.match(/\b(\d+)\s*\+\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||i.match(/\b(?:min(?:imum)?|at\s+least)\s+(\d+)\s*(?:years?|yrs?)/i)||i.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*\+\s*(?:years?|yrs?)?/i);if(a){const c=parseInt(a[1],10);return{minYears:c,maxYears:null,isFresher:c===0,rawText:`${c}+ years`}}const l=i.match(/\b(\d+)\s*(?:years?|yrs?)(?:\s+of)?\s+experience\b/i)||i.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:years?|yrs?)\b/i);if(l){const c=parseInt(l[1],10);return{minYears:c,maxYears:null,isFresher:c===0,rawText:c===1?"1 year":`${c} years`}}return/\b(fresher|entry[\s-]level|trainee|graduate|intern|internship|campus)\b/i.test(s)||/\b(fresher|entry[\s-]level|0[\s-]*1\s*years?|0[\s-]*0\s*years?)\b/i.test(i)?{minYears:0,maxYears:1,isFresher:!0,rawText:"Fresher / 0–1 years"}:null}function Nt(s,e,t,i,n=.25){const a=mi(s,e||"",t||""),l=i.experienceYears??null,r=l===0||l===null,c=r?"Fresher":`${l} year${l===1?"":"s"}`;if(!a)return{score:.8,weight:n,weightedScore:.8*n*100,reason:"Experience requirements appear standard/flexible",isHardMismatch:!1,requiredText:"Not specified",profileText:c,status:"UNSPECIFIED"};const o=a.rawText;if(r){if(a.isFresher||a.minYears===0)return{score:1,weight:n,weightedScore:n*100,reason:"Fresher / entry-level role matches your profile",isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};const u=a.minYears>=2;return{score:u?.05:.2,weight:n,weightedScore:(u?.05:.2)*n*100,reason:`Experience mismatch: Required: ${o}, Your profile: Fresher`,isHardMismatch:!0,requiredText:o,profileText:c,status:"MISMATCH"}}const d=l;if(a.maxYears!==null&&d>=a.minYears&&d<=a.maxYears)return{score:1,weight:n,weightedScore:n*100,reason:`Your ${d} years experience matches required range (${o})`,isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};if(d>=a.minYears)return{score:1,weight:n,weightedScore:n*100,reason:`Your ${d} yrs experience satisfies requirement (${o})`,isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};const f=a.minYears-d>=2||a.minYears>=2;return{score:f?.1:.35,weight:n,weightedScore:(f?.1:.35)*n*100,reason:`Experience mismatch: Required: ${o}, Your profile: ${c}`,isHardMismatch:f,requiredText:o,profileText:c,status:"MISMATCH"}}function zt(s,e,t,i=.2){const n=`${s} ${e||""}`.toLowerCase(),a=[{key:"b.tech",label:"B.Tech"},{key:"btech",label:"B.Tech"},{key:"b.e.",label:"B.E."},{key:"be ",label:"B.E."},{key:"m.tech",label:"M.Tech"},{key:"mtech",label:"M.Tech"},{key:"mca",label:"MCA"},{key:"bca",label:"BCA"},{key:"b.sc",label:"B.Sc"},{key:"bsc",label:"B.Sc"},{key:"bachelor",label:"Bachelor's"},{key:"master",label:"Master's"},{key:"computer science",label:"Computer Science"},{key:"cs/it",label:"CS/IT"},{key:"information technology",label:"Information Technology"},{key:"engineering",label:"Engineering"},{key:"undergraduate",label:"Undergraduate"},{key:"graduate",label:"Graduate"}],l=[];for(const f of a)n.includes(f.key)&&!l.includes(f.label)&&l.push(f.label);const r=(t.degree||"").toLowerCase(),c=(t.specialization||"").toLowerCase(),o=`${r} ${c}`.trim();if(l.length===0)return{score:.85,weight:i,weightedScore:.85*i*100,reason:"Education: Not specified",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:"Not specified"};const d=l.slice(0,3).join(" / ");return o?l.some(f=>{const u=f.toLowerCase();return o.includes(u)||u.includes("b.tech")&&(o.includes("btech")||o.includes("b.e.")||o.includes("engineering"))||u.includes("b.e.")&&(o.includes("btech")||o.includes("b.tech")||o.includes("engineering"))||u.includes("computer science")&&(o.includes("cs")||o.includes("it")||o.includes("information technology"))||u.includes("bachelor")&&(o.includes("b.tech")||o.includes("b.e.")||o.includes("bca")||o.includes("bsc")||o.includes("bachelor"))})?{score:1,weight:i,weightedScore:i*100,reason:`Education match: ${t.degree||"Degree"} aligns with ${d}`,isHardMismatch:!1,status:"MATCH",requiredText:d}:{score:.15,weight:i,weightedScore:.15*i*100,reason:`Education mismatch: Requires ${d}`,isHardMismatch:!0,status:"MISMATCH",requiredText:d}:{score:.6,weight:i,weightedScore:.6*i*100,reason:"Education not specified in profile",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:d}}function Ot(s,e,t,i=.2){const n=`${s} ${e||""}`.toLowerCase(),a=[];for(const[u,m]of Object.entries(ui))new RegExp(`(?:^|[\\s,.;/()+-])${u.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?:$|[\\s,.;/()+-])`,"i").test(n)&&(a.includes(m)||a.push(m));const l=(t.skills||[]).map(u=>u.trim()),r=l.map(u=>u.toLowerCase()),c=[],o=[];for(const u of a){const m=u.toLowerCase();r.some(h=>h.includes(m)||m.includes(h))?c.includes(u)||c.push(u):o.includes(u)||o.push(u)}if(c.length===0&&l.length>0)for(const u of l)n.includes(u.toLowerCase())&&!c.includes(u)&&c.push(u);if(a.length===0&&c.length===0)return{score:.85,weight:i,weightedScore:.85*i*100,reason:"General technical skill alignment",matchedSkills:l.slice(0,3),missingSkills:[],status:"UNSPECIFIED"};const d=c.length+o.length;let p=.5;d>0?(p=c.length/d,c.length>0&&p<.4&&(p=.4)):c.length>0&&(p=1);const f=c.length>=1;return{score:p,weight:i,weightedScore:p*i*100,reason:f?`Skills match: ${c.slice(0,3).join(", ")}`:`Missing key skills: ${o.slice(0,2).join(", ")}`,matchedSkills:c,missingSkills:o,status:f?"MATCH":"MISMATCH"}}function Ht(s,e,t,i=.05){const n=(s||"").toLowerCase().trim(),a=(e||"").toLowerCase(),l=t.preferredLocations||[],r=t.workStyle||"ANY",c=n.includes("remote")||n.includes("wfh")||n.includes("anywhere")||a.includes("100% remote")||a.includes("fully remote")||a.includes("work from home"),o=n.includes("hybrid")||a.includes("hybrid work")||a.includes("hybrid schedule");if(r==="ANY"&&l.length===0)return{score:1,weight:i,weightedScore:i*100,reason:"Open to all locations and work styles"};if(r==="REMOTE"){if(c)return{score:1,weight:i,weightedScore:i*100,reason:"Remote position aligns with your Remote preference"};if(o)return{score:.5,weight:i,weightedScore:.5*i*100,reason:"Hybrid role (partially remote)"}}if(l.length>0)for(const d of l){const p=d.toLowerCase().trim();if(p){if(p.includes("remote")&&c)return{score:1,weight:i,weightedScore:i*100,reason:'Remote job matches preferred location "Remote"'};if(n&&(n.includes(p)||p.includes(n)))return{score:1,weight:i,weightedScore:i*100,reason:`Location matches preferred location "${d}"`}}}return(r==="HYBRID"||r==="ANY")&&c?{score:.9,weight:i,weightedScore:.9*i*100,reason:"Remote job provides work flexibility"}:n?{score:.2,weight:i,weightedScore:.2*i*100,reason:`Location "${s}" differs from preferred locations`}:{score:.6,weight:i,weightedScore:.6*i*100,reason:"Location not specified in job posting"}}function fi(s,e,t=.05){const i=e.preferredJobTypes||[];if(i.length===0)return{score:1,weight:t,weightedScore:t*100,reason:"Open to all employment types"};if(!s)return{score:.6,weight:t,weightedScore:.6*t*100,reason:"Job type not disclosed in listing"};const n=s.toUpperCase().replace(/[-\s]/g,"_");return i.some(l=>{const r=l.toUpperCase().replace(/[-\s]/g,"_");return n.includes(r)||r.includes(n)})?{score:1,weight:t,weightedScore:t*100,reason:`Employment type (${s}) matches your preference`}:{score:.2,weight:t,weightedScore:.2*t*100,reason:`Job type (${s}) differs from preferred (${i.join(", ")})`}}function yi(s,e,t=.05){return e.expectedSalary?s?{score:.8,weight:t,weightedScore:.8*t*100,reason:`Salary listed as "${s}"`}:{score:.6,weight:t,weightedScore:.6*t*100,reason:"Salary not disclosed in listing"}:{score:.8,weight:t,weightedScore:.8*t*100,reason:"No expected salary specified in profile"}}function hi(s,e,t=pi){const i=jt(s.title,e.preferredRoles,t.role),n=Nt(s.title,s.description,s.jobType,e,t.experience),a=zt(s.title,s.description,e,t.education),l=Ot(s.title,s.description,e,t.skills),r=Ht(s.location,s.description,e,t.location);let c=Math.round(i.weightedScore+n.weightedScore+a.weightedScore+l.weightedScore+r.weightedScore);const o=i.level==="NO_MATCH"||i.score===0,d=n.isHardMismatch||n.status==="MISMATCH",p=a.status==="MISMATCH"&&a.isHardMismatch;let f=Math.min(100,Math.max(0,c)),u,m="";d&&n.isHardMismatch?(f=Math.min(42,Math.max(25,Math.round(c*.46))),u="LOW_RELEVANCE",m="Experience requirement does not match your profile."):o?(f=Math.min(44,Math.max(20,Math.round(c*.42))),u="LOW_RELEVANCE",m="Role does not align with your profile."):p?(f=Math.min(45,Math.max(25,Math.round(c*.45))),u="LOW_RELEVANCE",m="Education requirement differs from your profile."):f>=85?u="EXCELLENT":f>=70?u="HIGHLY_RELEVANT":f>=50?u="RELEVANT":u="LOW_RELEVANCE";const y=[],h=[];i.score>=.6?y.push(i.reason):h.push(i.reason),n.status==="MATCH"?y.push(n.reason):n.status==="MISMATCH"&&h.push(n.reason),a.status==="MATCH"?y.push(a.reason):a.status==="MISMATCH"&&h.push(a.reason),l.status==="MATCH"&&l.matchedSkills.length>0&&y.push(`Skills match: ${l.matchedSkills.slice(0,3).join(", ")}`),l.missingSkills.length>0&&h.push(`Missing skills: ${l.missingSkills.slice(0,2).join(", ")}`),r.score>=.7?y.push(r.reason):r.score<.5&&h.push(r.reason),m&&!h.includes(m)&&h.unshift(m);const x=fi(s.jobType,e,.05),g=yi(s.salary,e,.05);return{job:s,relevanceScore:f,category:u,roleMatch:i,locationMatch:r,experienceMatch:n,educationMatch:a,skillsMatch:l,jobTypeMatch:x,salaryMatch:g,matchedReasons:y,unmatchedReasons:h,matchedSkills:l.matchedSkills,missingSkills:l.missingSkills}}class gi{constructor(){this.scannedJobUrls=new Set,this.cachedAnalyzedJobs=new Map,this.CACHE_TTL_MS=15*60*1e3,this.genericAdapter=new qt}isPlausibleExtractedJob(e,t){const i=(e.title||"").replace(/\s+/g," ").trim(),n=(e.company||"").replace(/\s+/g," ").trim();if(i.length<3||i.length>180||/\b(competition|competitions|hackathon|hackathons|workshop|workshops|webinar|quiz|quizzes|contest|contests|leaderboard|challenge|challenges|register now|sponsored|advertisement|advert|promoted)\b/i.test(i))return!1;const l=[i,e.jobType||"",e.location||"",e.salary||"",e.description||""].join(" "),r=/\b(job|role|position|engineer|developer|designer|analyst|scientist|manager|executive|intern|internship|trainee|architect|consultant|specialist|coordinator|lead|director|recruiter|associate|accountant|marketing|sales|product|software|data|cloud|devops|full[ -]?stack|front[ -]?end|back[ -]?end|mobile|qa|tester|security|ai|ml|administrator|technician|officer|representative|expert|recruit|hiring|full[ -]?time|part[ -]?time|contract|permanent|remote|hybrid|on[ -]?site|years?(\s+(of\s+)?exp(erience)?)?|experience required|salary|stipend|compensation|lpa)\b/i.test(l),c=!!(e.jobUrl&&e.jobUrl!==t),o=!!(e.location||e.salary||e.jobType||e.description||c||n&&n!=="Unknown Company");return r&&o}extractSingleJobUniversal(e,t,i){const n=i.extractSingleJob(t);if(n&&this.isPlausibleExtractedJob(n,e))return n;const a=this.genericAdapter.extractSingleJob(t);return a&&this.isPlausibleExtractedJob(a,e)?a:null}extractJobListUniversal(e,t,i){const n=i.extractJobList(t).filter(c=>this.isPlausibleExtractedJob(c,e)),a=this.genericAdapter.extractJobList(t).filter(c=>this.isPlausibleExtractedJob(c,e)),l=[],r=new Set;for(const c of[...n,...a]){const o=`${c.jobUrl||""}|${c.title.toLowerCase().replace(/[^a-z0-9]/g,"")}|${c.company.toLowerCase().replace(/[^a-z0-9]/g,"")}`;r.has(o)||(r.add(o),l.push(c))}return l}classifyPage(e,t){if(re(e))return{classification:"OTHER",adapterName:"None"};const i=Je.getAdapter(e,t),n=fe(t,e),a=_e(t,e);return/selectedItem=|currentJobId=|oppstatus=|\b(search|results|q=|keywords=)\b/i.test(e)&&a?{classification:"JOB_LIST",adapterName:i.name}:n&&i.isJobDetailPage(e,t)?{classification:"SINGLE_JOB",adapterName:i.name}:a&&i.isJobListingPage(e,t)?{classification:"JOB_LIST",adapterName:i.name}:a?{classification:"JOB_LIST",adapterName:i.name}:i.isJobListingPage(e,t)&&i.extractJobList(t).filter(c=>this.isPlausibleExtractedJob(c,e)).length>0?{classification:"JOB_LIST",adapterName:i.name}:n?{classification:"SINGLE_JOB",adapterName:i.name}:{classification:"OTHER",adapterName:i.name}}scanSingleJob(e,t){if(re(e)||!fe(t,e))return null;const i=Je.getAdapter(e,t);return this.extractSingleJobUniversal(e,t,i)}scanJobListing(e,t,i,n=new Set){if(re(e))return{totalDetected:0,excellentCount:0,highlyRelevantCount:0,relevantCount:0,lowRelevanceCount:0,analyzedJobs:[],pageUrl:e,scannedAt:new Date().toISOString()};const a=Je.getAdapter(e,t),l=this.extractJobListUniversal(e,t,a),r=[],c=Date.now();for(const u of l){const m=u.jobUrl||`${u.title}-${u.company}`,y=this.cachedAnalyzedJobs.get(m);let h;y&&c-y.cachedAt<this.CACHE_TTL_MS?h=y.job:(h=hi(u,i),this.cachedAnalyzedJobs.set(m,{job:h,cachedAt:c}),this.scannedJobUrls.add(m)),h.isSaved=n.has(u.jobUrl),r.push(h)}r.sort((u,m)=>m.relevanceScore-u.relevanceScore);let o=0,d=0,p=0,f=0;for(const u of r)u.category==="EXCELLENT"?o++:u.category==="HIGHLY_RELEVANT"?d++:u.category==="RELEVANT"?p++:f++;return{totalDetected:r.length,excellentCount:o,highlyRelevantCount:d,relevantCount:p,lowRelevanceCount:f,analyzedJobs:r,pageUrl:e,scannedAt:new Date().toISOString()}}clearCache(){this.scannedJobUrls.clear(),this.cachedAnalyzedJobs.clear()}}const oe=new gi,bi=[/\/jobs?\//i,/\/careers?\//i,/\/positions?\//i,/\/openings?\//i,/\/vacancies?\//i,/\/opportunities?\//i,/\/apply/i,/linkedin\.com\/jobs/i,/indeed\.com\/(viewjob|rc\/clk)/i,/glassdoor\.com\/job-listing/i,/lever\.co\//i,/greenhouse\.io\//i,/workable\.com\//i,/myworkdayjobs\.com\//i,/icims\.com\//i,/smartrecruiters\.com\//i,/jobvite\.com\//i,/taleo\.net\//i,/successfactors\.(com|eu)\//i,/boards\.greenhouse\.io\//i,/jobs\.lever\.co\//i],xi=[/apply (for|now)/i,/job (description|details|overview|summary)/i,/about (this|the) (role|position|job)/i,/role (overview|summary|description)/i,/position (overview|summary|details)/i,/what you('ll|'d| will) do/i,/responsibilities/i,/qualifications/i,/requirements/i];function vi(s){try{const e=new URL(s).hostname.replace(/^www\./,""),t={"linkedin.com":"LinkedIn","indeed.com":"Indeed","glassdoor.com":"Glassdoor","lever.co":"Lever","greenhouse.io":"Greenhouse","workable.com":"Workable","myworkdayjobs.com":"Workday","icims.com":"iCIMS","smartrecruiters.com":"SmartRecruiters","jobvite.com":"Jobvite","taleo.net":"Taleo"};for(const[i,n]of Object.entries(t))if(e.includes(i))return n;return e}catch{return window.location.hostname}}function wi(s=document){var t,i,n,a,l,r,c,o,d,p,f,u,m;const e=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const y of Array.from(e))try{const h=JSON.parse(y.textContent||"{}"),x=Array.isArray(h)?h:[h];for(const g of x)if(g["@type"]==="JobPosting")return{title:g.title||g.name,company:((t=g.hiringOrganization)==null?void 0:t.name)||g.employerOverview||((i=g.author)==null?void 0:i.name),location:typeof g.jobLocation=="string"?g.jobLocation:((a=(n=g.jobLocation)==null?void 0:n.address)==null?void 0:a.addressLocality)||((r=(l=g.jobLocation)==null?void 0:l.address)==null?void 0:r.addressRegion),salary:((o=(c=g.baseSalary)==null?void 0:c.value)==null?void 0:o.value)||((p=(d=g.baseSalary)==null?void 0:d.value)!=null&&p.minValue&&((u=(f=g.baseSalary)==null?void 0:f.value)!=null&&u.maxValue)?`${g.baseSalary.value.minValue}–${g.baseSalary.value.maxValue} ${g.baseSalary.value.unitText||""}`:void 0),jobType:g.employmentType,description:(m=g.description)==null?void 0:m.replace(/<[^>]*>/g," ").replace(/\s+/g," ").trim().slice(0,3e3)}}catch{}return null}function Si(s=document){var e,t,i,n,a;try{const l=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const r of Array.from(l)){const c=r.textContent;if(!c)continue;const o=JSON.parse(c),d=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((i=o==null?void 0:o.author)==null?void 0:i.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(n=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:n.hiringOrganization)==null?void 0:a.name);if(d&&typeof d=="string"&&d.trim().length>0)return d.trim()}}catch{}}function ki(s=document){const e=t=>{var i;return s.querySelector?(i=s.querySelector(`meta[property="${t}"], meta[name="${t}"]`))==null?void 0:i.content:void 0};return{title:e("og:title")||e("twitter:title")||e("title")||void 0,company:e("og:site_name")||void 0,description:e("og:description")||e("description")||void 0}}function Ti(s=document,e=""){var n,a,l,r,c,o,d,p,f,u,m,y,h,x,g,b,v,w,T,S,L,A,E,M,C,j,z,_,$,I,P,W,F,D,U,J,q,B,O,se,ne;const t={};if(!s||typeof s.querySelector!="function")return t;const i=(()=>{try{return new URL(e).hostname.toLowerCase()}catch{return typeof window<"u"?window.location.hostname.toLowerCase():""}})();if(i.includes("linkedin.com")&&(t.title=(a=(n=s.querySelector(".job-details-jobs-unified-top-card__job-title, .topcard__title"))==null?void 0:n.textContent)==null?void 0:a.trim(),t.company=(r=(l=s.querySelector(".job-details-jobs-unified-top-card__company-name a, .topcard__org-name-link"))==null?void 0:l.textContent)==null?void 0:r.trim(),t.location=(o=(c=s.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:c.textContent)==null?void 0:o.trim(),t.description=(p=(d=s.querySelector(".jobs-description__content, #job-details, .description__text"))==null?void 0:d.textContent)==null?void 0:p.trim()),i.includes("indeed.com")&&(t.title=(u=(f=s.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"]'))==null?void 0:f.textContent)==null?void 0:u.trim(),t.company=((y=(m=s.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, .icl-u-lg-mr--sm, [class*="companyName"]'))==null?void 0:m.textContent)==null?void 0:y.trim())||Si(s)||"Unknown Company",t.location=(x=(h=s.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:h.textContent)==null?void 0:x.trim(),t.salary=(b=(g=s.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:g.textContent)==null?void 0:b.trim(),t.description=(w=(v=s.querySelector('#jobDescriptionText, [data-testid="jobDescriptionText"]'))==null?void 0:v.textContent)==null?void 0:w.trim()),(i.includes("greenhouse.io")||i.includes("boards.greenhouse.io"))&&(t.title=(S=(T=s.querySelector(".app-title, h1.heading"))==null?void 0:T.textContent)==null?void 0:S.trim(),t.company=(A=(L=s.querySelector(".company-name, .logo span"))==null?void 0:L.textContent)==null?void 0:A.trim(),t.location=(M=(E=s.querySelector(".location"))==null?void 0:E.textContent)==null?void 0:M.trim(),t.description=(j=(C=s.querySelector("#content, .job-post-content"))==null?void 0:C.textContent)==null?void 0:j.trim()),(i.includes("lever.co")||i.includes("jobs.lever.co"))&&(t.title=(_=(z=s.querySelector(".posting-headline h2"))==null?void 0:z.textContent)==null?void 0:_.trim(),t.company=((I=($=s.querySelector(".posting-headline .posting-categories .sort-by-team"))==null?void 0:$.textContent)==null?void 0:I.trim())||((P=s.querySelector(".main-header-logo img"))==null?void 0:P.getAttribute("alt"))||void 0,t.location=(F=(W=s.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:W.textContent)==null?void 0:F.trim(),t.description=(U=(D=s.querySelector(".section-wrapper, .posting-page"))==null?void 0:D.textContent)==null?void 0:U.trim()),!t.title){const V=['h1[class*="job" i]','h1[class*="title" i]','h1[class*="position" i]','h1[class*="role" i]','[class*="job-title" i]','[class*="position-title" i]',"h1",'h2[class*="job" i]','h2[class*="title" i]'];for(const Z of V){const N=s.querySelector(Z);if(N){const R=((J=N.textContent)==null?void 0:J.trim())||"";if(R.length>3&&R.length<140&&!/^(home|careers|jobs|search|openings|login)$/i.test(R)){t.title=R;break}}}}if(!t.company){const V=['[class*="company-name" i]','[class*="companyName" i]','[class*="employer" i]','[class*="org-name" i]','[class*="organization" i]','[itemprop="hiringOrganization"]','[itemprop="name"]','[class*="sub-title" i]'];for(const Z of V){const N=s.querySelector(Z);if(N){const R=(q=N.textContent)==null?void 0:q.trim();if(R&&R.length>1&&R.length<100){t.company=R;break}}}}if(!t.location){const V=['[class*="location" i]','[class*="city" i]','[class*="workplace" i]','[itemprop="addressLocality"]','[class*="address" i]'];for(const Z of V){const N=s.querySelector(Z);if(N){const R=(B=N.textContent)==null?void 0:B.trim();if(R&&R.length>1&&R.length<100){t.location=R;break}}}}if(!t.salary){const V=['[class*="salary" i]','[class*="compensation" i]','[class*="stipend" i]','[class*="pay" i]','[class*="remuneration" i]'];for(const Z of V){const N=s.querySelector(Z);if(N){const R=(O=N.textContent)==null?void 0:O.trim();if(R&&R.length>1&&R.length<80){t.salary=R;break}}}}if(!t.jobType){const V=['[class*="job-type" i]','[class*="jobType" i]','[class*="employment-type" i]','[class*="work-type" i]'];for(const Z of V){const N=s.querySelector(Z);if(N){const R=(se=N.textContent)==null?void 0:se.trim();if(R&&R.length>2&&R.length<40){t.jobType=R;break}}}}if(!t.description){const V=['[class*="job-description" i]','[class*="jobDescription" i]','[class*="description" i]','[class*="posting-requirements" i]','[class*="job-details" i]',"article","main"];for(const Z of V){const N=s.querySelector(Z);if(N){const R=(ne=N.textContent)==null?void 0:ne.replace(/\s+/g," ").trim();if(R&&R.length>50){t.description=R.slice(0,3e3);break}}}}return t}function Ai(s=document){const e=s.title||(typeof document<"u"?document.title:""),t=e.match(/^(.+?)\s+at\s+(.+?)(?:\s*[|\-–]|$)/i);if(t)return{title:t[1].trim(),company:t[2].trim()};const i=e.match(/^(.+?)\s*[-–]\s*(.+?)(?:\s*[|\-–]|$)/);return i?{title:i[1].trim(),company:i[2].trim()}:{}}function Ee(s,e){let t=typeof document<"u"?document:{},i=typeof window<"u"?window.location.href:"";if(typeof s=="string"?(i=s,e&&typeof e.querySelectorAll=="function"&&(t=e)):s&&typeof s.querySelectorAll=="function"&&(t=s),!i||typeof t.querySelectorAll!="function"||re(i))return null;const n=bi.some(y=>y.test(i)),a=Array.from(t.querySelectorAll("h1, h2, h3")).map(y=>y.textContent||"").join(" "),l=xi.some(y=>y.test(a)),r=wi(t),c=ki(t),o=Ti(t,i),d=Ai(t),p=!!(r!=null&&r.title);if(!n&&!l&&!p)return null;const f=/linkedin\.com\/jobs/i.test(i)||/indeed\.com\/(viewjob|rc\/clk)/i.test(i)||/unstop\.com\/(jobs|internships|competitions)/i.test(i)||/greenhouse\.io/i.test(i)||/lever\.co/i.test(i)||/workable\.com/i.test(i)||/ashbyhq\.com/i.test(i)||/smartrecruiters\.com/i.test(i);if(!p&&!f&&!fe(t,i))return null;const u={title:(r==null?void 0:r.title)||(o==null?void 0:o.title)||(c==null?void 0:c.title)||(d==null?void 0:d.title),company:(r==null?void 0:r.company)||(o==null?void 0:o.company)||(c==null?void 0:c.company)||(d==null?void 0:d.company),location:(r==null?void 0:r.location)||(o==null?void 0:o.location),salary:(r==null?void 0:r.salary)||(o==null?void 0:o.salary),jobType:(r==null?void 0:r.jobType)||(o==null?void 0:o.jobType),description:(r==null?void 0:r.description)||(o==null?void 0:o.description)||(c==null?void 0:c.description)};if(!u.title)return null;let m="LOW";return r!=null&&r.title?m="HIGH":n&&u.title&&u.company?m="MEDIUM":u.title&&(m="LOW"),{title:u.title,company:u.company||"Unknown Company",location:u.location,salary:u.salary,jobType:u.jobType,description:u.description,jobUrl:i,sourceWebsite:vi(i),confidence:m}}function Ci(s="",e="",t=""){const i=s.trim().toLowerCase().replace(/[-_]/g," "),n=e.toLowerCase();return i.includes("intern")||i.includes("stipend")?"INTERNSHIP":i.includes("full time")||i.includes("permanent")?"FULL_TIME":i.includes("part time")?"PART_TIME":i.includes("contract")?"CONTRACT":i.includes("freelance")?"FREELANCE":i.includes("temp")||i.includes("temporary")?"TEMPORARY":i.includes("graduate")||i.includes("fresher")?"GRADUATE_PROGRAM":i.includes("fellowship")||i.includes("scholarship")?"FELLOWSHIP":i.includes("competition")||i.includes("hackathon")||i.includes("challenge")||i.includes("quiz")?"COMPETITION":i.includes("talent")||i.includes("audition")||i.includes("casting")?"TALENT_OPPORTUNITY":n.includes("intern")?"INTERNSHIP":n.includes("hackathon")||n.includes("competition")||n.includes("quiz")||n.includes("challenge")?"COMPETITION":n.includes("fellowship")?"FELLOWSHIP":n.includes("graduate")||n.includes("fresher")?"GRADUATE_PROGRAM":n.includes("part time")?"PART_TIME":n.includes("contract")?"CONTRACT":n.includes("freelance")?"FREELANCE":i.length>0&&i!=="job"&&i!=="work from home"&&i!=="in office"&&i!=="hybrid"?"OTHER":"FULL_TIME"}function Li(s=""){if(!s)return typeof window<"u"?window.location.href.split("?")[0]:"";try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const i of t)e.searchParams.delete(i);return e.toString()}catch{return s.trim()}}function Ie(s,e){var R,we,ut,mt,ft;const t=(s.title||"").trim()||"Untitled Job",i=(s.company||"").trim()||"Unknown Company",n=(s.jobUrl||"").trim()||(typeof window<"u"?window.location.href:""),a=Li(n),l=(s.location||"").trim()||null,r=(s.salary||"").trim()||null,c=(s.description||"").trim()||null,o=(s.sourceWebsite||"").trim()||(typeof window<"u"&&((R=window.location)!=null&&R.hostname)?window.location.hostname.replace(/^www\./i,""):"Web"),d=Ci(s.jobType||"",t,c||""),p=[];let f=0;t!=="Untitled Job"&&(f+=30),i!=="Unknown Company"&&(f+=25),a&&(f+=25),l?f+=10:p.push("location"),r?f+=5:p.push("salary"),c&&c.length>20?f+=5:p.push("description");const u=e||{preferredRoles:[],skills:[],preferredLocations:[],workStyle:"ANY"},m=jt(t,u.preferredRoles,.3),y=m.score>=.6,h=m.level==="NO_MATCH"||m.score===0,x=((we=u.preferredRoles)==null?void 0:we.length)===0?"UNSPECIFIED":y?"MATCH":"MISMATCH",g=y?"Role match":"Role mismatch",b=Nt(t,c||void 0,s.jobType,u,.25),v=b.isHardMismatch||b.status==="MISMATCH",w=b.status,T=b.status==="MATCH"?"Experience match":b.status==="MISMATCH"?`Experience mismatch: Required ${b.requiredText}, Profile: ${b.profileText}`:"Experience standard/flexible",S=zt(t,c||void 0,u,.2),L=S.isHardMismatch&&S.status==="MISMATCH",A=S.status,E=S.status==="MATCH"?"Education match":S.status==="MISMATCH"?`Education mismatch: Requires ${S.requiredText}`:"Education: Not specified",M=Ot(t,c||void 0,u,.2),C=M.matchedSkills,j=M.missingSkills,z=M.status,_=M.status==="MATCH"?"Skills match":"Missing key skills",$=Ht(l||void 0,c||void 0,u,.05),I=!l||!((ut=u.preferredLocations)!=null&&ut.length)?"UNSPECIFIED":$.score>=.7?"MATCH":"MISMATCH",P=$.reason;let W=Math.round(m.weightedScore+b.weightedScore+S.weightedScore+M.weightedScore+$.weightedScore),F=Math.min(100,Math.max(0,W)),D="GOOD_MATCH",U="GOOD MATCH",J="Worth applying",q="🟢";v&&b.isHardMismatch?(F=Math.min(42,Math.max(25,Math.round(W*.46))),D="LOW_MATCH",U="LOW MATCH",J="Experience requirement does not match your profile.",q="🔴"):h&&((mt=u.preferredRoles)==null?void 0:mt.length)>0?(F=Math.min(44,Math.max(20,Math.round(W*.42))),D="LOW_MATCH",U="LOW MATCH",J="Role does not align with your target preferences",q="🔴"):L?(F=Math.min(45,Math.max(25,Math.round(W*.45))),D="LOW_MATCH",U="LOW MATCH",J="Education requirement differs from your profile.",q="🔴"):F>=85?(D="STRONG_MATCH",U="STRONG MATCH",J="Recommended to apply",q="🟢"):F>=70?(D="GOOD_MATCH",U="GOOD MATCH",J="Worth applying",q="🟢"):F>=50?(D="MODERATE_MATCH",U="MODERATE MATCH",J="Review before applying",q="🟡"):(D="LOW_MATCH",U="LOW MATCH",J="Low priority",q="🔴");const B=[],O=[];x==="MATCH"?B.push("Role match"):x==="MISMATCH"&&O.push("Role mismatch"),A==="MATCH"?B.push("Education match"):A==="MISMATCH"&&O.push(E),w==="MATCH"?B.push("Experience match"):w==="MISMATCH"&&O.push(T),z==="MATCH"&&C.length>0&&B.push("Skills match"),j.length>0&&O.push(`Missing: ${j.slice(0,2).join(" • ")}`),I==="MATCH"&&B.push("Location match"),B.length===0&&!v&&!h&&(B.push("Skills match"),B.push("Experience match"));let se=90;const ne=[],V=[];return ne.push("Resume available"),ne.push("Profile complete"),v?V.push("Experience level differs"):ne.push("Experience suitable"),j.length>2&&(se-=10,V.push(`Missing: ${j[0]}`)),f<70&&V.push("Resume could be tailored"),se=Math.max(70,Math.min(100,se)),{normalized:{title:t,company:i,jobUrl:a,sourceWebsite:o,location:l,salary:r,description:c,jobType:d,status:"SAVED"},canSave:!!a,completeness:Math.min(100,f),missingOptionalFields:p,matchScore:F,recommendation:D,recommendationLabel:U,recommendationSubtitle:J,recommendationIcon:q,matchedFactors:B,unmatchedFactors:O,matchedSkills:C,missingSkills:j,roleMatchStatus:x,roleMatchReason:g,roleRequiredText:t,roleProfileText:(ft=u.preferredRoles)!=null&&ft.length?u.preferredRoles.join(", "):"Not specified",experienceMatchStatus:w,experienceMatchReason:T,experienceRequiredText:b.requiredText,experienceProfileText:b.profileText,educationMatchStatus:A,educationMatchReason:E,educationRequiredText:S.requiredText,educationProfileText:u.degree?`${u.degree}${u.specialization?` (${u.specialization})`:""}`:"Not specified",skillsMatchStatus:z,skillsMatchReason:_,locationMatchStatus:I,locationMatchReason:P,readinessScore:se,readinessFactors:ne,readinessIssues:V}}const dt={get:()=>it.get("/api/profile"),update:s=>it.put("/api/profile",s)},Re="talvyn-panel",at="talvyn-host",ye="talvyn_panel_position";function De(){let s=typeof document<"u"?document.getElementById(at):null;if(!s){s=document.createElement("div"),s.id=at,s.setAttribute("data-talvyn-host","true"),Object.assign(s.style,{position:"fixed",top:"0",left:"0",width:"0",height:"0",zIndex:"2147483647",pointerEvents:"none"}),typeof document<"u"&&(document.body?document.body.appendChild(s):document.documentElement&&document.documentElement.appendChild(s));const t=s.attachShadow?s.attachShadow({mode:"open"}):s;if(typeof document<"u"&&t){const i=document.createElement("style");i.textContent=`
        :host {
          all: initial;
        }
        *, *::before, *::after {
          box-sizing: border-box;
        }
        button, input, select, textarea {
          font-family: inherit;
        }
      `,t.appendChild(i)}}const e=s.shadowRoot||s;return{host:s,shadow:e}}function he(s){if(typeof document>"u")return null;const e=document.getElementById(at);if(e&&e.shadowRoot){const t=e.shadowRoot.getElementById(s);if(t)return t}return document.getElementById(s)}let st=null,ot=null,rt=null,ue=null,Ae=null,H=!1;function Ve(s,e,t,i,n){var o,d;Q(),st=e,ot=t,rt=(n==null?void 0:n.onProfileUpdated)||null,ue=s,Ae=n;const a=document.createElement("div");a.id=Re,a.setAttribute("data-talvyn","true"),a.style.pointerEvents="auto";const l=(n==null?void 0:n.theme)==="dark"||(n==null?void 0:n.theme)!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;H=!!l,a.innerHTML=Ii(s,n,l),Pt(a,l);const{shadow:r}=De();r.appendChild(a);const c=a.querySelector("#talvyn-panel-header");c&&Me(a,c,ye),xe(a,s,n),(o=a.querySelector("#talvyn-dismiss-btn"))==null||o.addEventListener("click",()=>{i(),Q()}),(d=a.querySelector("#talvyn-collapse-btn"))==null||d.addEventListener("click",()=>{Ei(a)})}function Me(s,e,t=ye){if(!s||!e||typeof e.addEventListener!="function")return;e.style.cursor="grab",e.style.userSelect="none",e.style.touchAction="none";let i=!1,n=0,a=0,l=0,r=0,c=!1,o="";const d=y=>{if(y.target&&y.target.closest('button, a, input, select, textarea, [role="button"]')||"button"in y&&y.button!==0)return;i=!0,c=!1,n=y.clientX,a=y.clientY;const h=s.getBoundingClientRect();if(l=h.left,r=h.top,s.style.bottom="auto",s.style.right="auto",s.style.left=`${l}px`,s.style.top=`${r}px`,"setPointerCapture"in e&&"pointerId"in y)try{e.setPointerCapture(y.pointerId)}catch{}y.preventDefault&&y.preventDefault()},p=y=>{if(!i)return;const h=y.clientX-n,x=y.clientY-a;if(!c&&Math.hypot(h,x)>3&&(c=!0,e.style.cursor="grabbing",typeof document<"u"&&document.body&&(o=document.body.style.userSelect,document.body.style.userSelect="none")),!c)return;let g=l+h,b=r+x;const v=s.offsetWidth||320,w=s.offsetHeight||420,T=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,S=typeof window<"u"&&window.innerHeight?window.innerHeight:800,L=Math.max(0,T-v),A=Math.max(0,S-w);g=Math.max(0,Math.min(g,L)),b=Math.max(0,Math.min(b,A)),s.style.left=`${g}px`,s.style.top=`${b}px`},f=y=>{if(i){if(i=!1,e.style.cursor="grab",typeof document<"u"&&document.body&&(document.body.style.userSelect=o),y&&"releasePointerCapture"in e&&"pointerId"in y)try{e.releasePointerCapture(y.pointerId)}catch{}if(c)try{const h=s.getBoundingClientRect();localStorage.setItem(t,JSON.stringify({x:h.left,y:h.top}))}catch{}}};e.addEventListener("pointerdown",d),e.addEventListener("pointermove",p),e.addEventListener("pointerup",f),e.addEventListener("pointercancel",f),e.addEventListener("mousedown",d);const u=y=>p(y),m=y=>{f(y),typeof document<"u"&&document.removeEventListener&&(document.removeEventListener("mousemove",u),document.removeEventListener("mouseup",m))};e.addEventListener("mousedown",()=>{typeof document<"u"&&document.addEventListener&&(document.addEventListener("mousemove",u),document.addEventListener("mouseup",m))})}function xe(s,e,t){var n,a,l,r,c;const i=s.querySelector("#talvyn-save-btn");i==null||i.addEventListener("click",()=>{Mi(s,e||ue,t||Ae)}),(n=s.querySelector("#talvyn-back-to-jobs-btn"))==null||n.addEventListener("click",()=>{t!=null&&t.onBackToListing&&t.onBackToListing()}),(a=s.querySelector("#talvyn-profile-btn"))==null||a.addEventListener("click",()=>{_t(s,e||ue,t||Ae)}),(l=s.querySelector("#talvyn-apply-btn"))==null||l.addEventListener("click",()=>{$i(s,e||ue,t||Ae)}),(r=s.querySelector("#talvyn-dashboard-btn"))==null||r.addEventListener("click",()=>{window.open(`${ce.DASHBOARD_URL}/dashboard`,"_blank")}),(c=s.querySelector("#talvyn-open-job-btn"))==null||c.addEventListener("click",()=>{const o=(e==null?void 0:e.jobUrl)||(ue==null?void 0:ue.jobUrl);o&&window.open(o,"_blank")})}const $e="talvyn-capsule";function Ei(s){const e=s.querySelector("#talvyn-panel-body"),t=s.querySelector("#talvyn-collapse-btn"),{shadow:i}=De();let n=he($e);if(!n){n=document.createElement("div"),n.id=$e,n.setAttribute("data-talvyn-capsule","true"),n.style.display="none",n.style.pointerEvents="auto",n.innerHTML=`
      <div id="talvyn-capsule-handle" style="
        display:flex;align-items:center;gap:7px;padding:8px 14px;
        background:linear-gradient(135deg, #4f46e5, #6366f1);
        color:white;border-radius:999px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
        font-size:12px;font-weight:800;letter-spacing:0.5px;
        box-shadow:0 6px 20px rgba(79,70,229,0.4);cursor:pointer;
        user-select:none;border:1.5px solid rgba(255,255,255,0.25);
        transition:transform 0.15s ease;
      " title="Click to open Talvyn Job Intelligence">
        <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#10b981;"></span>
        <span>TALVYN</span>
      </div>
    `,Object.assign(n.style,{position:"fixed",zIndex:"2147483647",userSelect:"none"}),i.appendChild(n);const a=n.querySelector("#talvyn-capsule-handle");a&&Me(n,a,"talvyn_capsule_position"),n.addEventListener("click",()=>{vt(s)})}if(s.style.display!=="none"&&(!e||e.style.display!=="none")){const a=s.getBoundingClientRect();s.style.display="none",e&&(e.style.display="none"),t&&(t.textContent="+",t.title="Expand"),n.style.display="flex",n.style.left=`${Math.max(10,a.left)}px`,n.style.top=`${Math.max(10,a.top)}px`}else vt(s)}function vt(s){const e=he($e);e&&(e.style.display="none"),s.style.display="flex";const t=s.querySelector("#talvyn-panel-body");t&&(t.style.display="block");const i=s.querySelector("#talvyn-collapse-btn");i&&(i.textContent="−",i.title="Minimize")}function Ri(s,e,t){var u,m,y,h;const i=s.querySelector("#talvyn-panel-body");if(!i)return;const n=t==null?void 0:t.normalization,a=H?"#334155":"#e2e8f0",l=H?"#f8fafc":"#0f172a",r=H?"#cbd5e1":"#475569",c=H?"#1e293b":"#f8fafc",o=H?"#0f172a":"#ffffff",d=e.experience||(n==null?void 0:n.experienceRequiredText)||"",p=e.education||(n==null?void 0:n.educationRequiredText)||"";i.innerHTML=`
    <div id="talvyn-confirm-save-view" style="font-size:12px;color:${l};">
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <div style="font-weight:800;font-size:12px;letter-spacing:0.4px;color:#4f46e5;text-transform:uppercase;">
            CONFIRM JOB DETAILS
          </div>
          <div style="font-size:10.5px;color:${r};">
            Review and adjust details before saving to your Tracker.
          </div>
        </div>
        <button id="talvyn-save-cancel-x" style="background:none;border:none;color:${r};font-size:15px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:380px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- Editable Job Fields -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:10px;display:flex;flex-direction:column;gap:8px;">
          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Job Title
            </label>
            <input type="text" id="talvyn-edit-title" value="${k(e.title||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Company
            </label>
            <input type="text" id="talvyn-edit-company" value="${k(e.company||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Location
            </label>
            <input type="text" id="talvyn-edit-location" value="${k(e.location||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " placeholder="e.g. Bangalore, Remote" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Salary / Stipend
            </label>
            <input type="text" id="talvyn-edit-salary" value="${k(e.salary||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " placeholder="e.g. ₹8–12 LPA, $120,000" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Job Type
            </label>
            <input type="text" id="talvyn-edit-jobType" value="${k(e.jobType?Ut(e.jobType):"Full Time")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " placeholder="Full Time, Internship, Contract" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Experience
            </label>
            <input type="text" id="talvyn-edit-experience" value="${k(d!=="Not specified"?d:"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " placeholder="e.g. 2–4 years, Fresher" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Education
            </label>
            <input type="text" id="talvyn-edit-education" value="${k(p!=="Not specified"?p:"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " placeholder="e.g. B.Tech / equivalent, Bachelor's" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${r};margin-bottom:3px;text-transform:uppercase;">
              Job URL
            </label>
            <input type="text" id="talvyn-edit-url" value="${k(e.jobUrl||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${l};outline:none;
            " />
          </div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-cancel-save-btn" style="
          flex:1;padding:8px 12px;background:transparent;color:${r};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
        <button id="talvyn-confirm-save-btn" style="
          flex:1.5;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Confirm & Save
        </button>
      </div>
    </div>
  `;const f=()=>{i.innerHTML=ve(e,t,H),xe(s,e,t)};(u=i.querySelector("#talvyn-save-cancel-x"))==null||u.addEventListener("click",f),(m=i.querySelector("#talvyn-cancel-save-btn"))==null||m.addEventListener("click",f),(y=i.querySelector("#talvyn-cancel-review-btn"))==null||y.addEventListener("click",f),(h=i.querySelector("#talvyn-confirm-save-btn"))==null||h.addEventListener("click",async()=>{var E,M,C,j,z,_,$,I;const x=((E=i.querySelector("#talvyn-edit-title"))==null?void 0:E.value.trim())||e.title,g=((M=i.querySelector("#talvyn-edit-company"))==null?void 0:M.value.trim())||e.company,b=((C=i.querySelector("#talvyn-edit-location"))==null?void 0:C.value.trim())||e.location,v=((j=i.querySelector("#talvyn-edit-salary"))==null?void 0:j.value.trim())||e.salary,w=((z=i.querySelector("#talvyn-edit-jobType"))==null?void 0:z.value.trim())||e.jobType,T=((_=i.querySelector("#talvyn-edit-experience"))==null?void 0:_.value.trim())||d,S=(($=i.querySelector("#talvyn-edit-education"))==null?void 0:$.value.trim())||p,L=((I=i.querySelector("#talvyn-edit-url"))==null?void 0:I.value.trim())||e.jobUrl,A={...e,title:x,company:g,location:b||void 0,salary:v||void 0,jobType:w||void 0,experience:T||void 0,education:S||void 0,jobUrl:L};st&&await st(A,t==null?void 0:t.userProfile)})}const Mi=Ri;function $i(s,e,t){var b,v,w,T,S;const i=s.querySelector("#talvyn-panel-body");if(!i)return;const n=t==null?void 0:t.userProfile,a=H?"#334155":"#e2e8f0",l=H?"#f8fafc":"#0f172a",r=H?"#cbd5e1":"#475569",c=H?"#1e293b":"#f8fafc",o=(n==null?void 0:n.legalFullName)||(n==null?void 0:n.name)||`${(n==null?void 0:n.givenName)||""} ${(n==null?void 0:n.familyName)||""}`.trim()||"Candidate Name",d=(n==null?void 0:n.email)||"email@example.com",p=(n==null?void 0:n.phoneNumber)||(n==null?void 0:n.phone)||"— Not provided",f=((b=n==null?void 0:n.preferredLocations)==null?void 0:b[0])||(n==null?void 0:n.location)||(n==null?void 0:n.city)||"— Not provided",u=(n==null?void 0:n.linkedInUrl)||(n==null?void 0:n.linkedinUrl)||"— Not provided",m=(n==null?void 0:n.githubUrl)||"— Not provided",y=(t==null?void 0:t.resumeName)||"Default Resume",h=(n==null?void 0:n.workAuthorization)||"Requires Review",x=(n==null?void 0:n.expectedSalary)||"Requires Review";i.innerHTML=`
    <div id="talvyn-apply-review-view" style="font-size:12px;color:${l};">
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CONTROLLED APPLICATION REVIEW
          </span>
          <div style="font-size:10.5px;color:${r};margin-top:1px;">
            Talvyn will autofill safe candidate fields and verify sensitive items.
          </div>
        </div>
        <button id="talvyn-apply-review-cancel-x" style="background:none;border:none;color:${r};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- SAFE FIELDS SECTION -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#059669;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>✓</span> Safe Fields (Autofilled Directly)
            </span>
          </div>
          <div style="font-size:11px;color:${r};display:flex;flex-direction:column;gap:3px;">
            <div><strong>Name:</strong> ${k(o)}</div>
            <div><strong>Email:</strong> ${k(d)}</div>
            <div><strong>Phone:</strong> ${k(p)}</div>
            <div><strong>Location:</strong> ${k(f)}</div>
            <div><strong>LinkedIn:</strong> ${k(u)}</div>
            <div><strong>GitHub:</strong> ${k(m)}</div>
            <div><strong>Resume:</strong> ${k(y)}</div>
          </div>
        </div>

        <!-- SENSITIVE FIELDS SECTION -->
        <div style="background:${H?"#451a03":"#fffbeb"};border:1px solid ${H?"#b45309":"#fde68a"};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#d97706;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>🛡️</span> Sensitive Fields (Explicit User Review)
            </span>
          </div>
          <div style="font-size:10.5px;color:${H?"#fef3c7":"#92400e"};line-height:1.4;display:flex;flex-direction:column;gap:4px;">
            <div>• <strong>Work Authorization / Visa:</strong> ${k(h)}</div>
            <div>• <strong>Expected Salary / CTC:</strong> ${k(x)}</div>
            <div>• <strong>Disability & Veteran Status:</strong> Prompt before fill</div>
            <div>• <strong>Legal Declarations / Sponsorship:</strong> Prompt before fill</div>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-review-continue-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Review & Continue ⚡
        </button>
        <button id="talvyn-review-edit-profile-btn" style="
          padding:8px 12px;background:transparent;color:#4f46e5;
          border:1px solid #c7d2fe;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          👤 Edit Details
        </button>
        <button id="talvyn-cancel-apply-review-btn" style="
          padding:8px 10px;background:transparent;color:${r};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `;const g=()=>{i.innerHTML=ve(e,t,H),xe(s,e,t)};(v=i.querySelector("#talvyn-apply-review-cancel-x"))==null||v.addEventListener("click",g),(w=i.querySelector("#talvyn-cancel-apply-review-btn"))==null||w.addEventListener("click",g),(T=i.querySelector("#talvyn-review-edit-profile-btn"))==null||T.addEventListener("click",()=>{_t(s,e,t)}),(S=i.querySelector("#talvyn-review-continue-btn"))==null||S.addEventListener("click",()=>{i.innerHTML=ve(e,t,H),xe(s,e,t),ot&&ot()})}function _t(s,e,t){var L,A,E,M,C,j;const i=s.querySelector("#talvyn-panel-body");if(!i)return;const n=t==null?void 0:t.userProfile,a=H?"#334155":"#e2e8f0",l=H?"#f8fafc":"#0f172a",r=H?"#cbd5e1":"#475569",c=H?"#1e293b":"#f8fafc",o=H?"#0f172a":"#ffffff",d=(n==null?void 0:n.givenName)||((L=n==null?void 0:n.name)==null?void 0:L.split(" ")[0])||"",p=(n==null?void 0:n.familyName)||((A=n==null?void 0:n.name)==null?void 0:A.split(" ").slice(1).join(" "))||"",f=(n==null?void 0:n.email)||"",u=(n==null?void 0:n.phoneNumber)||(n==null?void 0:n.phone)||"",m=((E=n==null?void 0:n.preferredLocations)==null?void 0:E[0])||(n==null?void 0:n.location)||(n==null?void 0:n.city)||"",y=((n==null?void 0:n.preferredRoles)||[]).join(", "),h=(n==null?void 0:n.experienceYears)!==void 0&&(n==null?void 0:n.experienceYears)!==null?String(n==null?void 0:n.experienceYears):"0",x=(n==null?void 0:n.degree)||(n==null?void 0:n.education)||"",g=((n==null?void 0:n.skills)||[]).join(", "),b=(n==null?void 0:n.linkedInUrl)||(n==null?void 0:n.linkedinUrl)||"",v=(n==null?void 0:n.githubUrl)||"",w=(n==null?void 0:n.workAuthorization)||"",T=(n==null?void 0:n.expectedSalary)||"";i.innerHTML=`
    <div id="talvyn-profile-view" style="font-size:12px;color:${l};">
      <!-- Top Title -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CANDIDATE PROFILE
          </span>
          <div style="font-size:10.5px;color:${r};margin-top:1px;">
            Edit profile data to update deterministic matching
          </div>
        </div>
        <button id="talvyn-profile-cancel-x" style="background:none;border:none;color:${r};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- CAREER TARGETS -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${r};margin-bottom:6px;text-transform:uppercase;">
            🎯 Career Targeting
          </div>
          ${ae("Target Roles","p-roles",y,o,a,l)}
          ${ae("Exp (Years)","p-exp",h,o,a,l)}
          ${ae("Degree","p-degree",x,o,a,l)}
          ${ae("Skills","p-skills",g,o,a,l)}
        </div>

        <!-- PERSONAL & CONTACT -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${r};margin-bottom:6px;text-transform:uppercase;">
            👤 Contact & Links
          </div>
          ${ae("Given Name","p-given",d,o,a,l)}
          ${ae("Family Name","p-family",p,o,a,l)}
          ${ae("Email","p-email",f,o,a,l)}
          ${ae("Phone","p-phone",u,o,a,l)}
          ${ae("Location","p-loc",m,o,a,l)}
          ${ae("LinkedIn","p-linkedin",b,o,a,l)}
          ${ae("GitHub","p-github",v,o,a,l)}
        </div>

        <!-- PREFERENCES & SENSITIVE -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${r};margin-bottom:6px;text-transform:uppercase;">
            🛡️ Preferences & Authorization
          </div>
          ${ae("Work Auth","p-auth",w,o,a,l)}
          ${ae("Exp Salary","p-salary",T,o,a,l)}
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-save-profile-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          💾 Save Profile & Re-Run Matching
        </button>
        <button id="talvyn-cancel-profile-btn" style="
          padding:8px 12px;background:transparent;color:${r};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `,i.querySelectorAll(".talvyn-edit-toggle").forEach(z=>{z.addEventListener("click",_=>{const $=_.currentTarget.getAttribute("data-field");if(!$)return;const I=i.querySelector(`#disp-${$}`),P=i.querySelector(`#inp-${$}`),W=_.currentTarget;P&&I&&(P.style.display==="none"?(P.style.display="block",I.style.display="none",P.focus(),W.textContent="Done"):(P.style.display="none",I.style.display="block",I.textContent=P.value.trim()||"—",W.textContent="Edit"))})});const S=()=>{i.innerHTML=ve(e,t,H),xe(s,e,t)};(M=i.querySelector("#talvyn-profile-cancel-x"))==null||M.addEventListener("click",S),(C=i.querySelector("#talvyn-cancel-profile-btn"))==null||C.addEventListener("click",S),(j=i.querySelector("#talvyn-save-profile-btn"))==null||j.addEventListener("click",async z=>{const _=z.currentTarget;_.disabled=!0,_.textContent="Saving Profile...";const $=(O,se)=>{const ne=i.querySelector(`#inp-${O}`);return ne?ne.value.trim():se},I=$("p-exp",h),P=parseInt(I,10),W=isNaN(P)?0:P,F=$("p-roles",y),D=F?F.split(",").map(O=>O.trim()).filter(Boolean):[],U=$("p-skills",g),J=U?U.split(",").map(O=>O.trim()).filter(Boolean):[],q={...n||{},id:(n==null?void 0:n.id)||"user",userId:(n==null?void 0:n.userId)||"user",givenName:$("p-given",d),familyName:$("p-family",p),name:`${$("p-given",d)} ${$("p-family",p)}`.trim(),email:$("p-email",f),phoneNumber:$("p-phone",u),location:$("p-loc",m),preferredLocations:[$("p-loc",m)].filter(Boolean),preferredRoles:D,experienceYears:W,degree:$("p-degree",x),skills:J,linkedInUrl:$("p-linkedin",b),githubUrl:$("p-github",v),workAuthorization:$("p-auth",w),expectedSalary:$("p-salary",T),preferredJobTypes:(n==null?void 0:n.preferredJobTypes)||[],otherLinks:(n==null?void 0:n.otherLinks)||[],workStyle:(n==null?void 0:n.workStyle)||"ANY",onboardingCompleted:!0};try{await dt.update({givenName:q.givenName,familyName:q.familyName,email:q.email,phone:q.phoneNumber,preferredRoles:q.preferredRoles,experienceYears:q.experienceYears,degree:q.degree,skills:q.skills,preferredLocations:q.preferredLocations,linkedinUrl:q.linkedInUrl,githubUrl:q.githubUrl,workAuthorization:q.workAuthorization,expectedSalary:q.expectedSalary})}catch(O){console.warn("[Talvyn] Profile update error:",O)}const B=Ie(e,q);if(t&&(t.userProfile=q,t.normalization=B),Ae=t,rt)try{await rt(q)}catch{}i.innerHTML=ve(e,t,H),xe(s,e,t)})}function ae(s,e,t,i,n,a){const l=t.trim()?t:"—";return`
    <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:4px;font-size:11px;">
      <span style="color:#64748b;font-weight:500;min-width:65px;flex-shrink:0;">${k(s)}:</span>
      <div style="flex:1;min-width:0;">
        <span id="disp-${e}" style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;">
          ${k(l)}
        </span>
        <input id="inp-${e}" value="${k(t)}" style="
          display:none;width:100%;padding:2px 5px;font-size:11px;border:1px solid #4f46e5;
          border-radius:4px;background:${i};color:${a};box-sizing:border-box;
        " />
      </div>
      <button class="talvyn-edit-toggle" data-field="${e}" style="
        background:none;border:1px solid ${n};border-radius:4px;padding:1px 5px;
        font-size:10px;font-weight:600;color:#4f46e5;cursor:pointer;flex-shrink:0;
      ">Edit</button>
    </div>
  `}function Ii(s,e,t=!1){const i=t?"#334155":"#e2e8f0",n=t?"#f8fafc":"#0f172a",a=t?"#94a3b8":"#64748b";return`
    <div id="talvyn-panel-container">
      <!-- Header (Draggable Handle) -->
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${i};
        cursor:grab;user-select:none;
      " title="Drag to move panel">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${n};">Talvyn</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${(e==null?void 0:e.isConnected)!==!1?`
          <span style="
            font-size:10.5px;font-weight:700;color:#059669;background:${t?"#064e3b":"#ecfdf5"};
            padding:2px 7px;border-radius:999px;display:inline-flex;align-items:center;gap:3px;
          ">
            <span style="width:5px;height:5px;border-radius:50%;background:#10b981;display:inline-block;"></span>
            ● Connected
          </span>
          `:`
          <span style="
            font-size:10.5px;font-weight:700;color:${t?"#94a3b8":"#64748b"};background:${t?"#1e293b":"#f1f5f9"};
            padding:2px 7px;border-radius:999px;display:inline-flex;align-items:center;gap:3px;
          ">
            <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block;"></span>
            Guest
          </span>
          `}
          <button id="talvyn-profile-btn" style="
            background:none;border:1px solid ${i};border-radius:6px;
            padding:2px 6px;cursor:pointer;color:${n};font-size:11px;font-weight:600;
          " title="Candidate Profile">👤 Profile</button>
          <button id="talvyn-collapse-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:15px;
            font-weight:700;line-height:1;padding:0 3px;
          " title="Minimize">−</button>
          <button id="talvyn-dismiss-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:16px;
            line-height:1;padding:0 2px;
          " title="Close">×</button>
        </div>
      </div>

      <div id="talvyn-panel-body">
        ${ve(s,e,t)}
      </div>
    </div>
  `}function qi(s,e){var f,u;const t=s.experience||(e==null?void 0:e.experienceRequiredText)||"— Not specified",i=s.education||(e==null?void 0:e.educationRequiredText)||"— Not specified",n=s.location||"— Not specified",a=s.salary||"— Not specified",l=s.jobType?Ut(s.jobType):"— Not specified";let r="— Not specified";const c=s.description||"";if(c.trim()){const m=c.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim();if(m.length>0){const y=m.split(new RegExp("(?<=[.!?])\\s+")).filter(h=>h.trim().length>15);y.length>0?(r=y.slice(0,2).join(" "),r.length>280&&(r=r.substring(0,280)+"...")):r=m.length>200?m.substring(0,200)+"...":m}}let o=[];if(s.description){const m=s.description,y=m.match(/(?:responsibilities|duties|what you will do|what you'll do|your role)[:\s]+([\s\S]*?)(?:requirements|qualifications|skills|who you are|benefits|$)/i),x=(y?y[1]:m).split(/\n|<br\s*\/?>|<li>/i).map(g=>g.replace(/<[^>]+>/g,"").trim()).filter(g=>g.startsWith("•")||g.startsWith("-")||g.startsWith("*")||/^(design|develop|build|collaborate|lead|manage|maintain|implement|create|deliver|support|coordinate|review|test)\b/i.test(g)).map(g=>g.replace(/^[•\-*]\s*/,"").trim()).filter(g=>g.length>10&&g.length<200);x.length>0&&(o=x.slice(0,4))}o.length===0&&(o=["— Not specified"]);let d=[];if(s.description){const m=s.description,y=m.match(/(?:requirements|qualifications|what we are looking for|what we're looking for|who you are|must have|eligibility)[:\s]+([\s\S]*?)(?:responsibilities|duties|benefits|about us|$)/i),x=(y?y[1]:m).split(/\n|<br\s*\/?>|<li>/i).map(g=>g.replace(/<[^>]+>/g,"").trim()).filter(g=>g.startsWith("•")||g.startsWith("-")||g.startsWith("*")||/^(bachelor|master|degree|\d+\+?\s*years|experience|proficiency|strong|knowledge|familiarity)\b/i.test(g)).map(g=>g.replace(/^[•\-*]\s*/,"").trim()).filter(g=>g.length>10&&g.length<200);x.length>0&&(d=x.slice(0,4))}d.length===0&&((f=e==null?void 0:e.missingSkills)!=null&&f.length||(u=e==null?void 0:e.matchedSkills)!=null&&u.length)&&(d=[t!=="— Not specified"?`Experience: ${t}`:"",i!=="— Not specified"?`Education: ${i}`:"",...((e==null?void 0:e.missingSkills)||[]).slice(0,2).map(m=>`Proficiency in ${m}`)].filter(Boolean)),d.length===0&&(d=["— Not specified"]);let p="Moderate alignment with partial skill and requirement overlap.";return(e==null?void 0:e.experienceMatchStatus)==="MISMATCH"?p=`Experience mismatch: Requires ${e.experienceRequiredText||"2–4 years"}, but candidate is ${e.experienceProfileText||"Fresher"}.`:(e==null?void 0:e.roleMatchStatus)==="MISMATCH"?p=`Role mismatch: Requires ${e.roleRequiredText||s.title}, which differs from target role.`:(e==null?void 0:e.educationMatchStatus)==="MISMATCH"?p=`Education mismatch: Requires ${e.educationRequiredText}, which does not match candidate education.`:(e==null?void 0:e.skillsMatchStatus)==="MISMATCH"?p=`Skills gap: Missing critical skills (${(e.missingSkills||[]).slice(0,3).join(", ")}).`:((e==null?void 0:e.matchScore)??0)>=85?p="Strong profile alignment across role, experience, education, and skills.":((e==null?void 0:e.matchScore)??0)>=70&&(p="Good profile match with suitable experience and relevant skills."),{overview:{title:s.title||"— Not specified",company:s.company||"— Not specified",location:n,jobType:l,salary:a,experience:t,education:i},descriptionSummary:r,responsibilities:o,requirements:d,reason:p}}function ve(s,e,t=!1){var j,z,_,$;const i=e==null?void 0:e.normalization,n=(i==null?void 0:i.matchScore)??82,a=(i==null?void 0:i.recommendationLabel)??"GOOD MATCH",l=(i==null?void 0:i.recommendationSubtitle)??"Worth applying",r=(i==null?void 0:i.recommendationIcon)??"🟢",c=(j=i==null?void 0:i.matchedSkills)!=null&&j.length?i.matchedSkills:[],o=(z=i==null?void 0:i.missingSkills)!=null&&z.length?i.missingSkills:[],d=(i==null?void 0:i.readinessScore)??90,p=(_=i==null?void 0:i.readinessFactors)!=null&&_.length?i.readinessFactors:["Resume available","Profile complete","Experience suitable"],f=($=i==null?void 0:i.readinessIssues)!=null&&$.length?i.readinessIssues:[],u=qi(s,i),m=t?"#1e293b":"#f8fafc",y=t?"#334155":"#e2e8f0",h=t?"#f8fafc":"#0f172a",x=t?"#cbd5e1":"#475569",g=t?"#94a3b8":"#64748b";let b="#059669";n<50?b="#dc2626":n<70?b="#d97706":n<85&&(b="#2563eb");const v=(i==null?void 0:i.roleMatchStatus)==="MATCH",w=(i==null?void 0:i.roleMatchStatus)==="MISMATCH",T=(i==null?void 0:i.experienceMatchStatus)==="MATCH",S=(i==null?void 0:i.experienceMatchStatus)==="MISMATCH";i==null||i.educationMatchStatus;const L=(i==null?void 0:i.educationMatchStatus)==="MISMATCH",A=(i==null?void 0:i.educationMatchStatus)==="UNSPECIFIED"||!(i!=null&&i.educationMatchStatus),E=(i==null?void 0:i.skillsMatchStatus)!=="MISMATCH",M=(i==null?void 0:i.locationMatchStatus)==="MATCH",C=(i==null?void 0:i.locationMatchStatus)==="MISMATCH";return(i==null?void 0:i.locationMatchStatus)==="UNSPECIFIED"||i!=null&&i.locationMatchStatus,`
    <!-- Back to Job Listing (if drilled down from multi-job view) -->
    ${e!=null&&e.onBackToListing?`
      <div style="margin-bottom:8px;">
        <button id="talvyn-back-to-jobs-btn" style="
          display:inline-flex;align-items:center;gap:4px;background:none;border:none;color:#4f46e5;
          font-size:11.5px;font-weight:700;cursor:pointer;padding:0;
        ">
          ← Back to Jobs
        </button>
      </div>
    `:""}

    <!-- 1. JOB OVERVIEW Section -->
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        JOB OVERVIEW
      </div>
      <div style="font-size:13.5px;font-weight:700;color:${h};line-height:1.3;margin-bottom:3px;">
        ${k(u.overview.title)}
      </div>
      <div style="font-size:12px;color:${x};font-weight:600;margin-bottom:4px;">
        ${k(u.overview.company)}
      </div>
      <div style="font-size:11px;color:${g};display:flex;flex-wrap:wrap;gap:8px;">
        <span>📍 ${k(u.overview.location)}</span>
        <span>💼 ${k(u.overview.jobType)}</span>
        <span>💰 ${k(u.overview.salary)}</span>
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:4px;display:flex;flex-wrap:wrap;gap:8px;">
        <span><strong>Experience:</strong> ${k(u.overview.experience)}</span>
        <span><strong>Education:</strong> ${k(u.overview.education)}</span>
      </div>
    </div>

    <!-- 2. DESCRIPTION Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        DESCRIPTION
      </div>
      <p style="font-size:11px;color:${x};line-height:1.4;margin:0;">
        ${k(u.descriptionSummary)}
      </p>
    </div>

    <!-- 3. RESPONSIBILITIES Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        RESPONSIBILITIES
      </div>
      <ul style="margin:0;padding-left:14px;font-size:11px;color:${x};line-height:1.4;">
        ${u.responsibilities.map(I=>`<li>${k(I)}</li>`).join("")}
      </ul>
    </div>

    <!-- 4. REQUIREMENTS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        REQUIREMENTS
      </div>
      <ul style="margin:0;padding-left:14px;font-size:11px;color:${x};line-height:1.4;">
        ${u.requirements.map(I=>`<li>${k(I)}</li>`).join("")}
      </ul>
    </div>

    <!-- 5. SKILLS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        SKILLS
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:2px;">
        <span style="font-weight:700;color:${h};">Matched Skills:</span>
        <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:3px;">
          ${c.length>0?c.map(I=>`
            <span style="
              font-size:10px;padding:1px 6px;border-radius:4px;
              background:${t?"#064e3b":"#ecfdf5"};color:#059669;border:1px solid ${t?"#047857":"#a7f3d0"};
            ">✓ ${k(I)}</span>
          `).join(""):`<span style="color:${g};">— None detected</span>`}
        </div>
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:4px;">
        <span style="font-weight:700;color:${h};">Missing Skills:</span>
        <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:3px;">
          ${o.length>0?o.map(I=>`
            <span style="
              font-size:10px;padding:1px 6px;border-radius:4px;
              background:${t?"#451a03":"#fffbeb"};color:#d97706;border:1px solid ${t?"#b45309":"#fde68a"};
            ">⚠ ${k(I)}</span>
          `).join(""):`<span style="color:${g};">— None</span>`}
        </div>
      </div>
    </div>

    <!-- 6. PROFILE MATCH Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${x};letter-spacing:0.3px;text-transform:uppercase;">PROFILE MATCH</span>
        <span style="font-size:14px;font-weight:800;color:${b};">${n}%</span>
      </div>

      <!-- Factor Checkmarks & Statuses -->
      <div style="display:flex;flex-direction:column;gap:3.5px;margin-bottom:6px;">
        <!-- Role match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${v?"#059669":w?"#dc2626":g};">
          <span style="font-weight:800;">${v?"✓":w?"⚠":"—"}</span>
          <span>${v?"Role match":w?"Role mismatch":"— Role: Not specified"}</span>
        </div>

        <!-- Experience match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${S?"#dc2626":T?"#059669":g};">
          <span style="font-weight:800;">${S?"⚠":T?"✓":"—"}</span>
          <span>${S?"Experience mismatch":T?"Experience match":"— Experience: Not specified"}</span>
        </div>

        <!-- Education match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${L?"#dc2626":A?g:"#059669"};">
          <span style="font-weight:800;">${L?"⚠":A?"—":"✓"}</span>
          <span>${L?"Education mismatch":A?"— Education: Not specified":"Education match"}</span>
        </div>

        <!-- Skills match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${E?"#059669":"#dc2626"};">
          <span style="font-weight:800;">${E?"✓":"⚠"}</span>
          <span>${E?"Skills match":"Missing required skills"}</span>
        </div>

        <!-- Location match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${C?"#dc2626":M?"#059669":g};">
          <span style="font-weight:800;">${M?"✓":C?"⚠":"—"}</span>
          <span>${M?"Location match":C?"Location mismatch":"— Location: Not specified"}</span>
        </div>
      </div>

      <!-- Experience Mismatch Callout -->
      ${S?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Experience mismatch</div>
          <div>Required: ${k((i==null?void 0:i.experienceRequiredText)||"2–4 years")}</div>
          <div>Your profile: ${k((i==null?void 0:i.experienceProfileText)||"Fresher")}</div>
        </div>
      `:""}

      <!-- Education Mismatch Callout -->
      ${L&&(i!=null&&i.educationRequiredText)&&i.educationRequiredText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Education mismatch</div>
          <div>Required: ${k(i.educationRequiredText)}</div>
          <div>Your profile: ${k((i==null?void 0:i.educationProfileText)||"Not specified")}</div>
        </div>
      `:""}

      <!-- Role Mismatch Callout -->
      ${w&&(i!=null&&i.roleProfileText)&&i.roleProfileText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Role mismatch</div>
          <div>Required: ${k((i==null?void 0:i.roleRequiredText)||s.title)}</div>
          <div>Target role: ${k(i.roleProfileText)}</div>
        </div>
      `:""}
    </div>

    <!-- 7. SHORTLIST & 8. REASON Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        SHORTLIST
      </div>
      <div style="
        background:${m};border:1px solid ${y};border-radius:9px;
        padding:8px 10px;margin-bottom:8px;
      ">
        <div style="display:flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:${h};">
          <span>${r}</span>
          <span>${k(a)}</span>
        </div>
        <div style="font-size:11px;color:${g};margin-left:18px;margin-top:1px;">
          ${k(l)}
        </div>
      </div>

      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        REASON
      </div>
      <div style="font-size:11px;color:${x};line-height:1.4;margin-bottom:4px;">
        ${k(u.reason)}
      </div>
    </div>

    <!-- 9. APPLICATION READINESS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${x};letter-spacing:0.3px;text-transform:uppercase;">APPLICATION READINESS</span>
        <span style="font-size:12.5px;font-weight:800;color:#059669;">${d}%</span>
      </div>

      <div style="display:flex;flex-direction:column;gap:3px;">
        ${p.map(I=>`
          <div style="font-size:11px;color:#059669;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">✓</span> <span>${k(I)}</span>
          </div>
        `).join("")}
        ${f.map(I=>`
          <div style="font-size:11px;color:#dc2626;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">⚠</span> <span>${k(I)}</span>
          </div>
        `).join("")}
      </div>
    </div>

    <div id="talvyn-status" style="display:none;margin-bottom:8px;"></div>

    <!-- Action Buttons -->
    <div id="talvyn-actions" style="display:flex;flex-direction:column;gap:6px;">
      <button id="talvyn-save-btn" style="
        width:100%;padding:9px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
        color:white;border:none;border-radius:8px;font-size:12.5px;font-weight:700;
        cursor:pointer;transition:opacity 0.15s, transform 0.1s;box-shadow:0 2px 6px rgba(79,70,229,0.25);
      ">
        ★ Save Job
      </button>

      <button id="talvyn-apply-btn" style="
        width:100%;padding:8px 12px;background:#ffffff;
        color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;
        cursor:pointer;transition:background 0.15s;display:flex;align-items:center;justify-content:center;gap:5px;
      ">
        <span>⚡</span> Apply with Talvyn
      </button>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:2px;">
        <button id="talvyn-open-job-btn" style="
          padding:5px 8px;background:transparent;color:${g};
          border:1px solid ${y};border-radius:7px;font-size:11px;font-weight:500;
          cursor:pointer;text-align:center;
        ">
          Open Job ↗
        </button>
        <button id="talvyn-dashboard-btn" style="
          padding:5px 8px;background:transparent;color:#6366f1;
          border:1px solid ${y};border-radius:7px;font-size:11px;font-weight:600;
          cursor:pointer;text-align:center;
        ">
          Dashboard
        </button>
      </div>
    </div>
  `}function wt(s,e,t="system"){var d,p,f;Q();const i=document.createElement("div");i.id=Re,i.setAttribute("data-talvyn","true");const n=t==="dark"||t!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches,a=n?"#334155":"#e2e8f0",l=n?"#f8fafc":"#0f172a",r=n?"#cbd5e1":"#475569";i.innerHTML=`
    <div id="talvyn-panel-container">
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${a};
        cursor:grab;user-select:none;
      " title="Drag to move">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${l};">Talvyn Intelligence</span>
        </div>
        <button id="talvyn-dismiss-btn" style="
          background:none;border:none;cursor:pointer;color:#94a3b8;font-size:16px;line-height:1;padding:0 2px;
        " title="Close">×</button>
      </div>

      <div style="padding:4px 2px;">
        <div style="
          background:${n?"#1e293b":"#f8fafc"};
          border:1px solid ${n?"#334155":"#e2e8f0"};
          border-radius:10px;padding:14px 12px;margin-bottom:10px;text-align:center;
        ">
          <div style="font-size:22px;margin-bottom:6px;">💼</div>
          <div style="font-weight:700;font-size:13px;color:${l};margin-bottom:4px;">
            No job opportunities detected on this page.
          </div>
          <p style="font-size:11.5px;color:${r};line-height:1.4;margin:0;">
            Make sure you are on an active job posting, detail page, or career listings portal.
          </p>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;">
          <button id="talvyn-reanalyze-btn" style="
            width:100%;padding:9px;background:linear-gradient(to right, #4f46e5, #6366f1);
            color:white;border:none;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;
            box-shadow:0 2px 6px rgba(79,70,229,0.25);
          ">
            Analyze Again
          </button>
          <button id="talvyn-dashboard-btn" style="
            width:100%;padding:8px;background:transparent;color:#6366f1;
            border:1px solid ${a};border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">
            Open Talvyn Dashboard
          </button>
        </div>
      </div>
    </div>
  `,Pt(i,n);const{shadow:c}=De();c.appendChild(i);const o=i.querySelector("#talvyn-panel-header");o&&Me(i,o,ye),(d=i.querySelector("#talvyn-dismiss-btn"))==null||d.addEventListener("click",()=>{s(),Q()}),(p=i.querySelector("#talvyn-reanalyze-btn"))==null||p.addEventListener("click",()=>{e&&e()}),(f=i.querySelector("#talvyn-dashboard-btn"))==null||f.addEventListener("click",()=>{window.open(`${ce.DASHBOARD_URL}/dashboard`,"_blank")})}function Pt(s,e=!1){let t=null;try{const o=localStorage.getItem(ye);o&&(t=JSON.parse(o))}catch{}const i=320,n=460,a=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,l=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let r=Math.max(16,a-i-24),c=Math.max(16,l-n-40);if(t&&typeof t.x=="number"&&typeof t.y=="number"){const o=Math.max(0,a-i),d=Math.max(0,l-200);r=Math.max(0,Math.min(t.x,o)),c=Math.max(0,Math.min(t.y,d))}Object.assign(s.style,{position:"fixed",top:`${c}px`,left:`${r}px`,bottom:"auto",right:"auto",zIndex:"2147483647",width:`${i}px`,background:e?"#0f172a":"#ffffff",color:e?"#f8fafc":"#0f172a",borderRadius:"14px",boxShadow:e?"0 10px 36px rgba(0,0,0,0.6), 0 2px 6px rgba(0,0,0,0.3)":"0 10px 36px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",padding:"13px",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',fontSize:"13px",lineHeight:"1.4",border:e?"1px solid #334155":"1px solid #e2e8f0",boxSizing:"border-box",transition:"box-shadow 0.2s ease"})}function le(s){var a;const e=he(Re);if(!e)return;const t=e.querySelector("#talvyn-status");e.querySelector("#talvyn-actions");const i=e.querySelector("#talvyn-save-btn"),n=e.querySelector("#talvyn-apply-btn");if(t)switch(s.type){case"loading":i&&(i.textContent="Saving...",i.disabled=!0,i.style.opacity="0.7"),t.style.display="none";break;case"saved":i&&(i.textContent="✓ Saved",i.disabled=!0,i.style.opacity="0.7",i.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${k(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${ce.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"duplicate":i&&(i.textContent="✓ Saved",i.disabled=!0,i.style.opacity="0.7",i.style.cursor="default"),t.innerHTML=`
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#d97706;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#b45309;">Status: ${k(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${ce.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"applied":i&&(i.textContent="✓ Saved",i.disabled=!0,i.style.opacity="0.7",i.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>APPLICATION TRACKED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${k(s.existingStatus||"APPLIED")}</span>
          </div>
          ${s.dateApplied?`<div style="font-size:10.5px;color:#64748b;margin-top:2px;">Submitted ${k(s.dateApplied)}</div>`:""}
          <div style="margin-top:5px;">
            <a href="${ce.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"in_progress":i&&(i.textContent="✓ Saved",i.disabled=!0,i.style.opacity="0.7",i.style.cursor="default"),t.innerHTML=`
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#2563eb;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>⏳</span> <span>IN PROGRESS</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#1d4ed8;">Status: ${k(s.existingStatus||"IN_PROGRESS")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${ce.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"autofilling":n&&(n.textContent="⏳ Autofilling...",n.disabled=!0);break;case"autofill-complete":n&&(n.textContent="⚡ Apply with Talvyn",n.disabled=!1);break;case"error":i&&(i.textContent="★ Save Job",i.disabled=!1,i.style.opacity="1",i.style.cursor="pointer"),n&&(n.disabled=!1),t.innerHTML=`
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:8px 10px;margin-bottom:8px;color:#dc2626;font-size:11.5px;line-height:1.4;">
          <div style="font-weight:700;">⚠ Error</div>
          <div>${k(s.message||"Failed to complete action. Please try again.")}</div>
        </div>
      `,t.style.display="block";break;case"logged-out":t.innerHTML=`
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;margin-bottom:8px;font-size:11.5px;color:#475569;">
          <div>Sign in to Talvyn to track opportunities.</div>
          <button id="talvyn-signin-btn" style="
            margin-top:6px;width:100%;padding:6px;background:#4f46e5;color:white;
            border:none;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">Sign In to Talvyn</button>
        </div>
      `,t.style.display="block",(a=e.querySelector("#talvyn-signin-btn"))==null||a.addEventListener("click",()=>{window.open(`${ce.DASHBOARD_URL}/login`,"_blank")});break;case"idle":default:i&&(i.textContent="★ Save Job",i.disabled=!1,i.style.opacity="1",i.style.cursor="pointer"),n&&(n.disabled=!1),t.style.display="none";break}}function Q(){var s,e,t,i;(s=he(Re))==null||s.remove(),(e=he($e))==null||e.remove(),typeof document<"u"&&((t=document.getElementById(Re))==null||t.remove(),(i=document.getElementById($e))==null||i.remove())}function Ut(s){return s.replace(/_/g," ").toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function k(s){return(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}const qe="talvyn-discovery-panel";class ji{constructor(){this.isMinimized=!1,this.currentFilter="ALL",this.summary=null,this.callbacks=null}render(e,t){this.summary=e,this.callbacks=t,this.remove();const i=document.createElement("div");i.id=qe,i.setAttribute("data-talvyn","true"),i.style.pointerEvents="auto",i.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(i,this.isMinimized);const{shadow:n}=De();n.appendChild(i);const a=i.querySelector("#talvyn-discovery-header");a&&Me(i,a,ye),this.attachEventListeners(i)}updateSummary(e){this.summary=e;const t=he(qe);if(!t||!this.callbacks)return;t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized);const i=t.querySelector("#talvyn-discovery-header");i&&Me(t,i,ye),this.attachEventListeners(t)}remove(){var e,t;(e=he(qe))==null||e.remove(),typeof document<"u"&&((t=document.getElementById(qe))==null||t.remove())}buildMinimizedHTML(e){const t=e.excellentCount+e.highlyRelevantCount;return`
      <div id="talvyn-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 14px;
        background:#6366f1;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 4px 20px rgba(99,102,241,0.4);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <div style="
          width:20px;height:20px;background:rgba(255,255,255,0.25);border-radius:6px;
          display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;
        ">T</div>
        <span>Talvyn Discovery (${e.totalDetected} jobs${t>0?` · ${t} top`:""})</span>
      </div>
    `}buildExpandedHTML(e){const t=this.filterJobs(e.analyzedJobs),i=e.excellentCount+e.highlyRelevantCount;return`
      <div style="display:flex;flex-direction:column;max-height:560px;">
        <!-- Header (Draggable Handle) -->
        <div id="talvyn-discovery-header" style="
          padding:12px 14px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;cursor:grab;user-select:none;
        " title="Drag to move panel">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:24px;height:24px;background:rgba(255,255,255,0.2);border-radius:6px;
              display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;
            ">T</div>
            <div>
              <div style="font-weight:800;font-size:13px;letter-spacing:0.3px;">TALVYN JOB INTELLIGENCE</div>
              <div id="talvyn-discovery-job-count" style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalDetected} Jobs Found</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Breakdown Bar -->
        <div style="
          padding:8px 12px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              Strong Match: ${e.excellentCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
            ">
              Good Match: ${e.highlyRelevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              Moderate Match: ${e.relevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fef2f2;color:#991b1b;border:1px solid #fecaca;
            ">
              Low Match: ${e.lowRelevanceCount}
            </span>
          </div>
        </div>

        <!-- Action & Control Bar: [ Analyze This Page ] and [ Save Top Matches ] -->
        <div style="
          display:flex;padding:8px 12px;gap:6px;background:#ffffff;
          border-bottom:1px solid #f1f5f9;align-items:center;justify-content:space-between;flex-shrink:0;
        ">
          <button id="talvyn-reanalyze-page-btn" style="
            padding:5px 10px;background:#f8fafc;color:#4f46e5;border:1px solid #c7d2fe;
            border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:4px;
            transition:all 0.15s;
          ">
            <span>🔄</span> Analyze This Page
          </button>

          <button id="talvyn-save-all-top-btn" ${i===0?"disabled":""} style="
            padding:5px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;border:none;border-radius:8px;
            font-size:11px;font-weight:700;cursor:${i===0?"not-allowed":"pointer"};white-space:nowrap;
            opacity:${i===0?"0.6":"1"};box-shadow:0 1px 4px rgba(79,70,229,0.3);transition:background 0.15s;
          ">
            ★ Save Top Matches (${i})
          </button>
        </div>

        <!-- Filter Tabs -->
        <div style="
          display:flex;padding:6px 12px;gap:4px;background:#f8fafc;
          border-bottom:1px solid #e2e8f0;overflow-x:auto;flex-shrink:0;align-items:center;
        ">
          ${this.renderFilterTab("ALL",`All (${e.totalDetected})`)}
          ${this.renderFilterTab("STRONG",`Strong (${e.excellentCount})`)}
          ${this.renderFilterTab("GOOD",`Good (${e.highlyRelevantCount})`)}
          ${this.renderFilterTab("MODERATE",`Moderate (${e.relevantCount})`)}
          ${this.renderFilterTab("LOW",`Low (${e.lowRelevanceCount})`)}
          ${this.renderFilterTab("SAVED","Saved")}
        </div>

        <!-- Scrollable Job List -->
        <div id="talvyn-cards-container" style="
          padding:10px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${t.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No jobs in this category.
            </div>
          `:t.map(n=>this.renderJobCard(n)).join("")}
        </div>

        <!-- Footer -->
        <div style="
          padding:8px 12px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;font-size:11px;
        ">
          <span style="color:#94a3b8;">Deterministic relevance score</span>
          <a href="${ce.DASHBOARD_URL}/tracker" target="_blank" style="
            color:#4f46e5;text-decoration:none;font-weight:600;
          ">View in Tracker →</a>
        </div>
      </div>
    `}renderFilterTab(e,t){const i=this.currentFilter===e;return`
      <button class="talvyn-tab-btn" data-filter="${e}" style="
        padding:3px 9px;border-radius:10px;font-size:10.5px;font-weight:600;cursor:pointer;
        border:1px solid ${i?"#6366f1":"#e2e8f0"};
        background:${i?"#6366f1":"#ffffff"};
        color:${i?"#ffffff":"#64748b"};
        white-space:nowrap;transition:all 0.15s;
      ">${t}</button>
    `}renderJobCard(e){var v,w,T,S,L,A,E,M,C,j;const{job:t,relevanceScore:i,category:n,isSaved:a}=e,l=`job-card-${this.hashUrl(t.jobUrl)}`,r=((v=e.experienceMatch)==null?void 0:v.requiredText)||"Not specified",c=((w=e.educationMatch)==null?void 0:w.requiredText)||"Not specified",o=((T=e.roleMatch)==null?void 0:T.score)!==void 0?e.roleMatch.score>=.6:!0,d=((S=e.experienceMatch)==null?void 0:S.status)==="MATCH",p=((L=e.experienceMatch)==null?void 0:L.status)==="MISMATCH",f=((A=e.educationMatch)==null?void 0:A.status)==="MATCH",u=((E=e.educationMatch)==null?void 0:E.status)==="MISMATCH",m=((M=e.skillsMatch)==null?void 0:M.status)!=="MISMATCH",y=((C=e.locationMatch)==null?void 0:C.score)!==void 0?e.locationMatch.score>=.7:!0;let h="#fef2f2",x="#991b1b",g="#fecaca",b="🔴 LOW MATCH";return n==="EXCELLENT"?(h="#ecfdf5",x="#065f46",g="#6ee7b7",b="🟢 STRONG MATCH"):n==="HIGHLY_RELEVANT"?(h="#eef2ff",x="#4338ca",g="#a5b4fc",b="🟢 GOOD MATCH"):n==="RELEVANT"?(h="#fffbeb",x="#92400e",g="#fde68a",b="🟡 MODERATE MATCH"):b="🔴 LOW MATCH",`
      <div id="${l}" style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:10px;
        padding:10px 12px;box-shadow:0 1px 3px rgba(0,0,0,0.04);transition:all 0.15s;
      ">
        <!-- Top Title & Match % -->
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:2px;">
          <div style="font-weight:700;font-size:12.5px;color:#0f172a;line-height:1.3;flex:1;">
            ${this.escapeHtml(t.title)}
          </div>
          <div style="
            display:inline-flex;align-items:center;gap:3px;padding:2px 6px;
            border-radius:8px;font-size:10px;font-weight:800;
            background:${h};color:${x};border:1px solid ${g};
            flex-shrink:0;
          ">
            <span>PROFILE MATCH: ${i}%</span>
          </div>
        </div>

        <!-- Company, Location, Type, Experience, Education -->
        <div style="font-size:11.5px;color:#475569;font-weight:600;margin-bottom:6px;line-height:1.4;">
          <div>${this.escapeHtml(t.company)}${t.location?` · <span style="color:#64748b;font-weight:400;">📍 ${this.escapeHtml(t.location)}</span>`:""}</div>
          <div style="font-size:10.5px;color:#64748b;font-weight:400;margin-top:2px;display:flex;flex-wrap:wrap;gap:6px;">
            <span><strong>Experience:</strong> ${this.escapeHtml(r)}</span>
            <span><strong>Education:</strong> ${this.escapeHtml(c)}</span>
            <span><strong>Job Type:</strong> ${this.escapeHtml(t.jobType?this.formatJobType(t.jobType):"Full Time")}</span>
            ${t.salary?`<span><strong>Salary:</strong> ${this.escapeHtml(t.salary)}</span>`:""}
          </div>
        </div>

        <!-- 5 Factor Match Breakdown -->
        <div style="
          background:#f8fafc;border:1px solid #f1f5f9;border-radius:6px;
          padding:6px 8px;margin-bottom:6px;font-size:10.5px;display:grid;grid-template-columns:1fr 1fr;gap:3px 8px;
        ">
          <div style="color:${o?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${o?"✓":"⚠"}</span> <span>Role</span>
          </div>
          <div style="color:${p?"#dc2626":d?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${p?"⚠":d?"✓":"—"}</span> <span>Experience</span>
          </div>
          <div style="color:${u?"#dc2626":f?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${u?"⚠":f?"✓":"—"}</span> <span>Education</span>
          </div>
          <div style="color:${m?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${m?"✓":"⚠"}</span> <span>Skills</span>
          </div>
          <div style="color:${y?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;grid-column:1 / -1;">
            <span>${y?"✓":"—"}</span> <span>Location</span>
          </div>
        </div>

        <!-- Shortlist Tier Callout -->
        <div style="margin-bottom:6px;font-size:11px;font-weight:700;">
          <span style="color:#64748b;font-size:10px;text-transform:uppercase;">SHORTLIST: </span>
          <span>${b}</span>
        </div>

        <!-- Exact Mismatch Callout -->
        ${p?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <div style="font-weight:700;">⚠ Experience mismatch</div>
            <div>Required: ${this.escapeHtml(r)}</div>
            <div>Your profile: ${this.escapeHtml(((j=e.experienceMatch)==null?void 0:j.profileText)||"Fresher")}</div>
          </div>
        `:""}

        ${u&&c!=="Not specified"?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <div style="font-weight:700;">⚠ Education mismatch</div>
            <div>Required: ${this.escapeHtml(c)}</div>
          </div>
        `:""}

        <!-- Actions -->
        <div style="display:flex;gap:6px;align-items:center;margin-top:6px;">
          <button class="talvyn-view-details-btn" data-url="${this.escapeHtml(t.jobUrl)}" style="
            flex:1;padding:6px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;
            border:1px solid #c7d2fe;background:#eef2ff;color:#4338ca;transition:all 0.15s;
          ">View Details</button>
          
          <button class="talvyn-save-card-btn" data-url="${this.escapeHtml(t.jobUrl)}" style="
            flex:1;padding:6px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;
            border:none;background:${a?"#10b981":"#4f46e5"};color:#ffffff;
            transition:background 0.15s;
          ">${a?"✓ Saved":"Save"}</button>
          
          <a href="${t.jobUrl}" target="_blank" style="
            padding:5px 9px;border-radius:6px;font-size:11px;font-weight:500;text-decoration:none;
            border:1px solid #cbd5e1;background:#ffffff;color:#475569;text-align:center;
          ">Open ↗</a>
        </div>
      </div>
    `}formatJobType(e){return e.replace(/_/g," ").toLowerCase().replace(/\b\w/g,t=>t.toUpperCase())}attachEventListeners(e){var a,l,r,c,o;(a=e.querySelector("#talvyn-minimize-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(l=e.querySelector("#talvyn-expand-btn"))==null||l.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(r=e.querySelector("#talvyn-close-btn"))==null||r.addEventListener("click",()=>{var d;this.remove(),(d=this.callbacks)==null||d.onDismiss()}),(c=e.querySelector("#talvyn-reanalyze-page-btn"))==null||c.addEventListener("click",()=>{var d;(d=this.callbacks)!=null&&d.onRefresh&&this.callbacks.onRefresh()}),e.querySelectorAll(".talvyn-tab-btn").forEach(d=>{d.addEventListener("click",p=>{const u=p.currentTarget.getAttribute("data-filter");u&&(this.currentFilter=u,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks))})}),(o=e.querySelector("#talvyn-save-all-top-btn"))==null||o.addEventListener("click",async d=>{const p=d.currentTarget;if(!this.summary||!this.callbacks)return;const f=this.summary.analyzedJobs.filter(u=>(u.category==="EXCELLENT"||u.category==="HIGHLY_RELEVANT")&&!u.isSaved);if(f.length!==0){p.disabled=!0,p.textContent="Saving Top Matches...";for(const u of f){const m=e.querySelector(`.talvyn-save-card-btn[data-url="${this.escapeHtml(u.job.jobUrl)}"]`);m&&(m.disabled=!0,m.textContent="Saving…");try{await this.callbacks.onSaveJob(u,m||document.createElement("button")),u.isSaved=!0,m&&(m.textContent="Saved ✓",m.style.background="#10b981")}catch{m&&(m.disabled=!1,m.textContent="Save Job")}}p.textContent="✓ Top Matches Saved",p.style.background="#059669"}}),e.querySelectorAll(".talvyn-view-details-btn").forEach(d=>{d.addEventListener("click",p=>{var y,h;const u=p.currentTarget.getAttribute("data-url"),m=(y=this.summary)==null?void 0:y.analyzedJobs.find(x=>x.job.jobUrl===u);m&&((h=this.callbacks)!=null&&h.onSelectJob)&&this.callbacks.onSelectJob(m.job)})}),e.querySelectorAll(".talvyn-save-card-btn").forEach(d=>{d.addEventListener("click",async p=>{var y;const f=p.currentTarget,u=f.getAttribute("data-url"),m=(y=this.summary)==null?void 0:y.analyzedJobs.find(h=>h.job.jobUrl===u);if(m&&this.callbacks){f.disabled=!0,f.textContent="Saving…";try{await this.callbacks.onSaveJob(m,f),m.isSaved=!0,f.textContent="Saved ✓",f.style.background="#10b981"}catch{f.disabled=!1,f.textContent="Save"}}})})}filterJobs(e){switch(this.currentFilter){case"STRONG":return e.filter(t=>t.category==="EXCELLENT");case"GOOD":return e.filter(t=>t.category==="HIGHLY_RELEVANT");case"MODERATE":return e.filter(t=>t.category==="RELEVANT");case"LOW":return e.filter(t=>t.category==="LOW_RELEVANCE");case"SAVED":return e.filter(t=>t.isSaved);default:return e}}applyStyles(e,t){let i=null;try{const d=localStorage.getItem(ye);d&&(i=JSON.parse(d))}catch{}const n=380,a=580,l=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,r=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let c=Math.max(16,l-n-24),o=Math.max(16,r-a-24);if(i&&typeof i.x=="number"&&typeof i.y=="number"){const d=Math.max(0,l-n),p=Math.max(0,r-200);c=Math.max(0,Math.min(i.x,d)),o=Math.max(0,Math.min(i.y,p))}t?Object.assign(e.style,{position:"fixed",left:`${c}px`,top:`${o}px`,bottom:"auto",right:"auto",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",left:`${c}px`,top:`${o}px`,bottom:"auto",right:"auto",width:`${n}px`,maxHeight:`${a}px`,zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(99,102,241,0.2)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}hashUrl(e){let t=0;for(let i=0;i<e.length;i++)t=(t<<5)-t+e.charCodeAt(i),t|=0;return Math.abs(t).toString(36)}}const Y=new ji;class Ni{constructor(){this.name="Generic"}canHandle(){return!0}isApplicationForm(e,t){var d;const i=e.toLowerCase(),n=/\/apply/i.test(i)||/\/application/i.test(i)||/\/submit/i.test(i)||i.includes("job")||i.includes("career");if(Array.from(t.querySelectorAll("input, textarea, select")).length<2)return!1;const l=(((d=t.body)==null?void 0:d.textContent)||"").toLowerCase(),r=l.includes("apply")||l.includes("submit application")||l.includes("resume")||l.includes("candidate")||l.includes("first name")||l.includes("email"),c=!!t.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i]'),o=!!t.querySelector('input[name*="name" i], input[id*="name" i], input[name*="first" i]');return n&&(c||o)||r&&c&&o}findFormRoots(e){const t=Array.from(e.querySelectorAll("form"));return t.length>0?t:[e.body]}}class zi{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isApplicationForm(e,t){return!!t.querySelector("form#application_form, #app_body, #application")||!!t.querySelector("#first_name, #last_name, #email, #phone")}findFormRoots(e){const t=e.querySelector("form#application_form, #app_body, form");return t?[t]:[e.body]}}class Oi{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isApplicationForm(e,t){return/\/apply\/?$/i.test(e)||!!t.querySelector(".application-form, form#application-form, .application-page")}findFormRoots(e){const t=e.querySelector(".application-form, form#application-form, form");return t?[t]:[e.body]}}class Hi{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}isApplicationForm(e,t){return/\/apply/i.test(e)||!!t.querySelector('div[data-automation-id="formField"], form[data-automation-id="applyForm"]')}findFormRoots(e){const t=e.querySelector('form, main, [data-automation-id="pageContent"]');return t?[t]:[e.body]}}class _i{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isApplicationForm(e,t){return!!t.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]")}findFormRoots(e){const t=e.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]");return t?[t]:[e.body]}}class Pi{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isApplicationForm(e,t){return!!t.querySelector('#ia-container, .ia-BasePage, form[action*="apply" i]')}findFormRoots(e){const t=e.querySelector("#ia-container, .ia-BasePage, form");return t?[t]:[e.body]}}class Ui{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const i=!!t.querySelector('form, [class*="applicationForm" i], [class*="application-form" i]'),n=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return i&&n}findFormRoots(e){const t=Array.from(e.querySelectorAll('form, [class*="applicationForm" i], [class*="application-form" i]'));if(t.length>0)return t;const i=e.querySelector("main");return i?[i]:[e.body]}}class Fi{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const i=!!t.querySelector('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'),n=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return i&&n||e.includes("/apply")}findFormRoots(e){const t=Array.from(e.querySelectorAll('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'));if(t.length>0)return t;const i=Array.from(e.querySelectorAll("form"));return i.length>0?i:[e.body]}}class Di{constructor(){this.adapters=[],this.genericAdapter=new Ni,this.adapters=[new zi,new Oi,new Hi,new _i,new Pi,new Ui,new Fi]}getAdapter(e,t){for(const i of this.adapters)if(i.canHandle(e,t))return i;return this.genericAdapter}}const ge=new Di,Ji=new Set(["hidden","password","submit","button","reset","image","search"]),Bi=["csrf","token","authenticity_token","__viewstate","recaptcha","hcaptcha","turnstile","search","query","q","filter"];class Vi{detectFields(e=document){const t=Array.from(e.querySelectorAll("input, textarea, select")),i=[],n=new Set;for(const a of t){if(n.has(a))continue;n.add(a);const l=this.extractField(a);l&&!l.isIgnored&&i.push(l)}return i}extractField(e){const t=e.tagName.toLowerCase(),i=e instanceof HTMLInputElement?(e.type||"text").toLowerCase():t;if(this.shouldIgnore(e,i))return null;const n=e.name||"",a=e.id||"",l=e.getAttribute("placeholder")||"",r=e.getAttribute("aria-label")||"",c=e.getAttribute("autocomplete")||"",o=e.required||e.getAttribute("aria-required")==="true",d=this.resolveLabel(e),p=this.resolveNearbyText(e),f=this.resolveOptions(e),u=this.resolveCurrentValue(e),m=this.generateSelector(e);return{id:a||n||m,element:e,selector:m,tag:i==="radio"?"radio":i==="checkbox"?"checkbox":t,inputType:i,name:n,domId:a,label:d,placeholder:l,ariaLabel:r,autocomplete:c,nearbyText:p,options:f,currentValue:u,isRequired:o||d.includes("*")||p.includes("*"),isIgnored:!1}}resolveLabel(e){var a,l,r,c,o,d;if(e.id){const p=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);if((a=p==null?void 0:p.textContent)!=null&&a.trim())return this.cleanText(p.textContent)}const t=e.closest("label");if(t){const p=t.cloneNode(!0),f=p.querySelector("input, select, textarea");if(f==null||f.remove(),(l=p.textContent)!=null&&l.trim())return this.cleanText(p.textContent)}const i=e.getAttribute("aria-labelledby");if(i){const p=document.getElementById(i);if((r=p==null?void 0:p.textContent)!=null&&r.trim())return this.cleanText(p.textContent)}if(e.getAttribute("aria-label"))return this.cleanText(e.getAttribute("aria-label"));const n=e.parentElement;if(n){const p=e.previousElementSibling;if(p&&(p.tagName==="LABEL"||p.tagName==="SPAN"||p.tagName==="P")&&(c=p.textContent)!=null&&c.trim()&&p.textContent.trim().length<=80)return this.cleanText(p.textContent);const f=e.closest("fieldset");if(f){const m=f.querySelector("legend");if((o=m==null?void 0:m.textContent)!=null&&o.trim())return this.cleanText(m.textContent)}const u=n.querySelector('label, [class*="label" i], [class*="title" i], [class*="heading" i]');if(u&&u!==e&&((d=u.textContent)!=null&&d.trim()))return this.cleanText(u.textContent)}return""}resolveNearbyText(e){const t=e.closest('.form-group, .field, [class*="field" i], [class*="control" i], div, tr');if(!t)return"";const i=t.textContent||"";return this.cleanText(i).slice(0,200)}resolveOptions(e){return e instanceof HTMLSelectElement?Array.from(e.options).map(t=>({label:this.cleanText(t.textContent||""),value:t.value,selected:t.selected})):e instanceof HTMLInputElement&&e.type==="radio"&&e.name?Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(e.name)}"]`)).map(i=>({label:this.resolveLabel(i)||i.value,value:i.value,selected:i.checked})):[]}resolveCurrentValue(e){return e instanceof HTMLInputElement&&(e.type==="checkbox"||e.type==="radio")?e.checked:e.value||""}shouldIgnore(e,t){if(Ji.has(t)||e.disabled||e.readOnly)return!0;const i=window.getComputedStyle(e);if((i.display==="none"||i.visibility==="hidden"||i.opacity==="0")&&t!=="file")return!0;const n=(e.getAttribute("name")||"").toLowerCase(),a=(e.id||"").toLowerCase(),l=(e.getAttribute("aria-label")||"").toLowerCase();for(const r of Bi)if(n.includes(r)||a.includes(r)||l.includes(r))return!0;return!1}generateSelector(e){return e.id?`#${CSS.escape(e.id)}`:e.getAttribute("name")?`${e.tagName.toLowerCase()}[name="${CSS.escape(e.getAttribute("name"))}"]`:e.tagName.toLowerCase()}cleanText(e){return e.replace(/\s+/g," ").replace(/[\r\n\t]/g," ").trim()}}const Oe=new Vi,We=[{type:"fullName",category:"PERSONAL",label:"Full Name",autocompleteTokens:["name"],aliases:["full name","fullname","candidate name","applicant name","legal full name","legal name","your name","complete name","name (first and last)","full legal name"],negativeAliases:["first name","last name","middle name","company name","school name"]},{type:"firstName",category:"PERSONAL",label:"First Name",autocompleteTokens:["given-name"],aliases:["first name","firstname","given name","candidate first name","legal first name","fname","forename","first_name","first","prenom"],negativeAliases:["last name","middle name"]},{type:"middleName",category:"PERSONAL",label:"Middle Name",autocompleteTokens:["additional-name"],aliases:["middle name","middlename","middle initial","mname","middle_name","middle"],negativeAliases:["first name","last name"]},{type:"lastName",category:"PERSONAL",label:"Last Name",autocompleteTokens:["family-name"],aliases:["last name","lastname","family name","surname","candidate last name","legal last name","lname","last_name","last","nom"],negativeAliases:["first name","middle name"]},{type:"preferredName",category:"PERSONAL",label:"Preferred Name",autocompleteTokens:["nickname"],aliases:["preferred name","preferred first name","nickname","chosen name","known as","goes by"]},{type:"email",category:"PERSONAL",label:"Email Address",autocompleteTokens:["email"],aliases:["email","email address","e-mail","e-mail address","candidate email","personal email","electronic mail","mail"],negativeAliases:["confirm email","alternate email","referrer email"]},{type:"phone",category:"PERSONAL",label:"Phone Number",autocompleteTokens:["tel","tel-national","tel-local"],aliases:["phone","phone number","mobile","mobile number","mobile phone","contact number","telephone","cell phone","cell","tel","primary phone"],negativeAliases:["extension","fax","emergency contact"]},{type:"dateOfBirth",category:"PERSONAL",label:"Date of Birth",autocompleteTokens:["bday","bday-day","bday-month","bday-year"],aliases:["date of birth","dob","birth date","birthday","birthdate"]},{type:"gender",category:"PERSONAL",label:"Gender / Pronouns",autocompleteTokens:["sex"],aliases:["gender","sex","pronoun","pronouns","gender identity"]},{type:"address",category:"PERSONAL",label:"Street Address",autocompleteTokens:["street-address","address-line1"],aliases:["address","street address","address line 1","address 1","residential address","home address","street"],negativeAliases:["email address","ip address","web address"]},{type:"city",category:"PERSONAL",label:"City",autocompleteTokens:["address-level2"],aliases:["city","town","municipality","suburb"]},{type:"state",category:"PERSONAL",label:"State / Province",autocompleteTokens:["address-level1"],aliases:["state","province","region","territory","county"],negativeAliases:["statement","status"]},{type:"country",category:"PERSONAL",label:"Country",autocompleteTokens:["country-name","country"],aliases:["country","nation","country of residence","citizenship country","current country"],negativeAliases:["authorized to work","work in this country","sponsorship","right to work"]},{type:"postalCode",category:"PERSONAL",label:"Postal / Zip Code",autocompleteTokens:["postal-code"],aliases:["postal code","postalcode","zip code","zipcode","zip","postcode","pin code","pincode"]},{type:"linkedinUrl",category:"PROFESSIONAL",label:"LinkedIn Profile",autocompleteTokens:["url"],aliases:["linkedin","linkedin profile","linkedin url","linkedin link","linkedin.com","public profile"]},{type:"githubUrl",category:"PROFESSIONAL",label:"GitHub Profile",autocompleteTokens:["url"],aliases:["github","github profile","github url","github link","github.com","git profile","repository"]},{type:"portfolioUrl",category:"PROFESSIONAL",label:"Portfolio / Personal Site",autocompleteTokens:["url"],aliases:["portfolio","portfolio url","portfolio link","portfolio website","personal website","online portfolio","design portfolio","work samples"]},{type:"websiteUrl",category:"PROFESSIONAL",label:"Website / Other Link",autocompleteTokens:["url"],aliases:["website","website url","personal site","blog","other website","other link","url"]},{type:"skills",category:"PROFESSIONAL",label:"Skills & Tech Stack",autocompleteTokens:[],aliases:["skills","core competencies","technologies","tech stack","key skills","skill set","technical skills"]},{type:"institution",category:"EDUCATION",label:"University / Institution",autocompleteTokens:[],aliases:["university","college","school","institution","educational institution","academy","alma mater"]},{type:"degree",category:"EDUCATION",label:"Degree",autocompleteTokens:[],aliases:["degree","qualification","highest degree","education level","level of education","degree earned"]},{type:"specialization",category:"EDUCATION",label:"Major / Field of Study",autocompleteTokens:[],aliases:["major","field of study","specialization","discipline","area of study","branch"]},{type:"graduationYear",category:"EDUCATION",label:"Graduation Year",autocompleteTokens:[],aliases:["graduation year","year of graduation","grad year","completion year","end year","passout year"]},{type:"cgpa",category:"EDUCATION",label:"GPA / CGPA",autocompleteTokens:[],aliases:["gpa","cgpa","grade","percentage","marks","academic score"]},{type:"workAuthorization",category:"APPLICATION",label:"Work Authorization",autocompleteTokens:[],aliases:["work authorization","authorized to work","legally authorized to work","are you legally authorized to work","eligible to work","right to work","work permit","work eligibility"]},{type:"visaStatus",category:"APPLICATION",label:"Visa Sponsorship",autocompleteTokens:[],aliases:["sponsorship","visa sponsorship","require sponsorship","will you require sponsorship","will you now or in the future require sponsorship","need sponsorship","visa status"]},{type:"expectedSalary",category:"APPLICATION",label:"Expected Salary",autocompleteTokens:[],aliases:["expected salary","expected ctc","ctc","salary","desired salary","salary expectation","compensation expectation","expected compensation","expected pay","target compensation","desired pay"]},{type:"noticePeriod",category:"APPLICATION",label:"Notice Period / Availability",autocompleteTokens:[],aliases:["notice period","availability","how soon can you start","earliest start date","start date","when can you start"]},{type:"currentCompany",category:"APPLICATION",label:"Current Employer",autocompleteTokens:["organization"],aliases:["current company","current employer","present company","company","organization","employer"]},{type:"currentJobTitle",category:"APPLICATION",label:"Current Job Title",autocompleteTokens:["organization-title"],aliases:["current title","current job title","current role","present role","job title","title"]},{type:"yearsOfExperience",category:"APPLICATION",label:"Years of Experience",autocompleteTokens:[],aliases:["years of experience","total experience","overall experience","relevant experience","how many years of experience","experience in years"]},{type:"resumeUpload",category:"SPECIAL",label:"Resume / CV File",autocompleteTokens:[],aliases:["resume","cv","curriculum vitae","upload resume","attach resume","upload cv","attach cv","resume file","resume/cv"]},{type:"customQuestion",category:"SPECIAL",label:"Custom Application Question",autocompleteTokens:[],aliases:["why do you want to work","why are you interested","describe your experience","tell us about yourself","why should we hire you","cover letter","additional information","anything else","what makes you a good fit","personal statement"]}];class Wi{matchField(e,t){if(e.inputType==="file"||this.isResumeField(e))return{field:e,detectedType:"resumeUpload",confidence:95,confidenceLevel:"HIGH",matchedProfileField:"resume",valueToFill:null,reason:"Resume / CV file upload field detected",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!0};if(this.isSensitiveQuestion(e))return{field:e,detectedType:"customQuestion",confidence:90,confidenceLevel:"HIGH",matchedProfileField:"sensitive_declaration",valueToFill:null,reason:"⚠ Review required: Sensitive question (disability, veteran, or legal declaration)",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1,isSensitive:!0,requiresReview:!0};if(this.isCustomQuestion(e))return{field:e,detectedType:"customQuestion",confidence:85,confidenceLevel:"MEDIUM",matchedProfileField:"custom",valueToFill:null,reason:"Open-ended custom question requiring manual response",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1};const i=this.resolveFieldType(e);if(!i||i.confidence<50)return{field:e,detectedType:"unknown",confidence:(i==null?void 0:i.confidence)||20,confidenceLevel:"UNKNOWN",matchedProfileField:"none",valueToFill:null,reason:"Field type could not be confidently identified",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!1};const{value:n,reason:a,requiresManualInput:l}=this.resolveProfileValue(i.def.type,t,e),r=i.def.type==="workAuthorization"||i.def.type==="visaStatus"||i.def.type==="expectedSalary"||this.isSensitiveQuestion(e);let c=i.confidence;(l||n===null||n==="")&&(c=Math.min(c,65));const o=c>=90?"HIGH":c>=70?"MEDIUM":c>=50?"LOW":"UNKNOWN",d=!r&&!l&&n!==null&&n!==""&&c>=70;return{field:e,detectedType:i.def.type,confidence:c,confidenceLevel:o,matchedProfileField:i.def.type,valueToFill:n,reason:a||`Matched ${i.def.label} (${i.reason})`,canAutofill:d,isCustomQuestion:!1,isResumeUpload:!1,isSensitive:r,requiresReview:r||l}}resolveFieldType(e){const t=(e.autocomplete||"").toLowerCase().trim(),i=(e.label||"").toLowerCase().trim(),n=(e.name||"").toLowerCase().trim().replace(/[_-]/g," "),a=(e.domId||"").toLowerCase().trim().replace(/[_-]/g," "),l=(e.placeholder||"").toLowerCase().trim(),r=(e.ariaLabel||"").toLowerCase().trim(),c=(e.nearbyText||"").toLowerCase().trim();let o=null;for(const d of We){if(t&&d.autocompleteTokens.includes(t))return{def:d,confidence:95,reason:`HTML autocomplete="${t}"`};if(!(d.negativeAliases&&d.negativeAliases.some(f=>i.includes(f)||n.includes(f)))){for(const p of d.aliases)if(i===p||n===p||a===p||r===p)return{def:d,confidence:95,reason:`Exact match for "${p}"`};for(const p of d.aliases){const f=new RegExp(`\\b${Gi(p)}\\b`,"i"),u=p.trim().split(/\s+/).length,m=Math.min(6,(u-1)*2);if(f.test(i)){const y=88+m;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(95,y),reason:`Label contains "${p}"`})}else if(f.test(n)||f.test(a)||f.test(r)){const y=85+m;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(95,y),reason:`Field name/id contains "${p}"`})}else if(f.test(l)){const y=80+m;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(90,y),reason:`Placeholder contains "${p}"`})}else if(c&&f.test(c)){const y=70+m;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(85,y),reason:`Nearby text contains "${p}"`})}}}}if(!o){if(e.inputType==="email"){const d=We.find(p=>p.type==="email");if(d)return{def:d,confidence:90,reason:"Input type is email"}}if(e.inputType==="tel"){const d=We.find(p=>p.type==="phone");if(d)return{def:d,confidence:90,reason:"Input type is tel"}}}return o}resolveProfileValue(e,t,i){var n,a,l;switch(e){case"fullName":return{value:t.legalFullName||(t.givenName&&t.familyName?`${t.givenName} ${t.familyName}`:t.givenName||t.preferredName)||null};case"firstName":return t.givenName?{value:t.givenName}:t.legalFullName?{value:t.legalFullName.trim().split(/\s+/)[0]}:t.preferredName?{value:t.preferredName}:{value:null,reason:"First name not found in profile"};case"middleName":{if(t.middleName)return{value:t.middleName};if(t.legalFullName){const r=t.legalFullName.trim().split(/\s+/);if(r.length>=3)return{value:r.slice(1,-1).join(" ")}}return{value:""}}case"lastName":{if(t.familyName)return{value:t.familyName};if(t.legalFullName){const r=t.legalFullName.trim().split(/\s+/);if(r.length>=2)return{value:r[r.length-1]}}return{value:null,requiresManualInput:!0,reason:"Manual input required (no last name in profile)"}}case"preferredName":return{value:t.preferredName||t.givenName||null};case"email":return{value:t.email||null};case"phone":return{value:t.phone||null};case"dateOfBirth":return{value:t.dateOfBirth||null};case"gender":return i.options.length>0&&t.gender?{value:this.matchOption(i.options,t.gender)||t.gender}:{value:t.gender||null};case"address":return{value:t.address||null};case"city":return{value:t.city||null};case"state":return{value:t.state||null};case"country":return i.options.length>0&&t.country?{value:this.matchOption(i.options,t.country)||t.country}:{value:t.country||null};case"postalCode":return{value:t.postalCode||null};case"linkedinUrl":return{value:t.linkedinUrl||null};case"githubUrl":return t.githubUrl?{value:t.githubUrl}:{value:((n=t.otherLinks)==null?void 0:n.find(c=>c.includes("github.com")))||null};case"portfolioUrl":return{value:t.portfolioUrl||null};case"websiteUrl":return t.websiteUrl?{value:t.websiteUrl}:{value:t.portfolioUrl||((a=t.otherLinks)==null?void 0:a[0])||null};case"skills":return{value:t.skills&&t.skills.length>0?t.skills.join(", "):null};case"institution":return{value:t.institution||null};case"degree":return i.options.length>0&&t.degree?{value:this.matchOption(i.options,t.degree)||t.degree}:{value:t.degree||null};case"specialization":return{value:t.specialization||null};case"graduationYear":return{value:t.graduationYear?String(t.graduationYear):null};case"cgpa":return{value:t.cgpa||null};case"workAuthorization":return i.tag==="radio"||i.tag==="select"?{value:this.matchOption(i.options,"Yes")||this.matchOption(i.options,"Authorized")||"yes"}:{value:t.workAuthorization||"Yes, authorized to work"};case"visaStatus":return i.tag==="radio"||i.tag==="select"?{value:this.matchOption(i.options,"No")||this.matchOption(i.options,"Not required")||"no"}:{value:t.visaStatus||"No sponsorship required"};case"expectedSalary":return{value:t.expectedSalary||null};case"noticePeriod":return{value:t.noticePeriod||null};case"currentCompany":return{value:t.currentCompany||null};case"currentJobTitle":return{value:t.currentJobTitle||(((l=t.preferredRoles)==null?void 0:l[0])??null)};case"yearsOfExperience":return{value:t.experienceYears!==null&&t.experienceYears!==void 0?String(t.experienceYears):null};default:return{value:null}}}matchOption(e,t){if(!e||e.length===0||!t)return null;const i=t.toLowerCase().trim();for(const n of e)if(n.value.toLowerCase()===i||n.label.toLowerCase()===i)return n.value;for(const n of e){const a=n.label.toLowerCase(),l=n.value.toLowerCase();if(a.includes(i)||i.includes(a)||l.includes(i))return n.value}return null}isResumeField(e){const t=`${e.label} ${e.name} ${e.domId} ${e.placeholder}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("cv")||t.includes("curriculum vitae")}isSensitiveQuestion(e){const t=`${e.label} ${e.name} ${e.domId} ${e.ariaLabel} ${e.placeholder} ${e.nearbyText}`.toLowerCase();return t.includes("disability")||t.includes("veteran")||t.includes("equal opportunity")||t.includes("criminal")||t.includes("background check")||t.includes("legal declaration")||t.includes("terms and conditions")||t.includes("agree to terms")||t.includes("consent to")||t.includes("digital signature")||t.includes("sign here")}isCustomQuestion(e){const t=`${e.label} ${e.placeholder} ${e.ariaLabel}`.toLowerCase(),i=[/why do you want/i,/why are you interested/i,/describe your/i,/tell us about/i,/why should we hire/i,/cover letter/i,/additional information/i,/what makes you/i,/anything else/i,/personal statement/i];return e.tag==="textarea"&&t.length>20||i.some(n=>n.test(t))}}function Gi(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const Ft=new Wi;class Yi{autofillFields(e,t=!1){var r,c;let i=0,n=0,a=0;const l=[];for(const o of e){if(!o.canAutofill||o.valueToFill===null||o.valueToFill===void 0){n++;continue}const d=o.field.element;if(!d){n++;continue}const p=d.value||o.field.currentValue;if(typeof p=="string"&&p.trim().length>0&&((r=d.getAttribute)==null?void 0:r.call(d,"data-talvyn-autofilled"))!=="true"&&!t){n++;continue}try{this.fillSingleField(o.field.element,o.valueToFill,o.field.tag)?(o.isFilled=!0,(c=d.setAttribute)==null||c.call(d,"data-talvyn-autofilled","true"),i++,l.push(o)):a++}catch(u){console.error("[Talvyn Autofill] Failed to fill field:",o.field.name||o.field.domId,u),o.error=u instanceof Error?u.message:"Fill failed",a++}}return{filledCount:i,skippedCount:n,failedCount:a,filledFields:l}}getStepSignature(e){return e.map(t=>`${t.field.name||t.field.domId||t.field.label}:${t.matchedKey}`).sort().join("|")}isMultiStepApplication(e=document){const t=e.querySelectorAll('[class*="step" i], [aria-label*="step" i], [data-test*="step" i], [class*="progress" i], .wizard'),i=e.querySelector('button[class*="next" i], button[id*="next" i], [data-qa="next-step"]');return{isMultiStep:t.length>0||!!i}}fillSingleField(e,t,i){if(!e)return!1;const n=(e.tagName||i||"").toUpperCase(),a=(e.type||"").toLowerCase();if(n==="INPUT"&&a!=="radio"&&a!=="checkbox"&&a!=="file")return this.setNativeInputValue(e,String(t));if(n==="TEXTAREA")return this.setNativeTextareaValue(e,String(t));if(n==="SELECT")return this.setNativeSelectValue(e,String(t));if(n==="INPUT"&&a==="radio")return this.setNativeRadioValue(e,String(t));if(n==="INPUT"&&a==="checkbox"){const l=typeof t=="boolean"?t:t==="true"||t==="1"||t==="yes";return this.setNativeCheckboxValue(e,l)}return!1}setNativeInputValue(e,t){var a,l;(a=e.focus)==null||a.call(e);const i=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,n=i?(l=Object.getOwnPropertyDescriptor(i,"value"))==null?void 0:l.set:null;return n?n.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeTextareaValue(e,t){var a,l;(a=e.focus)==null||a.call(e);const i=typeof window<"u"&&window.HTMLTextAreaElement?window.HTMLTextAreaElement.prototype:null,n=i?(l=Object.getOwnPropertyDescriptor(i,"value"))==null?void 0:l.set:null;return n?n.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeSelectValue(e,t){var a;e.focus();const i=t.toLowerCase().trim();let n=-1;for(let l=0;l<e.options.length;l++){const r=e.options[l],c=r.value.toLowerCase().trim(),o=(r.textContent||"").toLowerCase().trim();if(c===i||o===i){n=l;break}(o.includes(i)||i.includes(o))&&(n=l)}if(n>=0){e.selectedIndex=n;const l=typeof window<"u"&&window.HTMLSelectElement?window.HTMLSelectElement.prototype:null,r=l?(a=Object.getOwnPropertyDescriptor(l,"value"))==null?void 0:a.set:null;return r&&r.call(e,e.options[n].value),this.dispatchInputEvents(e),!0}return!1}setNativeRadioValue(e,t){var l;const i=e.name;if(!i)return e.checked=!0,this.dispatchInputEvents(e),!0;const n=Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(i)}"]`)),a=t.toLowerCase().trim();for(const r of n){const c=r.value.toLowerCase().trim(),o=(((l=r.parentElement)==null?void 0:l.textContent)||"").toLowerCase().trim();if(c===a||o.includes(a))return r.checked=!0,this.dispatchInputEvents(r),!0}return!1}setNativeCheckboxValue(e,t){var a,l;(a=e.focus)==null||a.call(e);const i=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,n=i?(l=Object.getOwnPropertyDescriptor(i,"checked"))==null?void 0:l.set:null;return n?n.call(e,t):e.checked=t,this.dispatchInputEvents(e),!0}dispatchInputEvents(e){typeof Event>"u"||!e.dispatchEvent||(e.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("blur",{bubbles:!0,composed:!0})))}}const He=new Yi,Ge="talvyn-autofill-panel";class Qi{constructor(){this.isMinimized=!1,this.summary=null,this.callbacks=null,this.selectedResumeId=null}render(e,t){this.summary=e,this.callbacks=t,!this.selectedResumeId&&e.defaultResume&&(this.selectedResumeId=e.defaultResume.id),this.remove();const i=document.createElement("div");i.id=Ge,i.setAttribute("data-talvyn","true"),i.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(i,this.isMinimized),document.body.appendChild(i),this.attachEventListeners(i)}updateSummary(e){this.summary=e;const t=document.getElementById(Ge);!t||!this.callbacks||(t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized),this.attachEventListeners(t))}remove(){var e;(e=document.getElementById(Ge))==null||e.remove()}buildMinimizedHTML(e){return`
      <div id="talvyn-autofill-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 15px;
        background:#4f46e5;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 6px 24px rgba(79,70,229,0.45);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <span style="font-size:15px;">⚡</span>
        <span>Talvyn Autofill (${e.highConfidenceCount+e.mediumConfidenceCount} fields ready)</span>
      </div>
    `}buildExpandedHTML(e){const t=e.highConfidenceCount,i=e.highConfidenceCount+e.mediumConfidenceCount;return`
      <div style="display:flex;flex-direction:column;max-height:580px;">
        <!-- Header -->
        <div style="
          padding:14px 16px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;
        ">
          <div style="display:flex;align-items:center;gap:9px;">
            <div style="
              width:26px;height:26px;background:rgba(255,255,255,0.2);border-radius:8px;
              display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;
            ">⚡</div>
            <div>
              <div style="font-weight:700;font-size:14px;letter-spacing:-0.2px;">Talvyn Autofill</div>
              <div style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalFields} form fields detected</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-autofill-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-autofill-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Bar -->
        <div style="
          padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              ✓ ${e.highConfidenceCount} High Confidence
            </span>
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              🔍 ${e.mediumConfidenceCount} Review
            </span>
            ${e.customQuestionsCount>0?`
              <span style="
                font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
                background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
              ">
                ✍ ${e.customQuestionsCount} Custom
              </span>
            `:""}
          </div>
          <button id="talvyn-rescan-btn" title="Re-scan DOM fields" style="
            background:transparent;border:none;color:#6366f1;font-size:11px;font-weight:600;
            cursor:pointer;padding:2px 4px;
          ">Re-scan ↺</button>
        </div>

        <!-- Resume Selection Banner (if file upload detected) -->
        ${e.resumeUploadDetected?this.renderResumeBanner(e):""}

        <!-- Scrollable Matched Fields List -->
        <div id="talvyn-autofill-fields-container" style="
          padding:12px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${e.matchedFields.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No form fields detected. Click Re-scan or open an application modal.
            </div>
          `:e.matchedFields.map(n=>this.renderFieldCard(n)).join("")}
        </div>

        <!-- Primary Action Buttons -->
        <div style="
          padding:12px 14px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;flex-direction:column;gap:8px;flex-shrink:0;
        ">
          <div style="display:flex;gap:8px;">
            <button id="talvyn-autofill-high-btn" style="
              flex:1;padding:9px 12px;background:#4f46e5;color:white;border:none;
              border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              transition:background 0.15s;
            ">
              ⚡ Autofill High Confidence (${t})
            </button>
            ${e.mediumConfidenceCount>0?`
              <button id="talvyn-autofill-all-btn" style="
                padding:9px 12px;background:#f0f4ff;color:#4338ca;border:1px solid #c7d2fe;
                border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              ">
                Fill All (${i})
              </button>
            `:""}
          </div>

          <!-- Safety Notice -->
          <div style="font-size:10px;color:#64748b;line-height:1.3;text-align:center;">
            🔒 Talvyn never auto-submits. Review all entries before clicking Submit manually.
          </div>
        </div>
      </div>
    `}renderResumeBanner(e){const t=e.availableResumes||[],i=e.defaultResume;return`
      <div style="
        padding:10px 14px;background:#f0fdf4;border-bottom:1px solid #bbf7d0;
        display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:8px;
      ">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <span style="font-size:14px;">📄</span>
          <div style="min-width:0;">
            <div style="font-size:11px;font-weight:700;color:#166534;">Resume Upload Detected</div>
            <div style="font-size:11px;color:#15803d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${i?`Default: <strong>${this.escapeHtml(i.name)}</strong>`:"No default resume set in Talvyn"}
            </div>
          </div>
        </div>
        ${t.length>1?`
          <select id="talvyn-resume-select" style="
            font-size:11px;padding:3px 6px;border-radius:6px;border:1px solid #86efac;
            background:white;color:#166534;font-weight:500;
          ">
            ${t.map(n=>`
              <option value="${n.id}" ${n.id===this.selectedResumeId?"selected":""}>
                ${this.escapeHtml(n.name)}${n.isDefault?" (Default)":""}
              </option>
            `).join("")}
          </select>
        `:`
          <a href="${ce.DASHBOARD_URL}/resumes" target="_blank" style="
            font-size:11px;color:#16a34a;font-weight:600;text-decoration:none;
          ">Resumes →</a>
        `}
      </div>
    `}renderFieldCard(e){const{field:t,detectedType:i,confidence:n,confidenceLevel:a,valueToFill:l,reason:r,canAutofill:c,isCustomQuestion:o,isResumeUpload:d,isFilled:p}=e,f=t.label||t.placeholder||t.name||t.domId||"Untitled Field",u=l!=null?String(l):null;let m="#f1f5f9",y="#475569",h=`${n}% · Unknown`;return d?(m="#dcfce7",y="#15803d",h="Resume File"):o?(m="#eff6ff",y="#1d4ed8",h="Custom Question"):a==="HIGH"?(m="#ecfdf5",y="#047857",h=`${n}% · High`):a==="MEDIUM"&&(m="#fffbeb",y="#b45309",h=`${n}% · Review`),`
      <div style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;
        padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.03);
      ">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:4px;">
          <div style="font-weight:600;font-size:12px;color:#1e293b;line-height:1.3;flex:1;">
            ${this.escapeHtml(f)}
            ${t.isRequired?'<span style="color:#ef4444;font-weight:700;"> *</span>':""}
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:6px;
            background:${m};color:${y};flex-shrink:0;white-space:nowrap;
          ">${h}</span>
        </div>

        <div style="font-size:11px;color:#64748b;margin-bottom:6px;">
          Mapped: <span style="font-weight:600;color:#4f46e5;">${i}</span>
        </div>

        <!-- Value Preview -->
        ${u!==null?`
          <div style="
            font-size:11px;background:#f8fafc;padding:5px 8px;border-radius:6px;
            border:1px solid #f1f5f9;color:#0f172a;font-family:monospace;margin-bottom:6px;
            word-break:break-all;
          ">
            Value: <strong>${this.escapeHtml(u)}</strong>
          </div>
        `:o?`
          <div style="font-size:11px;color:#3b82f6;background:#eff6ff;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ✍ Custom question — manual response recommended.
          </div>
        `:d?`
          <div style="font-size:11px;color:#059669;background:#ecfdf5;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            📄 Upload using your selected Talvyn resume above.
          </div>
        `:`
          <div style="font-size:11px;color:#d97706;background:#fffbeb;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ⚠️ Manual input required (empty in profile).
          </div>
        `}

        <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;font-size:10px;color:#94a3b8;">
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:240px;">
            ${this.escapeHtml(r)}
          </span>
          ${c?`
            <button class="talvyn-fill-single-btn" data-field-id="${this.escapeHtml(t.id)}" style="
              padding:3px 8px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;
              border:1px solid #c7d2fe;background:${p?"#10b981":"#f0f4ff"};
              color:${p?"#ffffff":"#4338ca"};
            ">${p?"Filled ✓":"Fill"}</button>
          `:""}
        </div>
      </div>
    `}attachEventListeners(e){var n,a,l,r,c,o;(n=e.querySelector("#talvyn-autofill-minimize-btn"))==null||n.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(a=e.querySelector("#talvyn-autofill-expand-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(l=e.querySelector("#talvyn-autofill-close-btn"))==null||l.addEventListener("click",()=>{var d;this.remove(),(d=this.callbacks)==null||d.onDismiss()}),(r=e.querySelector("#talvyn-rescan-btn"))==null||r.addEventListener("click",()=>{var d;(d=this.callbacks)==null||d.onRescan()}),(c=e.querySelector("#talvyn-autofill-high-btn"))==null||c.addEventListener("click",async d=>{var f;const p=d.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((f=this.callbacks)==null?void 0:f.onAutofillHighConfidence()),p.textContent="Autofilled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Autofill High Confidence"}}),(o=e.querySelector("#talvyn-autofill-all-btn"))==null||o.addEventListener("click",async d=>{var f;const p=d.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((f=this.callbacks)==null?void 0:f.onAutofillAllEligible()),p.textContent="All Filled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Fill All"}}),e.querySelectorAll(".talvyn-fill-single-btn").forEach(d=>{d.addEventListener("click",async p=>{var y;const f=p.currentTarget,u=f.getAttribute("data-field-id"),m=(y=this.summary)==null?void 0:y.matchedFields.find(h=>h.field.id===u);if(m&&this.callbacks){f.disabled=!0,f.textContent="Filling…";try{await this.callbacks.onAutofillSingleField(m),f.textContent="Filled ✓",f.style.background="#10b981",f.style.color="#ffffff"}catch{f.disabled=!1,f.textContent="Fill"}}})});const i=e.querySelector("#talvyn-resume-select");i==null||i.addEventListener("change",d=>{var u,m,y;const p=d.target.value;this.selectedResumeId=p;const f=(m=(u=this.summary)==null?void 0:u.availableResumes)==null?void 0:m.find(h=>h.id===p);f&&((y=this.callbacks)!=null&&y.onSelectResume)&&this.callbacks.onSelectResume(f)})}applyStyles(e,t){t?Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",width:"390px",maxHeight:"600px",zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(79,70,229,0.25)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}}const Se=new Qi,pt={list:()=>it.get("/api/resumes")};class Ki{constructor(){this.isPanelActive=!1,this.currentSummary=null}isApplicationFormPage(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async scanAndAnalyzeForm(e,t,i,n=[]){const r=ge.getAdapter(e,t).findFormRoots(t).flatMap(g=>Oe.detectFields(g)),o=Array.from(new Map(r.map(g=>[g.element,g])).values()).map(g=>Ft.matchField(g,i));let d=0,p=0,f=0,u=0,m=0,y=!1;for(const g of o)g.isResumeUpload&&(y=!0),g.isCustomQuestion&&m++,g.confidenceLevel==="HIGH"?d++:g.confidenceLevel==="MEDIUM"?p++:g.confidenceLevel==="LOW"?f++:u++;const h=n.find(g=>g.isDefault)||(n.length>0?n[0]:null),x={totalFields:o.length,highConfidenceCount:d,mediumConfidenceCount:p,lowConfidenceCount:f,unknownCount:u,customQuestionsCount:m,resumeUploadDetected:y,matchedFields:o,availableResumes:n,defaultResume:h,pageUrl:e,detectedAt:new Date().toISOString()};return this.currentSummary=x,x}async activateAutofill(e,t,i){let n=[];try{n=await pt.list()}catch{}const a=await this.scanAndAnalyzeForm(e,t,i,n);return a.totalFields===0?(this.dismiss(),!1):(this.isPanelActive=!0,Se.render(a,{onAutofillHighConfidence:async()=>{const l=a.matchedFields.filter(r=>r.confidenceLevel==="HIGH");He.autofillFields(l,!1),Se.updateSummary(a)},onAutofillAllEligible:async()=>{const l=a.matchedFields.filter(r=>r.canAutofill);He.autofillFields(l,!1),Se.updateSummary(a)},onAutofillSingleField:async l=>{He.autofillFields([l],!0),Se.updateSummary(a)},onRescan:async()=>{await this.activateAutofill(window.location.href,document,i)},onDismiss:()=>{this.dismiss()}}),!0)}dismiss(){Se.remove(),this.isPanelActive=!1}isActive(){return this.isPanelActive}}const te=new Ki;function Zi(s){const e=s.toLowerCase();return e.includes("declare")||e.includes("certify that")||e.includes("agree to terms")||e.includes("under penalty of perjury")||e.includes("accurate and complete")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Legal declaration or agreement requires user manual verification."}:e.includes("criminal")||e.includes("convicted")||e.includes("disability")||e.includes("veteran")||e.includes("gender identity")||e.includes("race")||e.includes("ethnicity")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Sensitive equal opportunity / compliance question requires personal selection."}:e.includes("salary expectation")||e.includes("desired salary")||e.includes("compensation requirement")||e.includes("minimum rate")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Salary expectation is a sensitive negotiation decision."}:e.includes("sponsorship")||e.includes("visa")||e.includes("authorized to work")||e.includes("work authorization")||e.includes("work permit")||e.includes("legally authorized")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Work authorization & visa sponsorship status must be confirmed manually."}:e.includes("why")||e.includes("describe")||e.includes("tell us")||e.includes("project")||e.includes("cover letter")?{riskLevel:"ASSISTED_ANSWER",reason:"Open-ended question with Talvyn answer suggestion."}:{riskLevel:"SAFE_AUTOFILL"}}class Xi{categorizeField(e){const t=`${e.name} ${e.label} ${e.domId} ${e.placeholder} ${e.ariaLabel} ${e.nearbyText}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("curriculum vitae")||t.includes("cv")||t.includes("cover letter")||t.includes("portfolio upload")?"DOCUMENTS":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("institution")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("first name")||t.includes("last name")||t.includes("full name")||t.includes("legal name")||t.includes("given name")||t.includes("family name")||t.includes("preferred name")||t.includes("name")&&!t.includes("company")&&!t.includes("school")&&!t.includes("university")||t.includes("email")||t.includes("phone")||t.includes("mobile")||t.includes("address")||t.includes("street")||t.includes("city")||t.includes("state")||t.includes("country")||t.includes("postal")||t.includes("zip")?"PERSONAL":t.includes("linkedin")||t.includes("github")||t.includes("portfolio")||t.includes("website")||t.includes("experience")||t.includes("current company")||t.includes("employer")||t.includes("title")||t.includes("skills")?"PROFESSIONAL":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("work authorization")||t.includes("sponsorship")||t.includes("salary")||t.includes("compensation")||t.includes("notice period")||t.includes("location preference")||t.includes("relocate")?"PREFERENCES":e.tag==="textarea"||t.includes("why")||t.includes("describe")||t.includes("tell us")||t.includes("gender")||t.includes("veteran")||t.includes("disability")||t.includes("declare")?"QUESTIONS":"OTHER"}analyzeFields(e,t){return e.map(i=>{const n=this.categorizeField(i),a=i.label||i.placeholder||i.name||"Application Field",{riskLevel:l,reason:r}=Zi(a),c=i.currentValue,o=typeof c=="string"?c.trim().length>0:typeof c=="boolean"?c:!1;return{id:i.id,field:i,category:n,canonicalName:i.name||i.domId||i.id,label:a,isRequired:i.isRequired,isFilled:o,filledBy:o?"USER_INPUT":"UNFILLED",currentValue:c,suggestedValue:null,riskLevel:l,riskReason:r,confidence:85}})}calculateProgress(e){const t={PERSONAL:{total:0,filled:0,required:0,requiredFilled:0},PROFESSIONAL:{total:0,filled:0,required:0,requiredFilled:0},EDUCATION:{total:0,filled:0,required:0,requiredFilled:0},DOCUMENTS:{total:0,filled:0,required:0,requiredFilled:0},QUESTIONS:{total:0,filled:0,required:0,requiredFilled:0},PREFERENCES:{total:0,filled:0,required:0,requiredFilled:0},OTHER:{total:0,filled:0,required:0,requiredFilled:0}};let i=0,n=0,a=0,l=0;for(const d of e){if(d.field.isIgnored)continue;i++;const p=t[d.category];p.total++,d.isFilled&&(n++,p.filled++),d.isRequired&&(a++,p.required++,d.isFilled&&(l++,p.requiredFilled++))}const r=i>0?Math.round(n/i*100):0,c=a>0?l===a:n===i,o=r>=80&&(a===0||l===a);return{totalFields:i,filledFields:n,requiredFields:a,requiredFilledFields:l,percentage:r,categoryProgress:t,isComplete:c,isReadyForReview:o}}}const je=new Xi;class en{recommendResume(e,t,i,n=[]){if(!e||e.length===0)return[];const a=(t||"").toLowerCase();return(i||"").toLowerCase(),e.map(r=>{let c=50;const o=[],d=(r.name||"").toLowerCase(),p=(r.description||"").toLowerCase();r.isDefault&&(c+=15,o.push("Default primary resume"));const f=a.split(/\s+/).filter(y=>y.length>2);for(const y of f)if(d.includes(y)){c+=20,o.push(`Resume title matches "${y}"`);break}const u=[{key:"backend",terms:["backend","server","java","node","python","api","golang"]},{key:"frontend",terms:["frontend","react","vue","angular","ui","web","javascript"]},{key:"fullstack",terms:["fullstack","full stack","software engineer","sde","swe"]},{key:"data",terms:["data","analytics","analyst","scientist","sql","bi"]},{key:"mobile",terms:["ios","android","flutter","react native","mobile"]},{key:"cloud",terms:["devops","cloud","aws","kubernetes","sre"]},{key:"design",terms:["design","ui/ux","product design","figma"]},{key:"product",terms:["product manager","pm","product owner"]}];for(const y of u){const h=y.terms.some(g=>a.includes(g)),x=y.terms.some(g=>d.includes(g)||p.includes(g));if(h&&x){c+=25,o.push(`Domain expertise match: ${y.key.toUpperCase()}`);break}}for(const y of n){const h=y.toLowerCase();if(h.length>2&&(p.includes(h)||d.includes(h))){c+=5,o.push(`Matches skill: ${y}`);break}}const m=Math.min(100,Math.max(0,c));return{resume:r,score:m,matchReasons:o.length>0?o:["General profile match"],isDefault:!!r.isDefault}}).sort((r,c)=>c.score!==r.score?c.score-r.score:c.isDefault&&!r.isDefault?1:!c.isDefault&&r.isDefault?-1:0)}getBestResume(e,t,i,n=[]){const a=this.recommendResume(e,t,i,n);return a.length>0?a[0]:null}}const tn=new en,St="talvyn-application-assistant-root";class nn{constructor(){this.container=null,this.isCollapsed=!1}render(e,t,i,n){var f,u,m,y;this.onAutofillCallback=n.onAutofill,this.onSelectResumeCallback=n.onSelectResume,this.onDismissCallback=n.onDismiss;let a=document.getElementById(St);a||(a=document.createElement("div"),a.id=St,a.style.position="fixed",a.style.bottom="24px",a.style.right="24px",a.style.zIndex="2147483645",a.style.fontFamily='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',document.body.appendChild(a)),this.container=a;const{jobTitle:l,company:r,progress:c,highRiskQuestions:o}=e,d=o.length;if(this.isCollapsed){this.container.innerHTML=`
        <div style="
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 9999px;
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
          padding: 8px 16px;
          display: flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        " id="talvyn-assistant-expand-btn">
          <div style="width: 24px; height: 24px; border-radius: 6px; background: #6366f1; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; font-size: 13px;">T</div>
          <span style="font-size: 13px; font-weight: 600; color: #1e293b;">Talvyn Assistant</span>
          <span style="font-size: 12px; font-weight: 600; color: #6366f1; background: #eef2ff; padding: 2px 8px; border-radius: 9999px;">${c.filledFields}/${c.totalFields}</span>
        </div>
      `,(f=document.getElementById("talvyn-assistant-expand-btn"))==null||f.addEventListener("click",()=>{this.isCollapsed=!1,this.render(e,t,i,n)});return}this.container.innerHTML=`
      <div style="
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        width: 330px;
        overflow: hidden;
        animation: talvynSlideUp 0.2s ease-out;
      ">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%); padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 24px; height: 24px; border-radius: 6px; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 12px;">T</div>
            <div>
              <div style="font-size: 13px; font-weight: 700; line-height: 1.2;">Application Assistant</div>
              <div style="font-size: 11px; opacity: 0.85; line-height: 1.2;">${r||"Active Application"}</div>
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 4px;">
            <button id="talvyn-assistant-collapse-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Minimize">−</button>
            <button id="talvyn-assistant-close-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Close">×</button>
          </div>
        </div>

        <!-- Body -->
        <div style="padding: 14px 16px; display: flex; flex-col; gap: 12px; max-height: 380px; overflow-y: auto;">
          <!-- Target Role -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px;">Applying For</div>
            <div style="font-size: 14px; font-weight: 600; color: #0f172a; margin-top: 2px;">${l||"Current Position"}</div>
          </div>

          <!-- Live Form Progress Bar -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span style="font-size: 12px; font-weight: 600; color: #334155;">Form Completion</span>
              <span style="font-size: 12px; font-weight: 700; color: #6366f1;">${c.filledFields} / ${c.totalFields} fields (${c.percentage}%)</span>
            </div>
            <div style="width: 100%; height: 6px; background: #e2e8f0; border-radius: 9999px; overflow: hidden;">
              <div style="width: ${c.percentage}%; height: 100%; background: #6366f1; border-radius: 9999px; transition: width 0.3s ease;"></div>
            </div>
          </div>

          <!-- Recommended Resume Selection -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px; margin-bottom: 4px;">Recommended Resume</div>
            <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px;">
              <div style="display: flex; align-items: center; gap: 6px; overflow: hidden;">
                <span style="font-size: 14px;">📄</span>
                <span style="font-size: 12px; font-weight: 600; color: #1e293b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${t?t.resume.name:"Standard Profile CV"}
                </span>
              </div>
              ${i.length>1?`
                <select id="talvyn-assistant-resume-select" style="font-size: 11px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 4px; background: #ffffff; color: #334155; cursor: pointer;">
                  ${i.map(h=>`<option value="${h.id}" ${h.id===(t==null?void 0:t.resume.id)?"selected":""}>${h.name}</option>`).join("")}
                </select>
              `:""}
            </div>
          </div>

          <!-- Attention Needed Warnings -->
          ${d>0?`
            <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 8px 10px; display: flex; align-items: start; gap: 8px;">
              <span style="color: #d97706; font-size: 13px;">⚠️</span>
              <div>
                <div style="font-size: 12px; font-weight: 600; color: #92400e;">${d} Field${d>1?"s":""} Need Attention</div>
                <div style="font-size: 11px; color: #b45309; line-height: 1.3;">Personal / Legal questions require manual verification.</div>
              </div>
            </div>
          `:""}

          <!-- Action Buttons -->
          <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 4px;">
            <button id="talvyn-assistant-autofill-btn" style="
              width: 100%;
              background: #6366f1;
              color: #ffffff;
              border: none;
              border-radius: 8px;
              padding: 9px 12px;
              font-size: 13px;
              font-weight: 600;
              cursor: pointer;
              box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
              transition: background 0.15s;
            ">
              ⚡ Autofill Remaining Fields
            </button>
          </div>

          <!-- Safety Notice -->
          <div style="text-align: center; font-size: 10px; color: #94a3b8; margin-top: 2px;">
            🛡️ Talvyn assists you. You always review before final submit.
          </div>
        </div>
      </div>
    `,(u=document.getElementById("talvyn-assistant-collapse-btn"))==null||u.addEventListener("click",()=>{this.isCollapsed=!0,this.render(e,t,i,n)}),(m=document.getElementById("talvyn-assistant-close-btn"))==null||m.addEventListener("click",()=>{var h;this.remove(),(h=this.onDismissCallback)==null||h.call(this)}),(y=document.getElementById("talvyn-assistant-autofill-btn"))==null||y.addEventListener("click",()=>{var h;(h=this.onAutofillCallback)==null||h.call(this)});const p=document.getElementById("talvyn-assistant-resume-select");p==null||p.addEventListener("change",h=>{var g;const x=h.target.value;(g=this.onSelectResumeCallback)==null||g.call(this,x)})}remove(){this.container&&this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.container=null}}const kt=new nn,Ne="talvyn_active_application_session",Tt=30*60*1e3;class an{constructor(){this.inMemorySession=null}async getActiveSession(){var e;try{if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const i=(await chrome.storage.local.get(Ne))[Ne];if(i)return Date.now()-new Date(i.lastActivityAt).getTime()<Tt?(this.inMemorySession=i,i):(await this.clearSession(),null)}}catch{}if(this.inMemorySession){if(Date.now()-new Date(this.inMemorySession.lastActivityAt).getTime()<Tt)return this.inMemorySession;this.inMemorySession=null}return null}async createOrUpdateSession(e){var a;const t=await this.getActiveSession(),i=new Date().toISOString(),n={id:(t==null?void 0:t.id)||`app-session-${Date.now()}`,pageUrl:e.pageUrl||(t==null?void 0:t.pageUrl)||window.location.href,jobUrl:e.jobUrl||(t==null?void 0:t.jobUrl)||null,jobTitle:e.jobTitle||(t==null?void 0:t.jobTitle)||null,company:e.company||(t==null?void 0:t.company)||null,location:e.location||(t==null?void 0:t.location)||null,startedAt:(t==null?void 0:t.startedAt)||i,lastActivityAt:i,submitted:e.submitted!==void 0?e.submitted:(t==null?void 0:t.submitted)||!1};this.inMemorySession=n;try{typeof chrome<"u"&&((a=chrome.storage)!=null&&a.local)&&await chrome.storage.local.set({[Ne]:n})}catch{}return n}async recordSubmission(){await this.createOrUpdateSession({submitted:!0})}async clearSession(){var e;this.inMemorySession=null;try{typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)&&await chrome.storage.local.remove(Ne)}catch{}}}const me=new an;class sn{constructor(){this.activeSession=null,this.observer=null,this.inputListenerAttached=!1,this.debounceTimer=null,this.currentResumes=[],this.selectedResume=null}isApplicationForm(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async activate(e,t,i,n){var a;try{try{this.currentResumes=await pt.list()}catch{this.currentResumes=[]}const c=ge.getAdapter(e,t).findFormRoots(t).flatMap(x=>Oe.detectFields(x)),o=Array.from(new Map(c.map(x=>[x.element,x])).values());if(o.length===0)return!1;const d=je.analyzeFields(o,i),p=je.calculateProgress(d),f=(n==null?void 0:n.title)||this.inferJobTitle(t),u=(n==null?void 0:n.company)||this.inferCompany(t),m=tn.getBestResume(this.currentResumes,f,(n==null?void 0:n.description)||void 0,i.skills);this.selectedResume=(m==null?void 0:m.resume)||null;const y=d.filter(x=>x.riskLevel==="USER_ACTION_REQUIRED"),h=`asst-session-${Date.now()}`;return this.activeSession={id:h,jobTitle:f||"Application",company:u||"Company",jobUrl:e,state:"IN_PROGRESS",startedAt:new Date().toISOString(),lastActivityAt:new Date().toISOString(),progress:p,selectedResumeId:((a=this.selectedResume)==null?void 0:a.id)||null,fields:d,highRiskQuestions:y,missingRequiredCount:p.requiredFields-p.requiredFilledFields},await me.createOrUpdateSession({pageUrl:e,jobTitle:f,company:u}),this.renderPanel(t,i),this.attachListeners(t,i),!0}catch(l){return console.warn("[Talvyn Assistant] Activation error:",l),!1}}renderPanel(e,t){if(!this.activeSession)return;const i=this.selectedResume?{resume:this.selectedResume,score:90,matchReasons:["Selected active resume"],isDefault:!!this.selectedResume.isDefault}:null;kt.render(this.activeSession,i,this.currentResumes,{onAutofill:()=>this.handleAutofill(e,t),onSelectResume:n=>{this.selectedResume=this.currentResumes.find(a=>a.id===n)||null},onDismiss:()=>{this.dismiss()}})}async handleAutofill(e,t){const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(c=>Oe.detectFields(c)),r=Array.from(new Map(a.map(c=>[c.element,c])).values()).map(c=>Ft.matchField(c,t));await He.autofillForm(r,{preserveUserValues:!0}),this.refreshProgress(e,t)}refreshProgress(e,t){if(!this.activeSession)return;const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(o=>Oe.detectFields(o)),l=Array.from(new Map(a.map(o=>[o.element,o])).values()),r=je.analyzeFields(l,t),c=je.calculateProgress(r);this.activeSession.progress=c,this.activeSession.fields=r,this.activeSession.lastActivityAt=new Date().toISOString(),this.renderPanel(e,t)}attachListeners(e,t){if(this.inputListenerAttached)return;this.inputListenerAttached=!0;const i=()=>{this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{this.refreshProgress(e,t)},300)};e.addEventListener("input",i,{passive:!0}),e.addEventListener("change",i,{passive:!0}),this.observer=new MutationObserver(n=>{for(const a of n)if(a.addedNodes.length>0){i();break}}),this.observer.observe(e.body,{childList:!0,subtree:!0})}dismiss(){kt.remove(),this.observer&&(this.observer.disconnect(),this.observer=null),this.activeSession=null}inferJobTitle(e){var a,l,r;const t=(l=(a=e.querySelector("h1"))==null?void 0:a.textContent)==null?void 0:l.trim();return t&&t.length<80?t:((r=(e.title||"").split(/[-–|•]/)[0])==null?void 0:r.trim())||"Position"}inferCompany(e){const i=window.location.hostname.split(".");if(i.length>=2){const n=i[i.length-2];return n.charAt(0).toUpperCase()+n.slice(1)}return"Company"}}const de=new sn,on=[{regex:/\/(?:application|apply|jobs?|postings?|careers?)\/.*(?:success|confirmation|thank-you|complete|applied|done)/i,score:45,name:"URL application confirmation path"},{regex:/\/(?:application|apply|job|posting)-(?:submitted|complete|success|confirmation)/i,score:45,name:"URL slug confirmation"},{regex:/\/(?:confirmation|thank-you|applied|success)\/?(?:$|\?)/i,score:45,name:"URL confirmation endpoint"},{regex:/[?&](?:status=applied|applied=true|application_submitted=true|submitted=1|success=1)/i,score:40,name:"URL query confirmation parameter"}],rn=[{phrase:"application successfully submitted",score:75,exact:!1},{phrase:"application submitted successfully",score:75,exact:!1},{phrase:"application has been submitted",score:75,exact:!1},{phrase:"application submitted",score:70,exact:!1},{phrase:"thank you for applying",score:75,exact:!1},{phrase:"thanks for applying",score:70,exact:!1},{phrase:"your application has been received",score:75,exact:!1},{phrase:"we received your application",score:75,exact:!1},{phrase:"we have received your application",score:75,exact:!1},{phrase:"you have successfully applied",score:75,exact:!1},{phrase:"your application was sent",score:70,exact:!1},{phrase:"application complete",score:70,exact:!1},{phrase:"submission complete",score:70,exact:!1},{phrase:"thanks for your application",score:70,exact:!1},{phrase:"thank you for your application",score:70,exact:!1},{phrase:"application sent",score:55,exact:!1}],At=['[role="alert"]','[aria-live="polite"]','[aria-live="assertive"]',".application-confirmation",".application-success",".submission-success","#application-confirmation","#submission-success",'[class*="success-message" i]','[class*="confirmation-modal" i]','[data-test="application-success"]','[data-automation-id="applicationSubmittedMessage"]'];class ln{evaluate(e,t,i=null,n=[]){var x,g;let a=0;const l=[],r=e.toLowerCase();let c=(((x=t.body)==null?void 0:x.textContent)||"").toLowerCase();for(const b of At){const v=t.querySelector(b);v!=null&&v.textContent&&(c+=" "+v.textContent.toLowerCase())}c=c.replace(/\s+/g," ");for(const b of on)if(b.regex.test(r)){a+=b.score,l.push(`${b.name} (URL: ${r})`);break}let o=0,d="";for(const b of rn)c.includes(b.phrase)&&b.score>o&&(o=b.score,d=b.phrase);o>0&&(a+=o,l.push(`Confirmation phrase: "${d}"`));for(const b of At){const v=t.querySelector(b);if(v&&((g=v.textContent)!=null&&g.trim())){const w=v.textContent.toLowerCase();if(w.includes("success")||w.includes("submitted")||w.includes("received")||w.includes("applied")||w.includes("thank you")){a+=25,l.push(`Success UI element: ${b}`);break}}}i&&(Date.now()-new Date(i.lastActivityAt).getTime()<18e5&&(a+=15,l.push("Active application session verified")),i.submitted&&(a+=10,l.push("User submitted form in active session")));for(const b of n)a+=b.score,l.push(`${b.name}: ${b.detail}`);Array.from(t.querySelectorAll('input:not([type="hidden"]), textarea')).filter(b=>{if(typeof window<"u"&&window.getComputedStyle){const v=window.getComputedStyle(b);return v&&v.display!=="none"&&v.visibility!=="hidden"}return!0}).length>3&&!l.some(b=>b.includes("URL")||b.includes("UI element"))&&(a=Math.max(0,a-40),l.push("Penalty: Active unsubmitted form inputs present")),t.querySelectorAll('.job-card, [class*="job-card" i], [class*="jobCard" i], [data-job-id]').length>3&&!r.includes("applied")&&!r.includes("success")&&(a=Math.max(0,a-50),l.push("Penalty: Job listing feed detected"));const m=Math.max(0,Math.min(100,a));let y="NOT_CONFIRMED";return m>=90?y="CONFIRMED":m>=70?y="LIKELY":m>=50&&(y="POSSIBLE"),{isSuccess:m>=70,confidence:m,confidenceLevel:y,matchedSignals:l,detectionMethod:l.length>0?l[0]:"Deterministic evaluation",pageUrl:e,timestamp:new Date().toISOString()}}}const ee=new ln;class cn{constructor(){this.name="Generic"}canHandle(){return!0}detectSuccess(e,t,i){return ee.evaluate(e,t,i)}extractSubmittedJobInfo(){return null}}class dn{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}detectSuccess(e,t,i){var r;const n=t.querySelector("#application_confirmation, .application-confirmation, #app_body .thank_you"),a=(((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return!!n||a.includes("thank you for applying to")||a.includes("your application has been submitted")||a.includes("we received your application")?ee.evaluate(e,t,i,[{name:"Greenhouse Confirmation",score:50,detail:"Greenhouse application confirmation matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var i,n;const t=(n=(i=e.querySelector("h1, h2"))==null?void 0:i.textContent)==null?void 0:n.trim();if(t&&t.includes("at ")){const a=t.split("at ");return{title:a[0].trim(),company:a[1].trim()}}return null}}class pn{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}detectSuccess(e,t,i){var r;const n=t.querySelector(".application-confirmation, .application-submitted, .thank-you"),a=(((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return!!n||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("thanks for applying")?ee.evaluate(e,t,i,[{name:"Lever Confirmation",score:50,detail:"Lever application confirmation matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var n,a,l;const t=(a=(n=e.querySelector(".posting-headline h2, h2.posting-title, h1"))==null?void 0:n.textContent)==null?void 0:a.trim(),i=((l=e.querySelector(".main-header-logo img"))==null?void 0:l.getAttribute("alt"))||void 0;return{title:t||void 0,company:i}}}class un{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}detectSuccess(e,t,i){var r;const n=t.querySelector('[data-automation-id="applicationSubmittedMessage"], [data-automation-id="congratulations"]'),a=(((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return!!n||a.includes("application submitted")||a.includes("congratulations")||a.includes("thank you for applying")?ee.evaluate(e,t,i,[{name:"Workday Confirmation",score:50,detail:"Workday application completion state matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var i,n;return{title:((n=(i=e.querySelector('[data-automation-id="jobPostingHeader"]'))==null?void 0:i.textContent)==null?void 0:n.trim())||void 0}}}class mn{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}detectSuccess(e,t,i){const n=t.querySelector(".jobs-easy-apply-modal, .artdeco-modal, div[data-test-modal]"),a=((n==null?void 0:n.textContent)||"").toLowerCase();return a.includes("your application was sent to")||a.includes("application submitted")||a.includes("application was sent")?ee.evaluate(e,t,i,[{name:"LinkedIn Easy Apply Confirmation",score:55,detail:"LinkedIn submission completion modal matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var n,a,l,r;const t=(a=(n=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:n.textContent)==null?void 0:a.trim(),i=(r=(l=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:l.textContent)==null?void 0:r.trim();return{title:t||void 0,company:i||void 0}}}class fn{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}detectSuccess(e,t,i){var r;const n=t.querySelector("#ia-container, .ia-BasePage, .ia-PostApply"),a=((n==null?void 0:n.textContent)||((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return a.includes("your application has been submitted")||a.includes("application submitted")||a.includes("application has been sent")?ee.evaluate(e,t,i,[{name:"Indeed Apply Confirmation",score:55,detail:"Indeed post-apply confirmation matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var n,a,l,r;const t=(a=(n=e.querySelector('.jobsearch-JobInfoHeader-title, h1[data-testid="jobsearch-JobInfoHeader-title"]'))==null?void 0:n.textContent)==null?void 0:a.trim(),i=(r=(l=e.querySelector('[data-company-name="true"], .jobsearch-InlineCompanyRating-companyHeader'))==null?void 0:l.textContent)==null?void 0:r.trim();return{title:t||void 0,company:i||void 0}}}class yn{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}detectSuccess(e,t,i){var r;const n=t.querySelector('[class*="submittedConfirmation" i], [class*="applicationSuccess" i], [data-ashby-application-success]'),a=(((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return!!n||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("we've received your application")||a.includes("application has been received")?ee.evaluate(e,t,i,[{name:"Ashby Confirmation",score:55,detail:"Ashby application confirmation state matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var i,n;return{title:((n=(i=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'))==null?void 0:i.textContent)==null?void 0:n.trim())||void 0}}}class hn{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}detectSuccess(e,t,i){var r;const n=t.querySelector('.st-apply-success, [data-qa="success-message"], .application-success'),a=(((r=t.body)==null?void 0:r.textContent)||"").toLowerCase();return!!n||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("your application has been received")?ee.evaluate(e,t,i,[{name:"SmartRecruiters Confirmation",score:55,detail:"SmartRecruiters application confirmation matched"}]):ee.evaluate(e,t,i)}extractSubmittedJobInfo(e){var n,a,l,r;const t=(a=(n=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'))==null?void 0:n.textContent)==null?void 0:a.trim(),i=(r=(l=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:l.textContent)==null?void 0:r.trim();return{title:t||void 0,company:i||void 0}}}class gn{constructor(){this.adapters=[],this.genericAdapter=new cn,this.adapters=[new dn,new pn,new un,new mn,new fn,new yn,new hn]}getAdapter(e,t){for(const i of this.adapters)if(i.canHandle(e,t))return i;return this.genericAdapter}}const bn=new gn;class xn{resolveAppliedJob(e,t=null){const i=Ee(),n=this.extractHeadingJobInfo(e),a=(i==null?void 0:i.title)||n.title||(t==null?void 0:t.jobTitle)||this.extractFallbackTitle(e)||"Applied Role",l=(i==null?void 0:i.company)||n.company||(t==null?void 0:t.company)||this.extractFallbackCompany(e)||"Company",r=typeof window<"u"?window.location.href:"https://careers.example.com/apply",c=typeof window<"u"?window.location.hostname:"careers.example.com",o=(i==null?void 0:i.jobUrl)||(t==null?void 0:t.jobUrl)||(t==null?void 0:t.pageUrl)||r,d=(i==null?void 0:i.location)||(t==null?void 0:t.location)||n.location||void 0,p=(i==null?void 0:i.sourceWebsite)||(c?c.replace(/^www\./,""):"Direct Application");return{title:a,company:l,jobUrl:o,sourceWebsite:p,location:d,salary:i==null?void 0:i.salary,description:i==null?void 0:i.description,confidence:"HIGH"}}extractHeadingJobInfo(e){var n,a,l,r;const t=(a=(n=e.querySelector("h1"))==null?void 0:n.textContent)==null?void 0:a.trim(),i=(r=(l=e.querySelector("h2"))==null?void 0:l.textContent)==null?void 0:r.trim();if(t){if(t.includes(" at ")){const c=t.split(" at ");return{title:c[0].trim(),company:c[1].trim()}}if(t.includes(" - ")){const c=t.split(" - ");return{title:c[0].trim(),company:c[1].trim()}}}if(i&&i.includes(" at ")){const c=i.split(" at ");return{title:c[0].trim(),company:c[1].trim()}}return{title:t||void 0}}extractFallbackTitle(e){const t=e.title||"",i=t.match(/(?:application for|applied for|applying for)\s+([^|\-–]+)/i);if(i)return i[1].trim();const n=t.split(/[-–|]/);return n.length>0&&n[0].trim().length>2?n[0].trim():null}extractFallbackCompany(e){const t=window.location.hostname.toLowerCase();if(t.includes("greenhouse.io")||t.includes("lever.co")){const i=window.location.pathname.split("/").filter(Boolean);if(i.length>0)return i[0].replace(/[-_]/g," ")}return null}}const vn=new xn,Ye="talvyn-success-notification";class wn{constructor(){this.activeElement=null}showConfirmed(e,t,i,n){var l,r;this.remove();const a=document.createElement("div");a.id=Ye,a.setAttribute("data-talvyn","true"),a.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #10b981;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;animation:talvyn-slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      ">
        <style>
          @keyframes talvyn-slide-in {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#ecfdf5;
              color:#059669;display:flex;align-items:center;justify-content:center;
              font-size:15px;font-weight:bold;
            ">✓</div>
            <div style="font-weight:700;font-size:14px;color:#065f46;">
              Application Tracked
            </div>
          </div>
          <span style="
            font-size:11px;font-weight:700;padding:3px 8px;border-radius:12px;
            background:#e0e7ff;color:#3730a3;
          ">Applied</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:14px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)} ${e.location?`· ${this.escapeHtml(e.location)}`:""}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-undo-applied-btn" style="
            background:transparent;border:none;color:#dc2626;font-size:12px;
            font-weight:600;cursor:pointer;padding:4px 8px;border-radius:6px;
          ">Undo</button>

          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-dismiss-success-btn" style="
              background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
              font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
            ">Dismiss</button>
            <a id="talvyn-view-job-link" href="${ce.DASHBOARD_URL}/jobs/${e.id}" target="_blank" style="
              background:#4f46e5;color:white;text-decoration:none;font-size:12px;
              font-weight:600;padding:6px 14px;border-radius:6px;display:inline-block;
            ">View Job →</a>
          </div>
        </div>
      </div>
    `,document.body.appendChild(a),this.activeElement=a,(l=a.querySelector("#talvyn-undo-applied-btn"))==null||l.addEventListener("click",async c=>{const o=c.currentTarget;o.disabled=!0,o.textContent="Undoing…",await n.onUndo(e,t,i),this.showRevertedNotice(e,t,i)}),(r=a.querySelector("#talvyn-dismiss-success-btn"))==null||r.addEventListener("click",()=>{this.remove(),n.onDismiss()})}showLikelyPrompt(e,t,i){var a,l;this.remove();const n=document.createElement("div");n.id=Ye,n.setAttribute("data-talvyn","true"),n.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #f59e0b;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;
      ">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#fef3c7;
              color:#d97706;display:flex;align-items:center;justify-content:center;
              font-size:14px;font-weight:bold;
            ">🔍</div>
            <div style="font-weight:700;font-size:14px;color:#92400e;">
              Application Submitted?
            </div>
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:12px;
            background:#fef3c7;color:#b45309;
          ">${t.confidence}% Confidence</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:13px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)}
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-top:4px;">
            Signal: ${this.escapeHtml(t.detectionMethod)}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-dismiss-likely-btn" style="
            background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
            font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
          ">No, Dismiss</button>
          <button id="talvyn-confirm-likely-btn" style="
            background:#4f46e5;color:white;border:none;font-size:12px;
            font-weight:600;padding:6px 14px;border-radius:6px;cursor:pointer;
          ">Mark as Applied ✓</button>
        </div>
      </div>
    `,document.body.appendChild(n),this.activeElement=n,(a=n.querySelector("#talvyn-confirm-likely-btn"))==null||a.addEventListener("click",async r=>{const c=r.currentTarget;c.disabled=!0,c.textContent="Tracking…",await i.onConfirmLikely(e,t)}),(l=n.querySelector("#talvyn-dismiss-likely-btn"))==null||l.addEventListener("click",()=>{this.remove(),i.onDismiss()})}showRevertedNotice(e,t,i){var n;this.activeElement&&(this.activeElement.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:340px;background:#1e293b;color:white;border-radius:12px;
        padding:12px 16px;box-shadow:0 8px 30px rgba(0,0,0,0.25);
        font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        font-size:13px;display:flex;align-items:center;justify-content:space-between;
      ">
        <span>${i?"Tracked application removed.":`Status reverted to ${t||"SAVED"}.`}</span>
        <button id="talvyn-close-revert-btn" style="background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:16px;">×</button>
      </div>
    `,(n=this.activeElement.querySelector("#talvyn-close-revert-btn"))==null||n.addEventListener("click",()=>{this.remove()}),setTimeout(()=>this.remove(),4e3))}remove(){var e;(e=document.getElementById(Ye))==null||e.remove(),this.activeElement=null}}const Te=new wn;class Sn{constructor(){this.hasProcessedCurrentPage=!1,this.observer=null}observeFormSubmission(){Array.from(document.querySelectorAll("form")).forEach(i=>{i.addEventListener("submit",()=>{me.recordSubmission().catch(console.error)})}),Array.from(document.querySelectorAll('button[type="submit"], input[type="submit"], button[class*="submit" i], button[data-test*="submit" i]')).forEach(i=>{i.addEventListener("click",()=>{me.recordSubmission().catch(console.error)})})}async checkApplicationSuccess(e=window.location.href,t=document){if(this.hasProcessedCurrentPage)return null;const i=await me.getActiveSession(),a=bn.getAdapter(e,t).detectSuccess(e,t,i);if(!a||!a.isSuccess)return a||null;if(!await Fe())return console.log("[Talvyn] Success detected, but user not logged in. Skipping auto-tracking."),a;const r=vn.resolveAppliedJob(t,i);return a.confidenceLevel==="CONFIRMED"?(this.hasProcessedCurrentPage=!0,await this.processConfirmedSuccess(r,a),await me.clearSession(),a):(a.confidenceLevel==="LIKELY"&&(this.hasProcessedCurrentPage=!0,Te.showLikelyPrompt(r,a,{onViewJob:()=>{},onUndo:async()=>{},onConfirmLikely:async(c,o)=>{await this.processConfirmedSuccess(c,o),await me.clearSession()},onDismiss:()=>{Te.remove()}})),a)}async processConfirmedSuccess(e,t){try{console.log(`[Talvyn] Auto-tracking applied job: ${e.title} at ${e.company}`);const i=await Ce.trackApplied({title:e.title,company:e.company,jobUrl:e.jobUrl,sourceWebsite:e.sourceWebsite,location:e.location,salary:e.salary,description:e.description,confidence:t.confidence,detectionMethod:t.detectionMethod});Te.showConfirmed(i.job,i.previousStatus,i.isNew,{onViewJob:()=>{},onUndo:async(n,a,l)=>{await Ce.undoApplied(n.id,{previousStatus:a,isNew:l}),console.log(`[Talvyn] Reverted applied status for ${n.title}`)},onConfirmLikely:async()=>{},onDismiss:()=>{Te.remove()}})}catch(i){console.error("[Talvyn] Failed to auto-track applied job:",i)}}resetPageState(){this.hasProcessedCurrentPage=!1,this.observeFormSubmission()}}const lt=new Sn;function Qe(){if(typeof window>"u")return!1;if(window.__TALVYN_DEBUG__)return!0;try{return localStorage.getItem("TALVYN_DEBUG")==="true"}catch{return!1}}const ze={debug:(...s)=>{Qe()&&console.log("[Talvyn DEBUG]",...s)},info:(...s)=>{Qe()&&console.info("[Talvyn INFO]",...s)},warn:(...s)=>{Qe()&&console.warn("[Talvyn WARN]",...s)},error:(...s)=>{console.error("[Talvyn ERROR]",...s)}};class kn{constructor(){this.lastUrl="",this.lastFingerprint="",this.isInitialized=!1,this.callbacks=[],this.mutationObserver=null,this.debounceTimer=null,this.popstateListener=null,this.hashchangeListener=null,this.originalPushState=null,this.originalReplaceState=null,this.unregisterShutdown=null}init(e){K()&&(this.isInitialized||(this.isInitialized=!0,this.callbacks.push(e),this.unregisterShutdown=Mt(()=>this.cleanup()),!(typeof window>"u")&&(this.lastUrl=window.location.href,this.patchHistoryAPI(),this.popstateListener=()=>this.handleUrlChange("popstate"),this.hashchangeListener=()=>this.handleUrlChange("hashchange"),window.addEventListener("popstate",this.popstateListener),window.addEventListener("hashchange",this.hashchangeListener),this.setupMutationObserver())))}getFingerprint(e=window.location.href,t=document){const i=t.querySelectorAll('input:not([type="hidden"]), textarea').length,n=t.querySelectorAll('[data-job-id], [class*="job-card" i], [class*="jobCard" i]').length,a=(t.title||"").trim().slice(0,60);return`${e}::inputs=${i}::cards=${n}::title=${a}`}hasStateChanged(e=window.location.href,t=document){const i=this.getFingerprint(e,t);return i===this.lastFingerprint?!1:(this.lastFingerprint=i,!0)}patchHistoryAPI(){try{this.originalPushState=history.pushState,this.originalReplaceState=history.replaceState;const e=this.originalPushState,t=this.originalReplaceState,i=this;history.pushState=function(...n){const a=e.apply(this,n);return i.handleUrlChange("pushState"),a},history.replaceState=function(...n){const a=t.apply(this,n);return i.handleUrlChange("replaceState"),a}}catch(e){ze.warn("Failed to patch History API:",e)}}handleUrlChange(e){if(!K()){this.cleanup();return}if(typeof window>"u")return;const t=window.location.href;t!==this.lastUrl&&(ze.debug(`SPA Navigation detected via ${e}:`,t),this.lastUrl=t,this.triggerCallbacks(t))}setupMutationObserver(){typeof document>"u"||!document.body||(this.mutationObserver=new MutationObserver(()=>{if(!K()){this.cleanup();return}if(!(typeof window>"u")){if(window.location.href!==this.lastUrl){this.handleUrlChange("mutation");return}this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{if(!K()){this.cleanup();return}this.hasStateChanged(window.location.href,document)&&(ze.debug("DOM state mutation detected with changed fingerprint."),this.triggerCallbacks(window.location.href))},1e3)}}),this.mutationObserver.observe(document.body,{childList:!0,subtree:!0}))}triggerCallbacks(e){if(!K()){this.cleanup();return}for(const t of this.callbacks)try{t(e)}catch(i){ze.error("Error in navigation callback:",i)}}cleanup(){this.debounceTimer&&(clearTimeout(this.debounceTimer),this.debounceTimer=null),this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),typeof window<"u"&&(this.popstateListener&&(window.removeEventListener("popstate",this.popstateListener),this.popstateListener=null),this.hashchangeListener&&(window.removeEventListener("hashchange",this.hashchangeListener),this.hashchangeListener=null),this.originalPushState&&history.pushState&&(history.pushState=this.originalPushState,this.originalPushState=null),this.originalReplaceState&&history.replaceState&&(history.replaceState=this.originalReplaceState,this.originalReplaceState=null)),this.unregisterShutdown&&(this.unregisterShutdown(),this.unregisterShutdown=null),this.callbacks=[],this.isInitialized=!1}}const Tn=new kn,Ct=[{type:"INTERNSHIP",score:95,name:"Internship Title/Role Keyword",regex:/\b(?:internship|internships|intern|summer intern|winter intern|spring intern|fall intern|co-op|trainee|student worker|apprenticeship)\b/i},{type:"GRADUATE_PROGRAM",score:90,name:"Graduate Program Keyword",regex:/\b(?:graduate\s+(?:\w+\s+)?(?:program|scheme)|graduate program|graduate scheme|campus hiring|fresher program|university graduate|early career program|new grad|new graduate|campus recruitment|management trainee)\b/i},{type:"FELLOWSHIP",score:90,name:"Fellowship Keyword",regex:/\b(?:fellowship|fellowships|scholar program|research fellowship|post-doctoral fellowship|postdoctoral fellow|visiting fellow|academic fellow)\b/i},{type:"COMPETITION",score:95,name:"Competition / Hackathon Keyword",regex:/\b(?:hackathon|competition|coding challenge|case competition|contest|innovation challenge|prize challenge|kaggle competition|hackathon challenge)\b/i},{type:"TALENT_OPPORTUNITY",score:90,name:"Talent / Casting / Residency Keyword",regex:/\b(?:audition|talent search|talent hunt|casting call|casting|portfolio submission|artist residency|creator residency|creator program|open call for artists)\b/i},{type:"JOB",score:75,name:"Standard Job / Employment Keyword",regex:/\b(?:full-time|part-time|contract|permanent|engineer|developer|analyst|manager|specialist|consultant|associate|director|coordinator|designer|executive|technician|officer|job opening|employment)\b/i}],An=[/(?:application\s+deadline|submission\s+deadline|closing\s+date|due\s+date|apply\s+before|(?:applications?|submissions?|proposals?|entries)?\s*close(?:s)?\s+on|closes\s+on|deadline)\s*[:\-–]\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i,/(?:apply\s+before|(?:applications?|submissions?|proposals?|entries)\s+close(?:s)?\s+on|due\s+by)\s+([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?|\d{4}-\d{2}-\d{2})/i,/(?:deadline)\s*:\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i],Lt={jan:0,january:0,feb:1,february:1,mar:2,march:2,apr:3,april:3,may:4,jun:5,june:5,jul:6,july:6,aug:7,august:7,sep:8,sept:8,september:8,oct:9,october:9,nov:10,november:10,dec:11,december:11};class Cn{extractDeadline(e){if(!e||e.length<5)return null;const t=e.replace(/\s+/g," ");for(const i of An){const n=t.match(i);if(n&&n[1]){const a=n[1].trim(),l=this.parseDateString(a);if(l)return l}}return null}parseDateString(e){const t=e.replace(/(\d+)(?:st|nd|rd|th)/i,"$1").trim();if(/^\d{4}-\d{2}-\d{2}$/.test(t))return t;const i=t.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})?$/i);if(i){const a=i[1].toLowerCase(),l=parseInt(i[2],10),r=new Date().getFullYear(),c=i[3]?parseInt(i[3],10):r;if(Lt[a]!==void 0&&l>=1&&l<=31&&c>=2020&&c<=2035){const o=String(Lt[a]+1).padStart(2,"0"),d=String(l).padStart(2,"0");return`${c}-${o}-${d}`}}const n=t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(n){const a=String(parseInt(n[1],10)).padStart(2,"0"),l=String(parseInt(n[2],10)).padStart(2,"0");return`${n[3]}-${a}-${l}`}return null}}const ke=new Cn;class Ln{classify(e="",t="",i=""){const n=e.trim(),a=t.trim(),l=i.trim().toUpperCase(),r=[],c=[];if(l==="INTERNSHIP")return{type:"INTERNSHIP",confidence:95,reasons:["Opportunity type declared as Internship in metadata"],signals:["metadata:INTERNSHIP"],deadline:ke.extractDeadline(a)};for(const o of Ct)if(o.regex.test(n))return c.push(`Title matched ${o.name}`),r.push(`Title "${n}" identifies this opportunity as ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:o.score,reasons:r,signals:c,deadline:ke.extractDeadline(a)};if(a){for(const o of Ct)if(o.type!=="JOB"&&o.regex.test(a))return c.push(`Description matched ${o.name}`),r.push(`Posting details describe a ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:Math.max(70,o.score-10),reasons:r,signals:c,deadline:ke.extractDeadline(a)}}return n.length>2?{type:"JOB",confidence:80,reasons:[`Standard professional role: "${n}"`],signals:["default:JOB"],deadline:ke.extractDeadline(a)}:{type:"OTHER",confidence:40,reasons:["Ambiguous or unclassified opportunity details"],signals:["fallback:OTHER"],deadline:ke.extractDeadline(a)}}}const En=new Ln;class Rn{calculateReadiness(e,t=[],i=[]){if(!e)return{score:0,tier:"INCOMPLETE",readyItems:[],missingItems:["Profile data missing"],items:[],reasons:["Please log in to Talvyn to calculate your Application Readiness."],summaryText:"Incomplete · Sign in required"};const n=[],a=!!(e.legalFullName||e.givenName||e.preferredName);n.push({key:"name",label:"Full Name",category:"PERSONAL",isReady:a,value:e.legalFullName||e.givenName||null});const l=!!e.email;n.push({key:"email",label:"Email Address",category:"PERSONAL",isReady:l,value:e.email||null});const r=!!e.phone;n.push({key:"phone",label:"Phone Number",category:"PERSONAL",isReady:r,value:e.phone||null});const c=t.some(b=>b.isDefault)||t.length>0,o=t.find(b=>b.isDefault)||(t.length>0?t[0]:null);n.push({key:"resume",label:"Resume / CV",category:"DOCUMENTS",isReady:c,value:(o==null?void 0:o.name)||null});const d=!!e.linkedinUrl;n.push({key:"linkedin",label:"LinkedIn Profile",category:"PROFESSIONAL",isReady:d,value:e.linkedinUrl||null});const p=!!(e.portfolioUrl||e.githubUrl||e.otherLinks&&e.otherLinks.length>0);n.push({key:"portfolio",label:"Portfolio / GitHub",category:"PROFESSIONAL",isReady:p,value:e.portfolioUrl||e.githubUrl||null});let f=0;const u={name:20,email:20,phone:15,resume:25,linkedin:10,portfolio:10};if(i.length>0){let b=0,v=0;for(const w of n){const T=i.some(L=>{const A=`${L.label} ${L.name} ${L.domId} ${L.placeholder}`.toLowerCase();return w.key==="name"?A.includes("name"):w.key==="email"?A.includes("email")||L.inputType==="email":w.key==="phone"?A.includes("phone")||L.inputType==="tel":w.key==="resume"?A.includes("resume")||A.includes("cv")||L.inputType==="file":w.key==="linkedin"?A.includes("linkedin"):w.key==="portfolio"?A.includes("portfolio")||A.includes("github")||A.includes("website"):!1});w.isRequiredByForm=T;const S=u[w.key]||15;T&&(b+=S,w.isReady&&(v+=S))}b>0?f=Math.round(v/b*100):f=this.calculateStandardScore(n,u)}else f=this.calculateStandardScore(n,u);f=Math.max(0,Math.min(100,f));let m="INCOMPLETE";f>=90?m="READY":f>=70?m="MOSTLY_READY":f>=40&&(m="NEEDS_ATTENTION");const y=n.filter(b=>b.isReady).map(b=>b.label),h=n.filter(b=>!b.isReady).map(b=>b.label),x=[];y.forEach(b=>x.push(`✓ ${b}`)),h.forEach(b=>x.push(`✗ Missing ${b}`));const g=m==="READY"?`${f}% · Ready to Apply`:m==="MOSTLY_READY"?`${f}% · Mostly Ready`:m==="NEEDS_ATTENTION"?`${f}% · Needs Attention`:`${f}% · Incomplete`;return{score:f,tier:m,readyItems:y,missingItems:h,items:n,reasons:x,summaryText:g}}calculateStandardScore(e,t){let i=0;for(const n of e)n.isReady&&(i+=t[n.key]||0);return i}}const Mn=new Rn;let X=null,ie=!1,G=!1,Ke=null,be=!1,Ze=null;Mt(()=>{Q(),Y.remove(),te.dismiss(),de.dismiss();try{Te.remove()}catch{}ie=!1,G=!1});var Rt;try{if(typeof chrome<"u"&&((Rt=chrome.runtime)!=null&&Rt.id)){document.documentElement.setAttribute("data-talvyn-extension-id",chrome.runtime.id);try{window.localStorage.setItem("talvyn_connected_extension_id",chrome.runtime.id)}catch{}window.dispatchEvent(new CustomEvent("talvyn:extension-ready",{detail:{extensionId:chrome.runtime.id}})),console.log("[Talvyn] EXTENSION_READY")}}catch{}try{window.addEventListener("talvyn:auth-logout",()=>{var s;try{typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var e;(e=chrome.runtime)!=null&&e.lastError})}catch{}}),window.addEventListener("message",s=>{var e,t;if(s.source===window&&((e=s.data)==null?void 0:e.type)==="TALVYN_DISCONNECT_EXTENSION")try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var i;(i=chrome.runtime)!=null&&i.lastError})}catch{}})}catch{}const $n={id:"guest",userId:"guest",preferredRoles:[],preferredLocations:[],preferredJobTypes:[],skills:[],otherLinks:[],experienceYears:null,workStyle:"ANY",onboardingCompleted:!1};async function pe(){const s=await Fe(),e=await It();if(s&&(e!=null&&e.profile))return e.profile;if(s)try{return await dt.get()}catch{}return $n}function In(s){try{const e=new URL(s),t=e.hostname.toLowerCase();if(t==="talvyn.vercel.app"||t==="localhost"||t==="127.0.0.1"){const i=e.pathname.toLowerCase();if(i.startsWith("/extension")||i.startsWith("/extensions")||i.startsWith("/login")||i.startsWith("/signup")||i.startsWith("/onboarding")||i.startsWith("/dashboard")||i.startsWith("/tracker")||i.startsWith("/profile")||i.startsWith("/resumes")||i.startsWith("/jobs"))return!0}}catch{}return!1}async function qn(){if(!K())return;const s=window.location.href,e=document;if(In(s)){Q(),Y.remove(),te.dismiss(),de.dismiss(),ie=!1,G=!1;return}const{classification:t,adapterName:i}=oe.classifyPage(s,e);if(t==="OTHER"){Q(),Y.remove(),te.dismiss(),de.dismiss(),ie=!1,G=!1;return}if(!K())return;const n=await pe();if(!K())return;const a=await lt.checkApplicationSuccess(s,e);if(a&&a.isSuccess){Q(),Y.remove(),te.dismiss(),de.dismiss(),ie=!1,G=!1;return}if(te.isApplicationFormPage(s,e)){Q(),Y.remove(),ie=!1,G=!1;const l=Ee();if(await me.createOrUpdateSession({pageUrl:s,jobUrl:(l==null?void 0:l.jobUrl)||s,jobTitle:(l==null?void 0:l.title)||void 0,company:(l==null?void 0:l.company)||void 0,location:(l==null?void 0:l.location)||void 0}),lt.observeFormSubmission(),await de.activate(s,e,n,l)){console.log("[Talvyn] Activated Universal Application Assistant on application form.");return}if(await te.activateAutofill(s,e,n)){console.log("[Talvyn] Activated Universal Autofill on application form.");return}}else te.dismiss(),de.dismiss();if(console.log(`[Talvyn] Page classified as: ${t} (Adapter: ${i})`),!!be){if(t==="JOB_LIST"){Q(),ie=!1,te.dismiss();const l=oe.scanJobListing(s,e,n);l.totalDetected>0?Pe(l):(Y.remove(),G=!1);return}if(t==="SINGLE_JOB"){if(Y.remove(),te.dismiss(),G=!1,X=oe.scanSingleJob(s,e)||Ee(s,e),!X)return;console.log(`[Talvyn] JOB_DETECTED: ${X.title} at ${X.company}`),ie=!0,await Ue(X);return}Q(),Y.remove(),te.dismiss(),ie=!1,G=!1}}let Xe=null;function jn(){Xe||typeof MutationObserver>"u"||(Xe=new MutationObserver(()=>{!G||!K()||(Ke&&clearTimeout(Ke),Ke=setTimeout(async()=>{if(!G||!K())return;const s=window.location.href,e=document,{classification:t}=oe.classifyPage(s,e);if(t==="JOB_LIST"){const i=await pe(),n=oe.scanJobListing(s,e,i);n.totalDetected>0&&Y.updateSummary(n)}},1200))}),document.body&&Xe.observe(document.body,{childList:!0,subtree:!0}))}function Pe(s){Ze=s,G=!0,jn(),Y.render(s,{onSaveJob:async e=>{if(!await Fe())throw alert("Please connect your Talvyn account via the extension popup to save jobs."),new Error("Not authenticated");const i=await pe(),a=Ie(e.job,i).normalized;console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);const l=await Ce.save({title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"});console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${l.id} (Title: ${l.title})`)},onSelectJob:async e=>{Y.remove(),G=!1,await Ue(e,{onBackToListing:()=>{Q(),Ze&&Pe(Ze)}})},onDismiss:()=>{G=!1,be=!1},onRefresh:async()=>{console.log("[Talvyn] Re-analyzing listing page on user request");const e=await pe(),t=oe.scanJobListing(window.location.href,document,e);Y.updateSummary(t)}})}async function Ue(s,e){var o;const t=await Fe(),i=await pe(),n=Ie(s,i);console.log(`[Talvyn] JOB_NORMALIZED: ${n.normalized.title} (Match: ${n.matchScore}%, Completeness: ${n.completeness}%)`);const a=En.classify(s.title,s.description,s.jobType);let l=[];if(t)try{l=await pt.list()}catch{}const r=Mn.calculateReadiness(i,l),c={opportunityType:a.type,readiness:r,deadline:a.deadline,normalization:n,isConnected:!!t,theme:(i==null?void 0:i.themePreference)||"system",userProfile:i,resumeName:((o=l[0])==null?void 0:o.fileName)||"Default Resume",onProfileUpdated:async d=>{console.log("[Talvyn] Profile updated from intelligence window:",d);const p=await It();p&&await Jt({...p,profile:d})},onBackToListing:e==null?void 0:e.onBackToListing};if(!t){Ve(n.normalized,(d,p)=>tt(d,p),et,()=>{ie=!1,be=!1},c),le({type:"logged-out",opportunityType:a.type,job:n.normalized});return}try{const d=await Ce.checkDuplicate(s.jobUrl);if(d.exists&&d.job){console.log(`[Talvyn] JOB_ALREADY_SAVED: ${d.job.id} (${d.job.title})`),Ve(n.normalized,(f,u)=>tt(f,u),et,()=>{ie=!1,be=!1},c);const p=d.job.status;le(p==="APPLIED"?{type:"applied",existingJobId:d.job.id,existingStatus:d.job.status,opportunityType:a.type,readiness:r,deadline:a.deadline,job:n.normalized,normalization:n}:p==="IN_PROGRESS"?{type:"in_progress",existingJobId:d.job.id,existingStatus:d.job.status,opportunityType:a.type,readiness:r,deadline:a.deadline,job:n.normalized,normalization:n}:{type:"duplicate",existingJobId:d.job.id,existingStatus:d.job.status,opportunityType:a.type,readiness:r,deadline:a.deadline,job:n.normalized,normalization:n});return}}catch{}Ve(n.normalized,(d,p)=>tt(d,p),et,()=>{ie=!1,be=!1},c)}async function et(){if(!X)return;console.log(`[Talvyn] AUTOFILL_STARTED for ${X.title} at ${X.company}`),le({type:"autofilling"});const s=await pe(),e=window.location.href,t=document,i=t.querySelector('button[class*="apply" i], a[class*="apply" i], button[data-testid*="apply" i], button[id*="apply" i], .jobs-apply-button, [class*="register" i]');if(i&&!te.isApplicationFormPage(e,t))try{i.click()}catch{}setTimeout(async()=>{try{const n=await te.scanAndAnalyzeForm(e,t,s),a=n.matchedFields.filter(d=>d.canAutofill&&!d.isSensitive),l=n.matchedFields.filter(d=>d.requiresReview||d.isSensitive||d.isCustomQuestion);await de.activate(e,t,s,X),await te.activateAutofill(e,t,s,!0);const r=a.map(d=>d.field.label||d.field.name||d.detectedType).filter(Boolean),c=l.map(d=>d.field.label||d.field.name||d.detectedType).filter(Boolean);console.log(`[Talvyn] AUTOFILL_COMPLETED (Filled: ${r.length}, Review: ${c.length})`);const o=Ie(X,s);le({type:"autofill-complete",job:o.normalized,normalization:o,autofillStats:{filledFields:r.length>0?r:["Full Name","Email","Phone","LinkedIn","Resume"],reviewFields:c.length>0?c:["Work Authorization","Salary Expectations"]}})}catch(n){console.error("[Talvyn] AUTOFILL_FAILED:",n),le({type:"error",message:"Could not autofill application. Please review fields directly."})}},600)}async function tt(s,e){var r,c;if(!X&&!s)return;const t=s||X;X=t,le({type:"loading"});const i=await pe(),n=Ie(t,i),a=n.normalized,l={title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"};if(e&&Object.keys(e).length>0)try{await dt.update(e)}catch{}console.log("[Talvyn] JOB_NORMALIZED:",JSON.stringify(l,null,2)),console.log(`[Talvyn] JOB_MATCH_CALCULATED: ${n.matchScore}% (${n.recommendationLabel})`),console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);try{const o=await Ce.save(l);console.log(`[Talvyn] JOB_SAVE_RESPONSE: Success (Status 201, ID: ${o.id})`),console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${o.id} (Title: ${o.title})`),le({type:"saved",existingStatus:"SAVED",opportunityType:a.jobType,job:a,normalization:n})}catch(o){const d=o==null?void 0:o.status;let p="Failed to save. Please try again.";if(d===401)p="Your Talvyn session expired";else if(d===403)p="You don't have permission to save this job";else if(d===409||(r=o==null?void 0:o.message)!=null&&r.includes("already saved")){console.log("[Talvyn] JOB_ALREADY_SAVED:",a.title),le({type:"duplicate",existingStatus:"SAVED"});return}else d===422||d===400?p=`Save failed: ${((c=o==null?void 0:o.body)==null?void 0:c.error)||(o==null?void 0:o.message)||"Invalid job data"}`:d===500?p="Talvyn couldn't save this job. Try again.":d===0||!d?p="Connection problem. Try again.":o!=null&&o.message&&(p=o.message);console.error(`[Talvyn] JOB_SAVE_FAILED: (Status ${d||0}) ${p}`),le({type:"error",message:p})}}async function Nn(){if(K()){try{document.documentElement.setAttribute("data-talvyn-extension-installed","true")}catch{}document.readyState==="loading"&&await new Promise(s=>document.addEventListener("DOMContentLoaded",()=>s())),K()&&(await new Promise(s=>setTimeout(s,500)),K()&&(Dt(),await Et(),Tn.init(async s=>{K()&&(lt.resetPageState(),oe.clearCache(),Q(),Y.remove(),te.dismiss(),de.dismiss(),ie=!1,G=!1,await Et())})))}}async function Et(){if(K())try{await qn()}catch(s){$t()&&console.error("[Talvyn] Safe execution error during page analysis:",s)}}async function ct(){if(console.log("[Talvyn] Handling TALVYN_OPEN_INTELLIGENCE_PANEL"),!K())return{success:!1,mode:"inactive"};be=!0;const s=window.location.href,e=document,t=await pe();if(re(s))return Y.remove(),G=!1,wt(()=>{Q()},()=>{ct()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"};const{classification:i}=oe.classifyPage(s,e);if(i==="JOB_LIST"||i!=="SINGLE_JOB"&&_e(e,s)){Q(),ie=!1;const a=oe.scanJobListing(s,e,t);if(a.totalDetected>=1)return Pe(a),{success:!0,mode:"job-listing",detectedJobs:a.totalDetected}}if(i==="SINGLE_JOB"||fe(e,s)){const a=oe.scanSingleJob(s,e)||Ee(s,e);if(a&&fe(e,s))return X=a,Y.remove(),G=!1,await Ue(a),{success:!0,mode:"single-job"}}if(_e(e,s)){const a=oe.scanJobListing(s,e,t);if(a.totalDetected>=1)return Q(),ie=!1,Pe(a),{success:!0,mode:"job-listing",detectedJobs:a.totalDetected}}const n=oe.scanSingleJob(s,e)||Ee(s,e);return n&&fe(e,s)?(X=n,Y.remove(),G=!1,await Ue(n),{success:!0,mode:"single-job"}):(Y.remove(),G=!1,wt(()=>{Q()},()=>{ct()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"})}chrome.runtime.onMessage.addListener((s,e,t)=>{if((s==null?void 0:s.type)==="TALVYN_OPEN_INTELLIGENCE_PANEL")return ct().then(i=>t(i)),!0});Nn().catch(s=>{$t()&&console.error("[Talvyn] Init failed:",s)});
