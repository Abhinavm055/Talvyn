import{a as We,C as le,d as Oe,i as B,o as wt,e as Tt,f as qt,h as At,j as Ot}from"./apiClient-CDeLsrBN.js";import{j as Te}from"./jobsService-BuEU-K8d.js";const zt=[{domain:"youtube.com"},{domain:"youtu.be"},{domain:"google.com",allowedSubdomains:["careers.google.com"]},{domain:"facebook.com",allowedSubdomains:["metacareers.com"]},{domain:"instagram.com"},{domain:"twitter.com"},{domain:"x.com"},{domain:"reddit.com"},{domain:"wikipedia.org"},{domain:"amazon.com",allowedSubdomains:["amazon.jobs"]},{domain:"netflix.com",allowedSubdomains:["jobs.netflix.com"]},{domain:"nytimes.com"},{domain:"cnn.com"},{domain:"bbc.com"},{domain:"medium.com"},{domain:"substack.com"},{domain:"twitch.tv"},{domain:"vimeo.com"},{domain:"tiktok.com"},{domain:"quora.com"}];function ae(s){try{const e=new URL(s),t=e.hostname.toLowerCase().replace(/^www\./,""),n=e.pathname.toLowerCase();for(const i of zt)if(t===i.domain||t.endsWith(`.${i.domain}`))return!(i.allowedSubdomains&&i.allowedSubdomains.some(r=>t===r||t.endsWith(`.${r}`))||i.domain==="google.com"&&n.startsWith("/about/careers"));return!1}catch{return!1}}const Ht=[/\/jobs?\/\d+/i,/\/jobs?\/[a-zA-Z0-9_-]+-[a-zA-Z0-9_-]+/i,/\/careers?\/[a-zA-Z0-9_-]+/i,/\/positions?\/[a-zA-Z0-9_-]+/i,/\/openings?\/[a-zA-Z0-9_-]+/i,/\/vacancies?\/[a-zA-Z0-9_-]+/i,/\/viewjob/i,/linkedin\.com\/jobs\/view/i,/indeed\.com\/(viewjob|rc\/clk)/i,/unstop\.com\/(jobs|internships|competitions)\/[a-zA-Z0-9_-]+/i,/glassdoor\.com\/job-listing/i,/boards\.greenhouse\.io\/[^/]+\/jobs/i,/jobs\.lever\.co\/[^/]+\/[a-f0-9-]+/i,/jobs\.ashbyhq\.com\/[^/]+\/[a-f0-9-]+/i,/myworkdayjobs\.com\/[^/]+\/job\//i,/smartrecruiters\.com\/[^/]+\/[a-f0-9-]+/i];function _t(s,e){var b,v,S,T,k;const t=[],n=[];let i=0;if(ae(e))return n.push("Domain is identified as non-job platform (video, social, news, or search engine)"),{score:0,isConfidentJob:!1,signals:t,disqualifiers:n,rejectionReason:"Page is on a known non-job domain."};s.querySelector("ytd-watch-flexy, ytd-search, ytd-app, #movie_player, video.html5-main-video, .vjs-tech")&&(n.push("Contains primary video player elements (YouTube / Video stream)"),i-=60),s.querySelector("#rso, #search, .g .rc, div[data-sokoban-container]")&&(n.push("Contains Google SERP search result elements"),i-=60),s.querySelector('#add-to-cart-button, [name="submit.add-to-cart"], button[class*="add-to-cart" i]')&&(n.push("Contains e-commerce shopping cart elements"),i-=60);const a=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];let r=!1;for(const A of Array.from(a)){try{const w=JSON.parse(A.textContent||"{}"),C=Array.isArray(w)?w:[w];for(const L of C)if(L["@type"]==="JobPosting"&&typeof L.title=="string"&&L.title.trim().length>=3){r=!0,t.push(`Schema.org JobPosting found with title: "${L.title.trim()}"`),i+=50,((b=L.hiringOrganization)!=null&&b.name||L.employerOverview)&&(t.push(`Hiring organization: ${((v=L.hiringOrganization)==null?void 0:v.name)||L.employerOverview}`),i+=15),L.description&&(t.push("Job description present in JSON-LD"),i+=15);break}}catch{}if(r)break}const l=Ht.some(A=>A.test(e));l&&(t.push("URL matches verified job or career detail path"),i+=25);const c=s.querySelectorAll?Array.from(s.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]')):[],o=/^(apply(\s+now|\s+online|\s+for\s+this\s+job|\s+here)?|submit\s+application|easy\s+apply|apply\s+with\s+talvyn)$/i;let d=!1;for(const A of c){const w=((S=A.textContent)==null?void 0:S.trim())||((T=A.value)==null?void 0:T.trim())||"";if(o.test(w)){d=!0,t.push(`Explicit application control: "${w}"`),i+=25;break}}const p=s.querySelectorAll?Array.from(s.querySelectorAll("h1, h2, h3, h4")):[],u=[/responsibilities/i,/qualifications/i,/requirements/i,/what you('ll| will) do/i,/about the (role|position|job)/i,/role overview/i,/experience required/i,/who you are/i,/key responsibilities/i];let m=0;for(const A of p){const w=((k=A.textContent)==null?void 0:k.trim())||"";u.some(C=>C.test(w))&&m++}m>=2?(t.push(`${m} job requirement/responsibility sections found`),i+=25):m===1&&(t.push("Job requirement section heading found"),i+=15);const f=s.body&&s.body.textContent||"";/\b(full[ -]time|part[ -]time|contract|internship|remote|hybrid|on-site)\b/i.test(f)&&(t.push("Employment type keywords detected in page content"),i+=10),/([$€£₹]\s*[\d,]+|\b\d+\s*-\s*\d+\s*(lpa|k|usd|eur|gbp|inr)\b|\bper\s+(year|annum|month|hour)\b)/i.test(f)&&(t.push("Salary or compensation indicators detected"),i+=10),/\b(\d+\+?\s*years?(\s+of)?\s+experience|fresher|entry[ -]level|bachelor'?s(\s+degree)?|master'?s|b\.?tech|b\.?e\.)\b/i.test(f)&&(t.push("Experience or education requirements mentioned"),i+=10);const g=i>=50&&n.length===0&&(r||l||d||m>=1);return{score:i,isConfidentJob:g,signals:t,disqualifiers:n,rejectionReason:g?void 0:n.length>0?n.join("; "):"Insufficient verified job signals (minimum confidence score not met)."}}function be(s,e){return ae(e)?!1:_t(s,e).isConfidentJob}function Ct(s){var b,v,S,T,k;const e=((b=s.textContent)==null?void 0:b.trim())||"";if(e.length<15)return{isValid:!1,signals:[],reason:"Card content too brief"};if(/\b\d+(\.\d+)?[KM]?\s+views\b/i.test(e)||/\b(subscribers?|playlist|episodes?|season\s+\d+)\b/i.test(e)||s.querySelector("ytd-thumbnail, .ytd-thumbnail, ytd-video-renderer, #video-title"))return{isValid:!1,signals:[],reason:"Card contains video player / view count indicators"};if(/\b(add to cart|buy now|in stock|free delivery|eligible for free)\b/i.test(e)||s.querySelector('[class*="add-to-cart" i]'))return{isValid:!1,signals:[],reason:"Card contains e-commerce purchase indicators"};const t=s.querySelector('h1, h2, h3, h4, [class*="job-title" i], [class*="title" i], a[class*="job" i]'),n=(t==null?void 0:t.tagName)==="A"?t:s.querySelector("a"),i=((v=t==null?void 0:t.textContent)==null?void 0:v.trim())||((S=n==null?void 0:n.textContent)==null?void 0:S.trim())||"";if(!i||i.length<3||i.length>140)return{isValid:!1,signals:[],reason:"No valid title element found in card"};if(/^(home|about|careers|jobs|login|sign in|privacy|terms|menu|search|share|watch|video|playlist|trending)$/i.test(i))return{isValid:!1,signals:[],reason:"Title matches generic navigation/media keyword"};const r=s.querySelector('[class*="company" i], [class*="employer" i], [class*="org" i], [class*="hiring" i]');let l=((T=r==null?void 0:r.textContent)==null?void 0:T.trim())||"";if(!l){const A=s.closest('[class*="job" i], [id*="job" i]'),w=A==null?void 0:A.querySelector('[class*="company" i], [class*="employer" i]');l=((k=w==null?void 0:w.textContent)==null?void 0:k.trim())||""}const c=[];(!!s.querySelector('[class*="location" i], [class*="city" i], [class*="place" i]')||/\b(remote|hybrid|on-site|in-office|[A-Z][a-zA-Z]+,\s*[A-Z]{2})\b/i.test(e))&&c.push("location"),/\b(\d+\+?\s*years?|fresher|entry[ -]level|mid[ -]senior|intern)\b/i.test(e)&&c.push("experience");const p=!!s.querySelector('[class*="salary" i], [class*="stipend" i], [class*="pay" i]')||/([$€£₹]\s*[\d,]+|\b\d+\s*-\s*\d+\s*(lpa|k)\b|\bper\s+(month|year|hr)\b)/i.test(e);p&&c.push("salary");const u=/\b(full[ -]time|part[ -]time|contract|internship|intern|campus\s+ambassador|freelance)\b/i.test(e);u&&c.push("jobType");const m=n!=null&&n.href?n:s.querySelector("a"),f=(m==null?void 0:m.href)||"",y=/\/jobs?\//i.test(f)||/\/careers?\//i.test(f)||/\/position\//i.test(f)||/\/apply/i.test(f)||/viewjob/i.test(f)||/unstop\.com\/(jobs|internships|opportunity|p)\//i.test(f)||/\/(opportunity|p)\//i.test(f);y&&c.push("jobLink"),(!!s.querySelector('[class*="snippet" i], [class*="summary" i], [class*="description" i]')||/\b(responsibilities|qualifications|skills|requirements|eligibility|apply\s+by)\b/i.test(e))&&c.push("jobSnippet");const x=!!(l&&l.length>=2);return x&&c.length>=1||!x&&c.length>=2&&(y||u||p)?{isValid:!0,title:i,company:l||"Unknown Company",signals:c}:{isValid:!1,title:i,company:l,signals:c,reason:`Card lacks sufficient verified job signals (found ${c.length}: ${c.join(", ")})`}}function Ie(s,e){if(ae(e))return!1;const t=e.toLowerCase(),n=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const l of Array.from(n))try{const c=JSON.parse(l.textContent||"{}"),o=Array.isArray(c)?c:[c];for(const d of o)if(d["@type"]==="ItemList"&&Array.isArray(d.itemListElement)&&d.itemListElement.filter(u=>(u.item||u)["@type"]==="JobPosting").length>=2)return!0}catch{}const i=/linkedin\.com\/jobs/i.test(t)||/indeed\.com\/jobs/i.test(t)||/unstop\.com\/(jobs|internships|all-opportunities|competitions)/i.test(t)||t.includes("opportunity=")||/glassdoor\.com\/job-listing/i.test(t)||/careers\.[a-z0-9-]+\.[a-z]+/i.test(t)||/\/careers?\/?(\?.*)?$/i.test(t)||/\/jobs?\/?(\?.*)?$/i.test(t)||/\/openings\/?(\?.*)?$/i.test(t)||/\/vacancies\/?(\?.*)?$/i.test(t),a=s.querySelectorAll?Array.from(s.querySelectorAll('[class*="job-card" i], [class*="jobCard" i], [class*="job-listing" i], [class*="job-item" i], [data-job-id], article[class*="job" i], li[class*="job" i], .card[class*="job" i], [class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="listing_card" i], .single_opportunity, [class*="opportunity" i]')):[];let r=0;for(const l of a)if(Ct(l).isValid&&(r++,r>=2))return!0;return!!(i&&(r>=1||a.length>=2))}class Ft{constructor(){this.name="Generic"}canHandle(){return!0}isJobDetailPage(e,t){return ae(e)?!1:be(t,e)}isJobListingPage(e,t){return ae(e)?!1:Ie(t,e)}extractJobList(e){const t=typeof window<"u"?window.location.href:"";if(ae(t))return[];const n=[],i=new Set,a=this.extractFromJsonLd(e);for(const l of a)l.jobUrl&&!i.has(l.jobUrl)&&(i.add(l.jobUrl),n.push(l));if(n.length>=2)return n;const r=['[class*="job-card" i]','[class*="jobCard" i]','[class*="job-listing" i]','[class*="job-item" i]','[class*="job_item" i]','[class*="job-result" i]',"[data-job-id]",'[data-testid*="job" i]','article[class*="job" i]','li[class*="job" i]','div[class*="opening" i]','div[class*="posting" i]','.card[class*="job" i]','tr[class*="job" i]',".resultContent"];for(const l of r){const c=Array.from(e.querySelectorAll(l));if(c.length>=2){for(const o of c){const d=o;if(!Ct(d).isValid)continue;const u=this.extractCardData(d);u&&u.title&&!i.has(u.jobUrl)&&(i.add(u.jobUrl),n.push(u))}if(n.length>=2)break}}return n}extractSingleJob(e){var u,m,f,y,h,x,g,b,v,S,T,k,A,w;const t=typeof window<"u"?window.location.href:"";if(ae(t)||!be(e,t))return null;const n=this.extractFromJsonLd(e);if(n.length===1&&n[0].title){const C=n[0];if(!C.description){const L=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main');L&&(C.description=(u=L.textContent)==null?void 0:u.replace(/\s+/g," ").trim().slice(0,3e3))}return C}const i=e.querySelector("h1");let a=((m=i==null?void 0:i.textContent)==null?void 0:m.trim())||"";if(!a||a.length<3||a.length>150){const C=(f=e.querySelector('meta[property="og:title"], meta[name="title"]'))==null?void 0:f.content;C&&C.length>=3&&C.length<=150&&(a=C)}if(!a||a.length<3||a.length>150)return null;const r=((h=(y=e.querySelector('[class*="company-name" i], [class*="companyName" i], [class*="employer" i], [class*="org-name" i], [class*="company" i], [class*="org" i]'))==null?void 0:y.textContent)==null?void 0:h.trim())||((g=(x=e.querySelector('meta[property="og:site_name"]'))==null?void 0:x.content)==null?void 0:g.trim())||"Unknown Company",l=(v=(b=e.querySelector('[class*="location" i], [class*="city" i], [class*="workplace" i], [itemprop="addressLocality"]'))==null?void 0:b.textContent)==null?void 0:v.trim(),c=(T=(S=e.querySelector('[class*="salary" i], [class*="compensation" i], [class*="stipend" i], [class*="pay" i]'))==null?void 0:S.textContent)==null?void 0:T.trim(),o=(A=(k=e.querySelector('[class*="job-type" i], [class*="employment-type" i], [class*="work-type" i]'))==null?void 0:k.textContent)==null?void 0:A.trim(),d=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main'),p=(w=d==null?void 0:d.textContent)==null?void 0:w.replace(/\s+/g," ").trim().slice(0,3e3);return{title:a,company:r,location:l,salary:c,jobType:o,description:p,jobUrl:t,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}extractFromJsonLd(e){const t=[],n=e.querySelectorAll?e.querySelectorAll('script[type="application/ld+json"]'):[];for(const i of Array.from(n))try{const a=JSON.parse(i.textContent||"{}"),r=Array.isArray(a)?a:[a];for(const l of r)if(l["@type"]==="ItemList"&&Array.isArray(l.itemListElement))for(const c of l.itemListElement){const o=c.item||c;(o["@type"]==="JobPosting"||o.title)&&t.push(this.formatJsonLdJob(o))}else l["@type"]==="JobPosting"&&t.push(this.formatJsonLdJob(l))}catch{}return t}formatJsonLdJob(e){var t,n,i,a,r,l,c,o,d,p,u;return{title:e.title||e.name||"Untitled Position",company:((t=e.hiringOrganization)==null?void 0:t.name)||e.employerOverview||"Unknown Company",location:typeof e.jobLocation=="string"?e.jobLocation:((i=(n=e.jobLocation)==null?void 0:n.address)==null?void 0:i.addressLocality)||((r=(a=e.jobLocation)==null?void 0:a.address)==null?void 0:r.addressRegion),salary:((c=(l=e.baseSalary)==null?void 0:l.value)==null?void 0:c.value)||((d=(o=e.baseSalary)==null?void 0:o.value)!=null&&d.minValue&&((u=(p=e.baseSalary)==null?void 0:p.value)!=null&&u.maxValue)?`${e.baseSalary.value.minValue}–${e.baseSalary.value.maxValue} ${e.baseSalary.value.unitText||""}`:void 0),jobType:e.employmentType,jobUrl:e.url||(typeof window<"u"?window.location.href:""),sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"HIGH"}}extractCardData(e){var h,x,g,b,v,S,T;const t=e.querySelector('h1, h2, h3, h4, [class*="job-title" i], [class*="title" i], [class*="role" i], a[class*="job" i]'),n=(t==null?void 0:t.tagName)==="A"?t:e.querySelector("a"),i=((h=t==null?void 0:t.textContent)==null?void 0:h.trim())||((x=n==null?void 0:n.textContent)==null?void 0:x.trim());if(!i||i.length<3||i.length>150)return null;const a=(n==null?void 0:n.href)||(typeof window<"u"?window.location.href:""),r=e.querySelector('[class*="company" i], [class*="employer" i], [class*="org" i], [class*="sub-title" i], [class*="subtitle" i]'),l=((g=r==null?void 0:r.textContent)==null?void 0:g.trim())||"Unknown Company",c=e.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="region" i]'),o=(b=c==null?void 0:c.textContent)==null?void 0:b.trim(),d=e.querySelector('[class*="salary" i], [class*="compensation" i], [class*="pay" i], [class*="wage" i]'),p=(v=d==null?void 0:d.textContent)==null?void 0:v.trim(),u=e.querySelector('[class*="job-type" i], [class*="employment" i], [class*="work-type" i]'),m=(S=u==null?void 0:u.textContent)==null?void 0:S.trim(),f=e.querySelector('[class*="snippet" i], [class*="description" i], [class*="summary" i], p'),y=(T=f==null?void 0:f.textContent)==null?void 0:T.trim().slice(0,1e3);return{title:i,company:l,location:o,salary:p,jobType:m,description:y,jobUrl:a,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}}class Pt{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isJobDetailPage(e,t){return/\/jobs\/view\//i.test(e)||/\/jobs\/collections\//i.test(e)||!!t.querySelector(".job-details-jobs-unified-top-card__job-title")}isJobListingPage(e,t){return/\/jobs\/search/i.test(e)||/\/jobs\/collections/i.test(e)||t.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card").length>=2}extractJobList(e){var a,r,l;const t=[],n=new Set,i=Array.from(e.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card, div[data-job-id]"));for(const c of i){const o=c.querySelector(".job-card-list__title, .base-search-card__title, .job-card-container__link, h3"),d=c.querySelector("a"),p=c.querySelector(".job-card-container__primary-description, .base-search-card__subtitle, .job-card-container__company-name"),u=c.querySelector(".job-card-container__metadata-item, .job-search-card__location, .job-card-container__metadata-wrapper"),m=(a=o==null?void 0:o.textContent)==null?void 0:a.trim(),f=(d==null?void 0:d.href)||(typeof window<"u"?window.location.href:"");m&&m.length>2&&!n.has(f)&&(n.add(f),t.push({title:m,company:((r=p==null?void 0:p.textContent)==null?void 0:r.trim())||"LinkedIn Poster",location:(l=u==null?void 0:u.textContent)==null?void 0:l.trim(),jobUrl:f,sourceWebsite:"LinkedIn",confidence:"HIGH"}))}return t}extractSingleJob(e){var r,l,c,o,d,p,u,m;const t=(l=(r=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:r.textContent)==null?void 0:l.trim();if(!t)return null;const n=((o=(c=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:c.textContent)==null?void 0:o.trim())||"LinkedIn Poster",i=(p=(d=e.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(m=(u=e.querySelector(".jobs-description__content, #job-details"))==null?void 0:u.textContent)==null?void 0:m.trim();return{title:t,company:n,location:i,description:a,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"LinkedIn",confidence:"HIGH"}}}function Ut(s){var e,t,n,i,a;try{const r=s.querySelectorAll('script[type="application/ld+json"]');for(const l of Array.from(r)){const c=l.textContent;if(!c)continue;const o=JSON.parse(c),d=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((n=o==null?void 0:o.author)==null?void 0:n.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(i=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:i.hiringOrganization)==null?void 0:a.name);if(d&&typeof d=="string"&&d.trim().length>0)return d.trim()}}catch{}}class Dt{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isJobDetailPage(e,t){return/\/viewjob/i.test(e)||/\/rc\/clk/i.test(e)||!!t.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')||!!t.querySelector("h1.jobsearch-JobInfoHeader-title")}isJobListingPage(e,t){return/\/jobs/i.test(e)||t.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]').length>=2}extractJobList(e){var a,r,l,c;const t=[],n=new Set,i=Array.from(e.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]'));for(const o of i){const d=o.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h2.jobTitle, a[data-jk], a[id^="job_"], span[id^="jobTitle"]'),p=(d==null?void 0:d.tagName)==="A"?d:o.querySelector('a[data-jk], a[id^="job_"]'),u=o.querySelector('[data-testid="company-name"], [data-testid="inlineHeader-companyName"], span[data-testid="company-name"], a[data-testid="company-name"], .companyName, .company-name, [class*="companyName"], [class*="company_location"] span, .icl-u-lg-mr--sm'),m=o.querySelector('[data-testid="text-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation, [class*="companyLocation"]'),f=o.querySelector('[data-testid="attribute_snippet_testid"], .salary-snippet-container, [class*="salary-snippet"], #salaryInfoAndJobType'),y=(a=d==null?void 0:d.textContent)==null?void 0:a.trim(),h=(p==null?void 0:p.href)||window.location.href,x=(r=u==null?void 0:u.textContent)==null?void 0:r.trim(),g=x&&x.length>0?x:"Unknown Company";y&&y.length>2&&!n.has(h)&&(n.add(h),t.push({title:y,company:g,location:(l=m==null?void 0:m.textContent)==null?void 0:l.trim(),salary:(c=f==null?void 0:f.textContent)==null?void 0:c.trim(),jobUrl:h,sourceWebsite:"Indeed",confidence:"HIGH"}))}return t}extractSingleJob(e){var c,o,d,p,u,m,f,y,h;const t=(o=(c=e.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"]'))==null?void 0:c.textContent)==null?void 0:o.trim();if(!t)return null;const n=e.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="inlineHeader-companyName"] span, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, div[data-testid="jobsearch-CompanyInfoContainer"] span, .companyName, .icl-u-lg-mr--sm, [class*="companyName"]'),i=((d=n==null?void 0:n.textContent)==null?void 0:d.trim())||Ut(e)||"Unknown Company",a=(u=(p=e.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:p.textContent)==null?void 0:u.trim(),r=(f=(m=e.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:m.textContent)==null?void 0:f.trim(),l=(h=(y=e.querySelector('#jobDescriptionText, [data-testid="jobsearch-JobComponent-description"]'))==null?void 0:y.textContent)==null?void 0:h.trim();return{title:t,company:i,location:a,salary:r,description:l,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Indeed",confidence:"HIGH"}}}class Jt{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isJobDetailPage(e,t){return/\/jobs\/\d+/i.test(e)||!!t.querySelector(".app-title, #app_body, form#application_form")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll(".opening, tr.job, div.level-0").length>=1}extractJobList(e){var r,l,c,o;const t=[],n=new Set,i=((l=(r=e.querySelector(".company-name, #header .logo span, h1"))==null?void 0:r.textContent)==null?void 0:l.trim())||"Greenhouse Employer",a=Array.from(e.querySelectorAll('.opening, tr.job, div[class*="opening"]'));for(const d of a){const p=d.querySelector("a"),u=(c=p==null?void 0:p.textContent)==null?void 0:c.trim(),m=d.querySelector(".location"),f=(p==null?void 0:p.href)||window.location.href;u&&u.length>2&&!n.has(f)&&(n.add(f),t.push({title:u,company:i,location:(o=m==null?void 0:m.textContent)==null?void 0:o.trim(),jobUrl:f,sourceWebsite:"Greenhouse",confidence:"HIGH"}))}return t}extractSingleJob(e){var r,l,c,o,d,p,u,m;const t=(l=(r=e.querySelector(".app-title, h1.heading"))==null?void 0:r.textContent)==null?void 0:l.trim();if(!t)return null;const n=((o=(c=e.querySelector(".company-name, .logo span"))==null?void 0:c.textContent)==null?void 0:o.trim())||"Greenhouse Employer",i=(p=(d=e.querySelector(".location"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(m=(u=e.querySelector("#content"))==null?void 0:u.textContent)==null?void 0:m.trim();return{title:t,company:n,location:i,description:a,jobUrl:window.location.href,sourceWebsite:"Greenhouse",confidence:"HIGH"}}}class Bt{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isJobDetailPage(e,t){return/\/jobs\.lever\.co\/[^/]+\/[a-zA-Z0-9_-]{10,}/i.test(e)||/\/apply\/?$/i.test(e)||!!t.querySelector(".posting-header h2, .application-page")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll('.posting, div[data-qa="posting-category"]').length>=1}extractJobList(e){var r,l,c,o,d,p,u;const t=[],n=new Set,i=((r=e.querySelector(".main-header-logo img"))==null?void 0:r.getAttribute("alt"))||((c=(l=e.querySelector(".posting-headline .sort-by-team"))==null?void 0:l.textContent)==null?void 0:c.trim())||"Lever Employer",a=Array.from(e.querySelectorAll(".posting"));for(const m of a){const f=m.querySelector(".posting-title, a.posting-btn-submit, a"),y=m.querySelector('h5[data-qa="posting-name"], .posting-title h5, h5'),h=m.querySelector(".sort-by-location, .posting-categories .location"),x=m.querySelector(".sort-by-commitment, .posting-categories .commitment"),g=((o=y==null?void 0:y.textContent)==null?void 0:o.trim())||((d=f==null?void 0:f.textContent)==null?void 0:d.trim()),b=(f==null?void 0:f.href)||window.location.href;g&&g.length>2&&!n.has(b)&&(n.add(b),t.push({title:g,company:i,location:(p=h==null?void 0:h.textContent)==null?void 0:p.trim(),jobType:(u=x==null?void 0:x.textContent)==null?void 0:u.trim(),jobUrl:b,sourceWebsite:"Lever",confidence:"HIGH"}))}return t}extractSingleJob(e){var l,c,o,d,p,u,m,f,y;const t=(c=(l=e.querySelector(".posting-headline h2"))==null?void 0:l.textContent)==null?void 0:c.trim();if(!t)return null;const n=((o=e.querySelector(".main-header-logo img"))==null?void 0:o.getAttribute("alt"))||"Lever Employer",i=(p=(d=e.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:d.textContent)==null?void 0:p.trim(),a=(m=(u=e.querySelector(".commitment, .posting-categories .sort-by-commitment"))==null?void 0:u.textContent)==null?void 0:m.trim(),r=(y=(f=e.querySelector(".section-wrapper, .posting-page"))==null?void 0:f.textContent)==null?void 0:y.trim();return{title:t,company:n,location:i,jobType:a,description:r,jobUrl:window.location.href,sourceWebsite:"Lever",confidence:"HIGH"}}}class Gt{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const a=new URL(e,"https://jobs.ashbyhq.com").pathname.split("/").filter(Boolean).length>=2,r=!!t.querySelector('form, [data-ashby-job-posting], [class*="applicationForm" i]'),l=!!t.querySelector('h1, [class*="jobTitle" i], [class*="heading" i]');return a&&l||r}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]').length>=2:!1}extractJobList(e){var r,l;const t=[],n=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",i=this.extractCompanyFromUrl(n)||"Company",a=Array.from(e.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]'));for(const c of a){const o=c.tagName==="A"?c:c.querySelector("a"),d=c.querySelector('h2, h3, h4, [class*="title" i], strong')||o,p=c.querySelector('[class*="location" i], [class*="metadata" i]'),u=(r=d==null?void 0:d.textContent)==null?void 0:r.trim(),m=(o==null?void 0:o.href)||n,f=(l=p==null?void 0:p.textContent)==null?void 0:l.trim();u&&u.length>2&&t.push({title:u,company:i,jobUrl:m,sourceWebsite:"Ashby",location:f||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var u,m,f,y,h;const t=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",n=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'),i=(u=n==null?void 0:n.textContent)==null?void 0:u.trim();if(!i)return null;const a=this.extractCompanyFromUrl(t)||((m=e.querySelector('[class*="company" i], header img'))==null?void 0:m.getAttribute("alt"))||"Company",r=e.querySelector('[class*="location" i], [data-testid="job-location"]'),l=((f=r==null?void 0:r.textContent)==null?void 0:f.trim())||void 0,c=e.querySelector('[class*="compensation" i], [class*="salary" i]'),o=((y=c==null?void 0:c.textContent)==null?void 0:y.trim())||void 0,d=e.querySelector('[class*="description" i], [class*="jobBody" i], main'),p=((h=d==null?void 0:d.textContent)==null?void 0:h.trim())||void 0;return{title:i,company:a,jobUrl:t,sourceWebsite:"Ashby",location:l,salary:o,description:p,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const n=new URL(e).pathname.split("/").filter(Boolean);if(n.length>0)return n[0].replace(/[-_]/g," ")}catch{}return null}}class Vt{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),i=!!t.querySelector('a[href*="/apply"], button[data-qa="apply-button"], .st-apply'),a=/\/jobs\/[a-zA-Z0-9_-]+/i.test(e);return n&&i||a}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('.opening-job, .job-item, li.opening, a[href*="smartrecruiters.com/"][href*="/"]').length>=2:!1}extractJobList(e){var r,l,c,o;const t=[],n=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",i=((l=(r=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:r.textContent)==null?void 0:l.trim())||"Company",a=Array.from(e.querySelectorAll('.opening-job, .job-item, li.opening, [class*="job-item" i]'));for(const d of a){const p=d.querySelector("a"),u=d.querySelector('h3, h4, .job-title, [data-qa="job-title"]')||p,m=d.querySelector('.job-location, .location, [data-qa="job-location"]'),f=(c=u==null?void 0:u.textContent)==null?void 0:c.trim(),y=(p==null?void 0:p.href)||n,h=(o=m==null?void 0:m.textContent)==null?void 0:o.trim();f&&f.length>2&&t.push({title:f,company:i,jobUrl:y,sourceWebsite:"SmartRecruiters",location:h||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var p,u,m,f;const t=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",n=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),i=(p=n==null?void 0:n.textContent)==null?void 0:p.trim();if(!i)return null;const a=e.querySelector('.company-name, [data-qa="company-name"], .job-header .company'),r=((u=a==null?void 0:a.textContent)==null?void 0:u.trim())||this.extractCompanyFromUrl(t)||"Company",l=e.querySelector('.job-location, [data-qa="job-location"], .spl-location'),c=((m=l==null?void 0:l.textContent)==null?void 0:m.trim())||void 0,o=e.querySelector(".job-sections, #job-details, .job-detail"),d=((f=o==null?void 0:o.textContent)==null?void 0:f.trim())||void 0;return{title:i,company:r,jobUrl:t,sourceWebsite:"SmartRecruiters",location:c,description:d,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const n=new URL(e).pathname.split("/").filter(Boolean);if(n.length>0&&n[0]!=="jobs")return n[0].replace(/[-_]/g," ")}catch{}return null}}function lt(s){try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const n of t)e.searchParams.delete(n);return e.toString()}catch{return s}}function Wt(s){var e,t,n,i,a;try{const r=s.querySelectorAll('script[type="application/ld+json"]');for(const l of Array.from(r)){const c=l.textContent;if(!c)continue;const o=JSON.parse(c),d=(o==null?void 0:o["@type"])==="JobPosting"?o:Array.isArray(o==null?void 0:o["@graph"])?o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"):o;if(d){const p=((e=d==null?void 0:d.hiringOrganization)==null?void 0:e.name)||((t=d==null?void 0:d.hiringOrganization)==null?void 0:t.legalName)||((n=d==null?void 0:d.author)==null?void 0:n.name),u=((i=d==null?void 0:d.jobLocation)==null?void 0:i.address)||(d==null?void 0:d.jobLocation);let m="";typeof u=="string"?m=u:u&&(m=[u.addressLocality,u.addressRegion,u.addressCountry].filter(Boolean).join(", "));let f="";const y=((a=d==null?void 0:d.baseSalary)==null?void 0:a.value)||(d==null?void 0:d.baseSalary);return y&&(typeof y=="string"||typeof y=="number"?f=String(y):y.minValue&&y.maxValue?f=`${y.minValue} - ${y.maxValue} ${y.unitText||""}`.trim():y.value&&(f=String(y.value))),{company:p==null?void 0:p.trim(),location:(m==null?void 0:m.trim())||void 0,salary:(f==null?void 0:f.trim())||void 0,description:(d==null?void 0:d.description)||void 0,title:(d==null?void 0:d.title)||void 0}}}}catch{}return{}}class Yt{constructor(){this.name="Unstop"}canHandle(e){return e.includes("unstop.com")}isJobDetailPage(e,t){var c,o,d,p;const n=e.toLowerCase();if(this.isJobListingPage(e,t)||(((o=(c=t==null?void 0:t.querySelectorAll)==null?void 0:c.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], .single_opportunity'))==null?void 0:o.length)||0)>=2)return!1;const a=/\/jobs\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/internships\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/competitions\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/hackathons\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/workshops\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/conferences\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/quizzes\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/p\/[a-zA-Z0-9_-]+/i.test(n)||/\/(jobs|internships|competitions)\/[a-zA-Z0-9_-]{4,}/i.test(n)&&!/\/(jobs|internships|competitions)\/(search|all|\?|$)/i.test(n),r=!!((d=t==null?void 0:t.querySelector)!=null&&d.call(t,'h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i]')),l=!!((p=t==null?void 0:t.querySelector)!=null&&p.call(t,'button[class*="apply" i], a[class*="apply" i], button[class*="register" i], a[class*="register" i]'));return a?!0:!!(r&&l)}isJobListingPage(e,t){var r,l;const n=e.toLowerCase(),i=/\/jobs\/?(\?.*)?$/i.test(n)||/\/jobs\/search/i.test(n)||/\/internships\/?(\?.*)?$/i.test(n)||/\/internships\/search/i.test(n)||/\/competitions\/?(\?.*)?$/i.test(n)||/\/all-opportunities/i.test(n)||n.includes("opportunity="),a=((l=(r=t==null?void 0:t.querySelectorAll)==null?void 0:r.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], [class*="opportunity" i], .single_opportunity'))==null?void 0:l.length)||0;return!!(i||a>=1)}extractJobList(e){var a,r,l,c,o;const t=[],n=new Set,i=Array.from(e.querySelectorAll('[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], .single_opportunity, [class*="opportunity" i]'));for(const d of i){if(d.children.length>25&&d.querySelectorAll('[class*="opportunity" i]').length>1)continue;const p=d.querySelector('h2, h3, h4, h1, [class*="title" i], [class*="opp_title" i], [class*="heading" i], a'),u=(p==null?void 0:p.tagName)==="A"?p:d.querySelector("a"),m=d.querySelector('[class*="company" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub-title" i], [class*="subtitle" i], [class*="brand" i]'),f=d.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="meta_item" i], [aria-label*="location" i]'),y=d.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="pay" i], [class*="compensation" i]'),h=d.querySelector('[class*="job-type" i], [class*="opp-type" i], [class*="timing" i], [class*="type" i]'),x=(a=p==null?void 0:p.textContent)==null?void 0:a.trim(),g=(u==null?void 0:u.href)||(typeof window<"u"?window.location.href:""),b=lt(g),v=(r=m==null?void 0:m.textContent)==null?void 0:r.trim(),S=v&&v.length>0?v:"Unknown Company";let T=((l=f==null?void 0:f.textContent)==null?void 0:l.trim())||void 0;T&&(T.includes("Bengaluru")||T.includes("Bangalore"))&&(T=T.replace(/\s+/g," ").trim()),x&&x.length>2&&!n.has(b)&&(n.add(b),t.push({title:x,company:S,location:T,salary:((c=y==null?void 0:y.textContent)==null?void 0:c.trim())||void 0,jobType:((o=h==null?void 0:h.textContent)==null?void 0:o.trim())||void 0,jobUrl:b,sourceWebsite:"Unstop",confidence:"HIGH"}))}return t}extractSingleJob(e){var x,g,b,v,S,T,k,A,w;const t=Wt(e),n=e.querySelector('h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="header" i] h1, [class*="main_title" i]'),i=((x=n==null?void 0:n.textContent)==null?void 0:x.trim())||t.title;if(!i||i.length<2)return null;const a=e.querySelector('[class*="company_name" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub_title" i], [class*="sub-title" i], [class*="org" i], [class*="employer" i], [class*="brand" i], h2'),r=((g=a==null?void 0:a.textContent)==null?void 0:g.trim())||t.company||"Unknown Company",l=e.querySelector('[class*="location" i], [class*="place" i], [class*="city" i], [class*="job_location" i], [aria-label*="location" i], .job_details_item_location, .other_details .location');let c=((b=l==null?void 0:l.textContent)==null?void 0:b.trim())||t.location;if(!c){const C=Array.from(e.querySelectorAll('[class*="chip" i], [class*="badge" i], [class*="meta" i], [class*="detail" i]'));for(const L of C){const N=((v=L.textContent)==null?void 0:v.trim())||"";if(/\b(Bangalore|Bengaluru|Hyderabad|Pune|Mumbai|Delhi|Gurgaon|Gurugram|Noida|Chennai|Kolkata|Remote|Work from home|Hybrid)\b/i.test(N)&&N.length<50){c=N;break}}}c&&(c=c.replace(/\s+/g," ").trim());const o=e.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="compensation" i], [class*="pay" i]'),d=((S=o==null?void 0:o.textContent)==null?void 0:S.trim())||t.salary||void 0,p=e.querySelector('[class*="job-type" i], [class*="job_type" i], [class*="opp_type" i], [class*="opp-type" i], [class*="timing" i], [class*="work_type" i]'),u=((T=p==null?void 0:p.textContent)==null?void 0:T.trim())||void 0,m=e.querySelector('#description, [class*="description" i], [class*="details" i], [class*="about" i], [class*="eligibility" i], [class*="overview" i]'),f=((A=(k=m==null?void 0:m.textContent)==null?void 0:k.trim())==null?void 0:A.slice(0,2e3))||((w=t.description)==null?void 0:w.slice(0,2e3))||void 0,y=typeof window<"u"?window.location.href:"",h=lt(y);return console.log(`[Talvyn] UNSSTOP_JOB_EXTRACTED: ${i} at ${r} (URL: ${h}, Location: ${c||"N/A"})`),{title:i,company:r,location:c,salary:d,jobType:u,description:f,jobUrl:h,sourceWebsite:"Unstop",confidence:"HIGH"}}}class Qt{constructor(){this.adapters=[],this.genericAdapter=new Ft,this.adapters=[new Pt,new Dt,new Yt,new Jt,new Bt,new Gt,new Vt]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const ze=new Qt,Zt={intern:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"intern"},internship:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"internship"},trainee:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"trainee"},apprentice:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"apprentice"},fellow:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"fellow"},junior:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"junior"},"jr.":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr."},jr:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr"},"entry level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry level"},"entry-level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry-level"},associate:{level:"ENTRY",yearsMin:0,yearsMax:3,matchedTerm:"associate"},graduate:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"graduate"},level1:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level 1":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level i"}," i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"i"},mid:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid"},"mid-level":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid-level"},intermediate:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"intermediate"},level2:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level 2":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level ii"}," ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"ii"},senior:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"senior"},"sr.":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr."},sr:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr"},level3:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level 3":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level iii"}," iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"iii"},experienced:{level:"SENIOR",yearsMin:4,yearsMax:8,matchedTerm:"experienced"},lead:{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"lead"},"team lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"team lead"},"tech lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"tech lead"},principal:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"principal"},staff:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"staff"},distinguished:{level:"STAFF_PLUS",yearsMin:12,matchedTerm:"distinguished"},fellow2:{level:"STAFF_PLUS",yearsMin:15,matchedTerm:"fellow"},"executive director":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"executive director"},"vice president":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vice president"},vp:{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vp"},director:{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"director"},"head of":{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"head of"},chief:{level:"DIRECTOR_PLUS",yearsMin:12,matchedTerm:"chief"}},Kt=["senior","sr.","sr","junior","jr.","jr","entry-level","entry level","lead","principal","staff","intern","internship","trainee","apprentice","graduate","experienced","mid-level","level 1","level 2","level 3","level i","level ii","level iii"],Xt=[/\b(urgent|urgently hiring|immediate hiring|hiring now|we're hiring|apply now|remote|hybrid|onsite|on-site|full-time|part-time|contract|temporary|wfh|work from home|multiple openings|100% remote)\b/gi,/\b(\[.*?\]|\(.*?\))\b/g,/\s+[-–|•#]\s+.*$/g,/[^\w\s/]/g,/\//g,/\s+/g],en=[{canonical:"data analyst",domain:"Data",synonyms:["analytics associate","reporting analyst","bi analyst","business intelligence analyst","data analytics specialist","product analyst","operations data analyst","sql data analyst","insights analyst","metrics analyst"],broaderRelated:["data scientist","business analyst","data engineer","analytics engineer","quantitative analyst"]},{canonical:"data scientist",domain:"Data",synonyms:["machine learning scientist","applied scientist","ai scientist","decision scientist","ml researcher","statistical modeler","data science specialist"],broaderRelated:["data analyst","machine learning engineer","ai engineer","quantitative researcher","statistician"]},{canonical:"data engineer",domain:"Data",synonyms:["big data engineer","etl developer","data platform engineer","data warehouse engineer","analytics engineer","data pipeline engineer","sql developer"],broaderRelated:["data analyst","data scientist","backend engineer","database administrator","cloud data architect"]},{canonical:"machine learning engineer",domain:"Data",synonyms:["ml engineer","ai engineer","mlops engineer","deep learning engineer","nlp engineer","computer vision engineer","ai developer"],broaderRelated:["data scientist","data engineer","software engineer","backend engineer"]},{canonical:"business intelligence analyst",domain:"Data",synonyms:["bi analyst","bi developer","power bi developer","tableau developer","bi specialist","reporting specialist"],broaderRelated:["data analyst","business analyst","data engineer"]},{canonical:"software engineer",domain:"Software",synonyms:["software developer","programmer","application developer","systems developer","software architect","sde","swe"],broaderRelated:["fullstack developer","frontend developer","backend developer","devops engineer","mobile developer"]},{canonical:"frontend developer",domain:"Software",synonyms:["frontend engineer","front end developer","front-end engineer","ui developer","ui engineer","web developer","react developer","javascript developer","client side engineer"],broaderRelated:["software engineer","fullstack developer","ui designer","product designer"]},{canonical:"backend developer",domain:"Software",synonyms:["backend engineer","back end developer","back-end engineer","server side developer","api developer","node developer","python developer","java developer","golang developer"],broaderRelated:["software engineer","fullstack developer","data engineer","devops engineer","cloud engineer"]},{canonical:"fullstack developer",domain:"Software",synonyms:["fullstack engineer","full stack developer","full-stack engineer","web application engineer"],broaderRelated:["software engineer","frontend developer","backend developer","mobile developer"]},{canonical:"mobile developer",domain:"Software",synonyms:["mobile engineer","ios developer","android developer","ios engineer","android engineer","flutter developer","react native developer","mobile app developer"],broaderRelated:["software engineer","frontend developer"]},{canonical:"devops engineer",domain:"Software",synonyms:["site reliability engineer","sre","cloud engineer","platform engineer","infrastructure engineer","cloud architect","systems engineer","sysadmin"],broaderRelated:["backend developer","software engineer","security engineer","network engineer"]},{canonical:"qa engineer",domain:"Software",synonyms:["quality assurance engineer","sdet","software development engineer in test","automation test engineer","test engineer","qa automation engineer","tester"],broaderRelated:["software engineer","devops engineer"]},{canonical:"cybersecurity analyst",domain:"Security",synonyms:["security analyst","information security analyst","infosec engineer","security engineer","soc analyst","penetration tester","threat analyst"],broaderRelated:["devops engineer","systems engineer","network engineer"]},{canonical:"product manager",domain:"Product",synonyms:["technical product manager","tpm","associate product manager","apm","group product manager","product lead","product owner","digital product manager"],broaderRelated:["project manager","program manager","business analyst","scrum master","product marketing manager"]},{canonical:"project manager",domain:"Project Management",synonyms:["technical project manager","it project manager","scrum master","agile coach","delivery manager","project coordinator","pmo analyst"],broaderRelated:["program manager","product manager","operations manager"]},{canonical:"program manager",domain:"Project Management",synonyms:["technical program manager","tpm","strategic program manager","transformation manager"],broaderRelated:["project manager","product manager","operations director"]},{canonical:"business analyst",domain:"Business",synonyms:["business systems analyst","it business analyst","requirements analyst","functional analyst","strategy analyst","process analyst"],broaderRelated:["product manager","data analyst","project manager","operations analyst"]},{canonical:"product designer",domain:"Design",synonyms:["ux designer","ui designer","ui ux designer","ui/ux designer","user experience designer","interaction designer","digital designer","experience designer"],broaderRelated:["ux researcher","visual designer","graphic designer","frontend developer","design system engineer"]},{canonical:"ux researcher",domain:"Design",synonyms:["user researcher","design researcher","user experience researcher","usability analyst","cx researcher"],broaderRelated:["product designer","data analyst","product manager"]},{canonical:"graphic designer",domain:"Design",synonyms:["visual designer","brand designer","creative designer","marketing designer","illustrator","motion designer"],broaderRelated:["product designer","content creator","art director"]},{canonical:"digital marketer",domain:"Marketing",synonyms:["marketing specialist","growth marketer","performance marketer","online marketing specialist","demand generation specialist","paid media specialist","sem specialist","media buyer"],broaderRelated:["content marketer","seo specialist","social media manager","product marketing manager","brand manager"]},{canonical:"product marketing manager",domain:"Marketing",synonyms:["pmm","product marketer","go-to-market specialist","gtm manager","solution marketing manager"],broaderRelated:["product manager","digital marketer","content marketer","brand manager"]},{canonical:"content marketer",domain:"Marketing",synonyms:["content strategist","copywriter","content writer","technical writer","editorial specialist","blog writer","communications specialist"],broaderRelated:["social media manager","seo specialist","digital marketer","pr specialist"]},{canonical:"seo specialist",domain:"Marketing",synonyms:["seo manager","search engine optimization analyst","organic growth specialist","seo strategist"],broaderRelated:["content marketer","digital marketer","web analyst"]},{canonical:"social media manager",domain:"Marketing",synonyms:["community manager","social media strategist","social media specialist","influencer marketing manager"],broaderRelated:["content marketer","digital marketer","brand manager"]},{canonical:"recruiter",domain:"HR",synonyms:["technical recruiter","talent acquisition specialist","talent acquisition partner","headhunter","talent sourcer","recruiting specialist","staffing consultant"],broaderRelated:["hr generalist","hr business partner","people operations specialist"]},{canonical:"hr generalist",domain:"HR",synonyms:["hr specialist","human resources coordinator","people operations specialist","hr officer","human resources manager","hr administrator"],broaderRelated:["recruiter","hr business partner","compensation analyst","payroll specialist"]},{canonical:"hr business partner",domain:"HR",synonyms:["hrbp","people partner","strategic hr partner","senior hr consultant"],broaderRelated:["hr generalist","recruiter","operations manager"]},{canonical:"financial analyst",domain:"Finance",synonyms:["fpa analyst","fp&a analyst","finance associate","investment analyst","budget analyst","financial planning analyst","commercial finance analyst","treasury analyst"],broaderRelated:["accountant","business analyst","risk analyst","data analyst","portfolio manager"]},{canonical:"accountant",domain:"Finance",synonyms:["staff accountant","senior accountant","certified public accountant","cpa","bookkeeper","tax accountant","audit associate","financial accountant","cost accountant"],broaderRelated:["financial analyst","controller","finance manager"]},{canonical:"controller",domain:"Finance",synonyms:["financial controller","comptroller","accounting director","head of finance"],broaderRelated:["accountant","financial analyst","cfo"]},{canonical:"account executive",domain:"Sales",synonyms:["ae","sales executive","enterprise account executive","sales representative","commercial sales representative","sales manager","closing rep"],broaderRelated:["sales development representative","business development manager","account manager","partnerships manager"]},{canonical:"sales development representative",domain:"Sales",synonyms:["sdr","bdr","business development representative","inside sales representative","outbound sales specialist","lead generation specialist"],broaderRelated:["account executive","business development manager","sales specialist"]},{canonical:"account manager",domain:"Sales",synonyms:["client manager","key account manager","client relationship manager","strategic account manager","client partner"],broaderRelated:["customer success manager","account executive","customer support specialist"]},{canonical:"business development manager",domain:"Sales",synonyms:["bdm","partnerships manager","strategic partnerships lead","alliance manager","channel sales manager"],broaderRelated:["account executive","sales development representative","product manager"]},{canonical:"customer success manager",domain:"Customer Success",synonyms:["csm","client success specialist","customer success specialist","client relationship specialist","customer onboarding specialist","implementation consultant"],broaderRelated:["account manager","customer support specialist","project manager","sales engineer"]},{canonical:"customer support specialist",domain:"Customer Support",synonyms:["support engineer","technical support specialist","help desk analyst","customer service representative","client support specialist","service desk analyst"],broaderRelated:["customer success manager","operations specialist","qa engineer"]},{canonical:"operations manager",domain:"Operations",synonyms:["business operations manager","bizops manager","operations lead","chief of staff","general manager","operations supervisor"],broaderRelated:["project manager","program manager","supply chain analyst","business analyst"]},{canonical:"supply chain analyst",domain:"Operations",synonyms:["logistics analyst","procurement specialist","inventory analyst","demand planning analyst","operations analyst"],broaderRelated:["operations manager","data analyst","financial analyst"]}];function ct(s){if(!s)return{raw:"",normalized:"",seniority:{level:"UNSPECIFIED",yearsMin:0},tokens:[]};let e=s.toLowerCase().trim(),t={level:"UNSPECIFIED",yearsMin:0};for(const[i,a]of Object.entries(Zt))if(new RegExp(`\\b${dt(i)}\\b`,"i").test(e)){t=a;break}for(const i of Xt)e=e.replace(i," ");for(const i of Kt){const a=new RegExp(`\\b${dt(i)}\\b`,"gi");e=e.replace(a," ")}e=e.replace(/\s+/g," ").trim();const n=e.split(" ").filter(i=>i.length>1);return{raw:s,normalized:e,seniority:t,tokens:n}}function dt(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function tn(s,e){const t=s.normalized,n=e.normalized;if(t===n||s.raw.toLowerCase().trim()===e.raw.toLowerCase().trim())return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:1,reason:`Exact match for preferred role "${e.raw}"`};if(t.length>2&&n.length>2&&(t.includes(n)||n.includes(t)))return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:.95,reason:`Direct title match for preferred role "${e.raw}"`};const i=pt(n),a=pt(t);for(const c of i){if(c.canonical===t)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${c.domain}`};const o=c.synonyms.find(p=>p===t||t.includes(p)||p.includes(t));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`};const d=c.broaderRelated.find(p=>p===t||t.includes(p)||p.includes(t));if(d)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.6,reason:`Related career path (${d}) for "${e.raw}"`}}for(const c of a){if(c.canonical===n)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${c.domain}`};const o=c.synonyms.find(d=>d===n||n.includes(d)||d.includes(n));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`}}const r=new Set(s.tokens),l=new Set(e.tokens);if(r.size>0&&l.size>0){let c=0;for(const p of l)r.has(p)&&c++;const o=c/l.size,d=c/(r.size+l.size-c);if(o>=.75)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.75,reason:`Key skill/role tokens match "${e.raw}"`};if(o>=.5||d>=.4)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.55,reason:`Partial keyword overlap with preferred role "${e.raw}"`};if(c>=1&&(r.size<=3||l.size<=3))return{preferredRole:e.raw,jobTitle:s.raw,level:"WEAK_MATCH",score:.3,reason:`Minor keyword match with "${e.raw}"`}}return{preferredRole:e.raw,jobTitle:s.raw,level:"NO_MATCH",score:0,reason:`Role does not match "${e.raw}"`}}function pt(s){if(!s||s.length<3)return[];const e=[];for(const t of en)(t.canonical===s||He(t.canonical,s)||t.synonyms.some(n=>n===s||He(n,s))||t.broaderRelated.some(n=>n===s||He(n,s)))&&e.push(t);return e}function He(s,e){if(s===e)return!0;const t=new RegExp(`\\b${ut(s)}\\b`,"i"),n=new RegExp(`\\b${ut(e)}\\b`,"i");return t.test(e)||n.test(s)}function ut(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function kt(s,e,t=.45){const n=ct(s);if(!e||e.length===0)return{level:"RELATED",score:.5,weight:t,weightedScore:.5*t*100,reason:"No preferred roles specified in profile",rawTitle:s,normalizedTitle:n.normalized};let i={preferredRole:e[0],level:"NO_MATCH",score:0,reason:"Role did not match your preferred roles"};for(const a of e){const r=ct(a),l=tn(n,r);if(l.score>i.score&&(i=l),i.score===1)break}return{level:i.level,matchedRole:i.preferredRole,score:i.score,weight:t,weightedScore:Math.round(i.score*t*100*10)/10,reason:i.reason,rawTitle:s,normalizedTitle:n.normalized}}const nn={role:.3,experience:.25,education:.2,skills:.2,location:.05},an={javascript:"JavaScript",typescript:"TypeScript",react:"React","react native":"React Native","node.js":"Node.js",nodejs:"Node.js",node:"Node.js",python:"Python",java:"Java","c++":"C++","c#":"C#",".net":".NET",aws:"AWS","amazon web services":"AWS",docker:"Docker",kubernetes:"Kubernetes",sql:"SQL",mysql:"MySQL",postgresql:"PostgreSQL",postgres:"PostgreSQL",mongodb:"MongoDB",graphql:"GraphQL","rest api":"REST APIs",rest:"REST APIs",git:"Git",github:"GitHub",html:"HTML5",css:"CSS3",tailwind:"Tailwind CSS","next.js":"Next.js",nextjs:"Next.js",vue:"Vue.js",angular:"Angular",django:"Django",fastapi:"FastAPI",flask:"Flask","spring boot":"Spring Boot",spring:"Spring Boot",go:"Golang",golang:"Golang",rust:"Rust",ruby:"Ruby","ruby on rails":"Rails",rails:"Rails",php:"PHP",laravel:"Laravel",flutter:"Flutter",swift:"Swift",kotlin:"Kotlin",figma:"Figma",jira:"Jira",agile:"Agile","ci/cd":"CI/CD",linux:"Linux",azure:"Azure",gcp:"GCP",redis:"Redis",kafka:"Kafka",microservices:"Microservices",devops:"DevOps",pandas:"Pandas",numpy:"NumPy","machine learning":"Machine Learning",ai:"AI",tableau:"Tableau",excel:"Excel",powerbi:"PowerBI","power bi":"PowerBI","financial modeling":"Financial Modeling",budgeting:"Budgeting",prototyping:"Prototyping","user research":"User Research"};function sn(s="",e="",t=""){const n=`${s} ${t} ${e||""}`.toLowerCase(),i=n.match(/\b(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)?/i);if(i){const c=parseInt(i[1],10),o=parseInt(i[2],10);return{minYears:c,maxYears:o,isFresher:c===0,rawText:`${c}–${o} years`}}const a=n.match(/\b(\d+)\s*\+\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||n.match(/\b(?:min(?:imum)?|at\s+least)\s+(\d+)\s*(?:years?|yrs?)/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*\+\s*(?:years?|yrs?)?/i);if(a){const c=parseInt(a[1],10);return{minYears:c,maxYears:null,isFresher:c===0,rawText:`${c}+ years`}}const r=n.match(/\b(\d+)\s*(?:years?|yrs?)(?:\s+of)?\s+experience\b/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:years?|yrs?)\b/i);if(r){const c=parseInt(r[1],10);return{minYears:c,maxYears:null,isFresher:c===0,rawText:c===1?"1 year":`${c} years`}}return/\b(fresher|entry[\s-]level|trainee|graduate|intern|internship|campus)\b/i.test(s)||/\b(fresher|entry[\s-]level|0[\s-]*1\s*years?|0[\s-]*0\s*years?)\b/i.test(n)?{minYears:0,maxYears:1,isFresher:!0,rawText:"Fresher / 0–1 years"}:null}function Lt(s,e,t,n,i=.25){const a=sn(s,e||"",t||""),r=n.experienceYears??null,l=r===0||r===null,c=l?"Fresher":`${r} year${r===1?"":"s"}`;if(!a)return{score:.8,weight:i,weightedScore:.8*i*100,reason:"Experience requirements appear standard/flexible",isHardMismatch:!1,requiredText:"Not specified",profileText:c,status:"UNSPECIFIED"};const o=a.rawText;if(l){if(a.isFresher||a.minYears===0)return{score:1,weight:i,weightedScore:i*100,reason:"Fresher / entry-level role matches your profile",isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};const m=a.minYears>=2;return{score:m?.05:.2,weight:i,weightedScore:(m?.05:.2)*i*100,reason:`Experience mismatch: Required: ${o}, Your profile: Fresher`,isHardMismatch:!0,requiredText:o,profileText:c,status:"MISMATCH"}}const d=r;if(a.maxYears!==null&&d>=a.minYears&&d<=a.maxYears)return{score:1,weight:i,weightedScore:i*100,reason:`Your ${d} years experience matches required range (${o})`,isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};if(d>=a.minYears)return{score:1,weight:i,weightedScore:i*100,reason:`Your ${d} yrs experience satisfies requirement (${o})`,isHardMismatch:!1,requiredText:o,profileText:c,status:"MATCH"};const u=a.minYears-d>=2||a.minYears>=2;return{score:u?.1:.35,weight:i,weightedScore:(u?.1:.35)*i*100,reason:`Experience mismatch: Required: ${o}, Your profile: ${c}`,isHardMismatch:u,requiredText:o,profileText:c,status:"MISMATCH"}}function Et(s,e,t,n=.2){const i=`${s} ${e||""}`.toLowerCase(),a=[{key:"b.tech",label:"B.Tech"},{key:"btech",label:"B.Tech"},{key:"b.e.",label:"B.E."},{key:"be ",label:"B.E."},{key:"m.tech",label:"M.Tech"},{key:"mtech",label:"M.Tech"},{key:"mca",label:"MCA"},{key:"bca",label:"BCA"},{key:"b.sc",label:"B.Sc"},{key:"bsc",label:"B.Sc"},{key:"bachelor",label:"Bachelor's"},{key:"master",label:"Master's"},{key:"computer science",label:"Computer Science"},{key:"cs/it",label:"CS/IT"},{key:"information technology",label:"Information Technology"},{key:"engineering",label:"Engineering"},{key:"undergraduate",label:"Undergraduate"},{key:"graduate",label:"Graduate"}],r=[];for(const u of a)i.includes(u.key)&&!r.includes(u.label)&&r.push(u.label);const l=(t.degree||"").toLowerCase(),c=(t.specialization||"").toLowerCase(),o=`${l} ${c}`.trim();if(r.length===0)return{score:.85,weight:n,weightedScore:.85*n*100,reason:"Education: Not specified",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:"Not specified"};const d=r.slice(0,3).join(" / ");return o?r.some(u=>{const m=u.toLowerCase();return o.includes(m)||m.includes("b.tech")&&(o.includes("btech")||o.includes("b.e.")||o.includes("engineering"))||m.includes("b.e.")&&(o.includes("btech")||o.includes("b.tech")||o.includes("engineering"))||m.includes("computer science")&&(o.includes("cs")||o.includes("it")||o.includes("information technology"))||m.includes("bachelor")&&(o.includes("b.tech")||o.includes("b.e.")||o.includes("bca")||o.includes("bsc")||o.includes("bachelor"))})?{score:1,weight:n,weightedScore:n*100,reason:`Education match: ${t.degree||"Degree"} aligns with ${d}`,isHardMismatch:!1,status:"MATCH",requiredText:d}:{score:.15,weight:n,weightedScore:.15*n*100,reason:`Education mismatch: Requires ${d}`,isHardMismatch:!0,status:"MISMATCH",requiredText:d}:{score:.6,weight:n,weightedScore:.6*n*100,reason:"Education not specified in profile",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:d}}function Mt(s,e,t,n=.2){const i=`${s} ${e||""}`.toLowerCase(),a=[];for(const[m,f]of Object.entries(an))new RegExp(`(?:^|[\\s,.;/()+-])${m.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?:$|[\\s,.;/()+-])`,"i").test(i)&&(a.includes(f)||a.push(f));const r=(t.skills||[]).map(m=>m.trim()),l=r.map(m=>m.toLowerCase()),c=[],o=[];for(const m of a){const f=m.toLowerCase();l.some(h=>h.includes(f)||f.includes(h))?c.includes(m)||c.push(m):o.includes(m)||o.push(m)}if(c.length===0&&r.length>0)for(const m of r)i.includes(m.toLowerCase())&&!c.includes(m)&&c.push(m);if(a.length===0&&c.length===0)return{score:.85,weight:n,weightedScore:.85*n*100,reason:"General technical skill alignment",matchedSkills:r.slice(0,3),missingSkills:[],status:"UNSPECIFIED"};const d=c.length+o.length;let p=.5;d>0?(p=c.length/d,c.length>0&&p<.4&&(p=.4)):c.length>0&&(p=1);const u=c.length>=1;return{score:p,weight:n,weightedScore:p*n*100,reason:u?`Skills match: ${c.slice(0,3).join(", ")}`:`Missing key skills: ${o.slice(0,2).join(", ")}`,matchedSkills:c,missingSkills:o,status:u?"MATCH":"MISMATCH"}}function Rt(s,e,t,n=.05){const i=(s||"").toLowerCase().trim(),a=(e||"").toLowerCase(),r=t.preferredLocations||[],l=t.workStyle||"ANY",c=i.includes("remote")||i.includes("wfh")||i.includes("anywhere")||a.includes("100% remote")||a.includes("fully remote")||a.includes("work from home"),o=i.includes("hybrid")||a.includes("hybrid work")||a.includes("hybrid schedule");if(l==="ANY"&&r.length===0)return{score:1,weight:n,weightedScore:n*100,reason:"Open to all locations and work styles"};if(l==="REMOTE"){if(c)return{score:1,weight:n,weightedScore:n*100,reason:"Remote position aligns with your Remote preference"};if(o)return{score:.5,weight:n,weightedScore:.5*n*100,reason:"Hybrid role (partially remote)"}}if(r.length>0)for(const d of r){const p=d.toLowerCase().trim();if(p){if(p.includes("remote")&&c)return{score:1,weight:n,weightedScore:n*100,reason:'Remote job matches preferred location "Remote"'};if(i&&(i.includes(p)||p.includes(i)))return{score:1,weight:n,weightedScore:n*100,reason:`Location matches preferred location "${d}"`}}}return(l==="HYBRID"||l==="ANY")&&c?{score:.9,weight:n,weightedScore:.9*n*100,reason:"Remote job provides work flexibility"}:i?{score:.2,weight:n,weightedScore:.2*n*100,reason:`Location "${s}" differs from preferred locations`}:{score:.6,weight:n,weightedScore:.6*n*100,reason:"Location not specified in job posting"}}function on(s,e,t=.05){const n=e.preferredJobTypes||[];if(n.length===0)return{score:1,weight:t,weightedScore:t*100,reason:"Open to all employment types"};if(!s)return{score:.6,weight:t,weightedScore:.6*t*100,reason:"Job type not disclosed in listing"};const i=s.toUpperCase().replace(/[-\s]/g,"_");return n.some(r=>{const l=r.toUpperCase().replace(/[-\s]/g,"_");return i.includes(l)||l.includes(i)})?{score:1,weight:t,weightedScore:t*100,reason:`Employment type (${s}) matches your preference`}:{score:.2,weight:t,weightedScore:.2*t*100,reason:`Job type (${s}) differs from preferred (${n.join(", ")})`}}function rn(s,e,t=.05){return e.expectedSalary?s?{score:.8,weight:t,weightedScore:.8*t*100,reason:`Salary listed as "${s}"`}:{score:.6,weight:t,weightedScore:.6*t*100,reason:"Salary not disclosed in listing"}:{score:.8,weight:t,weightedScore:.8*t*100,reason:"No expected salary specified in profile"}}function ln(s,e,t=nn){const n=kt(s.title,e.preferredRoles,t.role),i=Lt(s.title,s.description,s.jobType,e,t.experience),a=Et(s.title,s.description,e,t.education),r=Mt(s.title,s.description,e,t.skills),l=Rt(s.location,s.description,e,t.location);let c=Math.round(n.weightedScore+i.weightedScore+a.weightedScore+r.weightedScore+l.weightedScore);const o=n.level==="NO_MATCH"||n.score===0,d=i.isHardMismatch||i.status==="MISMATCH",p=a.status==="MISMATCH"&&a.isHardMismatch;let u=Math.min(100,Math.max(0,c)),m,f="";d&&i.isHardMismatch?(u=Math.min(42,Math.max(25,Math.round(c*.46))),m="LOW_RELEVANCE",f="Experience requirement does not match your profile."):o?(u=Math.min(44,Math.max(20,Math.round(c*.42))),m="LOW_RELEVANCE",f="Role does not align with your profile."):p?(u=Math.min(45,Math.max(25,Math.round(c*.45))),m="LOW_RELEVANCE",f="Education requirement differs from your profile."):u>=85?m="EXCELLENT":u>=70?m="HIGHLY_RELEVANT":u>=50?m="RELEVANT":m="LOW_RELEVANCE";const y=[],h=[];n.score>=.6?y.push(n.reason):h.push(n.reason),i.status==="MATCH"?y.push(i.reason):i.status==="MISMATCH"&&h.push(i.reason),a.status==="MATCH"?y.push(a.reason):a.status==="MISMATCH"&&h.push(a.reason),r.status==="MATCH"&&r.matchedSkills.length>0&&y.push(`Skills match: ${r.matchedSkills.slice(0,3).join(", ")}`),r.missingSkills.length>0&&h.push(`Missing skills: ${r.missingSkills.slice(0,2).join(", ")}`),l.score>=.7?y.push(l.reason):l.score<.5&&h.push(l.reason),f&&!h.includes(f)&&h.unshift(f);const x=on(s.jobType,e,.05),g=rn(s.salary,e,.05);return{job:s,relevanceScore:u,category:m,roleMatch:n,locationMatch:l,experienceMatch:i,educationMatch:a,skillsMatch:r,jobTypeMatch:x,salaryMatch:g,matchedReasons:y,unmatchedReasons:h,matchedSkills:r.matchedSkills,missingSkills:r.missingSkills}}class cn{constructor(){this.scannedJobUrls=new Set,this.cachedAnalyzedJobs=new Map,this.CACHE_TTL_MS=15*60*1e3}classifyPage(e,t){if(ae(e))return{classification:"OTHER",adapterName:"None"};const n=ze.getAdapter(e,t);return n.isJobListingPage(e,t)?{classification:"JOB_LIST",adapterName:n.name}:n.isJobDetailPage(e,t)?{classification:"SINGLE_JOB",adapterName:n.name}:Ie(t,e)?{classification:"JOB_LIST",adapterName:n.name}:be(t,e)?{classification:"SINGLE_JOB",adapterName:n.name}:{classification:"OTHER",adapterName:n.name}}scanSingleJob(e,t){return ae(e)?null:ze.getAdapter(e,t).extractSingleJob(t)}scanJobListing(e,t,n,i=new Set){if(ae(e))return{totalDetected:0,excellentCount:0,highlyRelevantCount:0,relevantCount:0,lowRelevanceCount:0,analyzedJobs:[],pageUrl:e,scannedAt:new Date().toISOString()};const r=ze.getAdapter(e,t).extractJobList(t),l=[],c=Date.now();for(const m of r){const f=m.jobUrl||`${m.title}-${m.company}`,y=this.cachedAnalyzedJobs.get(f);let h;y&&c-y.cachedAt<this.CACHE_TTL_MS?h=y.job:(h=ln(m,n),this.cachedAnalyzedJobs.set(f,{job:h,cachedAt:c}),this.scannedJobUrls.add(f)),h.isSaved=i.has(m.jobUrl),l.push(h)}l.sort((m,f)=>f.relevanceScore-m.relevanceScore);let o=0,d=0,p=0,u=0;for(const m of l)m.category==="EXCELLENT"?o++:m.category==="HIGHLY_RELEVANT"?d++:m.category==="RELEVANT"?p++:u++;return{totalDetected:l.length,excellentCount:o,highlyRelevantCount:d,relevantCount:p,lowRelevanceCount:u,analyzedJobs:l,pageUrl:e,scannedAt:new Date().toISOString()}}clearCache(){this.scannedJobUrls.clear(),this.cachedAnalyzedJobs.clear()}}const se=new cn,dn=[/\/jobs?\//i,/\/careers?\//i,/\/positions?\//i,/\/openings?\//i,/\/vacancies?\//i,/\/opportunities?\//i,/\/apply/i,/linkedin\.com\/jobs/i,/indeed\.com\/(viewjob|rc\/clk)/i,/glassdoor\.com\/job-listing/i,/lever\.co\//i,/greenhouse\.io\//i,/workable\.com\//i,/myworkdayjobs\.com\//i,/icims\.com\//i,/smartrecruiters\.com\//i,/jobvite\.com\//i,/taleo\.net\//i,/successfactors\.(com|eu)\//i,/boards\.greenhouse\.io\//i,/jobs\.lever\.co\//i],pn=[/apply (for|now)/i,/job (description|details|overview|summary)/i,/about (this|the) (role|position|job)/i,/role (overview|summary|description)/i,/position (overview|summary|details)/i,/what you('ll|'d| will) do/i,/responsibilities/i,/qualifications/i,/requirements/i];function un(s){try{const e=new URL(s).hostname.replace(/^www\./,""),t={"linkedin.com":"LinkedIn","indeed.com":"Indeed","glassdoor.com":"Glassdoor","lever.co":"Lever","greenhouse.io":"Greenhouse","workable.com":"Workable","myworkdayjobs.com":"Workday","icims.com":"iCIMS","smartrecruiters.com":"SmartRecruiters","jobvite.com":"Jobvite","taleo.net":"Taleo"};for(const[n,i]of Object.entries(t))if(e.includes(n))return i;return e}catch{return window.location.hostname}}function mn(s=document){var t,n,i,a,r,l,c,o,d,p,u,m,f;const e=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const y of Array.from(e))try{const h=JSON.parse(y.textContent||"{}"),x=Array.isArray(h)?h:[h];for(const g of x)if(g["@type"]==="JobPosting")return{title:g.title||g.name,company:((t=g.hiringOrganization)==null?void 0:t.name)||g.employerOverview||((n=g.author)==null?void 0:n.name),location:typeof g.jobLocation=="string"?g.jobLocation:((a=(i=g.jobLocation)==null?void 0:i.address)==null?void 0:a.addressLocality)||((l=(r=g.jobLocation)==null?void 0:r.address)==null?void 0:l.addressRegion),salary:((o=(c=g.baseSalary)==null?void 0:c.value)==null?void 0:o.value)||((p=(d=g.baseSalary)==null?void 0:d.value)!=null&&p.minValue&&((m=(u=g.baseSalary)==null?void 0:u.value)!=null&&m.maxValue)?`${g.baseSalary.value.minValue}–${g.baseSalary.value.maxValue} ${g.baseSalary.value.unitText||""}`:void 0),jobType:g.employmentType,description:(f=g.description)==null?void 0:f.replace(/<[^>]*>/g," ").replace(/\s+/g," ").trim().slice(0,3e3)}}catch{}return null}function fn(s=document){var e,t,n,i,a;try{const r=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const l of Array.from(r)){const c=l.textContent;if(!c)continue;const o=JSON.parse(c),d=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((n=o==null?void 0:o.author)==null?void 0:n.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(i=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:i.hiringOrganization)==null?void 0:a.name);if(d&&typeof d=="string"&&d.trim().length>0)return d.trim()}}catch{}}function yn(s=document){const e=t=>{var n;return s.querySelector?(n=s.querySelector(`meta[property="${t}"], meta[name="${t}"]`))==null?void 0:n.content:void 0};return{title:e("og:title")||e("twitter:title")||e("title")||void 0,company:e("og:site_name")||void 0,description:e("og:description")||e("description")||void 0}}function hn(s=document,e=""){var i,a,r,l,c,o,d,p,u,m,f,y,h,x,g,b,v,S,T,k,A,w,C,L,N,j,O,H,R,G,F,z,ee,te,Y,ne,$,Q,P,ce,re;const t={};if(!s||typeof s.querySelector!="function")return t;const n=(()=>{try{return new URL(e).hostname.toLowerCase()}catch{return typeof window<"u"?window.location.hostname.toLowerCase():""}})();if(n.includes("linkedin.com")&&(t.title=(a=(i=s.querySelector(".job-details-jobs-unified-top-card__job-title, .topcard__title"))==null?void 0:i.textContent)==null?void 0:a.trim(),t.company=(l=(r=s.querySelector(".job-details-jobs-unified-top-card__company-name a, .topcard__org-name-link"))==null?void 0:r.textContent)==null?void 0:l.trim(),t.location=(o=(c=s.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:c.textContent)==null?void 0:o.trim(),t.description=(p=(d=s.querySelector(".jobs-description__content, #job-details, .description__text"))==null?void 0:d.textContent)==null?void 0:p.trim()),n.includes("indeed.com")&&(t.title=(m=(u=s.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"]'))==null?void 0:u.textContent)==null?void 0:m.trim(),t.company=((y=(f=s.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, .icl-u-lg-mr--sm, [class*="companyName"]'))==null?void 0:f.textContent)==null?void 0:y.trim())||fn(s)||"Unknown Company",t.location=(x=(h=s.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:h.textContent)==null?void 0:x.trim(),t.salary=(b=(g=s.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:g.textContent)==null?void 0:b.trim(),t.description=(S=(v=s.querySelector('#jobDescriptionText, [data-testid="jobDescriptionText"]'))==null?void 0:v.textContent)==null?void 0:S.trim()),(n.includes("greenhouse.io")||n.includes("boards.greenhouse.io"))&&(t.title=(k=(T=s.querySelector(".app-title, h1.heading"))==null?void 0:T.textContent)==null?void 0:k.trim(),t.company=(w=(A=s.querySelector(".company-name, .logo span"))==null?void 0:A.textContent)==null?void 0:w.trim(),t.location=(L=(C=s.querySelector(".location"))==null?void 0:C.textContent)==null?void 0:L.trim(),t.description=(j=(N=s.querySelector("#content, .job-post-content"))==null?void 0:N.textContent)==null?void 0:j.trim()),(n.includes("lever.co")||n.includes("jobs.lever.co"))&&(t.title=(H=(O=s.querySelector(".posting-headline h2"))==null?void 0:O.textContent)==null?void 0:H.trim(),t.company=((G=(R=s.querySelector(".posting-headline .posting-categories .sort-by-team"))==null?void 0:R.textContent)==null?void 0:G.trim())||((F=s.querySelector(".main-header-logo img"))==null?void 0:F.getAttribute("alt"))||void 0,t.location=(ee=(z=s.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:z.textContent)==null?void 0:ee.trim(),t.description=(Y=(te=s.querySelector(".section-wrapper, .posting-page"))==null?void 0:te.textContent)==null?void 0:Y.trim()),!t.title){const U=['h1[class*="job" i]','h1[class*="title" i]','h1[class*="position" i]','h1[class*="role" i]','[class*="job-title" i]','[class*="position-title" i]',"h1",'h2[class*="job" i]','h2[class*="title" i]'];for(const ie of U){const _=s.querySelector(ie);if(_){const M=((ne=_.textContent)==null?void 0:ne.trim())||"";if(M.length>3&&M.length<140&&!/^(home|careers|jobs|search|openings|login)$/i.test(M)){t.title=M;break}}}}if(!t.company){const U=['[class*="company-name" i]','[class*="companyName" i]','[class*="employer" i]','[class*="org-name" i]','[class*="organization" i]','[itemprop="hiringOrganization"]','[itemprop="name"]','[class*="sub-title" i]'];for(const ie of U){const _=s.querySelector(ie);if(_){const M=($=_.textContent)==null?void 0:$.trim();if(M&&M.length>1&&M.length<100){t.company=M;break}}}}if(!t.location){const U=['[class*="location" i]','[class*="city" i]','[class*="workplace" i]','[itemprop="addressLocality"]','[class*="address" i]'];for(const ie of U){const _=s.querySelector(ie);if(_){const M=(Q=_.textContent)==null?void 0:Q.trim();if(M&&M.length>1&&M.length<100){t.location=M;break}}}}if(!t.salary){const U=['[class*="salary" i]','[class*="compensation" i]','[class*="stipend" i]','[class*="pay" i]','[class*="remuneration" i]'];for(const ie of U){const _=s.querySelector(ie);if(_){const M=(P=_.textContent)==null?void 0:P.trim();if(M&&M.length>1&&M.length<80){t.salary=M;break}}}}if(!t.jobType){const U=['[class*="job-type" i]','[class*="jobType" i]','[class*="employment-type" i]','[class*="work-type" i]'];for(const ie of U){const _=s.querySelector(ie);if(_){const M=(ce=_.textContent)==null?void 0:ce.trim();if(M&&M.length>2&&M.length<40){t.jobType=M;break}}}}if(!t.description){const U=['[class*="job-description" i]','[class*="jobDescription" i]','[class*="description" i]','[class*="posting-requirements" i]','[class*="job-details" i]',"article","main"];for(const ie of U){const _=s.querySelector(ie);if(_){const M=(re=_.textContent)==null?void 0:re.replace(/\s+/g," ").trim();if(M&&M.length>50){t.description=M.slice(0,3e3);break}}}}return t}function gn(s=document){const e=s.title||(typeof document<"u"?document.title:""),t=e.match(/^(.+?)\s+at\s+(.+?)(?:\s*[|\-–]|$)/i);if(t)return{title:t[1].trim(),company:t[2].trim()};const n=e.match(/^(.+?)\s*[-–]\s*(.+?)(?:\s*[|\-–]|$)/);return n?{title:n[1].trim(),company:n[2].trim()}:{}}function Ne(s,e){let t=typeof document<"u"?document:{},n=typeof window<"u"?window.location.href:"";if(typeof s=="string"?(n=s,e&&typeof e.querySelectorAll=="function"&&(t=e)):s&&typeof s.querySelectorAll=="function"&&(t=s),!n||typeof t.querySelectorAll!="function"||ae(n))return null;const i=dn.some(y=>y.test(n)),a=Array.from(t.querySelectorAll("h1, h2, h3")).map(y=>y.textContent||"").join(" "),r=pn.some(y=>y.test(a)),l=mn(t),c=yn(t),o=hn(t,n),d=gn(t),p=!!(l!=null&&l.title);if(!i&&!r&&!p)return null;const u=/linkedin\.com\/jobs/i.test(n)||/indeed\.com\/(viewjob|rc\/clk)/i.test(n)||/unstop\.com\/(jobs|internships|competitions)/i.test(n)||/greenhouse\.io/i.test(n)||/lever\.co/i.test(n)||/workable\.com/i.test(n)||/ashbyhq\.com/i.test(n)||/smartrecruiters\.com/i.test(n);if(!p&&!u&&!be(t,n))return null;const m={title:(l==null?void 0:l.title)||(o==null?void 0:o.title)||(c==null?void 0:c.title)||(d==null?void 0:d.title),company:(l==null?void 0:l.company)||(o==null?void 0:o.company)||(c==null?void 0:c.company)||(d==null?void 0:d.company),location:(l==null?void 0:l.location)||(o==null?void 0:o.location),salary:(l==null?void 0:l.salary)||(o==null?void 0:o.salary),jobType:(l==null?void 0:l.jobType)||(o==null?void 0:o.jobType),description:(l==null?void 0:l.description)||(o==null?void 0:o.description)||(c==null?void 0:c.description)};if(!m.title)return null;let f="LOW";return l!=null&&l.title?f="HIGH":i&&m.title&&m.company?f="MEDIUM":m.title&&(f="LOW"),{title:m.title,company:m.company||"Unknown Company",location:m.location,salary:m.salary,jobType:m.jobType,description:m.description,jobUrl:n,sourceWebsite:un(n),confidence:f}}function bn(s="",e="",t=""){const n=s.trim().toLowerCase().replace(/[-_]/g," "),i=e.toLowerCase();return n.includes("intern")||n.includes("stipend")?"INTERNSHIP":n.includes("full time")||n.includes("permanent")?"FULL_TIME":n.includes("part time")?"PART_TIME":n.includes("contract")?"CONTRACT":n.includes("freelance")?"FREELANCE":n.includes("temp")||n.includes("temporary")?"TEMPORARY":n.includes("graduate")||n.includes("fresher")?"GRADUATE_PROGRAM":n.includes("fellowship")||n.includes("scholarship")?"FELLOWSHIP":n.includes("competition")||n.includes("hackathon")||n.includes("challenge")||n.includes("quiz")?"COMPETITION":n.includes("talent")||n.includes("audition")||n.includes("casting")?"TALENT_OPPORTUNITY":i.includes("intern")?"INTERNSHIP":i.includes("hackathon")||i.includes("competition")||i.includes("quiz")||i.includes("challenge")?"COMPETITION":i.includes("fellowship")?"FELLOWSHIP":i.includes("graduate")||i.includes("fresher")?"GRADUATE_PROGRAM":i.includes("part time")?"PART_TIME":i.includes("contract")?"CONTRACT":i.includes("freelance")?"FREELANCE":n.length>0&&n!=="job"&&n!=="work from home"&&n!=="in office"&&n!=="hybrid"?"OTHER":"FULL_TIME"}function xn(s=""){if(!s)return typeof window<"u"?window.location.href.split("?")[0]:"";try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const n of t)e.searchParams.delete(n);return e.toString()}catch{return s.trim()}}function Ce(s,e){var M,st,ot,rt;const t=(s.title||"").trim()||"Untitled Job",n=(s.company||"").trim()||"Unknown Company",i=(s.jobUrl||"").trim()||(typeof window<"u"?window.location.href:""),a=xn(i),r=(s.location||"").trim()||null,l=(s.salary||"").trim()||null,c=(s.description||"").trim()||null,o=(s.sourceWebsite||"").trim()||(typeof window<"u"?window.location.hostname.replace(/^www\./i,""):"Web"),d=bn(s.jobType||"",t,c||""),p=[];let u=0;t!=="Untitled Job"&&(u+=30),n!=="Unknown Company"&&(u+=25),a&&(u+=25),r?u+=10:p.push("location"),l?u+=5:p.push("salary"),c&&c.length>20?u+=5:p.push("description");const m=e||{preferredRoles:[],skills:[],preferredLocations:[],workStyle:"ANY"},f=kt(t,m.preferredRoles,.3),y=f.score>=.6,h=f.level==="NO_MATCH"||f.score===0,x=((M=m.preferredRoles)==null?void 0:M.length)===0?"UNSPECIFIED":y?"MATCH":"MISMATCH",g=y?"Role match":"Role mismatch",b=Lt(t,c||void 0,s.jobType,m,.25),v=b.isHardMismatch||b.status==="MISMATCH",S=b.status,T=b.status==="MATCH"?"Experience match":b.status==="MISMATCH"?`Experience mismatch: Required ${b.requiredText}, Profile: ${b.profileText}`:"Experience standard/flexible",k=Et(t,c||void 0,m,.2),A=k.isHardMismatch&&k.status==="MISMATCH",w=k.status,C=k.status==="MATCH"?"Education match":k.status==="MISMATCH"?`Education mismatch: Requires ${k.requiredText}`:"Education: Not specified",L=Mt(t,c||void 0,m,.2),N=L.matchedSkills,j=L.missingSkills,O=L.status,H=L.status==="MATCH"?"Skills match":"Missing key skills",R=Rt(r||void 0,c||void 0,m,.05),G=!r||!((st=m.preferredLocations)!=null&&st.length)?"UNSPECIFIED":R.score>=.7?"MATCH":"MISMATCH",F=R.reason;let z=Math.round(f.weightedScore+b.weightedScore+k.weightedScore+L.weightedScore+R.weightedScore),ee=Math.min(100,Math.max(0,z)),te="GOOD_MATCH",Y="GOOD MATCH",ne="Worth applying",$="🟢";v&&b.isHardMismatch?(ee=Math.min(42,Math.max(25,Math.round(z*.46))),te="LOW_MATCH",Y="LOW MATCH",ne="Experience requirement does not match your profile.",$="🔴"):h&&((ot=m.preferredRoles)==null?void 0:ot.length)>0?(ee=Math.min(44,Math.max(20,Math.round(z*.42))),te="LOW_MATCH",Y="LOW MATCH",ne="Role does not align with your target preferences",$="🔴"):A?(ee=Math.min(45,Math.max(25,Math.round(z*.45))),te="LOW_MATCH",Y="LOW MATCH",ne="Education requirement differs from your profile.",$="🔴"):ee>=85?(te="STRONG_MATCH",Y="STRONG MATCH",ne="Recommended to apply",$="🟢"):ee>=70?(te="GOOD_MATCH",Y="GOOD MATCH",ne="Worth applying",$="🟢"):ee>=50?(te="MODERATE_MATCH",Y="MODERATE MATCH",ne="Review before applying",$="🟡"):(te="LOW_MATCH",Y="LOW MATCH",ne="Low priority",$="🔴");const Q=[],P=[];x==="MATCH"?Q.push("Role match"):x==="MISMATCH"&&P.push("Role mismatch"),w==="MATCH"?Q.push("Education match"):w==="MISMATCH"&&P.push(C),S==="MATCH"?Q.push("Experience match"):S==="MISMATCH"&&P.push(T),O==="MATCH"&&N.length>0&&Q.push("Skills match"),j.length>0&&P.push(`Missing: ${j.slice(0,2).join(" • ")}`),G==="MATCH"&&Q.push("Location match"),Q.length===0&&!v&&!h&&(Q.push("Skills match"),Q.push("Experience match"));let ce=90;const re=[],U=[];return re.push("Resume available"),re.push("Profile complete"),v?U.push("Experience level differs"):re.push("Experience suitable"),j.length>2&&(ce-=10,U.push(`Missing: ${j[0]}`)),u<70&&U.push("Resume could be tailored"),ce=Math.max(70,Math.min(100,ce)),{normalized:{title:t,company:n,jobUrl:a,sourceWebsite:o,location:r,salary:l,description:c,jobType:d,status:"SAVED"},canSave:!!a,completeness:Math.min(100,u),missingOptionalFields:p,matchScore:ee,recommendation:te,recommendationLabel:Y,recommendationSubtitle:ne,recommendationIcon:$,matchedFactors:Q,unmatchedFactors:P,matchedSkills:N,missingSkills:j,roleMatchStatus:x,roleMatchReason:g,roleRequiredText:t,roleProfileText:(rt=m.preferredRoles)!=null&&rt.length?m.preferredRoles.join(", "):"Not specified",experienceMatchStatus:S,experienceMatchReason:T,experienceRequiredText:b.requiredText,experienceProfileText:b.profileText,educationMatchStatus:w,educationMatchReason:C,educationRequiredText:k.requiredText,educationProfileText:m.degree?`${m.degree}${m.specialization?` (${m.specialization})`:""}`:"Not specified",skillsMatchStatus:O,skillsMatchReason:H,locationMatchStatus:G,locationMatchReason:F,readinessScore:ce,readinessFactors:re,readinessIssues:U}}const nt={get:()=>We.get("/api/profile"),update:s=>We.put("/api/profile",s)},Ae="talvyn-panel",Ye="talvyn-host",fe="talvyn_panel_position";function it(){let s=typeof document<"u"?document.getElementById(Ye):null;if(!s){s=document.createElement("div"),s.id=Ye,s.setAttribute("data-talvyn-host","true"),Object.assign(s.style,{position:"fixed",top:"0",left:"0",width:"0",height:"0",zIndex:"2147483647",pointerEvents:"none"}),typeof document<"u"&&(document.body?document.body.appendChild(s):document.documentElement&&document.documentElement.appendChild(s));const t=s.attachShadow?s.attachShadow({mode:"open"}):s;if(typeof document<"u"&&t){const n=document.createElement("style");n.textContent=`
        :host {
          all: initial;
        }
        *, *::before, *::after {
          box-sizing: border-box;
        }
        button, input, select, textarea {
          font-family: inherit;
        }
      `,t.appendChild(n)}}const e=s.shadowRoot||s;return{host:s,shadow:e}}function je(s){if(typeof document>"u")return null;const e=document.getElementById(Ye);if(e&&e.shadowRoot){const t=e.shadowRoot.getElementById(s);if(t)return t}return document.getElementById(s)}let Qe=null,Ze=null,Ke=null,ue=null,we=null,q=!1;function _e(s,e,t,n,i){var o,d;J(),Qe=e,Ze=t,Ke=(i==null?void 0:i.onProfileUpdated)||null,ue=s,we=i;const a=document.createElement("div");a.id=Ae,a.setAttribute("data-talvyn","true"),a.style.pointerEvents="auto";const r=(i==null?void 0:i.theme)==="dark"||(i==null?void 0:i.theme)!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;q=!!r,a.innerHTML=Tn(s,i,r),It(a,r);const{shadow:l}=it();l.appendChild(a);const c=a.querySelector("#talvyn-panel-header");c&&qe(a,c,fe),ye(a,s,i),(o=a.querySelector("#talvyn-dismiss-btn"))==null||o.addEventListener("click",()=>{n(),J()}),(d=a.querySelector("#talvyn-collapse-btn"))==null||d.addEventListener("click",()=>{vn(a)})}function qe(s,e,t=fe){if(!s||!e||typeof e.addEventListener!="function")return;e.style.cursor="grab",e.style.userSelect="none",e.style.touchAction="none";let n=!1,i=0,a=0,r=0,l=0,c=!1,o="";const d=y=>{if(y.target&&y.target.closest('button, a, input, select, textarea, [role="button"]')||"button"in y&&y.button!==0)return;n=!0,c=!1,i=y.clientX,a=y.clientY;const h=s.getBoundingClientRect();if(r=h.left,l=h.top,s.style.bottom="auto",s.style.right="auto",s.style.left=`${r}px`,s.style.top=`${l}px`,"setPointerCapture"in e&&"pointerId"in y)try{e.setPointerCapture(y.pointerId)}catch{}y.preventDefault&&y.preventDefault()},p=y=>{if(!n)return;const h=y.clientX-i,x=y.clientY-a;if(!c&&Math.hypot(h,x)>3&&(c=!0,e.style.cursor="grabbing",typeof document<"u"&&document.body&&(o=document.body.style.userSelect,document.body.style.userSelect="none")),!c)return;let g=r+h,b=l+x;const v=s.offsetWidth||320,S=s.offsetHeight||420,T=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,k=typeof window<"u"&&window.innerHeight?window.innerHeight:800,A=Math.max(0,T-v),w=Math.max(0,k-S);g=Math.max(0,Math.min(g,A)),b=Math.max(0,Math.min(b,w)),s.style.left=`${g}px`,s.style.top=`${b}px`},u=y=>{if(n){if(n=!1,e.style.cursor="grab",typeof document<"u"&&document.body&&(document.body.style.userSelect=o),y&&"releasePointerCapture"in e&&"pointerId"in y)try{e.releasePointerCapture(y.pointerId)}catch{}if(c)try{const h=s.getBoundingClientRect();localStorage.setItem(t,JSON.stringify({x:h.left,y:h.top}))}catch{}}};e.addEventListener("pointerdown",d),e.addEventListener("pointermove",p),e.addEventListener("pointerup",u),e.addEventListener("pointercancel",u),e.addEventListener("mousedown",d);const m=y=>p(y),f=y=>{u(y),typeof document<"u"&&document.removeEventListener&&(document.removeEventListener("mousemove",m),document.removeEventListener("mouseup",f))};e.addEventListener("mousedown",()=>{typeof document<"u"&&document.addEventListener&&(document.addEventListener("mousemove",m),document.addEventListener("mouseup",f))})}function ye(s,e,t){var i,a,r,l;const n=s.querySelector("#talvyn-save-btn");n==null||n.addEventListener("click",()=>{Sn(s,e||ue,t||we)}),(i=s.querySelector("#talvyn-profile-btn"))==null||i.addEventListener("click",()=>{$t(s,e||ue,t||we)}),(a=s.querySelector("#talvyn-apply-btn"))==null||a.addEventListener("click",()=>{wn(s,e||ue,t||we)}),(r=s.querySelector("#talvyn-dashboard-btn"))==null||r.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/dashboard`,"_blank")}),(l=s.querySelector("#talvyn-open-job-btn"))==null||l.addEventListener("click",()=>{const c=(e==null?void 0:e.jobUrl)||(ue==null?void 0:ue.jobUrl);c&&window.open(c,"_blank")})}function vn(s){const e=s.querySelector("#talvyn-panel-body"),t=s.querySelector("#talvyn-collapse-btn");!e||!t||(e.style.display==="none"?(e.style.display="block",t.textContent="−",t.title="Minimize"):(e.style.display="none",t.textContent="+",t.title="Expand"))}function Sn(s,e,t){var v,S,T,k,A,w;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.userProfile,a=t==null?void 0:t.normalization,r=(i==null?void 0:i.givenName)||((v=i==null?void 0:i.name)==null?void 0:v.split(" ")[0])||"",l=(i==null?void 0:i.familyName)||((S=i==null?void 0:i.name)==null?void 0:S.split(" ").slice(1).join(" "))||"",c=(i==null?void 0:i.email)||"",o=(i==null?void 0:i.phoneNumber)||"",d=((T=i==null?void 0:i.preferredLocations)==null?void 0:T[0])||(i==null?void 0:i.location)||"",p=(i==null?void 0:i.linkedInUrl)||"",u=(i==null?void 0:i.githubUrl)||"",m=(t==null?void 0:t.resumeName)||"Default Resume",f=q?"#334155":"#e2e8f0",y=q?"#f8fafc":"#0f172a",h=q?"#cbd5e1":"#475569",x=q?"#1e293b":"#f8fafc",g=q?"#0f172a":"#ffffff";n.innerHTML=`
    <div id="talvyn-review-view" style="font-size:12px;color:${y};">
      <!-- Top Title -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${f};">
        <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
          REVIEW BEFORE SAVING
        </span>
        <button id="talvyn-review-cancel-x" style="background:none;border:none;color:${h};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:380px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- JOB SECTION -->
        <div style="background:${x};border:1px solid ${f};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${h};margin-bottom:6px;text-transform:uppercase;">
            💼 Job Details
          </div>

          ${I("Title","job-title",e.title||"",g,f,y)}
          ${I("Company","job-company",e.company||"",g,f,y)}
          ${I("Location","job-location",e.location||"",g,f,y)}
          ${I("Salary","job-salary",e.salary||"",g,f,y)}
          ${I("Job URL","job-url",e.jobUrl||"",g,f,y)}
        </div>

        <!-- MATCH SUMMARY SECTION -->
        <div style="background:${x};border:1px solid ${f};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
            <span style="font-weight:700;font-size:11px;color:${h};text-transform:uppercase;">
              ⚡ Match Summary
            </span>
            <span style="font-weight:800;font-size:12px;color:#059669;">
              ${(a==null?void 0:a.matchScore)??82}% · ${(a==null?void 0:a.recommendationLabel)??"GOOD MATCH"}
            </span>
          </div>
          <div style="font-size:11px;color:${h};line-height:1.4;">
            <div>Role: ${(a==null?void 0:a.roleMatchStatus)==="MATCH"?"✓ Match":(a==null?void 0:a.roleMatchStatus)==="MISMATCH"?"⚠ Mismatch":"— Not specified"}</div>
            <div>Experience: ${(a==null?void 0:a.experienceMatchStatus)==="MATCH"?"✓ Match":(a==null?void 0:a.experienceMatchStatus)==="MISMATCH"?"⚠ Mismatch":"— Not specified"}</div>
            <div>Education: ${(a==null?void 0:a.educationMatchStatus)==="MATCH"?"✓ Match":(a==null?void 0:a.educationMatchStatus)==="MISMATCH"?"⚠ Mismatch":"— Not specified"}</div>
            <div>Skills: ${(a==null?void 0:a.skillsMatchStatus)==="MATCH"?"✓ Match":"⚠ Missing some skills"}</div>
          </div>
        </div>

        <!-- APPLICATION PROFILE SECTION -->
        <div style="background:${x};border:1px solid ${f};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${h};margin-bottom:6px;text-transform:uppercase;">
            👤 Application Profile
          </div>

          ${I("First Name","prof-givenName",r,g,f,y)}
          ${I("Last Name","prof-familyName",l,g,f,y)}
          ${I("Email","prof-email",c,g,f,y)}
          ${I("Phone","prof-phone",o,g,f,y)}
          ${I("Location","prof-location",d,g,f,y)}
          ${I("LinkedIn","prof-linkedin",p,g,f,y)}
          ${I("GitHub","prof-github",u,g,f,y)}
          ${I("Resume","prof-resume",m,g,f,y)}
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-confirm-save-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Confirm & Save Job
        </button>
        <button id="talvyn-cancel-review-btn" style="
          padding:8px 12px;background:transparent;color:${h};
          border:1px solid ${f};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `,n.querySelectorAll(".talvyn-edit-toggle").forEach(C=>{C.addEventListener("click",L=>{const N=L.currentTarget.getAttribute("data-field");if(!N)return;const j=n.querySelector(`#disp-${N}`),O=n.querySelector(`#inp-${N}`),H=L.currentTarget;O&&j&&(O.style.display==="none"?(O.style.display="block",j.style.display="none",O.focus(),H.textContent="Done"):(O.style.display="none",j.style.display="block",j.textContent=O.value.trim()||"—",H.textContent="Edit"))})});const b=()=>{n.innerHTML=he(e,t,q),ye(s,e,t)};(k=n.querySelector("#talvyn-review-cancel-x"))==null||k.addEventListener("click",b),(A=n.querySelector("#talvyn-cancel-review-btn"))==null||A.addEventListener("click",b),(w=n.querySelector("#talvyn-confirm-save-btn"))==null||w.addEventListener("click",()=>{const C=(j,O)=>{const H=n.querySelector(`#inp-${j}`);return H?H.value.trim():O},L={...e,title:C("job-title",e.title||""),company:C("job-company",e.company||""),location:C("job-location",e.location||""),salary:C("job-salary",e.salary||""),jobUrl:C("job-url",e.jobUrl||window.location.href)},N={givenName:C("prof-givenName",r),familyName:C("prof-familyName",l),email:C("prof-email",c),phoneNumber:C("prof-phone",o),location:C("prof-location",d),linkedInUrl:C("prof-linkedin",p),githubUrl:C("prof-github",u)};n.innerHTML=he(L,t,q),ye(s,L,t),Qe&&Qe(L,N)})}function wn(s,e,t){var b,v,S,T,k;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.userProfile,a=q?"#334155":"#e2e8f0",r=q?"#f8fafc":"#0f172a",l=q?"#cbd5e1":"#475569",c=q?"#1e293b":"#f8fafc",o=(i==null?void 0:i.legalFullName)||(i==null?void 0:i.name)||`${(i==null?void 0:i.givenName)||""} ${(i==null?void 0:i.familyName)||""}`.trim()||"Candidate Name",d=(i==null?void 0:i.email)||"email@example.com",p=(i==null?void 0:i.phoneNumber)||(i==null?void 0:i.phone)||"— Not provided",u=((b=i==null?void 0:i.preferredLocations)==null?void 0:b[0])||(i==null?void 0:i.location)||(i==null?void 0:i.city)||"— Not provided",m=(i==null?void 0:i.linkedInUrl)||(i==null?void 0:i.linkedinUrl)||"— Not provided",f=(i==null?void 0:i.githubUrl)||"— Not provided",y=(t==null?void 0:t.resumeName)||"Default Resume",h=(i==null?void 0:i.workAuthorization)||"Requires Review",x=(i==null?void 0:i.expectedSalary)||"Requires Review";n.innerHTML=`
    <div id="talvyn-apply-review-view" style="font-size:12px;color:${r};">
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CONTROLLED APPLICATION REVIEW
          </span>
          <div style="font-size:10.5px;color:${l};margin-top:1px;">
            Talvyn will autofill safe candidate fields and verify sensitive items.
          </div>
        </div>
        <button id="talvyn-apply-review-cancel-x" style="background:none;border:none;color:${l};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- SAFE FIELDS SECTION -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#059669;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>✓</span> Safe Fields (Autofilled Directly)
            </span>
          </div>
          <div style="font-size:11px;color:${l};display:flex;flex-direction:column;gap:3px;">
            <div><strong>Name:</strong> ${E(o)}</div>
            <div><strong>Email:</strong> ${E(d)}</div>
            <div><strong>Phone:</strong> ${E(p)}</div>
            <div><strong>Location:</strong> ${E(u)}</div>
            <div><strong>LinkedIn:</strong> ${E(m)}</div>
            <div><strong>GitHub:</strong> ${E(f)}</div>
            <div><strong>Resume:</strong> ${E(y)}</div>
          </div>
        </div>

        <!-- SENSITIVE FIELDS SECTION -->
        <div style="background:${q?"#451a03":"#fffbeb"};border:1px solid ${q?"#b45309":"#fde68a"};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#d97706;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>🛡️</span> Sensitive Fields (Explicit User Review)
            </span>
          </div>
          <div style="font-size:10.5px;color:${q?"#fef3c7":"#92400e"};line-height:1.4;display:flex;flex-direction:column;gap:4px;">
            <div>• <strong>Work Authorization / Visa:</strong> ${E(h)}</div>
            <div>• <strong>Expected Salary / CTC:</strong> ${E(x)}</div>
            <div>• <strong>Disability & Veteran Status:</strong> Prompt before fill</div>
            <div>• <strong>Legal Declarations / Sponsorship:</strong> Prompt before fill</div>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-review-continue-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Review & Continue ⚡
        </button>
        <button id="talvyn-review-edit-profile-btn" style="
          padding:8px 12px;background:transparent;color:#4f46e5;
          border:1px solid #c7d2fe;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          👤 Edit Details
        </button>
        <button id="talvyn-cancel-apply-review-btn" style="
          padding:8px 10px;background:transparent;color:${l};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `;const g=()=>{n.innerHTML=he(e,t,q),ye(s,e,t)};(v=n.querySelector("#talvyn-apply-review-cancel-x"))==null||v.addEventListener("click",g),(S=n.querySelector("#talvyn-cancel-apply-review-btn"))==null||S.addEventListener("click",g),(T=n.querySelector("#talvyn-review-edit-profile-btn"))==null||T.addEventListener("click",()=>{$t(s,e,t)}),(k=n.querySelector("#talvyn-review-continue-btn"))==null||k.addEventListener("click",()=>{n.innerHTML=he(e,t,q),ye(s,e,t),Ze&&Ze()})}function $t(s,e,t){var A,w,C,L,N,j;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.userProfile,a=q?"#334155":"#e2e8f0",r=q?"#f8fafc":"#0f172a",l=q?"#cbd5e1":"#475569",c=q?"#1e293b":"#f8fafc",o=q?"#0f172a":"#ffffff",d=(i==null?void 0:i.givenName)||((A=i==null?void 0:i.name)==null?void 0:A.split(" ")[0])||"",p=(i==null?void 0:i.familyName)||((w=i==null?void 0:i.name)==null?void 0:w.split(" ").slice(1).join(" "))||"",u=(i==null?void 0:i.email)||"",m=(i==null?void 0:i.phoneNumber)||(i==null?void 0:i.phone)||"",f=((C=i==null?void 0:i.preferredLocations)==null?void 0:C[0])||(i==null?void 0:i.location)||(i==null?void 0:i.city)||"",y=((i==null?void 0:i.preferredRoles)||[]).join(", "),h=(i==null?void 0:i.experienceYears)!==void 0&&(i==null?void 0:i.experienceYears)!==null?String(i==null?void 0:i.experienceYears):"0",x=(i==null?void 0:i.degree)||(i==null?void 0:i.education)||"",g=((i==null?void 0:i.skills)||[]).join(", "),b=(i==null?void 0:i.linkedInUrl)||(i==null?void 0:i.linkedinUrl)||"",v=(i==null?void 0:i.githubUrl)||"",S=(i==null?void 0:i.workAuthorization)||"",T=(i==null?void 0:i.expectedSalary)||"";n.innerHTML=`
    <div id="talvyn-profile-view" style="font-size:12px;color:${r};">
      <!-- Top Title -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CANDIDATE PROFILE
          </span>
          <div style="font-size:10.5px;color:${l};margin-top:1px;">
            Edit profile data to update deterministic matching
          </div>
        </div>
        <button id="talvyn-profile-cancel-x" style="background:none;border:none;color:${l};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- CAREER TARGETS -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            🎯 Career Targeting
          </div>
          ${I("Target Roles","p-roles",y,o,a,r)}
          ${I("Exp (Years)","p-exp",h,o,a,r)}
          ${I("Degree","p-degree",x,o,a,r)}
          ${I("Skills","p-skills",g,o,a,r)}
        </div>

        <!-- PERSONAL & CONTACT -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            👤 Contact & Links
          </div>
          ${I("Given Name","p-given",d,o,a,r)}
          ${I("Family Name","p-family",p,o,a,r)}
          ${I("Email","p-email",u,o,a,r)}
          ${I("Phone","p-phone",m,o,a,r)}
          ${I("Location","p-loc",f,o,a,r)}
          ${I("LinkedIn","p-linkedin",b,o,a,r)}
          ${I("GitHub","p-github",v,o,a,r)}
        </div>

        <!-- PREFERENCES & SENSITIVE -->
        <div style="background:${c};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            🛡️ Preferences & Authorization
          </div>
          ${I("Work Auth","p-auth",S,o,a,r)}
          ${I("Exp Salary","p-salary",T,o,a,r)}
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-save-profile-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          💾 Save Profile & Re-Run Matching
        </button>
        <button id="talvyn-cancel-profile-btn" style="
          padding:8px 12px;background:transparent;color:${l};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `,n.querySelectorAll(".talvyn-edit-toggle").forEach(O=>{O.addEventListener("click",H=>{const R=H.currentTarget.getAttribute("data-field");if(!R)return;const G=n.querySelector(`#disp-${R}`),F=n.querySelector(`#inp-${R}`),z=H.currentTarget;F&&G&&(F.style.display==="none"?(F.style.display="block",G.style.display="none",F.focus(),z.textContent="Done"):(F.style.display="none",G.style.display="block",G.textContent=F.value.trim()||"—",z.textContent="Edit"))})});const k=()=>{n.innerHTML=he(e,t,q),ye(s,e,t)};(L=n.querySelector("#talvyn-profile-cancel-x"))==null||L.addEventListener("click",k),(N=n.querySelector("#talvyn-cancel-profile-btn"))==null||N.addEventListener("click",k),(j=n.querySelector("#talvyn-save-profile-btn"))==null||j.addEventListener("click",async O=>{const H=O.currentTarget;H.disabled=!0,H.textContent="Saving Profile...";const R=(P,ce)=>{const re=n.querySelector(`#inp-${P}`);return re?re.value.trim():ce},G=R("p-exp",h),F=parseInt(G,10),z=isNaN(F)?0:F,ee=R("p-roles",y),te=ee?ee.split(",").map(P=>P.trim()).filter(Boolean):[],Y=R("p-skills",g),ne=Y?Y.split(",").map(P=>P.trim()).filter(Boolean):[],$={...i||{},id:(i==null?void 0:i.id)||"user",userId:(i==null?void 0:i.userId)||"user",givenName:R("p-given",d),familyName:R("p-family",p),name:`${R("p-given",d)} ${R("p-family",p)}`.trim(),email:R("p-email",u),phoneNumber:R("p-phone",m),location:R("p-loc",f),preferredLocations:[R("p-loc",f)].filter(Boolean),preferredRoles:te,experienceYears:z,degree:R("p-degree",x),skills:ne,linkedInUrl:R("p-linkedin",b),githubUrl:R("p-github",v),workAuthorization:R("p-auth",S),expectedSalary:R("p-salary",T),preferredJobTypes:(i==null?void 0:i.preferredJobTypes)||[],otherLinks:(i==null?void 0:i.otherLinks)||[],workStyle:(i==null?void 0:i.workStyle)||"ANY",onboardingCompleted:!0};try{await nt.update({givenName:$.givenName,familyName:$.familyName,email:$.email,phone:$.phoneNumber,preferredRoles:$.preferredRoles,experienceYears:$.experienceYears,degree:$.degree,skills:$.skills,preferredLocations:$.preferredLocations,linkedinUrl:$.linkedInUrl,githubUrl:$.githubUrl,workAuthorization:$.workAuthorization,expectedSalary:$.expectedSalary})}catch(P){console.warn("[Talvyn] Profile update error:",P)}const Q=Ce(e,$);if(t&&(t.userProfile=$,t.normalization=Q),we=t,Ke)try{await Ke($)}catch{}n.innerHTML=he(e,t,q),ye(s,e,t)})}function I(s,e,t,n,i,a){const r=t.trim()?t:"—";return`
    <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:4px;font-size:11px;">
      <span style="color:#64748b;font-weight:500;min-width:65px;flex-shrink:0;">${E(s)}:</span>
      <div style="flex:1;min-width:0;">
        <span id="disp-${e}" style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;">
          ${E(r)}
        </span>
        <input id="inp-${e}" value="${E(t)}" style="
          display:none;width:100%;padding:2px 5px;font-size:11px;border:1px solid #4f46e5;
          border-radius:4px;background:${n};color:${a};box-sizing:border-box;
        " />
      </div>
      <button class="talvyn-edit-toggle" data-field="${e}" style="
        background:none;border:1px solid ${i};border-radius:4px;padding:1px 5px;
        font-size:10px;font-weight:600;color:#4f46e5;cursor:pointer;flex-shrink:0;
      ">Edit</button>
    </div>
  `}function Tn(s,e,t=!1){const n=t?"#334155":"#e2e8f0",i=t?"#f8fafc":"#0f172a",a=t?"#94a3b8":"#64748b";return`
    <div id="talvyn-panel-container">
      <!-- Header (Draggable Handle) -->
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${n};
        cursor:grab;user-select:none;
      " title="Drag to move panel">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${i};">Talvyn</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          <span style="
            font-size:10.5px;font-weight:700;color:#059669;background:${t?"#064e3b":"#ecfdf5"};
            padding:2px 7px;border-radius:999px;display:inline-flex;align-items:center;gap:3px;
          ">
            <span style="width:5px;height:5px;border-radius:50%;background:#10b981;display:inline-block;"></span>
            ● Connected
          </span>
          <button id="talvyn-profile-btn" style="
            background:none;border:1px solid ${n};border-radius:6px;
            padding:2px 6px;cursor:pointer;color:${i};font-size:11px;font-weight:600;
          " title="Candidate Profile">👤 Profile</button>
          <button id="talvyn-collapse-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:15px;
            font-weight:700;line-height:1;padding:0 3px;
          " title="Minimize">−</button>
          <button id="talvyn-dismiss-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:16px;
            line-height:1;padding:0 2px;
          " title="Close">×</button>
        </div>
      </div>

      <div id="talvyn-panel-body">
        ${he(s,e,t)}
      </div>
    </div>
  `}function he(s,e,t=!1){var H,R,G,F;const n=e==null?void 0:e.normalization,i=(n==null?void 0:n.matchScore)??82,a=(n==null?void 0:n.recommendationLabel)??"GOOD MATCH",r=(n==null?void 0:n.recommendationSubtitle)??"Worth applying",l=(n==null?void 0:n.recommendationIcon)??"🟢",c=(H=n==null?void 0:n.matchedSkills)!=null&&H.length?n.matchedSkills:[],o=(R=n==null?void 0:n.missingSkills)!=null&&R.length?n.missingSkills:[],d=(n==null?void 0:n.readinessScore)??90,p=(G=n==null?void 0:n.readinessFactors)!=null&&G.length?n.readinessFactors:["Resume available","Profile complete","Experience suitable"],u=(F=n==null?void 0:n.readinessIssues)!=null&&F.length?n.readinessIssues:[],m=s.location?`📍 ${s.location}`:"— Location: Not specified",f=s.salary?`💰 ${s.salary}`:"— Salary: Not specified",y=s.jobType?`💼 ${An(s.jobType)}`:"💼 Full Time",h=t?"#1e293b":"#f8fafc",x=t?"#334155":"#e2e8f0",g=t?"#f8fafc":"#0f172a",b=t?"#cbd5e1":"#475569",v=t?"#94a3b8":"#64748b";let S="#059669";i<50?S="#dc2626":i<70?S="#d97706":i<85&&(S="#2563eb");const T=(n==null?void 0:n.roleMatchStatus)==="MATCH",k=(n==null?void 0:n.roleMatchStatus)==="MISMATCH",A=(n==null?void 0:n.experienceMatchStatus)==="MATCH",w=(n==null?void 0:n.experienceMatchStatus)==="MISMATCH";n==null||n.educationMatchStatus;const C=(n==null?void 0:n.educationMatchStatus)==="MISMATCH",L=(n==null?void 0:n.educationMatchStatus)==="UNSPECIFIED"||!(n!=null&&n.educationMatchStatus),N=(n==null?void 0:n.skillsMatchStatus)!=="MISMATCH",j=(n==null?void 0:n.locationMatchStatus)==="MATCH",O=(n==null?void 0:n.locationMatchStatus)==="MISMATCH";return(n==null?void 0:n.locationMatchStatus)==="UNSPECIFIED"||n!=null&&n.locationMatchStatus,`
    <!-- 1. JOB Details -->
    <div style="margin-bottom:10px;">
      <div style="font-size:13.5px;font-weight:700;color:${g};line-height:1.3;margin-bottom:3px;">
        ${E(s.title)}
      </div>
      <div style="font-size:12px;color:${b};font-weight:600;margin-bottom:4px;">
        ${E(s.company)}
      </div>
      <div style="font-size:11px;color:${v};display:flex;flex-wrap:wrap;gap:8px;">
        <span>${E(m)}</span>
        <span>${E(f)}</span>
        <span>${E(y)}</span>
      </div>
    </div>

    <div style="height:1px;background:${x};margin:8px 0;"></div>

    <!-- 2. PROFILE MATCH Section -->
    <div style="margin-bottom:10px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${b};letter-spacing:0.3px;text-transform:uppercase;">PROFILE MATCH</span>
        <span style="font-size:14px;font-weight:800;color:${S};">${i}%</span>
      </div>

      <!-- Factor Checkmarks & Statuses -->
      <div style="display:flex;flex-direction:column;gap:3.5px;margin-bottom:6px;">
        <!-- Role match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${T?"#059669":k?"#dc2626":v};">
          <span style="font-weight:800;">${T?"✓":k?"⚠":"—"}</span>
          <span>${T?"Role match":k?"Role mismatch":"— Role: Not specified"}</span>
        </div>

        <!-- Experience match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${w?"#dc2626":A?"#059669":v};">
          <span style="font-weight:800;">${w?"⚠":A?"✓":"—"}</span>
          <span>${w?"Experience mismatch":A?"Experience match":"— Experience: Not specified"}</span>
        </div>

        <!-- Education match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${C?"#dc2626":L?v:"#059669"};">
          <span style="font-weight:800;">${C?"⚠":L?"—":"✓"}</span>
          <span>${C?"Education mismatch":L?"— Education: Not specified":"Education match"}</span>
        </div>

        <!-- Skills match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${N?"#059669":"#dc2626"};">
          <span style="font-weight:800;">${N?"✓":"⚠"}</span>
          <span>${N?"Skills match":"Missing required skills"}</span>
        </div>

        <!-- Location match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${O?"#dc2626":j?"#059669":v};">
          <span style="font-weight:800;">${j?"✓":O?"⚠":"—"}</span>
          <span>${j?"Location match":O?"Location mismatch":"— Location: Not specified"}</span>
        </div>
      </div>

      <!-- Experience Mismatch Callout -->
      ${w?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Experience mismatch</div>
          <div>Required: ${E((n==null?void 0:n.experienceRequiredText)||"2–4 years")}</div>
          <div>Your profile: ${E((n==null?void 0:n.experienceProfileText)||"Fresher")}</div>
        </div>
      `:""}

      <!-- Education Mismatch Callout -->
      ${C&&(n!=null&&n.educationRequiredText)&&n.educationRequiredText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Education mismatch</div>
          <div>Required: ${E(n.educationRequiredText)}</div>
          <div>Your profile: ${E((n==null?void 0:n.educationProfileText)||"Not specified")}</div>
        </div>
      `:""}

      <!-- Role Mismatch Callout -->
      ${k&&(n!=null&&n.roleProfileText)&&n.roleProfileText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Role mismatch</div>
          <div>Required: ${E((n==null?void 0:n.roleRequiredText)||s.title)}</div>
          <div>Target role: ${E(n.roleProfileText)}</div>
        </div>
      `:""}

      <!-- Matched Skills -->
      ${c.length>0?`
        <div style="font-size:10.5px;color:${b};margin-top:4px;">
          <span style="font-weight:700;color:${g};">Matched:</span>
          <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:2px;">
            ${c.map(z=>`
              <span style="
                font-size:10px;padding:1px 6px;border-radius:4px;
                background:${t?"#064e3b":"#ecfdf5"};color:#059669;border:1px solid ${t?"#047857":"#a7f3d0"};
              ">✓ ${E(z)}</span>
            `).join("")}
          </div>
        </div>
      `:""}

      <!-- Missing Skills -->
      ${o.length>0?`
        <div style="font-size:10.5px;color:${b};margin-top:4px;">
          <span style="font-weight:700;color:${g};">Missing:</span>
          <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:2px;">
            ${o.map(z=>`
              <span style="
                font-size:10px;padding:1px 6px;border-radius:4px;
                background:${t?"#451a03":"#fffbeb"};color:#d97706;border:1px solid ${t?"#b45309":"#fde68a"};
              ">⚠ ${E(z)}</span>
            `).join("")}
          </div>
        </div>
      `:""}
    </div>

    <div style="height:1px;background:${x};margin:8px 0;"></div>

    <!-- 3. SHORTLIST Recommendation Box -->
    <div style="
      background:${h};border:1px solid ${x};border-radius:9px;
      padding:8px 10px;margin-bottom:10px;
    ">
      <div style="display:flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:${g};">
        <span>${l}</span>
        <span>${E(a)}</span>
      </div>
      <div style="font-size:11px;color:${v};margin-left:18px;margin-top:1px;">
        ${E(r)}
      </div>
    </div>

    <!-- 4. APPLICATION READINESS Section -->
    <div style="margin-bottom:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${b};letter-spacing:0.3px;text-transform:uppercase;">APPLICATION READINESS</span>
        <span style="font-size:12.5px;font-weight:800;color:#059669;">${d}%</span>
      </div>

      <div style="display:flex;flex-direction:column;gap:3px;">
        ${p.map(z=>`
          <div style="font-size:11px;color:#059669;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">✓</span> <span>${E(z)}</span>
          </div>
        `).join("")}
        ${u.map(z=>`
          <div style="font-size:11px;color:#dc2626;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">⚠</span> <span>${E(z)}</span>
          </div>
        `).join("")}
      </div>
    </div>

    <div id="talvyn-status" style="display:none;margin-bottom:8px;"></div>

    <!-- 5. Action Buttons -->
    <div id="talvyn-actions" style="display:flex;flex-direction:column;gap:6px;">
      <button id="talvyn-save-btn" style="
        width:100%;padding:9px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
        color:white;border:none;border-radius:8px;font-size:12.5px;font-weight:700;
        cursor:pointer;transition:opacity 0.15s, transform 0.1s;box-shadow:0 2px 6px rgba(79,70,229,0.25);
      ">
        ★ Save Job
      </button>

      <button id="talvyn-apply-btn" style="
        width:100%;padding:8px 12px;background:#ffffff;
        color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;
        cursor:pointer;transition:background 0.15s;display:flex;align-items:center;justify-content:center;gap:5px;
      ">
        <span>⚡</span> Apply with Talvyn
      </button>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:2px;">
        <button id="talvyn-open-job-btn" style="
          padding:5px 8px;background:transparent;color:${v};
          border:1px solid ${x};border-radius:7px;font-size:11px;font-weight:500;
          cursor:pointer;text-align:center;
        ">
          Open Job ↗
        </button>
        <button id="talvyn-dashboard-btn" style="
          padding:5px 8px;background:transparent;color:#6366f1;
          border:1px solid ${x};border-radius:7px;font-size:11px;font-weight:600;
          cursor:pointer;text-align:center;
        ">
          Dashboard
        </button>
      </div>
    </div>
  `}function mt(s,e,t="system"){var d,p,u;J();const n=document.createElement("div");n.id=Ae,n.setAttribute("data-talvyn","true");const i=t==="dark"||t!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches,a=i?"#334155":"#e2e8f0",r=i?"#f8fafc":"#0f172a",l=i?"#cbd5e1":"#475569";n.innerHTML=`
    <div id="talvyn-panel-container">
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${a};
        cursor:grab;user-select:none;
      " title="Drag to move">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${r};">Talvyn Intelligence</span>
        </div>
        <button id="talvyn-dismiss-btn" style="
          background:none;border:none;cursor:pointer;color:#94a3b8;font-size:16px;line-height:1;padding:0 2px;
        " title="Close">×</button>
      </div>

      <div style="padding:4px 2px;">
        <div style="
          background:${i?"#1e293b":"#f8fafc"};
          border:1px solid ${i?"#334155":"#e2e8f0"};
          border-radius:10px;padding:14px 12px;margin-bottom:10px;text-align:center;
        ">
          <div style="font-size:22px;margin-bottom:6px;">💼</div>
          <div style="font-weight:700;font-size:13px;color:${r};margin-bottom:4px;">
            No job opportunities detected on this page.
          </div>
          <p style="font-size:11.5px;color:${l};line-height:1.4;margin:0;">
            Make sure you are on an active job posting, detail page, or career listings portal.
          </p>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;">
          <button id="talvyn-reanalyze-btn" style="
            width:100%;padding:9px;background:linear-gradient(to right, #4f46e5, #6366f1);
            color:white;border:none;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;
            box-shadow:0 2px 6px rgba(79,70,229,0.25);
          ">
            Analyze Again
          </button>
          <button id="talvyn-dashboard-btn" style="
            width:100%;padding:8px;background:transparent;color:#6366f1;
            border:1px solid ${a};border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">
            Open Talvyn Dashboard
          </button>
        </div>
      </div>
    </div>
  `,It(n,i);const{shadow:c}=it();c.appendChild(n);const o=n.querySelector("#talvyn-panel-header");o&&qe(n,o,fe),(d=n.querySelector("#talvyn-dismiss-btn"))==null||d.addEventListener("click",()=>{s(),J()}),(p=n.querySelector("#talvyn-reanalyze-btn"))==null||p.addEventListener("click",()=>{e&&e()}),(u=n.querySelector("#talvyn-dashboard-btn"))==null||u.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/dashboard`,"_blank")})}function It(s,e=!1){let t=null;try{const o=localStorage.getItem(fe);o&&(t=JSON.parse(o))}catch{}const n=320,i=460,a=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,r=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let l=Math.max(16,a-n-24),c=Math.max(16,r-i-40);if(t&&typeof t.x=="number"&&typeof t.y=="number"){const o=Math.max(0,a-n),d=Math.max(0,r-200);l=Math.max(0,Math.min(t.x,o)),c=Math.max(0,Math.min(t.y,d))}Object.assign(s.style,{position:"fixed",top:`${c}px`,left:`${l}px`,bottom:"auto",right:"auto",zIndex:"2147483647",width:`${n}px`,background:e?"#0f172a":"#ffffff",color:e?"#f8fafc":"#0f172a",borderRadius:"14px",boxShadow:e?"0 10px 36px rgba(0,0,0,0.6), 0 2px 6px rgba(0,0,0,0.3)":"0 10px 36px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",padding:"13px",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',fontSize:"13px",lineHeight:"1.4",border:e?"1px solid #334155":"1px solid #e2e8f0",boxSizing:"border-box",transition:"box-shadow 0.2s ease"})}function oe(s){var a;const e=je(Ae);if(!e)return;const t=e.querySelector("#talvyn-status");e.querySelector("#talvyn-actions");const n=e.querySelector("#talvyn-save-btn"),i=e.querySelector("#talvyn-apply-btn");if(t)switch(s.type){case"loading":n&&(n.textContent="Saving...",n.disabled=!0,n.style.opacity="0.7"),t.style.display="none";break;case"saved":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${E(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"duplicate":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#d97706;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#b45309;">Status: ${E(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"applied":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>APPLICATION TRACKED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${E(s.existingStatus||"APPLIED")}</span>
          </div>
          ${s.dateApplied?`<div style="font-size:10.5px;color:#64748b;margin-top:2px;">Submitted ${E(s.dateApplied)}</div>`:""}
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"in_progress":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#2563eb;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>⏳</span> <span>IN PROGRESS</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#1d4ed8;">Status: ${E(s.existingStatus||"IN_PROGRESS")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"autofilling":i&&(i.textContent="⏳ Autofilling...",i.disabled=!0);break;case"autofill-complete":i&&(i.textContent="⚡ Apply with Talvyn",i.disabled=!1);break;case"error":n&&(n.textContent="★ Save Job",n.disabled=!1,n.style.opacity="1",n.style.cursor="pointer"),i&&(i.disabled=!1),t.innerHTML=`
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:8px 10px;margin-bottom:8px;color:#dc2626;font-size:11.5px;line-height:1.4;">
          <div style="font-weight:700;">⚠ Error</div>
          <div>${E(s.message||"Failed to complete action. Please try again.")}</div>
        </div>
      `,t.style.display="block";break;case"logged-out":t.innerHTML=`
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;margin-bottom:8px;font-size:11.5px;color:#475569;">
          <div>Sign in to Talvyn to track opportunities.</div>
          <button id="talvyn-signin-btn" style="
            margin-top:6px;width:100%;padding:6px;background:#4f46e5;color:white;
            border:none;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">Sign In to Talvyn</button>
        </div>
      `,t.style.display="block",(a=e.querySelector("#talvyn-signin-btn"))==null||a.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/login`,"_blank")});break;case"idle":default:n&&(n.textContent="★ Save Job",n.disabled=!1,n.style.opacity="1",n.style.cursor="pointer"),i&&(i.disabled=!1),t.style.display="none";break}}function J(){var s,e;(s=je(Ae))==null||s.remove(),typeof document<"u"&&((e=document.getElementById(Ae))==null||e.remove())}function An(s){return s.replace(/_/g," ").toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function E(s){return(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}const ke="talvyn-discovery-panel";class Cn{constructor(){this.isMinimized=!1,this.currentFilter="ALL",this.summary=null,this.callbacks=null}render(e,t){this.summary=e,this.callbacks=t,this.remove();const n=document.createElement("div");n.id=ke,n.setAttribute("data-talvyn","true"),n.style.pointerEvents="auto",n.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(n,this.isMinimized);const{shadow:i}=it();i.appendChild(n);const a=n.querySelector("#talvyn-discovery-header");a&&qe(n,a,fe),this.attachEventListeners(n)}updateSummary(e){this.summary=e;const t=je(ke);if(!t||!this.callbacks)return;t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized);const n=t.querySelector("#talvyn-discovery-header");n&&qe(t,n,fe),this.attachEventListeners(t)}remove(){var e,t;(e=je(ke))==null||e.remove(),typeof document<"u"&&((t=document.getElementById(ke))==null||t.remove())}buildMinimizedHTML(e){const t=e.excellentCount+e.highlyRelevantCount;return`
      <div id="talvyn-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 14px;
        background:#6366f1;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 4px 20px rgba(99,102,241,0.4);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <div style="
          width:20px;height:20px;background:rgba(255,255,255,0.25);border-radius:6px;
          display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;
        ">T</div>
        <span>Talvyn Discovery (${e.totalDetected} jobs${t>0?` · ${t} top`:""})</span>
      </div>
    `}buildExpandedHTML(e){const t=this.filterJobs(e.analyzedJobs),n=e.excellentCount+e.highlyRelevantCount;return`
      <div style="display:flex;flex-direction:column;max-height:560px;">
        <!-- Header (Draggable Handle) -->
        <div id="talvyn-discovery-header" style="
          padding:12px 14px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;cursor:grab;user-select:none;
        " title="Drag to move panel">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:24px;height:24px;background:rgba(255,255,255,0.2);border-radius:6px;
              display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;
            ">T</div>
            <div>
              <div style="font-weight:800;font-size:13px;letter-spacing:0.3px;">TALVYN JOB INTELLIGENCE</div>
              <div style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalDetected} jobs analyzed</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Breakdown Bar -->
        <div style="
          padding:8px 12px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              Strong Match: ${e.excellentCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
            ">
              Good Match: ${e.highlyRelevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              Moderate Match: ${e.relevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fef2f2;color:#991b1b;border:1px solid #fecaca;
            ">
              Low Match: ${e.lowRelevanceCount}
            </span>
          </div>
        </div>

        <!-- Action & Control Bar: [ Analyze This Page ] and [ Save Top Matches ] -->
        <div style="
          display:flex;padding:8px 12px;gap:6px;background:#ffffff;
          border-bottom:1px solid #f1f5f9;align-items:center;justify-content:space-between;flex-shrink:0;
        ">
          <button id="talvyn-reanalyze-page-btn" style="
            padding:5px 10px;background:#f8fafc;color:#4f46e5;border:1px solid #c7d2fe;
            border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:4px;
            transition:all 0.15s;
          ">
            <span>🔄</span> Analyze This Page
          </button>

          <button id="talvyn-save-all-top-btn" ${n===0?"disabled":""} style="
            padding:5px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;border:none;border-radius:8px;
            font-size:11px;font-weight:700;cursor:${n===0?"not-allowed":"pointer"};white-space:nowrap;
            opacity:${n===0?"0.6":"1"};box-shadow:0 1px 4px rgba(79,70,229,0.3);transition:background 0.15s;
          ">
            ★ Save Top Matches (${n})
          </button>
        </div>

        <!-- Filter Tabs -->
        <div style="
          display:flex;padding:6px 12px;gap:4px;background:#f8fafc;
          border-bottom:1px solid #e2e8f0;overflow-x:auto;flex-shrink:0;align-items:center;
        ">
          ${this.renderFilterTab("ALL",`All (${e.totalDetected})`)}
          ${this.renderFilterTab("STRONG",`Strong (${e.excellentCount})`)}
          ${this.renderFilterTab("GOOD",`Good (${e.highlyRelevantCount})`)}
          ${this.renderFilterTab("MODERATE",`Moderate (${e.relevantCount})`)}
          ${this.renderFilterTab("LOW",`Low (${e.lowRelevanceCount})`)}
          ${this.renderFilterTab("SAVED","Saved")}
        </div>

        <!-- Scrollable Job List -->
        <div id="talvyn-cards-container" style="
          padding:10px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${t.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No jobs in this category.
            </div>
          `:t.map(i=>this.renderJobCard(i)).join("")}
        </div>

        <!-- Footer -->
        <div style="
          padding:8px 12px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;font-size:11px;
        ">
          <span style="color:#94a3b8;">Deterministic relevance score</span>
          <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="
            color:#4f46e5;text-decoration:none;font-weight:600;
          ">View in Tracker →</a>
        </div>
      </div>
    `}renderFilterTab(e,t){const n=this.currentFilter===e;return`
      <button class="talvyn-tab-btn" data-filter="${e}" style="
        padding:3px 9px;border-radius:10px;font-size:10.5px;font-weight:600;cursor:pointer;
        border:1px solid ${n?"#6366f1":"#e2e8f0"};
        background:${n?"#6366f1":"#ffffff"};
        color:${n?"#ffffff":"#64748b"};
        white-space:nowrap;transition:all 0.15s;
      ">${t}</button>
    `}renderJobCard(e){var v,S,T,k,A,w,C,L,N,j;const{job:t,relevanceScore:n,category:i,isSaved:a}=e,r=`job-card-${this.hashUrl(t.jobUrl)}`,l=((v=e.experienceMatch)==null?void 0:v.requiredText)||"Not specified",c=((S=e.educationMatch)==null?void 0:S.requiredText)||"Not specified",o=((T=e.roleMatch)==null?void 0:T.score)!==void 0?e.roleMatch.score>=.6:!0,d=((k=e.experienceMatch)==null?void 0:k.status)==="MATCH",p=((A=e.experienceMatch)==null?void 0:A.status)==="MISMATCH",u=((w=e.educationMatch)==null?void 0:w.status)==="MATCH",m=((C=e.educationMatch)==null?void 0:C.status)==="MISMATCH",f=((L=e.skillsMatch)==null?void 0:L.status)!=="MISMATCH",y=((N=e.locationMatch)==null?void 0:N.score)!==void 0?e.locationMatch.score>=.7:!0;let h="#fef2f2",x="#991b1b",g="#fecaca",b="🔴 LOW MATCH";return i==="EXCELLENT"?(h="#ecfdf5",x="#065f46",g="#6ee7b7",b="🟢 STRONG MATCH"):i==="HIGHLY_RELEVANT"?(h="#eef2ff",x="#4338ca",g="#a5b4fc",b="🟢 GOOD MATCH"):i==="RELEVANT"?(h="#fffbeb",x="#92400e",g="#fde68a",b="🟡 MODERATE MATCH"):b="🔴 LOW MATCH",`
      <div id="${r}" style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:10px;
        padding:10px 12px;box-shadow:0 1px 3px rgba(0,0,0,0.04);transition:all 0.15s;
      ">
        <!-- Top Title & Match % -->
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:2px;">
          <div style="font-weight:700;font-size:12.5px;color:#0f172a;line-height:1.3;flex:1;">
            ${this.escapeHtml(t.title)}
          </div>
          <div style="
            display:inline-flex;align-items:center;gap:3px;padding:2px 6px;
            border-radius:8px;font-size:10px;font-weight:800;
            background:${h};color:${x};border:1px solid ${g};
            flex-shrink:0;
          ">
            <span>PROFILE MATCH: ${n}%</span>
          </div>
        </div>

        <!-- Company & Location -->
        <div style="font-size:11.5px;color:#475569;font-weight:600;margin-bottom:6px;">
          ${this.escapeHtml(t.company)}${t.location?` · <span style="color:#64748b;font-weight:400;">📍 ${this.escapeHtml(t.location)}</span>`:""}
        </div>

        <!-- 5 Factor Match Breakdown -->
        <div style="
          background:#f8fafc;border:1px solid #f1f5f9;border-radius:6px;
          padding:6px 8px;margin-bottom:6px;font-size:10.5px;display:grid;grid-template-columns:1fr 1fr;gap:3px 8px;
        ">
          <div style="color:${o?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${o?"✓":"⚠"}</span> <span>Role</span>
          </div>
          <div style="color:${p?"#dc2626":d?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${p?"⚠":d?"✓":"—"}</span> <span>Experience</span>
          </div>
          <div style="color:${m?"#dc2626":u?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${m?"⚠":u?"✓":"—"}</span> <span>Education</span>
          </div>
          <div style="color:${f?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${f?"✓":"⚠"}</span> <span>Skills</span>
          </div>
          <div style="color:${y?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;grid-column:1 / -1;">
            <span>${y?"✓":"—"}</span> <span>Location</span>
          </div>
        </div>

        <!-- Shortlist Tier Callout -->
        <div style="margin-bottom:6px;font-size:11px;font-weight:700;">
          <span style="color:#64748b;font-size:10px;text-transform:uppercase;">SHORTLIST: </span>
          <span>${b}</span>
        </div>

        <!-- Exact Mismatch Callout -->
        ${p?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <strong>Reason:</strong> Experience mismatch: Required ${this.escapeHtml(l)}, Your profile: ${this.escapeHtml(((j=e.experienceMatch)==null?void 0:j.profileText)||"Fresher")}
          </div>
        `:""}

        ${m&&c!=="Not specified"?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <strong>Reason:</strong> Education mismatch: Required ${this.escapeHtml(c)}
          </div>
        `:""}

        <!-- Actions -->
        <div style="display:flex;gap:6px;align-items:center;margin-top:6px;">
          <button class="talvyn-save-card-btn" data-url="${this.escapeHtml(t.jobUrl)}" style="
            flex:1;padding:5px 10px;border-radius:6px;font-size:11.5px;font-weight:700;cursor:pointer;
            border:none;background:${a?"#10b981":"#4f46e5"};color:#ffffff;
            transition:background 0.15s;
          ">${a?"✓ Saved":"Save"}</button>
          
          <a href="${t.jobUrl}" target="_blank" style="
            padding:5px 10px;border-radius:6px;font-size:11px;font-weight:500;text-decoration:none;
            border:1px solid #cbd5e1;background:#ffffff;color:#475569;text-align:center;
          ">Open ↗</a>
        </div>
      </div>
    `}attachEventListeners(e){var i,a,r,l,c;(i=e.querySelector("#talvyn-minimize-btn"))==null||i.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(a=e.querySelector("#talvyn-expand-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(r=e.querySelector("#talvyn-close-btn"))==null||r.addEventListener("click",()=>{var o;this.remove(),(o=this.callbacks)==null||o.onDismiss()}),(l=e.querySelector("#talvyn-reanalyze-page-btn"))==null||l.addEventListener("click",()=>{var o;(o=this.callbacks)!=null&&o.onRefresh&&this.callbacks.onRefresh()}),e.querySelectorAll(".talvyn-tab-btn").forEach(o=>{o.addEventListener("click",d=>{const u=d.currentTarget.getAttribute("data-filter");u&&(this.currentFilter=u,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks))})}),(c=e.querySelector("#talvyn-save-all-top-btn"))==null||c.addEventListener("click",async o=>{const d=o.currentTarget;if(!this.summary||!this.callbacks)return;const p=this.summary.analyzedJobs.filter(u=>(u.category==="EXCELLENT"||u.category==="HIGHLY_RELEVANT")&&!u.isSaved);if(p.length!==0){d.disabled=!0,d.textContent="Saving Top Matches...";for(const u of p){const m=e.querySelector(`.talvyn-save-card-btn[data-url="${this.escapeHtml(u.job.jobUrl)}"]`);m&&(m.disabled=!0,m.textContent="Saving…");try{await this.callbacks.onSaveJob(u,m||document.createElement("button")),u.isSaved=!0,m&&(m.textContent="Saved ✓",m.style.background="#10b981")}catch{m&&(m.disabled=!1,m.textContent="Save Job")}}d.textContent="✓ Top Matches Saved",d.style.background="#059669"}}),e.querySelectorAll(".talvyn-save-card-btn").forEach(o=>{o.addEventListener("click",async d=>{var f;const p=d.currentTarget,u=p.getAttribute("data-url"),m=(f=this.summary)==null?void 0:f.analyzedJobs.find(y=>y.job.jobUrl===u);if(m&&this.callbacks){p.disabled=!0,p.textContent="Saving…";try{await this.callbacks.onSaveJob(m,p),m.isSaved=!0,p.textContent="Saved ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Save"}}})})}filterJobs(e){switch(this.currentFilter){case"STRONG":return e.filter(t=>t.category==="EXCELLENT");case"GOOD":return e.filter(t=>t.category==="HIGHLY_RELEVANT");case"MODERATE":return e.filter(t=>t.category==="RELEVANT");case"LOW":return e.filter(t=>t.category==="LOW_RELEVANCE");case"SAVED":return e.filter(t=>t.isSaved);default:return e}}applyStyles(e,t){let n=null;try{const d=localStorage.getItem(fe);d&&(n=JSON.parse(d))}catch{}const i=380,a=580,r=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,l=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let c=Math.max(16,r-i-24),o=Math.max(16,l-a-24);if(n&&typeof n.x=="number"&&typeof n.y=="number"){const d=Math.max(0,r-i),p=Math.max(0,l-200);c=Math.max(0,Math.min(n.x,d)),o=Math.max(0,Math.min(n.y,p))}t?Object.assign(e.style,{position:"fixed",left:`${c}px`,top:`${o}px`,bottom:"auto",right:"auto",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",left:`${c}px`,top:`${o}px`,bottom:"auto",right:"auto",width:`${i}px`,maxHeight:`${a}px`,zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(99,102,241,0.2)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}hashUrl(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n),t|=0;return Math.abs(t).toString(36)}}const V=new Cn;class kn{constructor(){this.name="Generic"}canHandle(){return!0}isApplicationForm(e,t){var d;const n=e.toLowerCase(),i=/\/apply/i.test(n)||/\/application/i.test(n)||/\/submit/i.test(n)||n.includes("job")||n.includes("career");if(Array.from(t.querySelectorAll("input, textarea, select")).length<2)return!1;const r=(((d=t.body)==null?void 0:d.textContent)||"").toLowerCase(),l=r.includes("apply")||r.includes("submit application")||r.includes("resume")||r.includes("candidate")||r.includes("first name")||r.includes("email"),c=!!t.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i]'),o=!!t.querySelector('input[name*="name" i], input[id*="name" i], input[name*="first" i]');return i&&(c||o)||l&&c&&o}findFormRoots(e){const t=Array.from(e.querySelectorAll("form"));return t.length>0?t:[e.body]}}class Ln{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isApplicationForm(e,t){return!!t.querySelector("form#application_form, #app_body, #application")||!!t.querySelector("#first_name, #last_name, #email, #phone")}findFormRoots(e){const t=e.querySelector("form#application_form, #app_body, form");return t?[t]:[e.body]}}class En{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isApplicationForm(e,t){return/\/apply\/?$/i.test(e)||!!t.querySelector(".application-form, form#application-form, .application-page")}findFormRoots(e){const t=e.querySelector(".application-form, form#application-form, form");return t?[t]:[e.body]}}class Mn{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}isApplicationForm(e,t){return/\/apply/i.test(e)||!!t.querySelector('div[data-automation-id="formField"], form[data-automation-id="applyForm"]')}findFormRoots(e){const t=e.querySelector('form, main, [data-automation-id="pageContent"]');return t?[t]:[e.body]}}class Rn{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isApplicationForm(e,t){return!!t.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]")}findFormRoots(e){const t=e.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]");return t?[t]:[e.body]}}class $n{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isApplicationForm(e,t){return!!t.querySelector('#ia-container, .ia-BasePage, form[action*="apply" i]')}findFormRoots(e){const t=e.querySelector("#ia-container, .ia-BasePage, form");return t?[t]:[e.body]}}class In{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('form, [class*="applicationForm" i], [class*="application-form" i]'),i=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return n&&i}findFormRoots(e){const t=Array.from(e.querySelectorAll('form, [class*="applicationForm" i], [class*="application-form" i]'));if(t.length>0)return t;const n=e.querySelector("main");return n?[n]:[e.body]}}class Nn{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'),i=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return n&&i||e.includes("/apply")}findFormRoots(e){const t=Array.from(e.querySelectorAll('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'));if(t.length>0)return t;const n=Array.from(e.querySelectorAll("form"));return n.length>0?n:[e.body]}}class jn{constructor(){this.adapters=[],this.genericAdapter=new kn,this.adapters=[new Ln,new En,new Mn,new Rn,new $n,new In,new Nn]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const ge=new jn,qn=new Set(["hidden","password","submit","button","reset","image","search"]),On=["csrf","token","authenticity_token","__viewstate","recaptcha","hcaptcha","turnstile","search","query","q","filter"];class zn{detectFields(e=document){const t=Array.from(e.querySelectorAll("input, textarea, select")),n=[],i=new Set;for(const a of t){if(i.has(a))continue;i.add(a);const r=this.extractField(a);r&&!r.isIgnored&&n.push(r)}return n}extractField(e){const t=e.tagName.toLowerCase(),n=e instanceof HTMLInputElement?(e.type||"text").toLowerCase():t;if(this.shouldIgnore(e,n))return null;const i=e.name||"",a=e.id||"",r=e.getAttribute("placeholder")||"",l=e.getAttribute("aria-label")||"",c=e.getAttribute("autocomplete")||"",o=e.required||e.getAttribute("aria-required")==="true",d=this.resolveLabel(e),p=this.resolveNearbyText(e),u=this.resolveOptions(e),m=this.resolveCurrentValue(e),f=this.generateSelector(e);return{id:a||i||f,element:e,selector:f,tag:n==="radio"?"radio":n==="checkbox"?"checkbox":t,inputType:n,name:i,domId:a,label:d,placeholder:r,ariaLabel:l,autocomplete:c,nearbyText:p,options:u,currentValue:m,isRequired:o||d.includes("*")||p.includes("*"),isIgnored:!1}}resolveLabel(e){var a,r,l,c,o,d;if(e.id){const p=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);if((a=p==null?void 0:p.textContent)!=null&&a.trim())return this.cleanText(p.textContent)}const t=e.closest("label");if(t){const p=t.cloneNode(!0),u=p.querySelector("input, select, textarea");if(u==null||u.remove(),(r=p.textContent)!=null&&r.trim())return this.cleanText(p.textContent)}const n=e.getAttribute("aria-labelledby");if(n){const p=document.getElementById(n);if((l=p==null?void 0:p.textContent)!=null&&l.trim())return this.cleanText(p.textContent)}if(e.getAttribute("aria-label"))return this.cleanText(e.getAttribute("aria-label"));const i=e.parentElement;if(i){const p=e.previousElementSibling;if(p&&(p.tagName==="LABEL"||p.tagName==="SPAN"||p.tagName==="P")&&(c=p.textContent)!=null&&c.trim()&&p.textContent.trim().length<=80)return this.cleanText(p.textContent);const u=e.closest("fieldset");if(u){const f=u.querySelector("legend");if((o=f==null?void 0:f.textContent)!=null&&o.trim())return this.cleanText(f.textContent)}const m=i.querySelector('label, [class*="label" i], [class*="title" i], [class*="heading" i]');if(m&&m!==e&&((d=m.textContent)!=null&&d.trim()))return this.cleanText(m.textContent)}return""}resolveNearbyText(e){const t=e.closest('.form-group, .field, [class*="field" i], [class*="control" i], div, tr');if(!t)return"";const n=t.textContent||"";return this.cleanText(n).slice(0,200)}resolveOptions(e){return e instanceof HTMLSelectElement?Array.from(e.options).map(t=>({label:this.cleanText(t.textContent||""),value:t.value,selected:t.selected})):e instanceof HTMLInputElement&&e.type==="radio"&&e.name?Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(e.name)}"]`)).map(n=>({label:this.resolveLabel(n)||n.value,value:n.value,selected:n.checked})):[]}resolveCurrentValue(e){return e instanceof HTMLInputElement&&(e.type==="checkbox"||e.type==="radio")?e.checked:e.value||""}shouldIgnore(e,t){if(qn.has(t)||e.disabled||e.readOnly)return!0;const n=window.getComputedStyle(e);if((n.display==="none"||n.visibility==="hidden"||n.opacity==="0")&&t!=="file")return!0;const i=(e.getAttribute("name")||"").toLowerCase(),a=(e.id||"").toLowerCase(),r=(e.getAttribute("aria-label")||"").toLowerCase();for(const l of On)if(i.includes(l)||a.includes(l)||r.includes(l))return!0;return!1}generateSelector(e){return e.id?`#${CSS.escape(e.id)}`:e.getAttribute("name")?`${e.tagName.toLowerCase()}[name="${CSS.escape(e.getAttribute("name"))}"]`:e.tagName.toLowerCase()}cleanText(e){return e.replace(/\s+/g," ").replace(/[\r\n\t]/g," ").trim()}}const Re=new zn,Fe=[{type:"fullName",category:"PERSONAL",label:"Full Name",autocompleteTokens:["name"],aliases:["full name","fullname","candidate name","applicant name","legal full name","legal name","your name","complete name","name (first and last)","full legal name"],negativeAliases:["first name","last name","middle name","company name","school name"]},{type:"firstName",category:"PERSONAL",label:"First Name",autocompleteTokens:["given-name"],aliases:["first name","firstname","given name","candidate first name","legal first name","fname","forename","first_name","first","prenom"],negativeAliases:["last name","middle name"]},{type:"middleName",category:"PERSONAL",label:"Middle Name",autocompleteTokens:["additional-name"],aliases:["middle name","middlename","middle initial","mname","middle_name","middle"],negativeAliases:["first name","last name"]},{type:"lastName",category:"PERSONAL",label:"Last Name",autocompleteTokens:["family-name"],aliases:["last name","lastname","family name","surname","candidate last name","legal last name","lname","last_name","last","nom"],negativeAliases:["first name","middle name"]},{type:"preferredName",category:"PERSONAL",label:"Preferred Name",autocompleteTokens:["nickname"],aliases:["preferred name","preferred first name","nickname","chosen name","known as","goes by"]},{type:"email",category:"PERSONAL",label:"Email Address",autocompleteTokens:["email"],aliases:["email","email address","e-mail","e-mail address","candidate email","personal email","electronic mail","mail"],negativeAliases:["confirm email","alternate email","referrer email"]},{type:"phone",category:"PERSONAL",label:"Phone Number",autocompleteTokens:["tel","tel-national","tel-local"],aliases:["phone","phone number","mobile","mobile number","mobile phone","contact number","telephone","cell phone","cell","tel","primary phone"],negativeAliases:["extension","fax","emergency contact"]},{type:"dateOfBirth",category:"PERSONAL",label:"Date of Birth",autocompleteTokens:["bday","bday-day","bday-month","bday-year"],aliases:["date of birth","dob","birth date","birthday","birthdate"]},{type:"gender",category:"PERSONAL",label:"Gender / Pronouns",autocompleteTokens:["sex"],aliases:["gender","sex","pronoun","pronouns","gender identity"]},{type:"address",category:"PERSONAL",label:"Street Address",autocompleteTokens:["street-address","address-line1"],aliases:["address","street address","address line 1","address 1","residential address","home address","street"],negativeAliases:["email address","ip address","web address"]},{type:"city",category:"PERSONAL",label:"City",autocompleteTokens:["address-level2"],aliases:["city","town","municipality","suburb"]},{type:"state",category:"PERSONAL",label:"State / Province",autocompleteTokens:["address-level1"],aliases:["state","province","region","territory","county"],negativeAliases:["statement","status"]},{type:"country",category:"PERSONAL",label:"Country",autocompleteTokens:["country-name","country"],aliases:["country","nation","country of residence","citizenship country","current country"],negativeAliases:["authorized to work","work in this country","sponsorship","right to work"]},{type:"postalCode",category:"PERSONAL",label:"Postal / Zip Code",autocompleteTokens:["postal-code"],aliases:["postal code","postalcode","zip code","zipcode","zip","postcode","pin code","pincode"]},{type:"linkedinUrl",category:"PROFESSIONAL",label:"LinkedIn Profile",autocompleteTokens:["url"],aliases:["linkedin","linkedin profile","linkedin url","linkedin link","linkedin.com","public profile"]},{type:"githubUrl",category:"PROFESSIONAL",label:"GitHub Profile",autocompleteTokens:["url"],aliases:["github","github profile","github url","github link","github.com","git profile","repository"]},{type:"portfolioUrl",category:"PROFESSIONAL",label:"Portfolio / Personal Site",autocompleteTokens:["url"],aliases:["portfolio","portfolio url","portfolio link","portfolio website","personal website","online portfolio","design portfolio","work samples"]},{type:"websiteUrl",category:"PROFESSIONAL",label:"Website / Other Link",autocompleteTokens:["url"],aliases:["website","website url","personal site","blog","other website","other link","url"]},{type:"skills",category:"PROFESSIONAL",label:"Skills & Tech Stack",autocompleteTokens:[],aliases:["skills","core competencies","technologies","tech stack","key skills","skill set","technical skills"]},{type:"institution",category:"EDUCATION",label:"University / Institution",autocompleteTokens:[],aliases:["university","college","school","institution","educational institution","academy","alma mater"]},{type:"degree",category:"EDUCATION",label:"Degree",autocompleteTokens:[],aliases:["degree","qualification","highest degree","education level","level of education","degree earned"]},{type:"specialization",category:"EDUCATION",label:"Major / Field of Study",autocompleteTokens:[],aliases:["major","field of study","specialization","discipline","area of study","branch"]},{type:"graduationYear",category:"EDUCATION",label:"Graduation Year",autocompleteTokens:[],aliases:["graduation year","year of graduation","grad year","completion year","end year","passout year"]},{type:"cgpa",category:"EDUCATION",label:"GPA / CGPA",autocompleteTokens:[],aliases:["gpa","cgpa","grade","percentage","marks","academic score"]},{type:"workAuthorization",category:"APPLICATION",label:"Work Authorization",autocompleteTokens:[],aliases:["work authorization","authorized to work","legally authorized to work","are you legally authorized to work","eligible to work","right to work","work permit","work eligibility"]},{type:"visaStatus",category:"APPLICATION",label:"Visa Sponsorship",autocompleteTokens:[],aliases:["sponsorship","visa sponsorship","require sponsorship","will you require sponsorship","will you now or in the future require sponsorship","need sponsorship","visa status"]},{type:"expectedSalary",category:"APPLICATION",label:"Expected Salary",autocompleteTokens:[],aliases:["expected salary","expected ctc","ctc","salary","desired salary","salary expectation","compensation expectation","expected compensation","expected pay","target compensation","desired pay"]},{type:"noticePeriod",category:"APPLICATION",label:"Notice Period / Availability",autocompleteTokens:[],aliases:["notice period","availability","how soon can you start","earliest start date","start date","when can you start"]},{type:"currentCompany",category:"APPLICATION",label:"Current Employer",autocompleteTokens:["organization"],aliases:["current company","current employer","present company","company","organization","employer"]},{type:"currentJobTitle",category:"APPLICATION",label:"Current Job Title",autocompleteTokens:["organization-title"],aliases:["current title","current job title","current role","present role","job title","title"]},{type:"yearsOfExperience",category:"APPLICATION",label:"Years of Experience",autocompleteTokens:[],aliases:["years of experience","total experience","overall experience","relevant experience","how many years of experience","experience in years"]},{type:"resumeUpload",category:"SPECIAL",label:"Resume / CV File",autocompleteTokens:[],aliases:["resume","cv","curriculum vitae","upload resume","attach resume","upload cv","attach cv","resume file","resume/cv"]},{type:"customQuestion",category:"SPECIAL",label:"Custom Application Question",autocompleteTokens:[],aliases:["why do you want to work","why are you interested","describe your experience","tell us about yourself","why should we hire you","cover letter","additional information","anything else","what makes you a good fit","personal statement"]}];class Hn{matchField(e,t){if(e.inputType==="file"||this.isResumeField(e))return{field:e,detectedType:"resumeUpload",confidence:95,confidenceLevel:"HIGH",matchedProfileField:"resume",valueToFill:null,reason:"Resume / CV file upload field detected",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!0};if(this.isSensitiveQuestion(e))return{field:e,detectedType:"customQuestion",confidence:90,confidenceLevel:"HIGH",matchedProfileField:"sensitive_declaration",valueToFill:null,reason:"⚠ Review required: Sensitive question (disability, veteran, or legal declaration)",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1,isSensitive:!0,requiresReview:!0};if(this.isCustomQuestion(e))return{field:e,detectedType:"customQuestion",confidence:85,confidenceLevel:"MEDIUM",matchedProfileField:"custom",valueToFill:null,reason:"Open-ended custom question requiring manual response",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1};const n=this.resolveFieldType(e);if(!n||n.confidence<50)return{field:e,detectedType:"unknown",confidence:(n==null?void 0:n.confidence)||20,confidenceLevel:"UNKNOWN",matchedProfileField:"none",valueToFill:null,reason:"Field type could not be confidently identified",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!1};const{value:i,reason:a,requiresManualInput:r}=this.resolveProfileValue(n.def.type,t,e),l=n.def.type==="workAuthorization"||n.def.type==="visaStatus"||n.def.type==="expectedSalary"||this.isSensitiveQuestion(e);let c=n.confidence;(r||i===null||i==="")&&(c=Math.min(c,65));const o=c>=90?"HIGH":c>=70?"MEDIUM":c>=50?"LOW":"UNKNOWN",d=!l&&!r&&i!==null&&i!==""&&c>=70;return{field:e,detectedType:n.def.type,confidence:c,confidenceLevel:o,matchedProfileField:n.def.type,valueToFill:i,reason:a||`Matched ${n.def.label} (${n.reason})`,canAutofill:d,isCustomQuestion:!1,isResumeUpload:!1,isSensitive:l,requiresReview:l||r}}resolveFieldType(e){const t=(e.autocomplete||"").toLowerCase().trim(),n=(e.label||"").toLowerCase().trim(),i=(e.name||"").toLowerCase().trim().replace(/[_-]/g," "),a=(e.domId||"").toLowerCase().trim().replace(/[_-]/g," "),r=(e.placeholder||"").toLowerCase().trim(),l=(e.ariaLabel||"").toLowerCase().trim(),c=(e.nearbyText||"").toLowerCase().trim();let o=null;for(const d of Fe){if(t&&d.autocompleteTokens.includes(t))return{def:d,confidence:95,reason:`HTML autocomplete="${t}"`};if(!(d.negativeAliases&&d.negativeAliases.some(u=>n.includes(u)||i.includes(u)))){for(const p of d.aliases)if(n===p||i===p||a===p||l===p)return{def:d,confidence:95,reason:`Exact match for "${p}"`};for(const p of d.aliases){const u=new RegExp(`\\b${_n(p)}\\b`,"i"),m=p.trim().split(/\s+/).length,f=Math.min(6,(m-1)*2);if(u.test(n)){const y=88+f;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(95,y),reason:`Label contains "${p}"`})}else if(u.test(i)||u.test(a)||u.test(l)){const y=85+f;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(95,y),reason:`Field name/id contains "${p}"`})}else if(u.test(r)){const y=80+f;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(90,y),reason:`Placeholder contains "${p}"`})}else if(c&&u.test(c)){const y=70+f;(!o||y>o.confidence)&&(o={def:d,confidence:Math.min(85,y),reason:`Nearby text contains "${p}"`})}}}}if(!o){if(e.inputType==="email"){const d=Fe.find(p=>p.type==="email");if(d)return{def:d,confidence:90,reason:"Input type is email"}}if(e.inputType==="tel"){const d=Fe.find(p=>p.type==="phone");if(d)return{def:d,confidence:90,reason:"Input type is tel"}}}return o}resolveProfileValue(e,t,n){var i,a,r;switch(e){case"fullName":return{value:t.legalFullName||(t.givenName&&t.familyName?`${t.givenName} ${t.familyName}`:t.givenName||t.preferredName)||null};case"firstName":return t.givenName?{value:t.givenName}:t.legalFullName?{value:t.legalFullName.trim().split(/\s+/)[0]}:t.preferredName?{value:t.preferredName}:{value:null,reason:"First name not found in profile"};case"middleName":{if(t.middleName)return{value:t.middleName};if(t.legalFullName){const l=t.legalFullName.trim().split(/\s+/);if(l.length>=3)return{value:l.slice(1,-1).join(" ")}}return{value:""}}case"lastName":{if(t.familyName)return{value:t.familyName};if(t.legalFullName){const l=t.legalFullName.trim().split(/\s+/);if(l.length>=2)return{value:l[l.length-1]}}return{value:null,requiresManualInput:!0,reason:"Manual input required (no last name in profile)"}}case"preferredName":return{value:t.preferredName||t.givenName||null};case"email":return{value:t.email||null};case"phone":return{value:t.phone||null};case"dateOfBirth":return{value:t.dateOfBirth||null};case"gender":return n.options.length>0&&t.gender?{value:this.matchOption(n.options,t.gender)||t.gender}:{value:t.gender||null};case"address":return{value:t.address||null};case"city":return{value:t.city||null};case"state":return{value:t.state||null};case"country":return n.options.length>0&&t.country?{value:this.matchOption(n.options,t.country)||t.country}:{value:t.country||null};case"postalCode":return{value:t.postalCode||null};case"linkedinUrl":return{value:t.linkedinUrl||null};case"githubUrl":return t.githubUrl?{value:t.githubUrl}:{value:((i=t.otherLinks)==null?void 0:i.find(c=>c.includes("github.com")))||null};case"portfolioUrl":return{value:t.portfolioUrl||null};case"websiteUrl":return t.websiteUrl?{value:t.websiteUrl}:{value:t.portfolioUrl||((a=t.otherLinks)==null?void 0:a[0])||null};case"skills":return{value:t.skills&&t.skills.length>0?t.skills.join(", "):null};case"institution":return{value:t.institution||null};case"degree":return n.options.length>0&&t.degree?{value:this.matchOption(n.options,t.degree)||t.degree}:{value:t.degree||null};case"specialization":return{value:t.specialization||null};case"graduationYear":return{value:t.graduationYear?String(t.graduationYear):null};case"cgpa":return{value:t.cgpa||null};case"workAuthorization":return n.tag==="radio"||n.tag==="select"?{value:this.matchOption(n.options,"Yes")||this.matchOption(n.options,"Authorized")||"yes"}:{value:t.workAuthorization||"Yes, authorized to work"};case"visaStatus":return n.tag==="radio"||n.tag==="select"?{value:this.matchOption(n.options,"No")||this.matchOption(n.options,"Not required")||"no"}:{value:t.visaStatus||"No sponsorship required"};case"expectedSalary":return{value:t.expectedSalary||null};case"noticePeriod":return{value:t.noticePeriod||null};case"currentCompany":return{value:t.currentCompany||null};case"currentJobTitle":return{value:t.currentJobTitle||(((r=t.preferredRoles)==null?void 0:r[0])??null)};case"yearsOfExperience":return{value:t.experienceYears!==null&&t.experienceYears!==void 0?String(t.experienceYears):null};default:return{value:null}}}matchOption(e,t){if(!e||e.length===0||!t)return null;const n=t.toLowerCase().trim();for(const i of e)if(i.value.toLowerCase()===n||i.label.toLowerCase()===n)return i.value;for(const i of e){const a=i.label.toLowerCase(),r=i.value.toLowerCase();if(a.includes(n)||n.includes(a)||r.includes(n))return i.value}return null}isResumeField(e){const t=`${e.label} ${e.name} ${e.domId} ${e.placeholder}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("cv")||t.includes("curriculum vitae")}isSensitiveQuestion(e){const t=`${e.label} ${e.name} ${e.domId} ${e.ariaLabel} ${e.placeholder} ${e.nearbyText}`.toLowerCase();return t.includes("disability")||t.includes("veteran")||t.includes("equal opportunity")||t.includes("criminal")||t.includes("background check")||t.includes("legal declaration")||t.includes("terms and conditions")||t.includes("agree to terms")||t.includes("consent to")||t.includes("digital signature")||t.includes("sign here")}isCustomQuestion(e){const t=`${e.label} ${e.placeholder} ${e.ariaLabel}`.toLowerCase(),n=[/why do you want/i,/why are you interested/i,/describe your/i,/tell us about/i,/why should we hire/i,/cover letter/i,/additional information/i,/what makes you/i,/anything else/i,/personal statement/i];return e.tag==="textarea"&&t.length>20||n.some(i=>i.test(t))}}function _n(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const Nt=new Hn;class Fn{autofillFields(e,t=!1){var l,c;let n=0,i=0,a=0;const r=[];for(const o of e){if(!o.canAutofill||o.valueToFill===null||o.valueToFill===void 0){i++;continue}const d=o.field.element;if(!d){i++;continue}const p=d.value||o.field.currentValue;if(typeof p=="string"&&p.trim().length>0&&((l=d.getAttribute)==null?void 0:l.call(d,"data-talvyn-autofilled"))!=="true"&&!t){i++;continue}try{this.fillSingleField(o.field.element,o.valueToFill,o.field.tag)?(o.isFilled=!0,(c=d.setAttribute)==null||c.call(d,"data-talvyn-autofilled","true"),n++,r.push(o)):a++}catch(m){console.error("[Talvyn Autofill] Failed to fill field:",o.field.name||o.field.domId,m),o.error=m instanceof Error?m.message:"Fill failed",a++}}return{filledCount:n,skippedCount:i,failedCount:a,filledFields:r}}getStepSignature(e){return e.map(t=>`${t.field.name||t.field.domId||t.field.label}:${t.matchedKey}`).sort().join("|")}isMultiStepApplication(e=document){const t=e.querySelectorAll('[class*="step" i], [aria-label*="step" i], [data-test*="step" i], [class*="progress" i], .wizard'),n=e.querySelector('button[class*="next" i], button[id*="next" i], [data-qa="next-step"]');return{isMultiStep:t.length>0||!!n}}fillSingleField(e,t,n){if(!e)return!1;const i=(e.tagName||n||"").toUpperCase(),a=(e.type||"").toLowerCase();if(i==="INPUT"&&a!=="radio"&&a!=="checkbox"&&a!=="file")return this.setNativeInputValue(e,String(t));if(i==="TEXTAREA")return this.setNativeTextareaValue(e,String(t));if(i==="SELECT")return this.setNativeSelectValue(e,String(t));if(i==="INPUT"&&a==="radio")return this.setNativeRadioValue(e,String(t));if(i==="INPUT"&&a==="checkbox"){const r=typeof t=="boolean"?t:t==="true"||t==="1"||t==="yes";return this.setNativeCheckboxValue(e,r)}return!1}setNativeInputValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:r.set:null;return i?i.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeTextareaValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLTextAreaElement?window.HTMLTextAreaElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:r.set:null;return i?i.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeSelectValue(e,t){var a;e.focus();const n=t.toLowerCase().trim();let i=-1;for(let r=0;r<e.options.length;r++){const l=e.options[r],c=l.value.toLowerCase().trim(),o=(l.textContent||"").toLowerCase().trim();if(c===n||o===n){i=r;break}(o.includes(n)||n.includes(o))&&(i=r)}if(i>=0){e.selectedIndex=i;const r=typeof window<"u"&&window.HTMLSelectElement?window.HTMLSelectElement.prototype:null,l=r?(a=Object.getOwnPropertyDescriptor(r,"value"))==null?void 0:a.set:null;return l&&l.call(e,e.options[i].value),this.dispatchInputEvents(e),!0}return!1}setNativeRadioValue(e,t){var r;const n=e.name;if(!n)return e.checked=!0,this.dispatchInputEvents(e),!0;const i=Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(n)}"]`)),a=t.toLowerCase().trim();for(const l of i){const c=l.value.toLowerCase().trim(),o=(((r=l.parentElement)==null?void 0:r.textContent)||"").toLowerCase().trim();if(c===a||o.includes(a))return l.checked=!0,this.dispatchInputEvents(l),!0}return!1}setNativeCheckboxValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"checked"))==null?void 0:r.set:null;return i?i.call(e,t):e.checked=t,this.dispatchInputEvents(e),!0}dispatchInputEvents(e){typeof Event>"u"||!e.dispatchEvent||(e.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("blur",{bubbles:!0,composed:!0})))}}const $e=new Fn,Pe="talvyn-autofill-panel";class Pn{constructor(){this.isMinimized=!1,this.summary=null,this.callbacks=null,this.selectedResumeId=null}render(e,t){this.summary=e,this.callbacks=t,!this.selectedResumeId&&e.defaultResume&&(this.selectedResumeId=e.defaultResume.id),this.remove();const n=document.createElement("div");n.id=Pe,n.setAttribute("data-talvyn","true"),n.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(n,this.isMinimized),document.body.appendChild(n),this.attachEventListeners(n)}updateSummary(e){this.summary=e;const t=document.getElementById(Pe);!t||!this.callbacks||(t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized),this.attachEventListeners(t))}remove(){var e;(e=document.getElementById(Pe))==null||e.remove()}buildMinimizedHTML(e){return`
      <div id="talvyn-autofill-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 15px;
        background:#4f46e5;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 6px 24px rgba(79,70,229,0.45);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <span style="font-size:15px;">⚡</span>
        <span>Talvyn Autofill (${e.highConfidenceCount+e.mediumConfidenceCount} fields ready)</span>
      </div>
    `}buildExpandedHTML(e){const t=e.highConfidenceCount,n=e.highConfidenceCount+e.mediumConfidenceCount;return`
      <div style="display:flex;flex-direction:column;max-height:580px;">
        <!-- Header -->
        <div style="
          padding:14px 16px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;
        ">
          <div style="display:flex;align-items:center;gap:9px;">
            <div style="
              width:26px;height:26px;background:rgba(255,255,255,0.2);border-radius:8px;
              display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;
            ">⚡</div>
            <div>
              <div style="font-weight:700;font-size:14px;letter-spacing:-0.2px;">Talvyn Autofill</div>
              <div style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalFields} form fields detected</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-autofill-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-autofill-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Bar -->
        <div style="
          padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              ✓ ${e.highConfidenceCount} High Confidence
            </span>
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              🔍 ${e.mediumConfidenceCount} Review
            </span>
            ${e.customQuestionsCount>0?`
              <span style="
                font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
                background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
              ">
                ✍ ${e.customQuestionsCount} Custom
              </span>
            `:""}
          </div>
          <button id="talvyn-rescan-btn" title="Re-scan DOM fields" style="
            background:transparent;border:none;color:#6366f1;font-size:11px;font-weight:600;
            cursor:pointer;padding:2px 4px;
          ">Re-scan ↺</button>
        </div>

        <!-- Resume Selection Banner (if file upload detected) -->
        ${e.resumeUploadDetected?this.renderResumeBanner(e):""}

        <!-- Scrollable Matched Fields List -->
        <div id="talvyn-autofill-fields-container" style="
          padding:12px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${e.matchedFields.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No form fields detected. Click Re-scan or open an application modal.
            </div>
          `:e.matchedFields.map(i=>this.renderFieldCard(i)).join("")}
        </div>

        <!-- Primary Action Buttons -->
        <div style="
          padding:12px 14px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;flex-direction:column;gap:8px;flex-shrink:0;
        ">
          <div style="display:flex;gap:8px;">
            <button id="talvyn-autofill-high-btn" style="
              flex:1;padding:9px 12px;background:#4f46e5;color:white;border:none;
              border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              transition:background 0.15s;
            ">
              ⚡ Autofill High Confidence (${t})
            </button>
            ${e.mediumConfidenceCount>0?`
              <button id="talvyn-autofill-all-btn" style="
                padding:9px 12px;background:#f0f4ff;color:#4338ca;border:1px solid #c7d2fe;
                border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              ">
                Fill All (${n})
              </button>
            `:""}
          </div>

          <!-- Safety Notice -->
          <div style="font-size:10px;color:#64748b;line-height:1.3;text-align:center;">
            🔒 Talvyn never auto-submits. Review all entries before clicking Submit manually.
          </div>
        </div>
      </div>
    `}renderResumeBanner(e){const t=e.availableResumes||[],n=e.defaultResume;return`
      <div style="
        padding:10px 14px;background:#f0fdf4;border-bottom:1px solid #bbf7d0;
        display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:8px;
      ">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <span style="font-size:14px;">📄</span>
          <div style="min-width:0;">
            <div style="font-size:11px;font-weight:700;color:#166534;">Resume Upload Detected</div>
            <div style="font-size:11px;color:#15803d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${n?`Default: <strong>${this.escapeHtml(n.name)}</strong>`:"No default resume set in Talvyn"}
            </div>
          </div>
        </div>
        ${t.length>1?`
          <select id="talvyn-resume-select" style="
            font-size:11px;padding:3px 6px;border-radius:6px;border:1px solid #86efac;
            background:white;color:#166534;font-weight:500;
          ">
            ${t.map(i=>`
              <option value="${i.id}" ${i.id===this.selectedResumeId?"selected":""}>
                ${this.escapeHtml(i.name)}${i.isDefault?" (Default)":""}
              </option>
            `).join("")}
          </select>
        `:`
          <a href="${le.DASHBOARD_URL}/resumes" target="_blank" style="
            font-size:11px;color:#16a34a;font-weight:600;text-decoration:none;
          ">Resumes →</a>
        `}
      </div>
    `}renderFieldCard(e){const{field:t,detectedType:n,confidence:i,confidenceLevel:a,valueToFill:r,reason:l,canAutofill:c,isCustomQuestion:o,isResumeUpload:d,isFilled:p}=e,u=t.label||t.placeholder||t.name||t.domId||"Untitled Field",m=r!=null?String(r):null;let f="#f1f5f9",y="#475569",h=`${i}% · Unknown`;return d?(f="#dcfce7",y="#15803d",h="Resume File"):o?(f="#eff6ff",y="#1d4ed8",h="Custom Question"):a==="HIGH"?(f="#ecfdf5",y="#047857",h=`${i}% · High`):a==="MEDIUM"&&(f="#fffbeb",y="#b45309",h=`${i}% · Review`),`
      <div style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;
        padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.03);
      ">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:4px;">
          <div style="font-weight:600;font-size:12px;color:#1e293b;line-height:1.3;flex:1;">
            ${this.escapeHtml(u)}
            ${t.isRequired?'<span style="color:#ef4444;font-weight:700;"> *</span>':""}
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:6px;
            background:${f};color:${y};flex-shrink:0;white-space:nowrap;
          ">${h}</span>
        </div>

        <div style="font-size:11px;color:#64748b;margin-bottom:6px;">
          Mapped: <span style="font-weight:600;color:#4f46e5;">${n}</span>
        </div>

        <!-- Value Preview -->
        ${m!==null?`
          <div style="
            font-size:11px;background:#f8fafc;padding:5px 8px;border-radius:6px;
            border:1px solid #f1f5f9;color:#0f172a;font-family:monospace;margin-bottom:6px;
            word-break:break-all;
          ">
            Value: <strong>${this.escapeHtml(m)}</strong>
          </div>
        `:o?`
          <div style="font-size:11px;color:#3b82f6;background:#eff6ff;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ✍ Custom question — manual response recommended.
          </div>
        `:d?`
          <div style="font-size:11px;color:#059669;background:#ecfdf5;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            📄 Upload using your selected Talvyn resume above.
          </div>
        `:`
          <div style="font-size:11px;color:#d97706;background:#fffbeb;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ⚠️ Manual input required (empty in profile).
          </div>
        `}

        <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;font-size:10px;color:#94a3b8;">
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:240px;">
            ${this.escapeHtml(l)}
          </span>
          ${c?`
            <button class="talvyn-fill-single-btn" data-field-id="${this.escapeHtml(t.id)}" style="
              padding:3px 8px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;
              border:1px solid #c7d2fe;background:${p?"#10b981":"#f0f4ff"};
              color:${p?"#ffffff":"#4338ca"};
            ">${p?"Filled ✓":"Fill"}</button>
          `:""}
        </div>
      </div>
    `}attachEventListeners(e){var i,a,r,l,c,o;(i=e.querySelector("#talvyn-autofill-minimize-btn"))==null||i.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(a=e.querySelector("#talvyn-autofill-expand-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(r=e.querySelector("#talvyn-autofill-close-btn"))==null||r.addEventListener("click",()=>{var d;this.remove(),(d=this.callbacks)==null||d.onDismiss()}),(l=e.querySelector("#talvyn-rescan-btn"))==null||l.addEventListener("click",()=>{var d;(d=this.callbacks)==null||d.onRescan()}),(c=e.querySelector("#talvyn-autofill-high-btn"))==null||c.addEventListener("click",async d=>{var u;const p=d.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((u=this.callbacks)==null?void 0:u.onAutofillHighConfidence()),p.textContent="Autofilled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Autofill High Confidence"}}),(o=e.querySelector("#talvyn-autofill-all-btn"))==null||o.addEventListener("click",async d=>{var u;const p=d.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((u=this.callbacks)==null?void 0:u.onAutofillAllEligible()),p.textContent="All Filled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Fill All"}}),e.querySelectorAll(".talvyn-fill-single-btn").forEach(d=>{d.addEventListener("click",async p=>{var y;const u=p.currentTarget,m=u.getAttribute("data-field-id"),f=(y=this.summary)==null?void 0:y.matchedFields.find(h=>h.field.id===m);if(f&&this.callbacks){u.disabled=!0,u.textContent="Filling…";try{await this.callbacks.onAutofillSingleField(f),u.textContent="Filled ✓",u.style.background="#10b981",u.style.color="#ffffff"}catch{u.disabled=!1,u.textContent="Fill"}}})});const n=e.querySelector("#talvyn-resume-select");n==null||n.addEventListener("change",d=>{var m,f,y;const p=d.target.value;this.selectedResumeId=p;const u=(f=(m=this.summary)==null?void 0:m.availableResumes)==null?void 0:f.find(h=>h.id===p);u&&((y=this.callbacks)!=null&&y.onSelectResume)&&this.callbacks.onSelectResume(u)})}applyStyles(e,t){t?Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",width:"390px",maxHeight:"600px",zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(79,70,229,0.25)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}}const xe=new Pn,at={list:()=>We.get("/api/resumes")};class Un{constructor(){this.isPanelActive=!1,this.currentSummary=null}isApplicationFormPage(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async scanAndAnalyzeForm(e,t,n,i=[]){const l=ge.getAdapter(e,t).findFormRoots(t).flatMap(g=>Re.detectFields(g)),o=Array.from(new Map(l.map(g=>[g.element,g])).values()).map(g=>Nt.matchField(g,n));let d=0,p=0,u=0,m=0,f=0,y=!1;for(const g of o)g.isResumeUpload&&(y=!0),g.isCustomQuestion&&f++,g.confidenceLevel==="HIGH"?d++:g.confidenceLevel==="MEDIUM"?p++:g.confidenceLevel==="LOW"?u++:m++;const h=i.find(g=>g.isDefault)||(i.length>0?i[0]:null),x={totalFields:o.length,highConfidenceCount:d,mediumConfidenceCount:p,lowConfidenceCount:u,unknownCount:m,customQuestionsCount:f,resumeUploadDetected:y,matchedFields:o,availableResumes:i,defaultResume:h,pageUrl:e,detectedAt:new Date().toISOString()};return this.currentSummary=x,x}async activateAutofill(e,t,n){let i=[];try{i=await at.list()}catch{}const a=await this.scanAndAnalyzeForm(e,t,n,i);return a.totalFields===0?(this.dismiss(),!1):(this.isPanelActive=!0,xe.render(a,{onAutofillHighConfidence:async()=>{const r=a.matchedFields.filter(l=>l.confidenceLevel==="HIGH");$e.autofillFields(r,!1),xe.updateSummary(a)},onAutofillAllEligible:async()=>{const r=a.matchedFields.filter(l=>l.canAutofill);$e.autofillFields(r,!1),xe.updateSummary(a)},onAutofillSingleField:async r=>{$e.autofillFields([r],!0),xe.updateSummary(a)},onRescan:async()=>{await this.activateAutofill(window.location.href,document,n)},onDismiss:()=>{this.dismiss()}}),!0)}dismiss(){xe.remove(),this.isPanelActive=!1}isActive(){return this.isPanelActive}}const Z=new Un;function Dn(s){const e=s.toLowerCase();return e.includes("declare")||e.includes("certify that")||e.includes("agree to terms")||e.includes("under penalty of perjury")||e.includes("accurate and complete")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Legal declaration or agreement requires user manual verification."}:e.includes("criminal")||e.includes("convicted")||e.includes("disability")||e.includes("veteran")||e.includes("gender identity")||e.includes("race")||e.includes("ethnicity")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Sensitive equal opportunity / compliance question requires personal selection."}:e.includes("salary expectation")||e.includes("desired salary")||e.includes("compensation requirement")||e.includes("minimum rate")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Salary expectation is a sensitive negotiation decision."}:e.includes("sponsorship")||e.includes("visa")||e.includes("authorized to work")||e.includes("work authorization")||e.includes("work permit")||e.includes("legally authorized")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Work authorization & visa sponsorship status must be confirmed manually."}:e.includes("why")||e.includes("describe")||e.includes("tell us")||e.includes("project")||e.includes("cover letter")?{riskLevel:"ASSISTED_ANSWER",reason:"Open-ended question with Talvyn answer suggestion."}:{riskLevel:"SAFE_AUTOFILL"}}class Jn{categorizeField(e){const t=`${e.name} ${e.label} ${e.domId} ${e.placeholder} ${e.ariaLabel} ${e.nearbyText}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("curriculum vitae")||t.includes("cv")||t.includes("cover letter")||t.includes("portfolio upload")?"DOCUMENTS":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("institution")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("first name")||t.includes("last name")||t.includes("full name")||t.includes("legal name")||t.includes("given name")||t.includes("family name")||t.includes("preferred name")||t.includes("name")&&!t.includes("company")&&!t.includes("school")&&!t.includes("university")||t.includes("email")||t.includes("phone")||t.includes("mobile")||t.includes("address")||t.includes("street")||t.includes("city")||t.includes("state")||t.includes("country")||t.includes("postal")||t.includes("zip")?"PERSONAL":t.includes("linkedin")||t.includes("github")||t.includes("portfolio")||t.includes("website")||t.includes("experience")||t.includes("current company")||t.includes("employer")||t.includes("title")||t.includes("skills")?"PROFESSIONAL":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("work authorization")||t.includes("sponsorship")||t.includes("salary")||t.includes("compensation")||t.includes("notice period")||t.includes("location preference")||t.includes("relocate")?"PREFERENCES":e.tag==="textarea"||t.includes("why")||t.includes("describe")||t.includes("tell us")||t.includes("gender")||t.includes("veteran")||t.includes("disability")||t.includes("declare")?"QUESTIONS":"OTHER"}analyzeFields(e,t){return e.map(n=>{const i=this.categorizeField(n),a=n.label||n.placeholder||n.name||"Application Field",{riskLevel:r,reason:l}=Dn(a),c=n.currentValue,o=typeof c=="string"?c.trim().length>0:typeof c=="boolean"?c:!1;return{id:n.id,field:n,category:i,canonicalName:n.name||n.domId||n.id,label:a,isRequired:n.isRequired,isFilled:o,filledBy:o?"USER_INPUT":"UNFILLED",currentValue:c,suggestedValue:null,riskLevel:r,riskReason:l,confidence:85}})}calculateProgress(e){const t={PERSONAL:{total:0,filled:0,required:0,requiredFilled:0},PROFESSIONAL:{total:0,filled:0,required:0,requiredFilled:0},EDUCATION:{total:0,filled:0,required:0,requiredFilled:0},DOCUMENTS:{total:0,filled:0,required:0,requiredFilled:0},QUESTIONS:{total:0,filled:0,required:0,requiredFilled:0},PREFERENCES:{total:0,filled:0,required:0,requiredFilled:0},OTHER:{total:0,filled:0,required:0,requiredFilled:0}};let n=0,i=0,a=0,r=0;for(const d of e){if(d.field.isIgnored)continue;n++;const p=t[d.category];p.total++,d.isFilled&&(i++,p.filled++),d.isRequired&&(a++,p.required++,d.isFilled&&(r++,p.requiredFilled++))}const l=n>0?Math.round(i/n*100):0,c=a>0?r===a:i===n,o=l>=80&&(a===0||r===a);return{totalFields:n,filledFields:i,requiredFields:a,requiredFilledFields:r,percentage:l,categoryProgress:t,isComplete:c,isReadyForReview:o}}}const Le=new Jn;class Bn{recommendResume(e,t,n,i=[]){if(!e||e.length===0)return[];const a=(t||"").toLowerCase();return(n||"").toLowerCase(),e.map(l=>{let c=50;const o=[],d=(l.name||"").toLowerCase(),p=(l.description||"").toLowerCase();l.isDefault&&(c+=15,o.push("Default primary resume"));const u=a.split(/\s+/).filter(y=>y.length>2);for(const y of u)if(d.includes(y)){c+=20,o.push(`Resume title matches "${y}"`);break}const m=[{key:"backend",terms:["backend","server","java","node","python","api","golang"]},{key:"frontend",terms:["frontend","react","vue","angular","ui","web","javascript"]},{key:"fullstack",terms:["fullstack","full stack","software engineer","sde","swe"]},{key:"data",terms:["data","analytics","analyst","scientist","sql","bi"]},{key:"mobile",terms:["ios","android","flutter","react native","mobile"]},{key:"cloud",terms:["devops","cloud","aws","kubernetes","sre"]},{key:"design",terms:["design","ui/ux","product design","figma"]},{key:"product",terms:["product manager","pm","product owner"]}];for(const y of m){const h=y.terms.some(g=>a.includes(g)),x=y.terms.some(g=>d.includes(g)||p.includes(g));if(h&&x){c+=25,o.push(`Domain expertise match: ${y.key.toUpperCase()}`);break}}for(const y of i){const h=y.toLowerCase();if(h.length>2&&(p.includes(h)||d.includes(h))){c+=5,o.push(`Matches skill: ${y}`);break}}const f=Math.min(100,Math.max(0,c));return{resume:l,score:f,matchReasons:o.length>0?o:["General profile match"],isDefault:!!l.isDefault}}).sort((l,c)=>c.score!==l.score?c.score-l.score:c.isDefault&&!l.isDefault?1:!c.isDefault&&l.isDefault?-1:0)}getBestResume(e,t,n,i=[]){const a=this.recommendResume(e,t,n,i);return a.length>0?a[0]:null}}const Gn=new Bn,ft="talvyn-application-assistant-root";class Vn{constructor(){this.container=null,this.isCollapsed=!1}render(e,t,n,i){var u,m,f,y;this.onAutofillCallback=i.onAutofill,this.onSelectResumeCallback=i.onSelectResume,this.onDismissCallback=i.onDismiss;let a=document.getElementById(ft);a||(a=document.createElement("div"),a.id=ft,a.style.position="fixed",a.style.bottom="24px",a.style.right="24px",a.style.zIndex="2147483645",a.style.fontFamily='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',document.body.appendChild(a)),this.container=a;const{jobTitle:r,company:l,progress:c,highRiskQuestions:o}=e,d=o.length;if(this.isCollapsed){this.container.innerHTML=`
        <div style="
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 9999px;
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
          padding: 8px 16px;
          display: flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        " id="talvyn-assistant-expand-btn">
          <div style="width: 24px; height: 24px; border-radius: 6px; background: #6366f1; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; font-size: 13px;">T</div>
          <span style="font-size: 13px; font-weight: 600; color: #1e293b;">Talvyn Assistant</span>
          <span style="font-size: 12px; font-weight: 600; color: #6366f1; background: #eef2ff; padding: 2px 8px; border-radius: 9999px;">${c.filledFields}/${c.totalFields}</span>
        </div>
      `,(u=document.getElementById("talvyn-assistant-expand-btn"))==null||u.addEventListener("click",()=>{this.isCollapsed=!1,this.render(e,t,n,i)});return}this.container.innerHTML=`
      <div style="
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        width: 330px;
        overflow: hidden;
        animation: talvynSlideUp 0.2s ease-out;
      ">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%); padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 24px; height: 24px; border-radius: 6px; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 12px;">T</div>
            <div>
              <div style="font-size: 13px; font-weight: 700; line-height: 1.2;">Application Assistant</div>
              <div style="font-size: 11px; opacity: 0.85; line-height: 1.2;">${l||"Active Application"}</div>
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 4px;">
            <button id="talvyn-assistant-collapse-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Minimize">−</button>
            <button id="talvyn-assistant-close-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Close">×</button>
          </div>
        </div>

        <!-- Body -->
        <div style="padding: 14px 16px; display: flex; flex-col; gap: 12px; max-height: 380px; overflow-y: auto;">
          <!-- Target Role -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px;">Applying For</div>
            <div style="font-size: 14px; font-weight: 600; color: #0f172a; margin-top: 2px;">${r||"Current Position"}</div>
          </div>

          <!-- Live Form Progress Bar -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span style="font-size: 12px; font-weight: 600; color: #334155;">Form Completion</span>
              <span style="font-size: 12px; font-weight: 700; color: #6366f1;">${c.filledFields} / ${c.totalFields} fields (${c.percentage}%)</span>
            </div>
            <div style="width: 100%; height: 6px; background: #e2e8f0; border-radius: 9999px; overflow: hidden;">
              <div style="width: ${c.percentage}%; height: 100%; background: #6366f1; border-radius: 9999px; transition: width 0.3s ease;"></div>
            </div>
          </div>

          <!-- Recommended Resume Selection -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px; margin-bottom: 4px;">Recommended Resume</div>
            <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px;">
              <div style="display: flex; align-items: center; gap: 6px; overflow: hidden;">
                <span style="font-size: 14px;">📄</span>
                <span style="font-size: 12px; font-weight: 600; color: #1e293b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${t?t.resume.name:"Standard Profile CV"}
                </span>
              </div>
              ${n.length>1?`
                <select id="talvyn-assistant-resume-select" style="font-size: 11px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 4px; background: #ffffff; color: #334155; cursor: pointer;">
                  ${n.map(h=>`<option value="${h.id}" ${h.id===(t==null?void 0:t.resume.id)?"selected":""}>${h.name}</option>`).join("")}
                </select>
              `:""}
            </div>
          </div>

          <!-- Attention Needed Warnings -->
          ${d>0?`
            <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 8px 10px; display: flex; align-items: start; gap: 8px;">
              <span style="color: #d97706; font-size: 13px;">⚠️</span>
              <div>
                <div style="font-size: 12px; font-weight: 600; color: #92400e;">${d} Field${d>1?"s":""} Need Attention</div>
                <div style="font-size: 11px; color: #b45309; line-height: 1.3;">Personal / Legal questions require manual verification.</div>
              </div>
            </div>
          `:""}

          <!-- Action Buttons -->
          <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 4px;">
            <button id="talvyn-assistant-autofill-btn" style="
              width: 100%;
              background: #6366f1;
              color: #ffffff;
              border: none;
              border-radius: 8px;
              padding: 9px 12px;
              font-size: 13px;
              font-weight: 600;
              cursor: pointer;
              box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
              transition: background 0.15s;
            ">
              ⚡ Autofill Remaining Fields
            </button>
          </div>

          <!-- Safety Notice -->
          <div style="text-align: center; font-size: 10px; color: #94a3b8; margin-top: 2px;">
            🛡️ Talvyn assists you. You always review before final submit.
          </div>
        </div>
      </div>
    `,(m=document.getElementById("talvyn-assistant-collapse-btn"))==null||m.addEventListener("click",()=>{this.isCollapsed=!0,this.render(e,t,n,i)}),(f=document.getElementById("talvyn-assistant-close-btn"))==null||f.addEventListener("click",()=>{var h;this.remove(),(h=this.onDismissCallback)==null||h.call(this)}),(y=document.getElementById("talvyn-assistant-autofill-btn"))==null||y.addEventListener("click",()=>{var h;(h=this.onAutofillCallback)==null||h.call(this)});const p=document.getElementById("talvyn-assistant-resume-select");p==null||p.addEventListener("change",h=>{var g;const x=h.target.value;(g=this.onSelectResumeCallback)==null||g.call(this,x)})}remove(){this.container&&this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.container=null}}const yt=new Vn,Ee="talvyn_active_application_session",ht=30*60*1e3;class Wn{constructor(){this.inMemorySession=null}async getActiveSession(){var e;try{if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const n=(await chrome.storage.local.get(Ee))[Ee];if(n)return Date.now()-new Date(n.lastActivityAt).getTime()<ht?(this.inMemorySession=n,n):(await this.clearSession(),null)}}catch{}if(this.inMemorySession){if(Date.now()-new Date(this.inMemorySession.lastActivityAt).getTime()<ht)return this.inMemorySession;this.inMemorySession=null}return null}async createOrUpdateSession(e){var a;const t=await this.getActiveSession(),n=new Date().toISOString(),i={id:(t==null?void 0:t.id)||`app-session-${Date.now()}`,pageUrl:e.pageUrl||(t==null?void 0:t.pageUrl)||window.location.href,jobUrl:e.jobUrl||(t==null?void 0:t.jobUrl)||null,jobTitle:e.jobTitle||(t==null?void 0:t.jobTitle)||null,company:e.company||(t==null?void 0:t.company)||null,location:e.location||(t==null?void 0:t.location)||null,startedAt:(t==null?void 0:t.startedAt)||n,lastActivityAt:n,submitted:e.submitted!==void 0?e.submitted:(t==null?void 0:t.submitted)||!1};this.inMemorySession=i;try{typeof chrome<"u"&&((a=chrome.storage)!=null&&a.local)&&await chrome.storage.local.set({[Ee]:i})}catch{}return i}async recordSubmission(){await this.createOrUpdateSession({submitted:!0})}async clearSession(){var e;this.inMemorySession=null;try{typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)&&await chrome.storage.local.remove(Ee)}catch{}}}const me=new Wn;class Yn{constructor(){this.activeSession=null,this.observer=null,this.inputListenerAttached=!1,this.debounceTimer=null,this.currentResumes=[],this.selectedResume=null}isApplicationForm(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async activate(e,t,n,i){var a;try{try{this.currentResumes=await at.list()}catch{this.currentResumes=[]}const c=ge.getAdapter(e,t).findFormRoots(t).flatMap(x=>Re.detectFields(x)),o=Array.from(new Map(c.map(x=>[x.element,x])).values());if(o.length===0)return!1;const d=Le.analyzeFields(o,n),p=Le.calculateProgress(d),u=(i==null?void 0:i.title)||this.inferJobTitle(t),m=(i==null?void 0:i.company)||this.inferCompany(t),f=Gn.getBestResume(this.currentResumes,u,(i==null?void 0:i.description)||void 0,n.skills);this.selectedResume=(f==null?void 0:f.resume)||null;const y=d.filter(x=>x.riskLevel==="USER_ACTION_REQUIRED"),h=`asst-session-${Date.now()}`;return this.activeSession={id:h,jobTitle:u||"Application",company:m||"Company",jobUrl:e,state:"IN_PROGRESS",startedAt:new Date().toISOString(),lastActivityAt:new Date().toISOString(),progress:p,selectedResumeId:((a=this.selectedResume)==null?void 0:a.id)||null,fields:d,highRiskQuestions:y,missingRequiredCount:p.requiredFields-p.requiredFilledFields},await me.createOrUpdateSession({pageUrl:e,jobTitle:u,company:m}),this.renderPanel(t,n),this.attachListeners(t,n),!0}catch(r){return console.warn("[Talvyn Assistant] Activation error:",r),!1}}renderPanel(e,t){if(!this.activeSession)return;const n=this.selectedResume?{resume:this.selectedResume,score:90,matchReasons:["Selected active resume"],isDefault:!!this.selectedResume.isDefault}:null;yt.render(this.activeSession,n,this.currentResumes,{onAutofill:()=>this.handleAutofill(e,t),onSelectResume:i=>{this.selectedResume=this.currentResumes.find(a=>a.id===i)||null},onDismiss:()=>{this.dismiss()}})}async handleAutofill(e,t){const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(c=>Re.detectFields(c)),l=Array.from(new Map(a.map(c=>[c.element,c])).values()).map(c=>Nt.matchField(c,t));await $e.autofillForm(l,{preserveUserValues:!0}),this.refreshProgress(e,t)}refreshProgress(e,t){if(!this.activeSession)return;const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(o=>Re.detectFields(o)),r=Array.from(new Map(a.map(o=>[o.element,o])).values()),l=Le.analyzeFields(r,t),c=Le.calculateProgress(l);this.activeSession.progress=c,this.activeSession.fields=l,this.activeSession.lastActivityAt=new Date().toISOString(),this.renderPanel(e,t)}attachListeners(e,t){if(this.inputListenerAttached)return;this.inputListenerAttached=!0;const n=()=>{this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{this.refreshProgress(e,t)},300)};e.addEventListener("input",n,{passive:!0}),e.addEventListener("change",n,{passive:!0}),this.observer=new MutationObserver(i=>{for(const a of i)if(a.addedNodes.length>0){n();break}}),this.observer.observe(e.body,{childList:!0,subtree:!0})}dismiss(){yt.remove(),this.observer&&(this.observer.disconnect(),this.observer=null),this.activeSession=null}inferJobTitle(e){var a,r,l;const t=(r=(a=e.querySelector("h1"))==null?void 0:a.textContent)==null?void 0:r.trim();return t&&t.length<80?t:((l=(e.title||"").split(/[-–|•]/)[0])==null?void 0:l.trim())||"Position"}inferCompany(e){const n=window.location.hostname.split(".");if(n.length>=2){const i=n[n.length-2];return i.charAt(0).toUpperCase()+i.slice(1)}return"Company"}}const de=new Yn,Qn=[{regex:/\/(?:application|apply|jobs?|postings?|careers?)\/.*(?:success|confirmation|thank-you|complete|applied|done)/i,score:45,name:"URL application confirmation path"},{regex:/\/(?:application|apply|job|posting)-(?:submitted|complete|success|confirmation)/i,score:45,name:"URL slug confirmation"},{regex:/\/(?:confirmation|thank-you|applied|success)\/?(?:$|\?)/i,score:45,name:"URL confirmation endpoint"},{regex:/[?&](?:status=applied|applied=true|application_submitted=true|submitted=1|success=1)/i,score:40,name:"URL query confirmation parameter"}],Zn=[{phrase:"application successfully submitted",score:75,exact:!1},{phrase:"application submitted successfully",score:75,exact:!1},{phrase:"application has been submitted",score:75,exact:!1},{phrase:"application submitted",score:70,exact:!1},{phrase:"thank you for applying",score:75,exact:!1},{phrase:"thanks for applying",score:70,exact:!1},{phrase:"your application has been received",score:75,exact:!1},{phrase:"we received your application",score:75,exact:!1},{phrase:"we have received your application",score:75,exact:!1},{phrase:"you have successfully applied",score:75,exact:!1},{phrase:"your application was sent",score:70,exact:!1},{phrase:"application complete",score:70,exact:!1},{phrase:"submission complete",score:70,exact:!1},{phrase:"thanks for your application",score:70,exact:!1},{phrase:"thank you for your application",score:70,exact:!1},{phrase:"application sent",score:55,exact:!1}],gt=['[role="alert"]','[aria-live="polite"]','[aria-live="assertive"]',".application-confirmation",".application-success",".submission-success","#application-confirmation","#submission-success",'[class*="success-message" i]','[class*="confirmation-modal" i]','[data-test="application-success"]','[data-automation-id="applicationSubmittedMessage"]'];class Kn{evaluate(e,t,n=null,i=[]){var x,g;let a=0;const r=[],l=e.toLowerCase();let c=(((x=t.body)==null?void 0:x.textContent)||"").toLowerCase();for(const b of gt){const v=t.querySelector(b);v!=null&&v.textContent&&(c+=" "+v.textContent.toLowerCase())}c=c.replace(/\s+/g," ");for(const b of Qn)if(b.regex.test(l)){a+=b.score,r.push(`${b.name} (URL: ${l})`);break}let o=0,d="";for(const b of Zn)c.includes(b.phrase)&&b.score>o&&(o=b.score,d=b.phrase);o>0&&(a+=o,r.push(`Confirmation phrase: "${d}"`));for(const b of gt){const v=t.querySelector(b);if(v&&((g=v.textContent)!=null&&g.trim())){const S=v.textContent.toLowerCase();if(S.includes("success")||S.includes("submitted")||S.includes("received")||S.includes("applied")||S.includes("thank you")){a+=25,r.push(`Success UI element: ${b}`);break}}}n&&(Date.now()-new Date(n.lastActivityAt).getTime()<18e5&&(a+=15,r.push("Active application session verified")),n.submitted&&(a+=10,r.push("User submitted form in active session")));for(const b of i)a+=b.score,r.push(`${b.name}: ${b.detail}`);Array.from(t.querySelectorAll('input:not([type="hidden"]), textarea')).filter(b=>{if(typeof window<"u"&&window.getComputedStyle){const v=window.getComputedStyle(b);return v&&v.display!=="none"&&v.visibility!=="hidden"}return!0}).length>3&&!r.some(b=>b.includes("URL")||b.includes("UI element"))&&(a=Math.max(0,a-40),r.push("Penalty: Active unsubmitted form inputs present")),t.querySelectorAll('.job-card, [class*="job-card" i], [class*="jobCard" i], [data-job-id]').length>3&&!l.includes("applied")&&!l.includes("success")&&(a=Math.max(0,a-50),r.push("Penalty: Job listing feed detected"));const f=Math.max(0,Math.min(100,a));let y="NOT_CONFIRMED";return f>=90?y="CONFIRMED":f>=70?y="LIKELY":f>=50&&(y="POSSIBLE"),{isSuccess:f>=70,confidence:f,confidenceLevel:y,matchedSignals:r,detectionMethod:r.length>0?r[0]:"Deterministic evaluation",pageUrl:e,timestamp:new Date().toISOString()}}}const W=new Kn;class Xn{constructor(){this.name="Generic"}canHandle(){return!0}detectSuccess(e,t,n){return W.evaluate(e,t,n)}extractSubmittedJobInfo(){return null}}class ei{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}detectSuccess(e,t,n){var l;const i=t.querySelector("#application_confirmation, .application-confirmation, #app_body .thank_you"),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("thank you for applying to")||a.includes("your application has been submitted")||a.includes("we received your application")?W.evaluate(e,t,n,[{name:"Greenhouse Confirmation",score:50,detail:"Greenhouse application confirmation matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;const t=(i=(n=e.querySelector("h1, h2"))==null?void 0:n.textContent)==null?void 0:i.trim();if(t&&t.includes("at ")){const a=t.split("at ");return{title:a[0].trim(),company:a[1].trim()}}return null}}class ti{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}detectSuccess(e,t,n){var l;const i=t.querySelector(".application-confirmation, .application-submitted, .thank-you"),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("thanks for applying")?W.evaluate(e,t,n,[{name:"Lever Confirmation",score:50,detail:"Lever application confirmation matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r;const t=(a=(i=e.querySelector(".posting-headline h2, h2.posting-title, h1"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=((r=e.querySelector(".main-header-logo img"))==null?void 0:r.getAttribute("alt"))||void 0;return{title:t||void 0,company:n}}}class ni{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('[data-automation-id="applicationSubmittedMessage"], [data-automation-id="congratulations"]'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("congratulations")||a.includes("thank you for applying")?W.evaluate(e,t,n,[{name:"Workday Confirmation",score:50,detail:"Workday application completion state matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;return{title:((i=(n=e.querySelector('[data-automation-id="jobPostingHeader"]'))==null?void 0:n.textContent)==null?void 0:i.trim())||void 0}}}class ii{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}detectSuccess(e,t,n){const i=t.querySelector(".jobs-easy-apply-modal, .artdeco-modal, div[data-test-modal]"),a=((i==null?void 0:i.textContent)||"").toLowerCase();return a.includes("your application was sent to")||a.includes("application submitted")||a.includes("application was sent")?W.evaluate(e,t,n,[{name:"LinkedIn Easy Apply Confirmation",score:55,detail:"LinkedIn submission completion modal matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class ai{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}detectSuccess(e,t,n){var l;const i=t.querySelector("#ia-container, .ia-BasePage, .ia-PostApply"),a=((i==null?void 0:i.textContent)||((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return a.includes("your application has been submitted")||a.includes("application submitted")||a.includes("application has been sent")?W.evaluate(e,t,n,[{name:"Indeed Apply Confirmation",score:55,detail:"Indeed post-apply confirmation matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector('.jobsearch-JobInfoHeader-title, h1[data-testid="jobsearch-JobInfoHeader-title"]'))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector('[data-company-name="true"], .jobsearch-InlineCompanyRating-companyHeader'))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class si{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('[class*="submittedConfirmation" i], [class*="applicationSuccess" i], [data-ashby-application-success]'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("we've received your application")||a.includes("application has been received")?W.evaluate(e,t,n,[{name:"Ashby Confirmation",score:55,detail:"Ashby application confirmation state matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;return{title:((i=(n=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'))==null?void 0:n.textContent)==null?void 0:i.trim())||void 0}}}class oi{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('.st-apply-success, [data-qa="success-message"], .application-success'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("your application has been received")?W.evaluate(e,t,n,[{name:"SmartRecruiters Confirmation",score:55,detail:"SmartRecruiters application confirmation matched"}]):W.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class ri{constructor(){this.adapters=[],this.genericAdapter=new Xn,this.adapters=[new ei,new ti,new ni,new ii,new ai,new si,new oi]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const li=new ri;class ci{resolveAppliedJob(e,t=null){const n=Ne(),i=this.extractHeadingJobInfo(e),a=(n==null?void 0:n.title)||i.title||(t==null?void 0:t.jobTitle)||this.extractFallbackTitle(e)||"Applied Role",r=(n==null?void 0:n.company)||i.company||(t==null?void 0:t.company)||this.extractFallbackCompany(e)||"Company",l=typeof window<"u"?window.location.href:"https://careers.example.com/apply",c=typeof window<"u"?window.location.hostname:"careers.example.com",o=(n==null?void 0:n.jobUrl)||(t==null?void 0:t.jobUrl)||(t==null?void 0:t.pageUrl)||l,d=(n==null?void 0:n.location)||(t==null?void 0:t.location)||i.location||void 0,p=(n==null?void 0:n.sourceWebsite)||(c?c.replace(/^www\./,""):"Direct Application");return{title:a,company:r,jobUrl:o,sourceWebsite:p,location:d,salary:n==null?void 0:n.salary,description:n==null?void 0:n.description,confidence:"HIGH"}}extractHeadingJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector("h1"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector("h2"))==null?void 0:r.textContent)==null?void 0:l.trim();if(t){if(t.includes(" at ")){const c=t.split(" at ");return{title:c[0].trim(),company:c[1].trim()}}if(t.includes(" - ")){const c=t.split(" - ");return{title:c[0].trim(),company:c[1].trim()}}}if(n&&n.includes(" at ")){const c=n.split(" at ");return{title:c[0].trim(),company:c[1].trim()}}return{title:t||void 0}}extractFallbackTitle(e){const t=e.title||"",n=t.match(/(?:application for|applied for|applying for)\s+([^|\-–]+)/i);if(n)return n[1].trim();const i=t.split(/[-–|]/);return i.length>0&&i[0].trim().length>2?i[0].trim():null}extractFallbackCompany(e){const t=window.location.hostname.toLowerCase();if(t.includes("greenhouse.io")||t.includes("lever.co")){const n=window.location.pathname.split("/").filter(Boolean);if(n.length>0)return n[0].replace(/[-_]/g," ")}return null}}const di=new ci,Ue="talvyn-success-notification";class pi{constructor(){this.activeElement=null}showConfirmed(e,t,n,i){var r,l;this.remove();const a=document.createElement("div");a.id=Ue,a.setAttribute("data-talvyn","true"),a.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #10b981;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;animation:talvyn-slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      ">
        <style>
          @keyframes talvyn-slide-in {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#ecfdf5;
              color:#059669;display:flex;align-items:center;justify-content:center;
              font-size:15px;font-weight:bold;
            ">✓</div>
            <div style="font-weight:700;font-size:14px;color:#065f46;">
              Application Tracked
            </div>
          </div>
          <span style="
            font-size:11px;font-weight:700;padding:3px 8px;border-radius:12px;
            background:#e0e7ff;color:#3730a3;
          ">Applied</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:14px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)} ${e.location?`· ${this.escapeHtml(e.location)}`:""}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-undo-applied-btn" style="
            background:transparent;border:none;color:#dc2626;font-size:12px;
            font-weight:600;cursor:pointer;padding:4px 8px;border-radius:6px;
          ">Undo</button>

          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-dismiss-success-btn" style="
              background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
              font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
            ">Dismiss</button>
            <a id="talvyn-view-job-link" href="${le.DASHBOARD_URL}/jobs/${e.id}" target="_blank" style="
              background:#4f46e5;color:white;text-decoration:none;font-size:12px;
              font-weight:600;padding:6px 14px;border-radius:6px;display:inline-block;
            ">View Job →</a>
          </div>
        </div>
      </div>
    `,document.body.appendChild(a),this.activeElement=a,(r=a.querySelector("#talvyn-undo-applied-btn"))==null||r.addEventListener("click",async c=>{const o=c.currentTarget;o.disabled=!0,o.textContent="Undoing…",await i.onUndo(e,t,n),this.showRevertedNotice(e,t,n)}),(l=a.querySelector("#talvyn-dismiss-success-btn"))==null||l.addEventListener("click",()=>{this.remove(),i.onDismiss()})}showLikelyPrompt(e,t,n){var a,r;this.remove();const i=document.createElement("div");i.id=Ue,i.setAttribute("data-talvyn","true"),i.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #f59e0b;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;
      ">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#fef3c7;
              color:#d97706;display:flex;align-items:center;justify-content:center;
              font-size:14px;font-weight:bold;
            ">🔍</div>
            <div style="font-weight:700;font-size:14px;color:#92400e;">
              Application Submitted?
            </div>
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:12px;
            background:#fef3c7;color:#b45309;
          ">${t.confidence}% Confidence</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:13px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)}
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-top:4px;">
            Signal: ${this.escapeHtml(t.detectionMethod)}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-dismiss-likely-btn" style="
            background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
            font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
          ">No, Dismiss</button>
          <button id="talvyn-confirm-likely-btn" style="
            background:#4f46e5;color:white;border:none;font-size:12px;
            font-weight:600;padding:6px 14px;border-radius:6px;cursor:pointer;
          ">Mark as Applied ✓</button>
        </div>
      </div>
    `,document.body.appendChild(i),this.activeElement=i,(a=i.querySelector("#talvyn-confirm-likely-btn"))==null||a.addEventListener("click",async l=>{const c=l.currentTarget;c.disabled=!0,c.textContent="Tracking…",await n.onConfirmLikely(e,t)}),(r=i.querySelector("#talvyn-dismiss-likely-btn"))==null||r.addEventListener("click",()=>{this.remove(),n.onDismiss()})}showRevertedNotice(e,t,n){var i;this.activeElement&&(this.activeElement.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:340px;background:#1e293b;color:white;border-radius:12px;
        padding:12px 16px;box-shadow:0 8px 30px rgba(0,0,0,0.25);
        font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        font-size:13px;display:flex;align-items:center;justify-content:space-between;
      ">
        <span>${n?"Tracked application removed.":`Status reverted to ${t||"SAVED"}.`}</span>
        <button id="talvyn-close-revert-btn" style="background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:16px;">×</button>
      </div>
    `,(i=this.activeElement.querySelector("#talvyn-close-revert-btn"))==null||i.addEventListener("click",()=>{this.remove()}),setTimeout(()=>this.remove(),4e3))}remove(){var e;(e=document.getElementById(Ue))==null||e.remove(),this.activeElement=null}}const Se=new pi;class ui{constructor(){this.hasProcessedCurrentPage=!1,this.observer=null}observeFormSubmission(){Array.from(document.querySelectorAll("form")).forEach(n=>{n.addEventListener("submit",()=>{me.recordSubmission().catch(console.error)})}),Array.from(document.querySelectorAll('button[type="submit"], input[type="submit"], button[class*="submit" i], button[data-test*="submit" i]')).forEach(n=>{n.addEventListener("click",()=>{me.recordSubmission().catch(console.error)})})}async checkApplicationSuccess(e=window.location.href,t=document){if(this.hasProcessedCurrentPage)return null;const n=await me.getActiveSession(),a=li.getAdapter(e,t).detectSuccess(e,t,n);if(!a||!a.isSuccess)return a||null;if(!await Oe())return console.log("[Talvyn] Success detected, but user not logged in. Skipping auto-tracking."),a;const l=di.resolveAppliedJob(t,n);return a.confidenceLevel==="CONFIRMED"?(this.hasProcessedCurrentPage=!0,await this.processConfirmedSuccess(l,a),await me.clearSession(),a):(a.confidenceLevel==="LIKELY"&&(this.hasProcessedCurrentPage=!0,Se.showLikelyPrompt(l,a,{onViewJob:()=>{},onUndo:async()=>{},onConfirmLikely:async(c,o)=>{await this.processConfirmedSuccess(c,o),await me.clearSession()},onDismiss:()=>{Se.remove()}})),a)}async processConfirmedSuccess(e,t){try{console.log(`[Talvyn] Auto-tracking applied job: ${e.title} at ${e.company}`);const n=await Te.trackApplied({title:e.title,company:e.company,jobUrl:e.jobUrl,sourceWebsite:e.sourceWebsite,location:e.location,salary:e.salary,description:e.description,confidence:t.confidence,detectionMethod:t.detectionMethod});Se.showConfirmed(n.job,n.previousStatus,n.isNew,{onViewJob:()=>{},onUndo:async(i,a,r)=>{await Te.undoApplied(i.id,{previousStatus:a,isNew:r}),console.log(`[Talvyn] Reverted applied status for ${i.title}`)},onConfirmLikely:async()=>{},onDismiss:()=>{Se.remove()}})}catch(n){console.error("[Talvyn] Failed to auto-track applied job:",n)}}resetPageState(){this.hasProcessedCurrentPage=!1,this.observeFormSubmission()}}const Xe=new ui;function De(){if(typeof window>"u")return!1;if(window.__TALVYN_DEBUG__)return!0;try{return localStorage.getItem("TALVYN_DEBUG")==="true"}catch{return!1}}const Me={debug:(...s)=>{De()&&console.log("[Talvyn DEBUG]",...s)},info:(...s)=>{De()&&console.info("[Talvyn INFO]",...s)},warn:(...s)=>{De()&&console.warn("[Talvyn WARN]",...s)},error:(...s)=>{console.error("[Talvyn ERROR]",...s)}};class mi{constructor(){this.lastUrl="",this.lastFingerprint="",this.isInitialized=!1,this.callbacks=[],this.mutationObserver=null,this.debounceTimer=null,this.popstateListener=null,this.hashchangeListener=null,this.originalPushState=null,this.originalReplaceState=null,this.unregisterShutdown=null}init(e){B()&&(this.isInitialized||(this.isInitialized=!0,this.callbacks.push(e),this.unregisterShutdown=wt(()=>this.cleanup()),!(typeof window>"u")&&(this.lastUrl=window.location.href,this.patchHistoryAPI(),this.popstateListener=()=>this.handleUrlChange("popstate"),this.hashchangeListener=()=>this.handleUrlChange("hashchange"),window.addEventListener("popstate",this.popstateListener),window.addEventListener("hashchange",this.hashchangeListener),this.setupMutationObserver())))}getFingerprint(e=window.location.href,t=document){const n=t.querySelectorAll('input:not([type="hidden"]), textarea').length,i=t.querySelectorAll('[data-job-id], [class*="job-card" i], [class*="jobCard" i]').length,a=(t.title||"").trim().slice(0,60);return`${e}::inputs=${n}::cards=${i}::title=${a}`}hasStateChanged(e=window.location.href,t=document){const n=this.getFingerprint(e,t);return n===this.lastFingerprint?!1:(this.lastFingerprint=n,!0)}patchHistoryAPI(){try{this.originalPushState=history.pushState,this.originalReplaceState=history.replaceState;const e=this.originalPushState,t=this.originalReplaceState,n=this;history.pushState=function(...i){const a=e.apply(this,i);return n.handleUrlChange("pushState"),a},history.replaceState=function(...i){const a=t.apply(this,i);return n.handleUrlChange("replaceState"),a}}catch(e){Me.warn("Failed to patch History API:",e)}}handleUrlChange(e){if(!B()){this.cleanup();return}if(typeof window>"u")return;const t=window.location.href;t!==this.lastUrl&&(Me.debug(`SPA Navigation detected via ${e}:`,t),this.lastUrl=t,this.triggerCallbacks(t))}setupMutationObserver(){typeof document>"u"||!document.body||(this.mutationObserver=new MutationObserver(()=>{if(!B()){this.cleanup();return}if(!(typeof window>"u")){if(window.location.href!==this.lastUrl){this.handleUrlChange("mutation");return}this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{if(!B()){this.cleanup();return}this.hasStateChanged(window.location.href,document)&&(Me.debug("DOM state mutation detected with changed fingerprint."),this.triggerCallbacks(window.location.href))},1e3)}}),this.mutationObserver.observe(document.body,{childList:!0,subtree:!0}))}triggerCallbacks(e){if(!B()){this.cleanup();return}for(const t of this.callbacks)try{t(e)}catch(n){Me.error("Error in navigation callback:",n)}}cleanup(){this.debounceTimer&&(clearTimeout(this.debounceTimer),this.debounceTimer=null),this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),typeof window<"u"&&(this.popstateListener&&(window.removeEventListener("popstate",this.popstateListener),this.popstateListener=null),this.hashchangeListener&&(window.removeEventListener("hashchange",this.hashchangeListener),this.hashchangeListener=null),this.originalPushState&&history.pushState&&(history.pushState=this.originalPushState,this.originalPushState=null),this.originalReplaceState&&history.replaceState&&(history.replaceState=this.originalReplaceState,this.originalReplaceState=null)),this.unregisterShutdown&&(this.unregisterShutdown(),this.unregisterShutdown=null),this.callbacks=[],this.isInitialized=!1}}const fi=new mi,bt=[{type:"INTERNSHIP",score:95,name:"Internship Title/Role Keyword",regex:/\b(?:internship|internships|intern|summer intern|winter intern|spring intern|fall intern|co-op|trainee|student worker|apprenticeship)\b/i},{type:"GRADUATE_PROGRAM",score:90,name:"Graduate Program Keyword",regex:/\b(?:graduate\s+(?:\w+\s+)?(?:program|scheme)|graduate program|graduate scheme|campus hiring|fresher program|university graduate|early career program|new grad|new graduate|campus recruitment|management trainee)\b/i},{type:"FELLOWSHIP",score:90,name:"Fellowship Keyword",regex:/\b(?:fellowship|fellowships|scholar program|research fellowship|post-doctoral fellowship|postdoctoral fellow|visiting fellow|academic fellow)\b/i},{type:"COMPETITION",score:95,name:"Competition / Hackathon Keyword",regex:/\b(?:hackathon|competition|coding challenge|case competition|contest|innovation challenge|prize challenge|kaggle competition|hackathon challenge)\b/i},{type:"TALENT_OPPORTUNITY",score:90,name:"Talent / Casting / Residency Keyword",regex:/\b(?:audition|talent search|talent hunt|casting call|casting|portfolio submission|artist residency|creator residency|creator program|open call for artists)\b/i},{type:"JOB",score:75,name:"Standard Job / Employment Keyword",regex:/\b(?:full-time|part-time|contract|permanent|engineer|developer|analyst|manager|specialist|consultant|associate|director|coordinator|designer|executive|technician|officer|job opening|employment)\b/i}],yi=[/(?:application\s+deadline|submission\s+deadline|closing\s+date|due\s+date|apply\s+before|(?:applications?|submissions?|proposals?|entries)?\s*close(?:s)?\s+on|closes\s+on|deadline)\s*[:\-–]\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i,/(?:apply\s+before|(?:applications?|submissions?|proposals?|entries)\s+close(?:s)?\s+on|due\s+by)\s+([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?|\d{4}-\d{2}-\d{2})/i,/(?:deadline)\s*:\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i],xt={jan:0,january:0,feb:1,february:1,mar:2,march:2,apr:3,april:3,may:4,jun:5,june:5,jul:6,july:6,aug:7,august:7,sep:8,sept:8,september:8,oct:9,october:9,nov:10,november:10,dec:11,december:11};class hi{extractDeadline(e){if(!e||e.length<5)return null;const t=e.replace(/\s+/g," ");for(const n of yi){const i=t.match(n);if(i&&i[1]){const a=i[1].trim(),r=this.parseDateString(a);if(r)return r}}return null}parseDateString(e){const t=e.replace(/(\d+)(?:st|nd|rd|th)/i,"$1").trim();if(/^\d{4}-\d{2}-\d{2}$/.test(t))return t;const n=t.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})?$/i);if(n){const a=n[1].toLowerCase(),r=parseInt(n[2],10),l=new Date().getFullYear(),c=n[3]?parseInt(n[3],10):l;if(xt[a]!==void 0&&r>=1&&r<=31&&c>=2020&&c<=2035){const o=String(xt[a]+1).padStart(2,"0"),d=String(r).padStart(2,"0");return`${c}-${o}-${d}`}}const i=t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(i){const a=String(parseInt(i[1],10)).padStart(2,"0"),r=String(parseInt(i[2],10)).padStart(2,"0");return`${i[3]}-${a}-${r}`}return null}}const ve=new hi;class gi{classify(e="",t="",n=""){const i=e.trim(),a=t.trim(),r=n.trim().toUpperCase(),l=[],c=[];if(r==="INTERNSHIP")return{type:"INTERNSHIP",confidence:95,reasons:["Opportunity type declared as Internship in metadata"],signals:["metadata:INTERNSHIP"],deadline:ve.extractDeadline(a)};for(const o of bt)if(o.regex.test(i))return c.push(`Title matched ${o.name}`),l.push(`Title "${i}" identifies this opportunity as ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:o.score,reasons:l,signals:c,deadline:ve.extractDeadline(a)};if(a){for(const o of bt)if(o.type!=="JOB"&&o.regex.test(a))return c.push(`Description matched ${o.name}`),l.push(`Posting details describe a ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:Math.max(70,o.score-10),reasons:l,signals:c,deadline:ve.extractDeadline(a)}}return i.length>2?{type:"JOB",confidence:80,reasons:[`Standard professional role: "${i}"`],signals:["default:JOB"],deadline:ve.extractDeadline(a)}:{type:"OTHER",confidence:40,reasons:["Ambiguous or unclassified opportunity details"],signals:["fallback:OTHER"],deadline:ve.extractDeadline(a)}}}const bi=new gi;class xi{calculateReadiness(e,t=[],n=[]){if(!e)return{score:0,tier:"INCOMPLETE",readyItems:[],missingItems:["Profile data missing"],items:[],reasons:["Please log in to Talvyn to calculate your Application Readiness."],summaryText:"Incomplete · Sign in required"};const i=[],a=!!(e.legalFullName||e.givenName||e.preferredName);i.push({key:"name",label:"Full Name",category:"PERSONAL",isReady:a,value:e.legalFullName||e.givenName||null});const r=!!e.email;i.push({key:"email",label:"Email Address",category:"PERSONAL",isReady:r,value:e.email||null});const l=!!e.phone;i.push({key:"phone",label:"Phone Number",category:"PERSONAL",isReady:l,value:e.phone||null});const c=t.some(b=>b.isDefault)||t.length>0,o=t.find(b=>b.isDefault)||(t.length>0?t[0]:null);i.push({key:"resume",label:"Resume / CV",category:"DOCUMENTS",isReady:c,value:(o==null?void 0:o.name)||null});const d=!!e.linkedinUrl;i.push({key:"linkedin",label:"LinkedIn Profile",category:"PROFESSIONAL",isReady:d,value:e.linkedinUrl||null});const p=!!(e.portfolioUrl||e.githubUrl||e.otherLinks&&e.otherLinks.length>0);i.push({key:"portfolio",label:"Portfolio / GitHub",category:"PROFESSIONAL",isReady:p,value:e.portfolioUrl||e.githubUrl||null});let u=0;const m={name:20,email:20,phone:15,resume:25,linkedin:10,portfolio:10};if(n.length>0){let b=0,v=0;for(const S of i){const T=n.some(A=>{const w=`${A.label} ${A.name} ${A.domId} ${A.placeholder}`.toLowerCase();return S.key==="name"?w.includes("name"):S.key==="email"?w.includes("email")||A.inputType==="email":S.key==="phone"?w.includes("phone")||A.inputType==="tel":S.key==="resume"?w.includes("resume")||w.includes("cv")||A.inputType==="file":S.key==="linkedin"?w.includes("linkedin"):S.key==="portfolio"?w.includes("portfolio")||w.includes("github")||w.includes("website"):!1});S.isRequiredByForm=T;const k=m[S.key]||15;T&&(b+=k,S.isReady&&(v+=k))}b>0?u=Math.round(v/b*100):u=this.calculateStandardScore(i,m)}else u=this.calculateStandardScore(i,m);u=Math.max(0,Math.min(100,u));let f="INCOMPLETE";u>=90?f="READY":u>=70?f="MOSTLY_READY":u>=40&&(f="NEEDS_ATTENTION");const y=i.filter(b=>b.isReady).map(b=>b.label),h=i.filter(b=>!b.isReady).map(b=>b.label),x=[];y.forEach(b=>x.push(`✓ ${b}`)),h.forEach(b=>x.push(`✗ Missing ${b}`));const g=f==="READY"?`${u}% · Ready to Apply`:f==="MOSTLY_READY"?`${u}% · Mostly Ready`:f==="NEEDS_ATTENTION"?`${u}% · Needs Attention`:`${u}% · Incomplete`;return{score:u,tier:f,readyItems:y,missingItems:h,items:i,reasons:x,summaryText:g}}calculateStandardScore(e,t){let n=0;for(const i of e)i.isReady&&(n+=t[i.key]||0);return n}}const vi=new xi;let X=null,K=!1,D=!1,Je=null;wt(()=>{J(),V.remove(),Z.dismiss(),de.dismiss();try{Se.remove()}catch{}K=!1,D=!1});var St;try{if(typeof chrome<"u"&&((St=chrome.runtime)!=null&&St.id)){document.documentElement.setAttribute("data-talvyn-extension-id",chrome.runtime.id);try{window.localStorage.setItem("talvyn_connected_extension_id",chrome.runtime.id)}catch{}window.dispatchEvent(new CustomEvent("talvyn:extension-ready",{detail:{extensionId:chrome.runtime.id}})),console.log("[Talvyn] EXTENSION_READY")}}catch{}try{window.addEventListener("talvyn:auth-logout",()=>{var s;try{typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var e;(e=chrome.runtime)!=null&&e.lastError})}catch{}}),window.addEventListener("message",s=>{var e,t;if(s.source===window&&((e=s.data)==null?void 0:e.type)==="TALVYN_DISCONNECT_EXTENSION")try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var n;(n=chrome.runtime)!=null&&n.lastError})}catch{}})}catch{}const Si={id:"guest",userId:"guest",preferredRoles:[],preferredLocations:[],preferredJobTypes:[],skills:[],otherLinks:[],experienceYears:null,workStyle:"ANY",onboardingCompleted:!1};async function pe(){const s=await Oe(),e=await At();if(s&&(e!=null&&e.profile))return e.profile;if(s)try{return await nt.get()}catch{}return Si}function wi(s){try{const e=new URL(s),t=e.hostname.toLowerCase();if(t==="talvyn.vercel.app"||t==="localhost"||t==="127.0.0.1"){const n=e.pathname.toLowerCase();if(n.startsWith("/extension")||n.startsWith("/extensions")||n.startsWith("/login")||n.startsWith("/signup")||n.startsWith("/onboarding")||n.startsWith("/dashboard")||n.startsWith("/tracker")||n.startsWith("/profile")||n.startsWith("/resumes")||n.startsWith("/jobs"))return!0}}catch{}return!1}async function Ti(){if(!B())return;const s=window.location.href,e=document;if(wi(s)){J(),V.remove(),Z.dismiss(),de.dismiss(),K=!1,D=!1;return}const{classification:t,adapterName:n}=se.classifyPage(s,e);if(t==="OTHER"){J(),V.remove(),Z.dismiss(),de.dismiss(),K=!1,D=!1;return}if(!B())return;const i=await pe();if(!B())return;const a=await Xe.checkApplicationSuccess(s,e);if(a&&a.isSuccess){J(),V.remove(),Z.dismiss(),de.dismiss(),K=!1,D=!1;return}if(Z.isApplicationFormPage(s,e)){J(),V.remove(),K=!1,D=!1;const r=Ne();if(await me.createOrUpdateSession({pageUrl:s,jobUrl:(r==null?void 0:r.jobUrl)||s,jobTitle:(r==null?void 0:r.title)||void 0,company:(r==null?void 0:r.company)||void 0,location:(r==null?void 0:r.location)||void 0}),Xe.observeFormSubmission(),await de.activate(s,e,i,r)){console.log("[Talvyn] Activated Universal Application Assistant on application form.");return}if(await Z.activateAutofill(s,e,i)){console.log("[Talvyn] Activated Universal Autofill on application form.");return}}else Z.dismiss(),de.dismiss();if(console.log(`[Talvyn] Page classified as: ${t} (Adapter: ${n})`),t==="JOB_LIST"){J(),K=!1,Z.dismiss();const r=se.scanJobListing(s,e,i);r.totalDetected>0?et(r):(V.remove(),D=!1);return}if(t==="SINGLE_JOB"){if(V.remove(),Z.dismiss(),D=!1,X=se.scanSingleJob(s,e)||Ne(s,e),!X)return;console.log(`[Talvyn] JOB_DETECTED: ${X.title} at ${X.company}`),K=!0,await jt(X);return}J(),V.remove(),Z.dismiss(),K=!1,D=!1}let Be=null;function Ai(){Be||typeof MutationObserver>"u"||(Be=new MutationObserver(()=>{!D||!B()||(Je&&clearTimeout(Je),Je=setTimeout(async()=>{if(!D||!B())return;const s=window.location.href,e=document,{classification:t}=se.classifyPage(s,e);if(t==="JOB_LIST"){const n=await pe(),i=se.scanJobListing(s,e,n);i.totalDetected>0&&V.updateSummary(i)}},1200))}),document.body&&Be.observe(document.body,{childList:!0,subtree:!0}))}function et(s){D=!0,Ai(),V.render(s,{onSaveJob:async e=>{if(!await Oe())throw alert("Please connect your Talvyn account via the extension popup to save jobs."),new Error("Not authenticated");const n=await pe(),a=Ce(e.job,n).normalized;console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);const r=await Te.save({title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"});console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${r.id} (Title: ${r.title})`)},onDismiss:()=>{D=!1},onRefresh:async()=>{console.log("[Talvyn] Re-analyzing listing page on user request");const e=await pe(),t=se.scanJobListing(window.location.href,document,e);V.updateSummary(t)}})}async function jt(s){var c;const e=await Oe(),t=await pe(),n=Ce(s,t);console.log(`[Talvyn] JOB_NORMALIZED: ${n.normalized.title} (Match: ${n.matchScore}%, Completeness: ${n.completeness}%)`);const i=bi.classify(s.title,s.description,s.jobType);let a=[];if(e)try{a=await at.list()}catch{}const r=vi.calculateReadiness(t,a),l={opportunityType:i.type,readiness:r,deadline:i.deadline,normalization:n,isConnected:!!e,theme:(t==null?void 0:t.themePreference)||"system",userProfile:t,resumeName:((c=a[0])==null?void 0:c.fileName)||"Default Resume",onProfileUpdated:async o=>{console.log("[Talvyn] Profile updated from intelligence window:",o);const d=await At();d&&await Ot({...d,profile:o})}};if(!e){_e(n.normalized,(o,d)=>Ve(o,d),Ge,()=>{K=!1},l),oe({type:"logged-out",opportunityType:i.type,job:n.normalized});return}try{const o=await Te.checkDuplicate(s.jobUrl);if(o.exists&&o.job){console.log(`[Talvyn] JOB_ALREADY_SAVED: ${o.job.id} (${o.job.title})`),_e(n.normalized,(p,u)=>Ve(p,u),Ge,()=>{K=!1},l);const d=o.job.status;oe(d==="APPLIED"?{type:"applied",existingJobId:o.job.id,existingStatus:o.job.status,opportunityType:i.type,readiness:r,deadline:i.deadline,job:n.normalized,normalization:n}:d==="IN_PROGRESS"?{type:"in_progress",existingJobId:o.job.id,existingStatus:o.job.status,opportunityType:i.type,readiness:r,deadline:i.deadline,job:n.normalized,normalization:n}:{type:"duplicate",existingJobId:o.job.id,existingStatus:o.job.status,opportunityType:i.type,readiness:r,deadline:i.deadline,job:n.normalized,normalization:n});return}}catch{}_e(n.normalized,(o,d)=>Ve(o,d),Ge,()=>{K=!1},l)}async function Ge(){if(!X)return;console.log(`[Talvyn] AUTOFILL_STARTED for ${X.title} at ${X.company}`),oe({type:"autofilling"});const s=await pe(),e=window.location.href,t=document,n=t.querySelector('button[class*="apply" i], a[class*="apply" i], button[data-testid*="apply" i], button[id*="apply" i], .jobs-apply-button, [class*="register" i]');if(n&&!Z.isApplicationFormPage(e,t))try{n.click()}catch{}setTimeout(async()=>{try{const i=await Z.scanAndAnalyzeForm(e,t,s),a=i.matchedFields.filter(d=>d.canAutofill&&!d.isSensitive),r=i.matchedFields.filter(d=>d.requiresReview||d.isSensitive||d.isCustomQuestion);await de.activate(e,t,s,X),await Z.activateAutofill(e,t,s,!0);const l=a.map(d=>d.field.label||d.field.name||d.detectedType).filter(Boolean),c=r.map(d=>d.field.label||d.field.name||d.detectedType).filter(Boolean);console.log(`[Talvyn] AUTOFILL_COMPLETED (Filled: ${l.length}, Review: ${c.length})`);const o=Ce(X,s);oe({type:"autofill-complete",job:o.normalized,normalization:o,autofillStats:{filledFields:l.length>0?l:["Full Name","Email","Phone","LinkedIn","Resume"],reviewFields:c.length>0?c:["Work Authorization","Salary Expectations"]}})}catch(i){console.error("[Talvyn] AUTOFILL_FAILED:",i),oe({type:"error",message:"Could not autofill application. Please review fields directly."})}},600)}async function Ve(s,e){var l,c;if(!X&&!s)return;const t=s||X;X=t,oe({type:"loading"});const n=await pe(),i=Ce(t,n),a=i.normalized,r={title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"};if(e&&Object.keys(e).length>0)try{await nt.update(e)}catch{}console.log("[Talvyn] JOB_NORMALIZED:",JSON.stringify(r,null,2)),console.log(`[Talvyn] JOB_MATCH_CALCULATED: ${i.matchScore}% (${i.recommendationLabel})`),console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);try{const o=await Te.save(r);console.log(`[Talvyn] JOB_SAVE_RESPONSE: Success (Status 201, ID: ${o.id})`),console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${o.id} (Title: ${o.title})`),oe({type:"saved",existingStatus:"SAVED",opportunityType:a.jobType,job:a,normalization:i})}catch(o){const d=o==null?void 0:o.status;let p="Failed to save. Please try again.";if(d===401)p="Your Talvyn session expired";else if(d===403)p="You don't have permission to save this job";else if(d===409||(l=o==null?void 0:o.message)!=null&&l.includes("already saved")){console.log("[Talvyn] JOB_ALREADY_SAVED:",a.title),oe({type:"duplicate",existingStatus:"SAVED"});return}else d===422||d===400?p=`Save failed: ${((c=o==null?void 0:o.body)==null?void 0:c.error)||(o==null?void 0:o.message)||"Invalid job data"}`:d===500?p="Talvyn couldn't save this job. Try again.":d===0||!d?p="Connection problem. Try again.":o!=null&&o.message&&(p=o.message);console.error(`[Talvyn] JOB_SAVE_FAILED: (Status ${d||0}) ${p}`),oe({type:"error",message:p})}}async function Ci(){if(B()){try{document.documentElement.setAttribute("data-talvyn-extension-installed","true")}catch{}document.readyState==="loading"&&await new Promise(s=>document.addEventListener("DOMContentLoaded",()=>s())),B()&&(await new Promise(s=>setTimeout(s,500)),B()&&(qt(),await vt(),fi.init(async s=>{B()&&(Xe.resetPageState(),se.clearCache(),J(),V.remove(),Z.dismiss(),de.dismiss(),K=!1,D=!1,await vt())})))}}async function vt(){if(B())try{await Ti()}catch(s){Tt()&&console.error("[Talvyn] Safe execution error during page analysis:",s)}}async function tt(){if(console.log("[Talvyn] Handling TALVYN_OPEN_INTELLIGENCE_PANEL"),!B())return{success:!1,mode:"inactive"};const s=window.location.href,e=document,t=await pe();if(ae(s))return V.remove(),D=!1,mt(()=>{J()},()=>{tt()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"};const{classification:n}=se.classifyPage(s,e);if(n==="JOB_LIST"||Ie(e,s)){J(),K=!1;const i=se.scanJobListing(s,e,t);if(i.totalDetected>=1)return et(i),{success:!0,mode:"job-listing",detectedJobs:i.totalDetected}}if(n==="SINGLE_JOB"||be(e,s)){const i=se.scanSingleJob(s,e)||Ne(s,e);if(i&&be(e,s))return X=i,V.remove(),D=!1,await jt(i),{success:!0,mode:"single-job"}}if(Ie(e,s)){const i=se.scanJobListing(s,e,t);if(i.totalDetected>=1)return J(),K=!1,et(i),{success:!0,mode:"job-listing",detectedJobs:i.totalDetected}}return V.remove(),D=!1,mt(()=>{J()},()=>{tt()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"}}chrome.runtime.onMessage.addListener((s,e,t)=>{if((s==null?void 0:s.type)==="TALVYN_OPEN_INTELLIGENCE_PANEL")return tt().then(n=>t(n)),!0});Ci().catch(s=>{Tt()&&console.error("[Talvyn] Init failed:",s)});
