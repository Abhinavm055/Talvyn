import{j as L}from"./jobsService-BuEU-K8d.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))i(n);new MutationObserver(n=>{for(const r of n)if(r.type==="childList")for(const s of r.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&i(s)}).observe(document,{childList:!0,subtree:!0});function o(n){const r={};return n.integrity&&(r.integrity=n.integrity),n.referrerPolicy&&(r.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?r.credentials="include":n.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(n){if(n.ep)return;n.ep=!0;const r=o(n);fetch(n.href,r)}})();let a="loading",z=null,k=!1;const d=document.getElementById("app");function c(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/logotalvyn.png")}catch{}return"/icons/logotalvyn.png"}function p(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/icon48.png")}catch{}return"/icons/icon48.png"}async function x(e){var t;if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage))try{return await chrome.runtime.sendMessage(e)}catch(o){throw console.warn("[Talvyn Popup] Background message failed:",o),o}throw new Error("Chrome runtime unavailable")}async function l(e){try{await x({type:"OPEN_DASHBOARD_ROUTE",route:e})}catch{const t={dashboard:"https://talvyn.vercel.app/dashboard",profile:"https://talvyn.vercel.app/profile",tracker:"https://talvyn.vercel.app/tracker",settings:"https://talvyn.vercel.app/extensions"};window.open(t[e]||"https://talvyn.vercel.app/dashboard","_blank")}}async function f(){var e;try{await x({type:"CONNECT_TALVYN"})}catch{const t=typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.id)?chrome.runtime.id:"",o=t?`https://talvyn.vercel.app/extension/connect?extId=${encodeURIComponent(t)}`:"https://talvyn.vercel.app/extension/connect";window.open(o,"_blank")}}async function B(){try{await x({type:"DISCONNECT_TALVYN"})}catch(e){console.warn("[Talvyn Popup] Failed to disconnect via background:",e)}a="disconnected",z=null,j()}async function E(){console.log("[Talvyn] POPUP_AUTH_CHECK_STARTED"),U();try{const e=await x({type:"GET_AUTH_STATUS"});if(!e||!e.success){a="error",T((e==null?void 0:e.error)||"Could not verify connection status.");return}e.state==="connected"&&e.user?(console.log("[Talvyn] SESSION_FOUND"),console.log("[Talvyn] SESSION_VALID"),a="connected",z=e.user,k=!!e.isOffline,I(e.user,{isOffline:k})):e.state==="expired"?(console.log("[Talvyn] SESSION_EXPIRED"),a="expired",S()):(a="disconnected",j())}catch(e){console.error("[Talvyn Popup] Error communicating with background worker:",e),a="error",T((e==null?void 0:e.message)||"Unable to connect to extension service worker.")}}function U(){const e=c(),t=p();d.innerHTML=`
    <div style="padding:28px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
      <img
        src="${e}"
        alt="Talvyn"
        onerror="this.onerror=null;this.src='${t}';"
        style="width:48px;height:48px;border-radius:12px;box-shadow:0 4px 12px rgba(99,102,241,0.25);margin-bottom:16px;object-fit:contain;"
      />
      <div style="font-weight:700;font-size:15px;color:#0f172a;margin-bottom:4px;">Talvyn</div>
      <div style="font-size:12px;color:#64748b;margin-bottom:20px;">Connecting...</div>
      <div style="width:26px;height:26px;border:2.5px solid #e2e8f0;border-top-color:#4f46e5;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
      <style>
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      </style>
    </div>
  `}function j(){var o,i;const e=c(),t=p();d.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#f1f5f9;
            color:#64748b;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#94a3b8;display:inline-block;"></span>
            Not connected
          </div>
        </div>

        <!-- Connection Notice Card -->
        <div style="
          padding:14px;background:linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
          border:1px solid #e0e7ff;border-radius:12px;margin-bottom:16px;text-align:center;
        ">
          <div style="font-size:13px;font-weight:700;color:#1e1b4b;margin-bottom:4px;">
            Connect your Talvyn Account
          </div>
          <div style="font-size:11.5px;color:#475569;line-height:1.45;">
            Authorize the extension to capture jobs, sync profile data, and manage your applications seamlessly.
          </div>
        </div>

        <!-- Primary Connect Action Button -->
        <button type="button" id="connect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          <span>Connect Talvyn</span>
        </button>

        <div style="font-size:11px;color:#64748b;text-align:center;line-height:1.4;">
          Opens your Talvyn dashboard to link your account securely.
        </div>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Don't have an account?</span>
        <button type="button" id="signup-btn" style="
          background:none;border:none;padding:0;font-size:10px;color:#4f46e5;font-weight:600;cursor:pointer;
        ">Create Free Account →</button>
      </div>
    </div>
  `,(o=document.getElementById("connect-account-btn"))==null||o.addEventListener("click",()=>{f()}),(i=document.getElementById("signup-btn"))==null||i.addEventListener("click",()=>{f()})}function S(){var o,i;const e=c(),t=p();d.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#fef3c7;
            color:#b45309;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#f59e0b;display:inline-block;"></span>
            Session expired
          </div>
        </div>

        <!-- Expired Notice Box -->
        <div style="
          margin-bottom:14px;padding:12px;background:#fffbeb;
          border:1px solid #fef3c7;border-radius:10px;font-size:11.5px;color:#b45309;
          display:flex;align-items:flex-start;gap:8px;line-height:1.45;
        ">
          <span style="font-size:14px;">⚠️</span>
          <div>
            <div style="font-weight:700;margin-bottom:2px;">Session Expired</div>
            Your Talvyn session has expired. Please reconnect your account to continue capturing and tracking jobs.
          </div>
        </div>

        <!-- Reconnect Action Button -->
        <button type="button" id="reconnect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>Reconnect Talvyn</span>
        </button>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Need help?</span>
        <button type="button" id="open-dash-footer-btn" style="
          background:none;border:none;padding:0;font-size:10px;color:#4f46e5;font-weight:600;cursor:pointer;
        ">Open Dashboard →</button>
      </div>
    </div>
  `,(o=document.getElementById("reconnect-account-btn"))==null||o.addEventListener("click",()=>{f()}),(i=document.getElementById("open-dash-footer-btn"))==null||i.addEventListener("click",()=>{l("dashboard")})}function T(e){var i,n;const t=c(),o=p();d.innerHTML=`
    <div style="padding:20px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Brand Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${t}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${o}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#fee2e2;
            color:#b91c1c;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#ef4444;display:inline-block;"></span>
            Unable to connect
          </div>
        </div>

        <!-- Error Notice Box -->
        <div style="
          margin-bottom:14px;padding:12px;background:#fef2f2;
          border:1px solid #fee2e2;border-radius:10px;font-size:11.5px;color:#b91c1c;
          display:flex;align-items:flex-start;gap:8px;line-height:1.45;
        ">
          <span style="font-size:14px;">⚠️</span>
          <div>
            <div style="font-weight:700;margin-bottom:2px;">Connection Issue</div>
            ${e}
          </div>
        </div>

        <!-- Retry Button -->
        <button type="button" id="retry-btn" style="
          width:100%;padding:12px 14px;background:#f1f5f9;color:#334155;
          border:1px solid #e2e8f0;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:10px;transition:all 0.15s;
        ">
          <span>Try Again</span>
        </button>

        <button type="button" id="connect-fallback-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <span>Connect Talvyn</span>
        </button>
      </div>

      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;text-align:center;">
        <span style="font-size:10px;color:#64748b;">Ensure your Talvyn backend is running.</span>
      </div>
    </div>
  `,(i=document.getElementById("retry-btn"))==null||i.addEventListener("click",()=>{E()}),(n=document.getElementById("connect-fallback-btn"))==null||n.addEventListener("click",()=>{f()})}function I(e,t={}){var s,g,b,u,y,v,h,m,w;const o=c(),i=p(),n=((s=e.profile)==null?void 0:s.preferredName)||((g=e.profile)==null?void 0:g.givenName)||((b=e.profile)==null?void 0:b.legalFullName)||e.email.split("@")[0],r=(u=e.profile)==null?void 0:u.avatarUrl;d.innerHTML=`
    <div style="padding:16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:380px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Top Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <img
              src="${o}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${i}';"
              style="width:30px;height:30px;border-radius:8px;box-shadow:0 2px 4px rgba(99,102,241,0.2);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:13px;color:#0f172a;">Talvyn</div>
              <div style="font-size:10px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:${t.isOffline?"#fef3c7":"#ecfdf5"};
            color:${t.isOffline?"#b45309":"#059669"};font-size:10px;font-weight:700;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:${t.isOffline?"#f59e0b":"#10b981"};display:inline-block;"></span>
            ${t.isOffline?"Offline":"Connected"}
          </div>
        </div>

        <!-- User Identity Card -->
        <div style="
          display:flex;align-items:center;gap:10px;padding:10px 12px;
          background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:12px;
        ">
          ${r?`<img src="${r}" alt="${n}" style="width:34px;height:34px;border-radius:50%;object-fit:cover;border:1px solid #cbd5e1;flex-shrink:0;" />`:`<div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg, #6366f1, #8b5cf6);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex-shrink:0;">${(n[0]||"U").toUpperCase()}</div>`}
          <div style="min-width:0;flex:1;">
            <div style="font-weight:700;font-size:12.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${n}</div>
            <div style="font-size:11px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${e.email}</div>
          </div>
        </div>

        <!-- 4 Core Navigation Route Buttons: Dashboard, Profile, Tracker, Settings -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
          <button type="button" id="btn-open-dashboard" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Dashboard</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>

          <button type="button" id="btn-open-profile" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Profile</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>

          <button type="button" id="btn-open-tracker" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Tracker</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
          </button>

          <button type="button" id="btn-open-settings" style="
            padding:9px 10px;background:#f8fafc;color:#1e293b;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Settings</span>
            <svg style="width:12px;height:12px;color:#64748b;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>
        </div>

        <!-- Recent Saved Jobs Section -->
        <div>
          <div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">
            Recent Saved Jobs
          </div>
          <div id="recent-jobs" style="min-height:60px;">
            <div style="font-size:11px;color:#94a3b8;text-align:center;padding:12px 0;">Loading jobs...</div>
          </div>
        </div>
      </div>

      <!-- Footer / Disconnect Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <button type="button" id="disconnect-btn" style="
          background:none;border:none;color:#94a3b8;font-size:11px;cursor:pointer;padding:0;
          font-weight:500;transition:color 0.15s;
        ">
          Disconnect Account
        </button>

        <span style="font-size:10px;color:#cbd5e1;">Talvyn v1.1</span>
      </div>
    </div>
  `,(y=document.getElementById("btn-open-dashboard"))==null||y.addEventListener("click",()=>{l("dashboard")}),(v=document.getElementById("btn-open-profile"))==null||v.addEventListener("click",()=>{l("profile")}),(h=document.getElementById("btn-open-tracker"))==null||h.addEventListener("click",()=>{l("tracker")}),(m=document.getElementById("btn-open-settings"))==null||m.addEventListener("click",()=>{l("settings")}),(w=document.getElementById("disconnect-btn"))==null||w.addEventListener("click",async()=>{confirm("Disconnect extension from your Talvyn account?")&&await B()}),C()}async function C(){const e=document.getElementById("recent-jobs");if(e)try{const t=await L.getJobs();if(!t||t.length===0){e.innerHTML=`
        <div style="padding:10px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;text-align:center;">
          <div style="font-size:11px;color:#64748b;margin-bottom:2px;">No jobs saved yet</div>
          <div style="font-size:10px;color:#94a3b8;">Browse any job board to capture listings with 1 click.</div>
        </div>
      `;return}const o=t.slice(0,3);e.innerHTML=o.map(i=>`
        <div style="
          display:flex;align-items:center;justify-content:space-between;
          padding:6px 10px;background:#f8fafc;border:1px solid #f1f5f9;border-radius:8px;margin-bottom:4px;
        ">
          <div style="min-width:0;flex:1;">
            <div style="font-weight:600;font-size:11.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${i.title}
            </div>
            <div style="font-size:10.5px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${i.company}
            </div>
          </div>
          <span style="
            font-size:9.5px;padding:2px 6px;border-radius:999px;font-weight:600;text-transform:capitalize;
            background:${i.status==="APPLIED"?"#e0f2fe":"#f1f5f9"};
            color:${i.status==="APPLIED"?"#0369a1":"#475569"};
          ">
            ${i.status.toLowerCase()}
          </span>
        </div>
      `).join("")}catch{e.innerHTML=`
      <div style="font-size:11px;color:#94a3b8;text-align:center;padding:10px 0;">
        Saved jobs will appear here
      </div>
    `}}E().catch(console.error);
