import{a as et,C as le,d as Pe,i as Q,o as Et,e as Rt,f as Ut,h as Mt,j as Ft}from"./apiClient-CDeLsrBN.js";import{j as Ae}from"./jobsService-BuEU-K8d.js";const Dt=[{domain:"youtube.com"},{domain:"youtu.be"},{domain:"google.com",allowedSubdomains:["careers.google.com"]},{domain:"facebook.com",allowedSubdomains:["metacareers.com"]},{domain:"instagram.com"},{domain:"twitter.com"},{domain:"x.com"},{domain:"reddit.com"},{domain:"wikipedia.org"},{domain:"amazon.com",allowedSubdomains:["amazon.jobs"]},{domain:"netflix.com",allowedSubdomains:["jobs.netflix.com"]},{domain:"nytimes.com"},{domain:"cnn.com"},{domain:"bbc.com"},{domain:"medium.com"},{domain:"substack.com"},{domain:"twitch.tv"},{domain:"vimeo.com"},{domain:"tiktok.com"},{domain:"quora.com"}];function se(s){try{const e=new URL(s),t=e.hostname.toLowerCase().replace(/^www\./,""),n=e.pathname.toLowerCase();for(const i of Dt)if(t===i.domain||t.endsWith(`.${i.domain}`))return!(i.allowedSubdomains&&i.allowedSubdomains.some(r=>t===r||t.endsWith(`.${r}`))||i.domain==="google.com"&&n.startsWith("/about/careers"));return!1}catch{return!1}}const Jt=[/\/jobs?\/\d+/i,/\/jobs?\/[a-zA-Z0-9_-]+-[a-zA-Z0-9_-]+/i,/\/careers?\/[a-zA-Z0-9_-]+/i,/\/positions?\/[a-zA-Z0-9_-]+/i,/\/openings?\/[a-zA-Z0-9_-]+/i,/\/vacancies?\/[a-zA-Z0-9_-]+/i,/\/viewjob/i,/linkedin\.com\/jobs\/view/i,/indeed\.com\/(viewjob|rc\/clk)/i,/unstop\.com\/(jobs|internships|competitions)\/[a-zA-Z0-9_-]+/i,/glassdoor\.com\/job-listing/i,/boards\.greenhouse\.io\/[^/]+\/jobs/i,/jobs\.lever\.co\/[^/]+\/[a-f0-9-]+/i,/jobs\.ashbyhq\.com\/[^/]+\/[a-f0-9-]+/i,/myworkdayjobs\.com\/[^/]+\/job\//i,/smartrecruiters\.com\/[^/]+\/[a-f0-9-]+/i];function Bt(s,e){var P,H,E,I,D,Z,V,W;const t=[],n=[];let i=0;if(se(e))return n.push("Domain is identified as non-job platform (video, social, news, or search engine)"),{score:0,isConfidentJob:!1,signals:t,disqualifiers:n,rejectionReason:"Page is on a known non-job domain."};s.querySelector("ytd-watch-flexy, ytd-search, ytd-app, #movie_player, video.html5-main-video, .vjs-tech")&&(n.push("Contains primary video player / stream elements"),i-=50),s.querySelector('#rso, #search, .g .rc, div[data-sokoban-container], form[action*="search"]')&&(n.push("Contains search engine SERP elements"),i-=50),s.querySelector('#add-to-cart-button, [name="submit.add-to-cart"], button[class*="add-to-cart" i], [class*="product-price" i]')&&(n.push("Contains e-commerce shopping cart elements"),i-=50),s.querySelector('[data-testid="tweet"], [data-testid="primaryColumn"], article[role="article"] button[aria-label*="Like" i]')&&(n.push("Contains social media feed elements"),i-=40),s.querySelector('.article-body, article.article, .byline, [rel="author"]')&&!s.querySelector('button[class*="apply" i], a[class*="apply" i], [data-automation-id="applyButton"]')&&(n.push("Identified as news or editorial article"),i-=40);try{const q=new URL(e);(q.pathname==="/"||q.pathname==="")&&!s.querySelector('h1, [class*="job" i], [data-automation-id*="job" i], script[type="application/ld+json"]')&&(n.push("Generic root homepage without job postings"),i-=30)}catch{}const a=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];let r=!1;for(const q of Array.from(a)){try{const j=JSON.parse(q.textContent||"{}"),R=Array.isArray(j)?j:[j];for(const _ of R)if(_["@type"]==="JobPosting"&&typeof _.title=="string"&&_.title.trim().length>=3){r=!0,t.push(`Schema.org JobPosting found with title: "${_.title.trim()}"`),i+=80;break}}catch{}if(r)break}const l=s.querySelector('h1, [class*="job-title" i], [class*="jobTitle" i], [class*="posting-header" i], [data-automation-id="jobPostingHeader"], [class*="app-title" i]'),d=((P=s.querySelector('meta[property="og:title"]'))==null?void 0:P.content)||"",o=((H=l==null?void 0:l.textContent)==null?void 0:H.trim())||d,c=s.querySelector('[class*="company" i], [class*="employer" i], [class*="org" i], [data-automation-id="companyName"]'),p=((E=s.querySelector('meta[property="og:site_name"]'))==null?void 0:E.content)||"",m=((I=c==null?void 0:c.textContent)==null?void 0:I.trim())||p,u=!!(o&&o.length>=3&&o.length<=140&&!/^(home|careers|jobs|search|about|login|sign in)$/i.test(o))&&!!(m&&m.length>=2);u&&(t.push(`Valid job title ("${o}") and company ("${m}") detected`),i+=25);const f=s.querySelectorAll?Array.from(s.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"], [data-automation-id="applyButton"]')):[],y=/^(apply(\s+now|\s+online|\s+for\s+this\s+job|\s+here)?|submit\s+application|easy\s+apply|start\s+application|application\s+form|apply\s+with\s+talvyn)$/i;let h=!1;for(const q of f){const j=((D=q.textContent)==null?void 0:D.trim())||((Z=q.value)==null?void 0:Z.trim())||"";if(y.test(j)||q.getAttribute("data-automation-id")==="applyButton"){h=!0,t.push(`Apply button found: "${j||"Apply"}"`),i+=20;break}}const x=s.querySelectorAll?Array.from(s.querySelectorAll('h1, h2, h3, h4, h5, [class*="heading" i], [class*="title" i], strong')):[],g=[/qualifications/i,/requirements/i,/eligibility/i,/what you('ll| will) need/i,/who you are/i,/required skills/i,/basic qualifications/i,/minimum qualifications/i];let b=!1;for(const q of x){const j=((V=q.textContent)==null?void 0:V.trim())||"";if(g.some(R=>R.test(j))){b=!0,t.push("Requirements/Qualifications section found"),i+=15;break}}const v=[/responsibilities/i,/what you('ll| will) do/i,/duties/i,/role overview/i,/key responsibilities/i,/about the (role|position|job)/i,/primary duties/i];let w=!1;for(const q of x){const j=((W=q.textContent)==null?void 0:W.trim())||"";if(v.some(R=>R.test(j))){w=!0,t.push("Responsibilities section found"),i+=15;break}}const k=s.body&&s.body.textContent||"",S=/\b(\d+\+?\s*years?(\s+of)?\s+experience|\d+\s*-\s*\d+\s*years?(\s+of)?\s+experience|fresher|entry[ -]level|bachelor'?s(\s+degree)?|master'?s|b\.?tech|b\.?e\.)\b/i.test(k);S&&(t.push("Experience requirement mentioned"),i+=10);const C=/\b(full[ -]time|part[ -]time|internship|contract|temporary|permanent|remote|hybrid|on-site)\b/i.test(k);C&&(t.push("Employment type keywords detected"),i+=10);const A=/([$€£₹]\s*[\d,]+|\b\d+\s*-\s*\d+\s*(lpa|k|usd|eur|gbp|inr)\b|\bper\s+(year|annum|month|hour)\b|\b(salary|stipend|compensation)\b)/i.test(k);A&&(t.push("Salary/stipend cues detected"),i+=10);const L=!!s.querySelector('[class*="location" i], [data-automation-id*="location" i], [itemprop="addressLocality"]')||/\b(remote|work from home|hybrid|office location|[A-Z][a-zA-Z]+,\s*[A-Z]{2})\b/i.test(k);L&&(t.push("Location details detected"),i+=10),Jt.some(q=>q.test(e))&&(t.push("URL matches verified career/ATS pattern"),i+=10);const N=[r,u,h,b,w,S,C,A,L].filter(Boolean).length,z=n.length===0&&i>=50&&(r||N>=2);return{score:i,isConfidentJob:z,signals:t,disqualifiers:n,rejectionReason:z?void 0:n.length>0?n.join("; "):"Insufficient verified job signals (minimum confidence score not met)."}}function fe(s,e){return se(e)?!1:Bt(s,e).isConfidentJob}function $t(s){var w,k,S,C,A;const e=((w=s.textContent)==null?void 0:w.trim())||"";if(e.length<15)return{isValid:!1,signals:[],reason:"Card content too brief"};if(/\b\d+(\.\d+)?[KM]?\s+views\b/i.test(e)||/\b(subscribers?|playlist|episodes?|season\s+\d+)\b/i.test(e)||s.querySelector("ytd-thumbnail, .ytd-thumbnail, ytd-video-renderer, #video-title"))return{isValid:!1,signals:[],reason:"Card contains video player / view count indicators"};if(/\b(add to cart|buy now|in stock|free delivery|eligible for free)\b/i.test(e)||s.querySelector('[class*="add-to-cart" i]'))return{isValid:!1,signals:[],reason:"Card contains e-commerce purchase indicators"};if(/\b(hackathons?|competitions?|quizzes?|coding\s+challenge|workshops?|webinars?|festivals?|conferences?)\b/i.test(e)&&!/\b(jobs?|internships?|hiring|recruitment|trainee|developer|engineer|analyst)\b/i.test(e))return{isValid:!1,signals:[],reason:"Card represents a competition, hackathon, or event rather than employment"};if(/\b(sponsored|advertisement|promoted)\b/i.test(e)||s.querySelector('[class*="sponsored" i], [class*="ad-" i], [data-ad]'))return{isValid:!1,signals:[],reason:"Card contains advertisement or sponsored content markers"};const t=s.querySelector('h1, h2, h3, h4, [class*="job-title" i], [class*="title" i], a[class*="job" i]'),n=(t==null?void 0:t.tagName)==="A"?t:s.querySelector("a"),i=((k=t==null?void 0:t.textContent)==null?void 0:k.trim())||((S=n==null?void 0:n.textContent)==null?void 0:S.trim())||"";if(!i||i.length<3||i.length>140)return{isValid:!1,signals:[],reason:"No valid title element found in card"};if(/^(home|about|careers|jobs|login|sign in|privacy|terms|menu|search|share|watch|video|playlist|trending)$/i.test(i))return{isValid:!1,signals:[],reason:"Title matches generic navigation/media keyword"};if(/\b(hackathons?|competitions?|quizzes?|coding\s+challenge|workshops?|webinars?)\b/i.test(i)&&!/\b(jobs?|internships?|hiring|recruitment|trainee)\b/i.test(i))return{isValid:!1,signals:[],reason:"Title indicates competition or event"};const r=s.querySelector('[class*="company" i], [class*="employer" i], [class*="org" i], [class*="hiring" i]');let l=((C=r==null?void 0:r.textContent)==null?void 0:C.trim())||"";if(!l){const L=s.closest('[class*="job" i], [id*="job" i]'),M=L==null?void 0:L.querySelector('[class*="company" i], [class*="employer" i]');l=((A=M==null?void 0:M.textContent)==null?void 0:A.trim())||""}const d=[];(!!s.querySelector('[class*="location" i], [class*="city" i], [class*="place" i]')||/\b(remote|hybrid|on-site|in-office|[A-Z][a-zA-Z]+,\s*[A-Z]{2})\b/i.test(e))&&d.push("location");const c=/\b(\d+\+?\s*years?|fresher|entry[ -]level|mid[ -]senior|intern|0-2 years|2-4 years|3\+ years)\b/i.test(e);c&&d.push("experience");const p=!!s.querySelector('[class*="salary" i], [class*="stipend" i], [class*="pay" i]')||/([$€£₹]\s*[\d,]+|\b\d+\s*-\s*\d+\s*(lpa|k)\b|\bper\s+(month|year|hr)\b)/i.test(e);p&&d.push("salary");const m=/\b(full[ -]time|part[ -]time|contract|internship|intern|campus\s+ambassador|freelance)\b/i.test(e);m&&d.push("jobType");const u=n!=null&&n.href?n:s.querySelector("a"),f=(u==null?void 0:u.href)||"",y=/\/jobs?\//i.test(f)||/\/careers?\//i.test(f)||/\/position\//i.test(f)||/\/apply/i.test(f)||/viewjob/i.test(f)||/unstop\.com\/(jobs|internships|opportunity|p)\//i.test(f)||/\/(opportunity|p)\//i.test(f);y&&d.push("jobLink"),(!!s.querySelector('[class*="snippet" i], [class*="summary" i], [class*="description" i]')||/\b(responsibilities|qualifications|skills|requirements|eligibility|apply\s+by)\b/i.test(e))&&d.push("jobSnippet"),/\b(bachelor'?s|master'?s|b\.?tech|b\.?e|degree|phd|diploma)\b/i.test(e)&&d.push("education"),(!!s.querySelector('button[class*="apply" i], a[class*="apply" i]')||/\b(apply|apply now|easy apply)\b/i.test(e))&&d.push("applyAction");const b=!!(l&&l.length>=2);return b&&d.length>=1||!b&&d.length>=2&&(y||m||p||c)?{isValid:!0,title:i,company:l||"Unknown Company",signals:d}:{isValid:!1,title:i,company:l,signals:d,reason:`Card lacks sufficient verified job signals (found ${d.length}: ${d.join(", ")})`}}function Oe(s,e){if(se(e))return!1;const t=e.toLowerCase(),n=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const l of Array.from(n))try{const d=JSON.parse(l.textContent||"{}"),o=Array.isArray(d)?d:[d];for(const c of o)if(c["@type"]==="ItemList"&&Array.isArray(c.itemListElement)&&c.itemListElement.filter(m=>(m.item||m)["@type"]==="JobPosting").length>=2)return!0}catch{}const i=s.querySelectorAll?Array.from(s.querySelectorAll('[class*="job-card" i], [class*="jobCard" i], [class*="job-listing" i], [class*="job-item" i], [data-job-id], article[class*="job" i], li[class*="job" i], .card[class*="job" i], [class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="listing_card" i], .single_opportunity, [class*="opportunity" i], div[class*="opening" i], tr.job, [data-automation-id="compositeHeader"], [data-automation-id="jobCard"]')):[];let a=0;for(const l of i)if($t(l).isValid&&(a++,a>=2))return!0;return!!((/linkedin\.com\/jobs/i.test(t)||/indeed\.com\/jobs/i.test(t)||/unstop\.com\/(jobs|internships|all-opportunities|competitions)/i.test(t)||t.includes("opportunity=")||/glassdoor\.com\/job-listing/i.test(t)||/careers\.[a-z0-9-]+\.[a-z]+/i.test(t)||/\/careers?\/?(\?.*)?$/i.test(t)||/\/jobs?\/?(\?.*)?$/i.test(t)||/\/openings\/?(\?.*)?$/i.test(t)||/\/vacancies\/?(\?.*)?$/i.test(t)||/boards\.greenhouse\.io/i.test(t)||/jobs\.lever\.co/i.test(t)||/myworkdayjobs\.com/i.test(t))&&a>=1)}class Vt{constructor(){this.name="Generic"}canHandle(){return!0}isJobDetailPage(e,t){return se(e)?!1:fe(t,e)}isJobListingPage(e,t){return se(e)?!1:Oe(t,e)}extractJobList(e){const t=typeof window<"u"?window.location.href:"";if(se(t))return[];const n=[],i=new Set,a=new Set,r=o=>{const c=o.title.toLowerCase().trim().replace(/[^a-z0-9]/g,""),p=o.company.toLowerCase().trim().replace(/[^a-z0-9]/g,""),m=`${c}|${p}`;if(a.has(m))return!0;if(a.add(m),o.jobUrl&&o.jobUrl!==t){if(i.has(o.jobUrl))return!0;i.add(o.jobUrl)}return!1},l=this.extractFromJsonLd(e);for(const o of l)r(o)||n.push(o);if(n.length>=2)return n;const d=['[class*="job-card" i]','[class*="jobCard" i]','[class*="job-listing" i]','[class*="job-item" i]','[class*="job_item" i]','[class*="job-result" i]',"[data-job-id]",'[data-testid*="job" i]','[data-automation-id*="job" i]','[data-automation-id*="composite" i]','article[class*="job" i]','li[class*="job" i]','div[class*="opening" i]','div[class*="posting" i]','div[class*="vacancy" i]','div[class*="position" i]','div[class*="career" i]','div[class*="role" i]','.card[class*="job" i]','tr[class*="job" i]',"tr.job",".resultContent",".job-search-card",".base-card",".opportunity-card",".opp-card",'li[class*="opening" i]'];for(const o of d){const c=Array.from(e.querySelectorAll(o));if(c.length>=1){for(const p of c){const m=p;if(!$t(m).isValid)continue;const f=this.extractCardData(m);f&&f.title&&!r(f)&&n.push(f)}if(n.length>=2)break}}return n}extractSingleJob(e){var m,u,f,y,h,x,g,b,v,w,k,S,C,A;const t=typeof window<"u"?window.location.href:"";if(se(t)||!fe(e,t))return null;const n=this.extractFromJsonLd(e);if(n.length===1&&n[0].title){const L=n[0];if(!L.description){const M=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main');M&&(L.description=(m=M.textContent)==null?void 0:m.replace(/\s+/g," ").trim().slice(0,3e3))}return L}const i=e.querySelector("h1");let a=((u=i==null?void 0:i.textContent)==null?void 0:u.trim())||"";if(!a||a.length<3||a.length>150){const L=(f=e.querySelector('meta[property="og:title"], meta[name="title"]'))==null?void 0:f.content;L&&L.length>=3&&L.length<=150&&(a=L)}if(!a||a.length<3||a.length>150)return null;const r=((h=(y=e.querySelector('[class*="company-name" i], [class*="companyName" i], [class*="employer" i], [class*="org-name" i], [class*="company" i], [class*="org" i]'))==null?void 0:y.textContent)==null?void 0:h.trim())||((g=(x=e.querySelector('meta[property="og:site_name"]'))==null?void 0:x.content)==null?void 0:g.trim())||"Unknown Company",l=(v=(b=e.querySelector('[class*="location" i], [class*="city" i], [class*="workplace" i], [itemprop="addressLocality"]'))==null?void 0:b.textContent)==null?void 0:v.trim(),d=(k=(w=e.querySelector('[class*="salary" i], [class*="compensation" i], [class*="stipend" i], [class*="pay" i]'))==null?void 0:w.textContent)==null?void 0:k.trim(),o=(C=(S=e.querySelector('[class*="job-type" i], [class*="employment-type" i], [class*="work-type" i]'))==null?void 0:S.textContent)==null?void 0:C.trim(),c=e.querySelector('[class*="job-description" i], [class*="jobDescription" i], [class*="description" i], [class*="posting-requirements" i], article, main'),p=(A=c==null?void 0:c.textContent)==null?void 0:A.replace(/\s+/g," ").trim().slice(0,3e3);return{title:a,company:r,location:l,salary:d,jobType:o,description:p,jobUrl:t,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}extractFromJsonLd(e){const t=[],n=e.querySelectorAll?e.querySelectorAll('script[type="application/ld+json"]'):[];for(const i of Array.from(n))try{const a=JSON.parse(i.textContent||"{}"),r=Array.isArray(a)?a:[a];for(const l of r)if(l["@type"]==="ItemList"&&Array.isArray(l.itemListElement))for(const d of l.itemListElement){const o=d.item||d;(o["@type"]==="JobPosting"||o.title)&&t.push(this.formatJsonLdJob(o))}else l["@type"]==="JobPosting"&&t.push(this.formatJsonLdJob(l))}catch{}return t}formatJsonLdJob(e){var t,n,i,a,r,l,d,o,c,p,m;return{title:e.title||e.name||"Untitled Position",company:((t=e.hiringOrganization)==null?void 0:t.name)||e.employerOverview||"Unknown Company",location:typeof e.jobLocation=="string"?e.jobLocation:((i=(n=e.jobLocation)==null?void 0:n.address)==null?void 0:i.addressLocality)||((r=(a=e.jobLocation)==null?void 0:a.address)==null?void 0:r.addressRegion),salary:((d=(l=e.baseSalary)==null?void 0:l.value)==null?void 0:d.value)||((c=(o=e.baseSalary)==null?void 0:o.value)!=null&&c.minValue&&((m=(p=e.baseSalary)==null?void 0:p.value)!=null&&m.maxValue)?`${e.baseSalary.value.minValue}–${e.baseSalary.value.maxValue} ${e.baseSalary.value.unitText||""}`:void 0),jobType:e.employmentType,jobUrl:e.url||(typeof window<"u"?window.location.href:""),sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"HIGH"}}extractCardData(e){var h,x,g,b,v,w,k;const t=e.querySelector('h1, h2, h3, h4, [class*="job-title" i], [class*="title" i], [class*="role" i], a[class*="job" i]'),n=(t==null?void 0:t.tagName)==="A"?t:e.querySelector("a"),i=((h=t==null?void 0:t.textContent)==null?void 0:h.trim())||((x=n==null?void 0:n.textContent)==null?void 0:x.trim());if(!i||i.length<3||i.length>150)return null;const a=(n==null?void 0:n.href)||(typeof window<"u"?window.location.href:""),r=e.querySelector('[class*="company" i], [class*="employer" i], [class*="org" i], [class*="sub-title" i], [class*="subtitle" i]'),l=((g=r==null?void 0:r.textContent)==null?void 0:g.trim())||"Unknown Company",d=e.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="region" i]'),o=(b=d==null?void 0:d.textContent)==null?void 0:b.trim(),c=e.querySelector('[class*="salary" i], [class*="compensation" i], [class*="pay" i], [class*="wage" i]'),p=(v=c==null?void 0:c.textContent)==null?void 0:v.trim(),m=e.querySelector('[class*="job-type" i], [class*="employment" i], [class*="work-type" i]'),u=(w=m==null?void 0:m.textContent)==null?void 0:w.trim(),f=e.querySelector('[class*="snippet" i], [class*="description" i], [class*="summary" i], p'),y=(k=f==null?void 0:f.textContent)==null?void 0:k.trim().slice(0,1e3);return{title:i,company:l,location:o,salary:p,jobType:u,description:y,jobUrl:a,sourceWebsite:typeof window<"u"?window.location.hostname.replace(/^www\./,""):"",confidence:"MEDIUM"}}}class Wt{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isJobDetailPage(e,t){return/\/jobs\/view\//i.test(e)||/\/jobs\/collections\//i.test(e)||!!t.querySelector(".job-details-jobs-unified-top-card__job-title")}isJobListingPage(e,t){return this.isJobDetailPage(e,t)?!1:/\/jobs\/search/i.test(e)||/\/jobs\/collections/i.test(e)||t.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card").length>=2}extractJobList(e){var a,r,l;const t=[],n=new Set,i=Array.from(e.querySelectorAll(".jobs-search__results-list li, .job-card-container, .base-card, div[data-job-id]"));for(const d of i){const o=d.querySelector(".job-card-list__title, .base-search-card__title, .job-card-container__link, h3"),c=d.querySelector("a"),p=d.querySelector(".job-card-container__primary-description, .base-search-card__subtitle, .job-card-container__company-name"),m=d.querySelector(".job-card-container__metadata-item, .job-search-card__location, .job-card-container__metadata-wrapper"),u=(a=o==null?void 0:o.textContent)==null?void 0:a.trim(),f=(c==null?void 0:c.href)||(typeof window<"u"?window.location.href:"");u&&u.length>2&&!n.has(f)&&(n.add(f),t.push({title:u,company:((r=p==null?void 0:p.textContent)==null?void 0:r.trim())||"LinkedIn Poster",location:(l=m==null?void 0:m.textContent)==null?void 0:l.trim(),jobUrl:f,sourceWebsite:"LinkedIn",confidence:"HIGH"}))}return t}extractSingleJob(e){var r,l,d,o,c,p,m,u;const t=(l=(r=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:r.textContent)==null?void 0:l.trim();if(!t)return null;const n=((o=(d=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:d.textContent)==null?void 0:o.trim())||"LinkedIn Poster",i=(p=(c=e.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:c.textContent)==null?void 0:p.trim(),a=(u=(m=e.querySelector(".jobs-description__content, #job-details"))==null?void 0:m.textContent)==null?void 0:u.trim();return{title:t,company:n,location:i,description:a,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"LinkedIn",confidence:"HIGH"}}}function Gt(s){var e,t,n,i,a;try{const r=s.querySelectorAll('script[type="application/ld+json"]');for(const l of Array.from(r)){const d=l.textContent;if(!d)continue;const o=JSON.parse(d),c=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((n=o==null?void 0:o.author)==null?void 0:n.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(i=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:i.hiringOrganization)==null?void 0:a.name);if(c&&typeof c=="string"&&c.trim().length>0)return c.trim()}}catch{}}class Yt{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isJobDetailPage(e,t){return/\/viewjob/i.test(e)||/\/rc\/clk/i.test(e)||!!t.querySelector('[data-testid="jobsearch-JobInfoHeader-title"]')||!!t.querySelector("h1.jobsearch-JobInfoHeader-title")}isJobListingPage(e,t){return this.isJobDetailPage(e,t)?!1:/\/jobs/i.test(e)||t.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]').length>=2}extractJobList(e){var a,r,l,d;const t=[],n=new Set,i=Array.from(e.querySelectorAll('.job_seen_beacon, .resultContent, div[class*="cardOutline"]'));for(const o of i){const c=o.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h2.jobTitle, a[data-jk], a[id^="job_"], span[id^="jobTitle"]'),p=(c==null?void 0:c.tagName)==="A"?c:o.querySelector('a[data-jk], a[id^="job_"], a[href*="viewjob" i], a[href*="/rc/clk" i], a'),m=o.querySelector('[data-testid="company-name"], [data-testid="inlineHeader-companyName"], span[data-testid="company-name"], a[data-testid="company-name"], .companyName, .company-name, [class*="companyName"], [class*="company_location"] span, .icl-u-lg-mr--sm'),u=o.querySelector('[data-testid="text-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation, [class*="companyLocation"]'),f=o.querySelector('[data-testid="attribute_snippet_testid"], .salary-snippet-container, [class*="salary-snippet"], #salaryInfoAndJobType'),y=(a=c==null?void 0:c.textContent)==null?void 0:a.trim(),h=(r=m==null?void 0:m.textContent)==null?void 0:r.trim(),x=h&&h.length>0?h:"Unknown Company",b=(p==null?void 0:p.href)||(typeof window<"u"?window.location.href:"")||`https://www.indeed.com/viewjob?key=${encodeURIComponent(y||"")}-${encodeURIComponent(x)}`;y&&y.length>2&&!n.has(b)&&(n.add(b),t.push({title:y,company:x,location:(l=u==null?void 0:u.textContent)==null?void 0:l.trim(),salary:(d=f==null?void 0:f.textContent)==null?void 0:d.trim(),jobUrl:b,sourceWebsite:"Indeed",confidence:"HIGH"}))}return t}extractSingleJob(e){var d,o,c,p,m,u,f,y,h;const t=(o=(d=e.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"]'))==null?void 0:d.textContent)==null?void 0:o.trim();if(!t)return null;const n=e.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="inlineHeader-companyName"] span, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, div[data-testid="jobsearch-CompanyInfoContainer"] span, .companyName, .icl-u-lg-mr--sm, [class*="companyName"]'),i=((c=n==null?void 0:n.textContent)==null?void 0:c.trim())||Gt(e)||"Unknown Company",a=(m=(p=e.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:p.textContent)==null?void 0:m.trim(),r=(f=(u=e.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:u.textContent)==null?void 0:f.trim(),l=(h=(y=e.querySelector('#jobDescriptionText, [data-testid="jobsearch-JobComponent-description"]'))==null?void 0:y.textContent)==null?void 0:h.trim();return{title:t,company:i,location:a,salary:r,description:l,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Indeed",confidence:"HIGH"}}}class Qt{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isJobDetailPage(e,t){return/\/jobs\/\d+/i.test(e)||!!t.querySelector(".app-title, #app_body, form#application_form")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll(".opening, tr.job, div.level-0").length>=1}extractJobList(e){var r,l,d,o;const t=[],n=new Set,i=((l=(r=e.querySelector(".company-name, #header .logo span, h1"))==null?void 0:r.textContent)==null?void 0:l.trim())||"Greenhouse Employer",a=Array.from(e.querySelectorAll('.opening, tr.job, div[class*="opening"]'));for(const c of a){const p=c.querySelector("a"),m=(d=p==null?void 0:p.textContent)==null?void 0:d.trim(),u=c.querySelector(".location"),f=(p==null?void 0:p.href)||(typeof window<"u"?window.location.href:"");m&&m.length>2&&!n.has(f)&&(n.add(f),t.push({title:m,company:i,location:(o=u==null?void 0:u.textContent)==null?void 0:o.trim(),jobUrl:f,sourceWebsite:"Greenhouse",confidence:"HIGH"}))}return t}extractSingleJob(e){var r,l,d,o,c,p,m,u;const t=(l=(r=e.querySelector(".app-title, h1.heading"))==null?void 0:r.textContent)==null?void 0:l.trim();if(!t)return null;const n=((o=(d=e.querySelector(".company-name, .logo span"))==null?void 0:d.textContent)==null?void 0:o.trim())||"Greenhouse Employer",i=(p=(c=e.querySelector(".location"))==null?void 0:c.textContent)==null?void 0:p.trim(),a=(u=(m=e.querySelector("#content"))==null?void 0:m.textContent)==null?void 0:u.trim();return{title:t,company:n,location:i,description:a,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Greenhouse",confidence:"HIGH"}}}class Zt{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isJobDetailPage(e,t){return/\/jobs\.lever\.co\/[^/]+\/[a-zA-Z0-9_-]{10,}/i.test(e)||/\/apply\/?$/i.test(e)||!!t.querySelector(".posting-header h2, .application-page")}isJobListingPage(e,t){return!this.isJobDetailPage(e,t)&&t.querySelectorAll('.posting, div[data-qa="posting-category"]').length>=1}extractJobList(e){var r,l,d,o,c,p,m;const t=[],n=new Set,i=((r=e.querySelector(".main-header-logo img"))==null?void 0:r.getAttribute("alt"))||((d=(l=e.querySelector(".posting-headline .sort-by-team"))==null?void 0:l.textContent)==null?void 0:d.trim())||"Lever Employer",a=Array.from(e.querySelectorAll(".posting"));for(const u of a){const f=u.querySelector(".posting-title, a.posting-btn-submit, a"),y=u.querySelector('h5[data-qa="posting-name"], .posting-title h5, h5'),h=u.querySelector(".sort-by-location, .posting-categories .location"),x=u.querySelector(".sort-by-commitment, .posting-categories .commitment"),g=((o=y==null?void 0:y.textContent)==null?void 0:o.trim())||((c=f==null?void 0:f.textContent)==null?void 0:c.trim()),b=(f==null?void 0:f.href)||(typeof window<"u"?window.location.href:"");g&&g.length>2&&!n.has(b)&&(n.add(b),t.push({title:g,company:i,location:(p=h==null?void 0:h.textContent)==null?void 0:p.trim(),jobType:(m=x==null?void 0:x.textContent)==null?void 0:m.trim(),jobUrl:b,sourceWebsite:"Lever",confidence:"HIGH"}))}return t}extractSingleJob(e){var l,d,o,c,p,m,u,f,y;const t=(d=(l=e.querySelector(".posting-headline h2"))==null?void 0:l.textContent)==null?void 0:d.trim();if(!t)return null;const n=((o=e.querySelector(".main-header-logo img"))==null?void 0:o.getAttribute("alt"))||"Lever Employer",i=(p=(c=e.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:c.textContent)==null?void 0:p.trim(),a=(u=(m=e.querySelector(".commitment, .posting-categories .sort-by-commitment"))==null?void 0:m.textContent)==null?void 0:u.trim(),r=(y=(f=e.querySelector(".section-wrapper, .posting-page"))==null?void 0:f.textContent)==null?void 0:y.trim();return{title:t,company:n,location:i,jobType:a,description:r,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Lever",confidence:"HIGH"}}}class Kt{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const a=new URL(e,"https://jobs.ashbyhq.com").pathname.split("/").filter(Boolean).length>=2,r=!!t.querySelector('form, [data-ashby-job-posting], [class*="applicationForm" i]'),l=!!t.querySelector('h1, [class*="jobTitle" i], [class*="heading" i]');return a&&l||r}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]').length>=2:!1}extractJobList(e){var r,l;const t=[],n=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",i=this.extractCompanyFromUrl(n)||"Company",a=Array.from(e.querySelectorAll('a[href*="/jobs.ashbyhq.com/"], [class*="jobPosting" i], [class*="ashby-job-posting" i]'));for(const d of a){const o=d.tagName==="A"?d:d.querySelector("a"),c=d.querySelector('h2, h3, h4, [class*="title" i], strong')||o,p=d.querySelector('[class*="location" i], [class*="metadata" i]'),m=(r=c==null?void 0:c.textContent)==null?void 0:r.trim(),u=(o==null?void 0:o.href)||n,f=(l=p==null?void 0:p.textContent)==null?void 0:l.trim();m&&m.length>2&&t.push({title:m,company:i,jobUrl:u,sourceWebsite:"Ashby",location:f||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var m,u,f,y,h;const t=typeof window<"u"?window.location.href:"https://jobs.ashbyhq.com/company",n=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'),i=(m=n==null?void 0:n.textContent)==null?void 0:m.trim();if(!i)return null;const a=this.extractCompanyFromUrl(t)||((u=e.querySelector('[class*="company" i], header img'))==null?void 0:u.getAttribute("alt"))||"Company",r=e.querySelector('[class*="location" i], [data-testid="job-location"]'),l=((f=r==null?void 0:r.textContent)==null?void 0:f.trim())||void 0,d=e.querySelector('[class*="compensation" i], [class*="salary" i]'),o=((y=d==null?void 0:d.textContent)==null?void 0:y.trim())||void 0,c=e.querySelector('[class*="description" i], [class*="jobBody" i], main'),p=((h=c==null?void 0:c.textContent)==null?void 0:h.trim())||void 0;return{title:i,company:a,jobUrl:t,sourceWebsite:"Ashby",location:l,salary:o,description:p,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const n=new URL(e).pathname.split("/").filter(Boolean);if(n.length>0)return n[0].replace(/[-_]/g," ")}catch{}return null}}class Xt{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isJobDetailPage(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),i=!!t.querySelector('a[href*="/apply"], button[data-qa="apply-button"], .st-apply'),a=/\/jobs\/[a-zA-Z0-9_-]+/i.test(e);return n&&i||a}isJobListingPage(e,t){return this.canHandle(e)?t.querySelectorAll('.opening-job, .job-item, li.opening, a[href*="smartrecruiters.com/"][href*="/"]').length>=2:!1}extractJobList(e){var r,l,d,o;const t=[],n=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",i=((l=(r=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:r.textContent)==null?void 0:l.trim())||"Company",a=Array.from(e.querySelectorAll('.opening-job, .job-item, li.opening, [class*="job-item" i]'));for(const c of a){const p=c.querySelector("a"),m=c.querySelector('h3, h4, .job-title, [data-qa="job-title"]')||p,u=c.querySelector('.job-location, .location, [data-qa="job-location"]'),f=(d=m==null?void 0:m.textContent)==null?void 0:d.trim(),y=(p==null?void 0:p.href)||n,h=(o=u==null?void 0:u.textContent)==null?void 0:o.trim();f&&f.length>2&&t.push({title:f,company:i,jobUrl:y,sourceWebsite:"SmartRecruiters",location:h||void 0,confidence:"HIGH"})}return t}extractSingleJob(e){var p,m,u,f;const t=typeof window<"u"?window.location.href:"https://jobs.smartrecruiters.com/company",n=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'),i=(p=n==null?void 0:n.textContent)==null?void 0:p.trim();if(!i)return null;const a=e.querySelector('.company-name, [data-qa="company-name"], .job-header .company'),r=((m=a==null?void 0:a.textContent)==null?void 0:m.trim())||this.extractCompanyFromUrl(t)||"Company",l=e.querySelector('.job-location, [data-qa="job-location"], .spl-location'),d=((u=l==null?void 0:l.textContent)==null?void 0:u.trim())||void 0,o=e.querySelector(".job-sections, #job-details, .job-detail"),c=((f=o==null?void 0:o.textContent)==null?void 0:f.trim())||void 0;return{title:i,company:r,jobUrl:t,sourceWebsite:"SmartRecruiters",location:d,description:c,confidence:"HIGH"}}extractCompanyFromUrl(e){try{const n=new URL(e).pathname.split("/").filter(Boolean);if(n.length>0&&n[0]!=="jobs")return n[0].replace(/[-_]/g," ")}catch{}return null}}class en{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}isJobDetailPage(e,t){return this.canHandle(e)?/\/job\/[^/?#]+/i.test(e)||!!t.querySelector('[data-automation-id="jobPostingHeader"], [data-automation-id="jobPostingDescription"]'):!1}isJobListingPage(e,t){return!this.canHandle(e)||this.isJobDetailPage(e,t)?!1:t.querySelectorAll('[data-automation-id="compositeHeader"], [data-automation-id="jobCard"], li[class*="css-"], a[href*="/job/"]').length>=1}extractJobList(e){var l,d,o,c,p,m,u;const t=[],n=new Set,i=typeof window<"u"?window.location.href:"https://company.myworkdayjobs.com",a=((l=e.querySelector('meta[property="og:site_name"]'))==null?void 0:l.content)||((o=(d=e.querySelector('[data-automation-id="companyName"]'))==null?void 0:d.textContent)==null?void 0:o.trim())||"Workday Employer",r=Array.from(e.querySelectorAll('[data-automation-id="compositeHeader"], [data-automation-id="jobCard"], li[class*="css-"], div[data-automation-id="jobPostingHeader"]'));for(const f of r){const y=f.tagName==="A"?f:f.querySelector("a"),h=f.querySelector('[data-automation-id="jobPostingHeader"], h3, h4, a')||y,x=f.querySelector('[data-automation-id="locations"], [data-automation-id="jobLocation"]'),g=f.querySelector('[data-automation-id="timeType"]'),b=(c=h==null?void 0:h.textContent)==null?void 0:c.trim(),v=(y==null?void 0:y.href)||i;b&&b.length>2&&!n.has(v)&&(n.add(v),t.push({title:b,company:a,location:(p=x==null?void 0:x.textContent)==null?void 0:p.trim(),jobType:(m=g==null?void 0:g.textContent)==null?void 0:m.trim(),jobUrl:v,sourceWebsite:"Workday",confidence:"HIGH"}))}if(t.length===0){const f=Array.from(e.querySelectorAll('a[href*="/job/"]'));for(const y of f){const h=(u=y.textContent)==null?void 0:u.trim(),x=y.href||i;h&&h.length>3&&!n.has(x)&&(n.add(x),t.push({title:h,company:a,jobUrl:x,sourceWebsite:"Workday",confidence:"HIGH"}))}}return t}extractSingleJob(e){var l,d,o,c,p,m,u,f,y,h,x;const t=(d=(l=e.querySelector('[data-automation-id="jobPostingHeader"], h2[data-automation-id="jobPostingHeader"], h1'))==null?void 0:l.textContent)==null?void 0:d.trim();if(!t)return null;const n=((o=e.querySelector('meta[property="og:site_name"]'))==null?void 0:o.content)||((p=(c=e.querySelector('[data-automation-id="companyName"]'))==null?void 0:c.textContent)==null?void 0:p.trim())||"Workday Employer",i=(u=(m=e.querySelector('[data-automation-id="locations"], [data-automation-id="jobLocation"]'))==null?void 0:m.textContent)==null?void 0:u.trim(),a=(y=(f=e.querySelector('[data-automation-id="timeType"]'))==null?void 0:f.textContent)==null?void 0:y.trim(),r=(x=(h=e.querySelector('[data-automation-id="jobPostingDescription"]'))==null?void 0:h.textContent)==null?void 0:x.trim();return{title:t,company:n,location:i,jobType:a,description:r,jobUrl:typeof window<"u"?window.location.href:"",sourceWebsite:"Workday",confidence:"HIGH"}}}function mt(s){try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const n of t)e.searchParams.delete(n);return e.toString()}catch{return s}}function tn(s){var e,t,n,i,a;try{const r=s.querySelectorAll('script[type="application/ld+json"]');for(const l of Array.from(r)){const d=l.textContent;if(!d)continue;const o=JSON.parse(d),c=(o==null?void 0:o["@type"])==="JobPosting"?o:Array.isArray(o==null?void 0:o["@graph"])?o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"):o;if(c){const p=((e=c==null?void 0:c.hiringOrganization)==null?void 0:e.name)||((t=c==null?void 0:c.hiringOrganization)==null?void 0:t.legalName)||((n=c==null?void 0:c.author)==null?void 0:n.name),m=((i=c==null?void 0:c.jobLocation)==null?void 0:i.address)||(c==null?void 0:c.jobLocation);let u="";typeof m=="string"?u=m:m&&(u=[m.addressLocality,m.addressRegion,m.addressCountry].filter(Boolean).join(", "));let f="";const y=((a=c==null?void 0:c.baseSalary)==null?void 0:a.value)||(c==null?void 0:c.baseSalary);return y&&(typeof y=="string"||typeof y=="number"?f=String(y):y.minValue&&y.maxValue?f=`${y.minValue} - ${y.maxValue} ${y.unitText||""}`.trim():y.value&&(f=String(y.value))),{company:p==null?void 0:p.trim(),location:(u==null?void 0:u.trim())||void 0,salary:(f==null?void 0:f.trim())||void 0,description:(c==null?void 0:c.description)||void 0,title:(c==null?void 0:c.title)||void 0}}}}catch{}return{}}class nn{constructor(){this.name="Unstop"}canHandle(e){return e.includes("unstop.com")}isJobDetailPage(e,t){var d,o,c,p;const n=e.toLowerCase();if((((o=(d=t==null?void 0:t.querySelectorAll)==null?void 0:d.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], .single_opportunity'))==null?void 0:o.length)||0)>=2)return!1;const a=/\/jobs\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/internships\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/competitions\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/hackathons\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/workshops\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/conferences\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/quizzes\/[a-zA-Z0-9_-]+-\d+/i.test(n)||/\/p\/[a-zA-Z0-9_-]+/i.test(n)||/\/(jobs|internships|competitions)\/[a-zA-Z0-9_-]{4,}/i.test(n)&&!/\/(jobs|internships|competitions)\/(search|all|\?|$)/i.test(n),r=!!((c=t==null?void 0:t.querySelector)!=null&&c.call(t,'h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i]')),l=!!((p=t==null?void 0:t.querySelector)!=null&&p.call(t,'button[class*="apply" i], a[class*="apply" i], button[class*="register" i], a[class*="register" i]'));return a?!0:!!(r&&l)}isJobListingPage(e,t){var r,l;if(this.isJobDetailPage(e,t))return!1;const n=e.toLowerCase(),i=/\/jobs\/?(\?.*)?$/i.test(n)||/\/jobs\/search/i.test(n)||/\/internships\/?(\?.*)?$/i.test(n)||/\/internships\/search/i.test(n)||/\/competitions\/?(\?.*)?$/i.test(n)||/\/all-opportunities/i.test(n)||n.includes("opportunity="),a=((l=(r=t==null?void 0:t.querySelectorAll)==null?void 0:r.call(t,'[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], [class*="opportunity" i], .single_opportunity'))==null?void 0:l.length)||0;return!!(i||a>=2)}extractJobList(e){var a,r,l,d,o;const t=[],n=new Set,i=Array.from(e.querySelectorAll('[class*="opportunity_card" i], [class*="opp-card" i], [class*="opp_card" i], [class*="c-card" i], [class*="job-card" i], [class*="listing_card" i], .single_opportunity, [class*="opportunity" i]'));for(const c of i){if(c.children.length>25&&c.querySelectorAll('[class*="opportunity" i]').length>1)continue;const p=c.querySelector('h2, h3, h4, h1, [class*="title" i], [class*="opp_title" i], [class*="heading" i], a'),m=(p==null?void 0:p.tagName)==="A"?p:c.querySelector("a"),u=c.querySelector('[class*="company" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub-title" i], [class*="subtitle" i], [class*="brand" i]'),f=c.querySelector('[class*="location" i], [class*="city" i], [class*="place" i], [class*="meta_item" i], [aria-label*="location" i]'),y=c.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="pay" i], [class*="compensation" i]'),h=c.querySelector('[class*="job-type" i], [class*="opp-type" i], [class*="timing" i], [class*="type" i]'),g=(((a=p==null?void 0:p.textContent)==null?void 0:a.trim())||"").replace(/\s+/g," ").trim(),b=(r=u==null?void 0:u.textContent)==null?void 0:r.trim(),v=b&&b.length>0?b:"Unknown Company",w=(m==null?void 0:m.href)||(typeof window<"u"?window.location.href:""),k=mt(w)||`https://unstop.com/jobs/${encodeURIComponent(g||"")}-${encodeURIComponent(v||"")}`;let S=((l=f==null?void 0:f.textContent)==null?void 0:l.trim())||void 0;S&&(S.includes("Bengaluru")||S.includes("Bangalore"))&&(S=S.replace(/\s+/g," ").trim()),g&&g.length>2&&!n.has(k)&&(n.add(k),t.push({title:g,company:v,location:S,salary:((d=y==null?void 0:y.textContent)==null?void 0:d.trim())||void 0,jobType:((o=h==null?void 0:h.textContent)==null?void 0:o.trim())||void 0,jobUrl:k,sourceWebsite:"Unstop",confidence:"HIGH"}))}return t}extractSingleJob(e){var x,g,b,v,w,k,S,C,A;const t=tn(e),n=e.querySelector('h1, h1.title, [class*="job-title" i], [class*="opp_title" i], [class*="opp-title" i], [class*="header" i] h1, [class*="main_title" i]'),i=((x=n==null?void 0:n.textContent)==null?void 0:x.trim())||t.title;if(!i||i.length<2)return null;const a=e.querySelector('[class*="company_name" i], [class*="organisation" i], [class*="organization" i], [class*="c-name" i], [class*="sub_title" i], [class*="sub-title" i], [class*="org" i], [class*="employer" i], [class*="brand" i], h2'),r=((g=a==null?void 0:a.textContent)==null?void 0:g.trim())||t.company||"Unknown Company",l=e.querySelector('[class*="location" i], [class*="place" i], [class*="city" i], [class*="job_location" i], [aria-label*="location" i], .job_details_item_location, .other_details .location');let d=((b=l==null?void 0:l.textContent)==null?void 0:b.trim())||t.location;if(!d){const L=Array.from(e.querySelectorAll('[class*="chip" i], [class*="badge" i], [class*="meta" i], [class*="detail" i]'));for(const M of L){const N=((v=M.textContent)==null?void 0:v.trim())||"";if(/\b(Bangalore|Bengaluru|Hyderabad|Pune|Mumbai|Delhi|Gurgaon|Gurugram|Noida|Chennai|Kolkata|Remote|Work from home|Hybrid)\b/i.test(N)&&N.length<50){d=N;break}}}d&&(d=d.replace(/\s+/g," ").trim());const o=e.querySelector('[class*="salary" i], [class*="stipend" i], [class*="ctc" i], [class*="compensation" i], [class*="pay" i]'),c=((w=o==null?void 0:o.textContent)==null?void 0:w.trim())||t.salary||void 0,p=e.querySelector('[class*="job-type" i], [class*="job_type" i], [class*="opp_type" i], [class*="opp-type" i], [class*="timing" i], [class*="work_type" i]'),m=((k=p==null?void 0:p.textContent)==null?void 0:k.trim())||void 0,u=e.querySelector('#description, [class*="description" i], [class*="details" i], [class*="about" i], [class*="eligibility" i], [class*="overview" i]'),f=((C=(S=u==null?void 0:u.textContent)==null?void 0:S.trim())==null?void 0:C.slice(0,2e3))||((A=t.description)==null?void 0:A.slice(0,2e3))||void 0,y=typeof window<"u"?window.location.href:"",h=mt(y);return console.log(`[Talvyn] UNSSTOP_JOB_EXTRACTED: ${i} at ${r} (URL: ${h}, Location: ${d||"N/A"})`),{title:i,company:r,location:d,salary:c,jobType:m,description:f,jobUrl:h,sourceWebsite:"Unstop",confidence:"HIGH"}}}class an{constructor(){this.adapters=[],this.genericAdapter=new Vt,this.adapters=[new Wt,new Yt,new nn,new Qt,new Zt,new Kt,new Xt,new en]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const Fe=new an,sn={intern:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"intern"},internship:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"internship"},trainee:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"trainee"},apprentice:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"apprentice"},fellow:{level:"INTERN",yearsMin:0,yearsMax:1,matchedTerm:"fellow"},junior:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"junior"},"jr.":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr."},jr:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"jr"},"entry level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry level"},"entry-level":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"entry-level"},associate:{level:"ENTRY",yearsMin:0,yearsMax:3,matchedTerm:"associate"},graduate:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"graduate"},level1:{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level 1":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level 1"},"level i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"level i"}," i":{level:"ENTRY",yearsMin:0,yearsMax:2,matchedTerm:"i"},mid:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid"},"mid-level":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"mid-level"},intermediate:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"intermediate"},level2:{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level 2":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level 2"},"level ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"level ii"}," ii":{level:"MID",yearsMin:2,yearsMax:5,matchedTerm:"ii"},senior:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"senior"},"sr.":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr."},sr:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"sr"},level3:{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level 3":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level 3"},"level iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"level iii"}," iii":{level:"SENIOR",yearsMin:5,yearsMax:8,matchedTerm:"iii"},experienced:{level:"SENIOR",yearsMin:4,yearsMax:8,matchedTerm:"experienced"},lead:{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"lead"},"team lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"team lead"},"tech lead":{level:"LEAD",yearsMin:6,yearsMax:10,matchedTerm:"tech lead"},principal:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"principal"},staff:{level:"STAFF_PLUS",yearsMin:8,matchedTerm:"staff"},distinguished:{level:"STAFF_PLUS",yearsMin:12,matchedTerm:"distinguished"},fellow2:{level:"STAFF_PLUS",yearsMin:15,matchedTerm:"fellow"},"executive director":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"executive director"},"vice president":{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vice president"},vp:{level:"DIRECTOR_PLUS",yearsMin:10,matchedTerm:"vp"},director:{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"director"},"head of":{level:"DIRECTOR_PLUS",yearsMin:8,matchedTerm:"head of"},chief:{level:"DIRECTOR_PLUS",yearsMin:12,matchedTerm:"chief"}},on=["senior","sr.","sr","junior","jr.","jr","entry-level","entry level","lead","principal","staff","intern","internship","trainee","apprentice","graduate","experienced","mid-level","level 1","level 2","level 3","level i","level ii","level iii"],rn=[/\b(urgent|urgently hiring|immediate hiring|hiring now|we're hiring|apply now|remote|hybrid|onsite|on-site|full-time|part-time|contract|temporary|wfh|work from home|multiple openings|100% remote)\b/gi,/\b(\[.*?\]|\(.*?\))\b/g,/\s+[-–|•#]\s+.*$/g,/[^\w\s/]/g,/\//g,/\s+/g],ln=[{canonical:"data analyst",domain:"Data",synonyms:["analytics associate","reporting analyst","bi analyst","business intelligence analyst","data analytics specialist","product analyst","operations data analyst","sql data analyst","insights analyst","metrics analyst"],broaderRelated:["data scientist","business analyst","data engineer","analytics engineer","quantitative analyst"]},{canonical:"data scientist",domain:"Data",synonyms:["machine learning scientist","applied scientist","ai scientist","decision scientist","ml researcher","statistical modeler","data science specialist"],broaderRelated:["data analyst","machine learning engineer","ai engineer","quantitative researcher","statistician"]},{canonical:"data engineer",domain:"Data",synonyms:["big data engineer","etl developer","data platform engineer","data warehouse engineer","analytics engineer","data pipeline engineer","sql developer"],broaderRelated:["data analyst","data scientist","backend engineer","database administrator","cloud data architect"]},{canonical:"machine learning engineer",domain:"Data",synonyms:["ml engineer","ai engineer","mlops engineer","deep learning engineer","nlp engineer","computer vision engineer","ai developer"],broaderRelated:["data scientist","data engineer","software engineer","backend engineer"]},{canonical:"business intelligence analyst",domain:"Data",synonyms:["bi analyst","bi developer","power bi developer","tableau developer","bi specialist","reporting specialist"],broaderRelated:["data analyst","business analyst","data engineer"]},{canonical:"software engineer",domain:"Software",synonyms:["software developer","programmer","application developer","systems developer","software architect","sde","swe"],broaderRelated:["fullstack developer","frontend developer","backend developer","devops engineer","mobile developer"]},{canonical:"frontend developer",domain:"Software",synonyms:["frontend engineer","front end developer","front-end engineer","ui developer","ui engineer","web developer","react developer","javascript developer","client side engineer"],broaderRelated:["software engineer","fullstack developer","ui designer","product designer"]},{canonical:"backend developer",domain:"Software",synonyms:["backend engineer","back end developer","back-end engineer","server side developer","api developer","node developer","python developer","java developer","golang developer"],broaderRelated:["software engineer","fullstack developer","data engineer","devops engineer","cloud engineer"]},{canonical:"fullstack developer",domain:"Software",synonyms:["fullstack engineer","full stack developer","full-stack engineer","web application engineer"],broaderRelated:["software engineer","frontend developer","backend developer","mobile developer"]},{canonical:"mobile developer",domain:"Software",synonyms:["mobile engineer","ios developer","android developer","ios engineer","android engineer","flutter developer","react native developer","mobile app developer"],broaderRelated:["software engineer","frontend developer"]},{canonical:"devops engineer",domain:"Software",synonyms:["site reliability engineer","sre","cloud engineer","platform engineer","infrastructure engineer","cloud architect","systems engineer","sysadmin"],broaderRelated:["backend developer","software engineer","security engineer","network engineer"]},{canonical:"qa engineer",domain:"Software",synonyms:["quality assurance engineer","sdet","software development engineer in test","automation test engineer","test engineer","qa automation engineer","tester"],broaderRelated:["software engineer","devops engineer"]},{canonical:"cybersecurity analyst",domain:"Security",synonyms:["security analyst","information security analyst","infosec engineer","security engineer","soc analyst","penetration tester","threat analyst"],broaderRelated:["devops engineer","systems engineer","network engineer"]},{canonical:"product manager",domain:"Product",synonyms:["technical product manager","tpm","associate product manager","apm","group product manager","product lead","product owner","digital product manager"],broaderRelated:["project manager","program manager","business analyst","scrum master","product marketing manager"]},{canonical:"project manager",domain:"Project Management",synonyms:["technical project manager","it project manager","scrum master","agile coach","delivery manager","project coordinator","pmo analyst"],broaderRelated:["program manager","product manager","operations manager"]},{canonical:"program manager",domain:"Project Management",synonyms:["technical program manager","tpm","strategic program manager","transformation manager"],broaderRelated:["project manager","product manager","operations director"]},{canonical:"business analyst",domain:"Business",synonyms:["business systems analyst","it business analyst","requirements analyst","functional analyst","strategy analyst","process analyst"],broaderRelated:["product manager","data analyst","project manager","operations analyst"]},{canonical:"product designer",domain:"Design",synonyms:["ux designer","ui designer","ui ux designer","ui/ux designer","user experience designer","interaction designer","digital designer","experience designer"],broaderRelated:["ux researcher","visual designer","graphic designer","frontend developer","design system engineer"]},{canonical:"ux researcher",domain:"Design",synonyms:["user researcher","design researcher","user experience researcher","usability analyst","cx researcher"],broaderRelated:["product designer","data analyst","product manager"]},{canonical:"graphic designer",domain:"Design",synonyms:["visual designer","brand designer","creative designer","marketing designer","illustrator","motion designer"],broaderRelated:["product designer","content creator","art director"]},{canonical:"digital marketer",domain:"Marketing",synonyms:["marketing specialist","growth marketer","performance marketer","online marketing specialist","demand generation specialist","paid media specialist","sem specialist","media buyer"],broaderRelated:["content marketer","seo specialist","social media manager","product marketing manager","brand manager"]},{canonical:"product marketing manager",domain:"Marketing",synonyms:["pmm","product marketer","go-to-market specialist","gtm manager","solution marketing manager"],broaderRelated:["product manager","digital marketer","content marketer","brand manager"]},{canonical:"content marketer",domain:"Marketing",synonyms:["content strategist","copywriter","content writer","technical writer","editorial specialist","blog writer","communications specialist"],broaderRelated:["social media manager","seo specialist","digital marketer","pr specialist"]},{canonical:"seo specialist",domain:"Marketing",synonyms:["seo manager","search engine optimization analyst","organic growth specialist","seo strategist"],broaderRelated:["content marketer","digital marketer","web analyst"]},{canonical:"social media manager",domain:"Marketing",synonyms:["community manager","social media strategist","social media specialist","influencer marketing manager"],broaderRelated:["content marketer","digital marketer","brand manager"]},{canonical:"recruiter",domain:"HR",synonyms:["technical recruiter","talent acquisition specialist","talent acquisition partner","headhunter","talent sourcer","recruiting specialist","staffing consultant"],broaderRelated:["hr generalist","hr business partner","people operations specialist"]},{canonical:"hr generalist",domain:"HR",synonyms:["hr specialist","human resources coordinator","people operations specialist","hr officer","human resources manager","hr administrator"],broaderRelated:["recruiter","hr business partner","compensation analyst","payroll specialist"]},{canonical:"hr business partner",domain:"HR",synonyms:["hrbp","people partner","strategic hr partner","senior hr consultant"],broaderRelated:["hr generalist","recruiter","operations manager"]},{canonical:"financial analyst",domain:"Finance",synonyms:["fpa analyst","fp&a analyst","finance associate","investment analyst","budget analyst","financial planning analyst","commercial finance analyst","treasury analyst"],broaderRelated:["accountant","business analyst","risk analyst","data analyst","portfolio manager"]},{canonical:"accountant",domain:"Finance",synonyms:["staff accountant","senior accountant","certified public accountant","cpa","bookkeeper","tax accountant","audit associate","financial accountant","cost accountant"],broaderRelated:["financial analyst","controller","finance manager"]},{canonical:"controller",domain:"Finance",synonyms:["financial controller","comptroller","accounting director","head of finance"],broaderRelated:["accountant","financial analyst","cfo"]},{canonical:"account executive",domain:"Sales",synonyms:["ae","sales executive","enterprise account executive","sales representative","commercial sales representative","sales manager","closing rep"],broaderRelated:["sales development representative","business development manager","account manager","partnerships manager"]},{canonical:"sales development representative",domain:"Sales",synonyms:["sdr","bdr","business development representative","inside sales representative","outbound sales specialist","lead generation specialist"],broaderRelated:["account executive","business development manager","sales specialist"]},{canonical:"account manager",domain:"Sales",synonyms:["client manager","key account manager","client relationship manager","strategic account manager","client partner"],broaderRelated:["customer success manager","account executive","customer support specialist"]},{canonical:"business development manager",domain:"Sales",synonyms:["bdm","partnerships manager","strategic partnerships lead","alliance manager","channel sales manager"],broaderRelated:["account executive","sales development representative","product manager"]},{canonical:"customer success manager",domain:"Customer Success",synonyms:["csm","client success specialist","customer success specialist","client relationship specialist","customer onboarding specialist","implementation consultant"],broaderRelated:["account manager","customer support specialist","project manager","sales engineer"]},{canonical:"customer support specialist",domain:"Customer Support",synonyms:["support engineer","technical support specialist","help desk analyst","customer service representative","client support specialist","service desk analyst"],broaderRelated:["customer success manager","operations specialist","qa engineer"]},{canonical:"operations manager",domain:"Operations",synonyms:["business operations manager","bizops manager","operations lead","chief of staff","general manager","operations supervisor"],broaderRelated:["project manager","program manager","supply chain analyst","business analyst"]},{canonical:"supply chain analyst",domain:"Operations",synonyms:["logistics analyst","procurement specialist","inventory analyst","demand planning analyst","operations analyst"],broaderRelated:["operations manager","data analyst","financial analyst"]}];function ft(s){if(!s)return{raw:"",normalized:"",seniority:{level:"UNSPECIFIED",yearsMin:0},tokens:[]};let e=s.toLowerCase().trim(),t={level:"UNSPECIFIED",yearsMin:0};for(const[i,a]of Object.entries(sn))if(new RegExp(`\\b${yt(i)}\\b`,"i").test(e)){t=a;break}for(const i of rn)e=e.replace(i," ");for(const i of on){const a=new RegExp(`\\b${yt(i)}\\b`,"gi");e=e.replace(a," ")}e=e.replace(/\s+/g," ").trim();const n=e.split(" ").filter(i=>i.length>1);return{raw:s,normalized:e,seniority:t,tokens:n}}function yt(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function cn(s,e){const t=s.normalized,n=e.normalized;if(t===n||s.raw.toLowerCase().trim()===e.raw.toLowerCase().trim())return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:1,reason:`Exact match for preferred role "${e.raw}"`};if(t.length>2&&n.length>2&&(t.includes(n)||n.includes(t)))return{preferredRole:e.raw,jobTitle:s.raw,level:"EXACT_MATCH",score:.95,reason:`Direct title match for preferred role "${e.raw}"`};const i=ht(n),a=ht(t);for(const d of i){if(d.canonical===t)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${d.domain}`};const o=d.synonyms.find(p=>p===t||t.includes(p)||p.includes(t));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`};const c=d.broaderRelated.find(p=>p===t||t.includes(p)||p.includes(t));if(c)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.6,reason:`Related career path (${c}) for "${e.raw}"`}}for(const d of a){if(d.canonical===n)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.85,reason:`Direct synonym match for "${e.raw}" in ${d.domain}`};const o=d.synonyms.find(c=>c===n||n.includes(c)||c.includes(n));if(o)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.8,reason:`Strong related match (${o}) for "${e.raw}"`}}const r=new Set(s.tokens),l=new Set(e.tokens);if(r.size>0&&l.size>0){let d=0;for(const p of l)r.has(p)&&d++;const o=d/l.size,c=d/(r.size+l.size-d);if(o>=.75)return{preferredRole:e.raw,jobTitle:s.raw,level:"STRONG_RELATED",score:.75,reason:`Key skill/role tokens match "${e.raw}"`};if(o>=.5||c>=.4)return{preferredRole:e.raw,jobTitle:s.raw,level:"RELATED",score:.55,reason:`Partial keyword overlap with preferred role "${e.raw}"`};if(d>=1&&(r.size<=3||l.size<=3))return{preferredRole:e.raw,jobTitle:s.raw,level:"WEAK_MATCH",score:.3,reason:`Minor keyword match with "${e.raw}"`}}return{preferredRole:e.raw,jobTitle:s.raw,level:"NO_MATCH",score:0,reason:`Role does not match "${e.raw}"`}}function ht(s){if(!s||s.length<3)return[];const e=[];for(const t of ln)(t.canonical===s||De(t.canonical,s)||t.synonyms.some(n=>n===s||De(n,s))||t.broaderRelated.some(n=>n===s||De(n,s)))&&e.push(t);return e}function De(s,e){if(s===e)return!0;const t=new RegExp(`\\b${gt(s)}\\b`,"i"),n=new RegExp(`\\b${gt(e)}\\b`,"i");return t.test(e)||n.test(s)}function gt(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function It(s,e,t=.45){const n=ft(s);if(!e||e.length===0)return{level:"RELATED",score:.5,weight:t,weightedScore:.5*t*100,reason:"No preferred roles specified in profile",rawTitle:s,normalizedTitle:n.normalized};let i={preferredRole:e[0],level:"NO_MATCH",score:0,reason:"Role did not match your preferred roles"};for(const a of e){const r=ft(a),l=cn(n,r);if(l.score>i.score&&(i=l),i.score===1)break}return{level:i.level,matchedRole:i.preferredRole,score:i.score,weight:t,weightedScore:Math.round(i.score*t*100*10)/10,reason:i.reason,rawTitle:s,normalizedTitle:n.normalized}}const dn={role:.3,experience:.25,education:.2,skills:.2,location:.05},pn={javascript:"JavaScript",typescript:"TypeScript",react:"React","react native":"React Native","node.js":"Node.js",nodejs:"Node.js",node:"Node.js",python:"Python",java:"Java","c++":"C++","c#":"C#",".net":".NET",aws:"AWS","amazon web services":"AWS",docker:"Docker",kubernetes:"Kubernetes",sql:"SQL",mysql:"MySQL",postgresql:"PostgreSQL",postgres:"PostgreSQL",mongodb:"MongoDB",graphql:"GraphQL","rest api":"REST APIs",rest:"REST APIs",git:"Git",github:"GitHub",html:"HTML5",css:"CSS3",tailwind:"Tailwind CSS","next.js":"Next.js",nextjs:"Next.js",vue:"Vue.js",angular:"Angular",django:"Django",fastapi:"FastAPI",flask:"Flask","spring boot":"Spring Boot",spring:"Spring Boot",go:"Golang",golang:"Golang",rust:"Rust",ruby:"Ruby","ruby on rails":"Rails",rails:"Rails",php:"PHP",laravel:"Laravel",flutter:"Flutter",swift:"Swift",kotlin:"Kotlin",figma:"Figma",jira:"Jira",agile:"Agile","ci/cd":"CI/CD",linux:"Linux",azure:"Azure",gcp:"GCP",redis:"Redis",kafka:"Kafka",microservices:"Microservices",devops:"DevOps",pandas:"Pandas",numpy:"NumPy","machine learning":"Machine Learning",ai:"AI",tableau:"Tableau",excel:"Excel",powerbi:"PowerBI","power bi":"PowerBI","financial modeling":"Financial Modeling",budgeting:"Budgeting",prototyping:"Prototyping","user research":"User Research"};function un(s="",e="",t=""){const n=`${s} ${t} ${e||""}`.toLowerCase(),i=n.match(/\b(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:[-–—]|to)\s*(\d+)\s*(?:years?|yrs?)?/i);if(i){const d=parseInt(i[1],10),o=parseInt(i[2],10);return{minYears:d,maxYears:o,isFresher:d===0,rawText:`${d}–${o} years`}}const a=n.match(/\b(\d+)\s*\+\s*(?:years?|yrs?)(?:\s+of\s+experience)?/i)||n.match(/\b(?:min(?:imum)?|at\s+least)\s+(\d+)\s*(?:years?|yrs?)/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*\+\s*(?:years?|yrs?)?/i);if(a){const d=parseInt(a[1],10);return{minYears:d,maxYears:null,isFresher:d===0,rawText:`${d}+ years`}}const r=n.match(/\b(\d+)\s*(?:years?|yrs?)(?:\s+of)?\s+experience\b/i)||n.match(/\bexperience\s*(?:required)?\s*[:\-–—]\s*(\d+)\s*(?:years?|yrs?)\b/i);if(r){const d=parseInt(r[1],10);return{minYears:d,maxYears:null,isFresher:d===0,rawText:d===1?"1 year":`${d} years`}}return/\b(fresher|entry[\s-]level|trainee|graduate|intern|internship|campus)\b/i.test(s)||/\b(fresher|entry[\s-]level|0[\s-]*1\s*years?|0[\s-]*0\s*years?)\b/i.test(n)?{minYears:0,maxYears:1,isFresher:!0,rawText:"Fresher / 0–1 years"}:null}function qt(s,e,t,n,i=.25){const a=un(s,e||"",t||""),r=n.experienceYears??null,l=r===0||r===null,d=l?"Fresher":`${r} year${r===1?"":"s"}`;if(!a)return{score:.8,weight:i,weightedScore:.8*i*100,reason:"Experience requirements appear standard/flexible",isHardMismatch:!1,requiredText:"Not specified",profileText:d,status:"UNSPECIFIED"};const o=a.rawText;if(l){if(a.isFresher||a.minYears===0)return{score:1,weight:i,weightedScore:i*100,reason:"Fresher / entry-level role matches your profile",isHardMismatch:!1,requiredText:o,profileText:d,status:"MATCH"};const u=a.minYears>=2;return{score:u?.05:.2,weight:i,weightedScore:(u?.05:.2)*i*100,reason:`Experience mismatch: Required: ${o}, Your profile: Fresher`,isHardMismatch:!0,requiredText:o,profileText:d,status:"MISMATCH"}}const c=r;if(a.maxYears!==null&&c>=a.minYears&&c<=a.maxYears)return{score:1,weight:i,weightedScore:i*100,reason:`Your ${c} years experience matches required range (${o})`,isHardMismatch:!1,requiredText:o,profileText:d,status:"MATCH"};if(c>=a.minYears)return{score:1,weight:i,weightedScore:i*100,reason:`Your ${c} yrs experience satisfies requirement (${o})`,isHardMismatch:!1,requiredText:o,profileText:d,status:"MATCH"};const m=a.minYears-c>=2||a.minYears>=2;return{score:m?.1:.35,weight:i,weightedScore:(m?.1:.35)*i*100,reason:`Experience mismatch: Required: ${o}, Your profile: ${d}`,isHardMismatch:m,requiredText:o,profileText:d,status:"MISMATCH"}}function jt(s,e,t,n=.2){const i=`${s} ${e||""}`.toLowerCase(),a=[{key:"b.tech",label:"B.Tech"},{key:"btech",label:"B.Tech"},{key:"b.e.",label:"B.E."},{key:"be ",label:"B.E."},{key:"m.tech",label:"M.Tech"},{key:"mtech",label:"M.Tech"},{key:"mca",label:"MCA"},{key:"bca",label:"BCA"},{key:"b.sc",label:"B.Sc"},{key:"bsc",label:"B.Sc"},{key:"bachelor",label:"Bachelor's"},{key:"master",label:"Master's"},{key:"computer science",label:"Computer Science"},{key:"cs/it",label:"CS/IT"},{key:"information technology",label:"Information Technology"},{key:"engineering",label:"Engineering"},{key:"undergraduate",label:"Undergraduate"},{key:"graduate",label:"Graduate"}],r=[];for(const m of a)i.includes(m.key)&&!r.includes(m.label)&&r.push(m.label);const l=(t.degree||"").toLowerCase(),d=(t.specialization||"").toLowerCase(),o=`${l} ${d}`.trim();if(r.length===0)return{score:.85,weight:n,weightedScore:.85*n*100,reason:"Education: Not specified",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:"Not specified"};const c=r.slice(0,3).join(" / ");return o?r.some(m=>{const u=m.toLowerCase();return o.includes(u)||u.includes("b.tech")&&(o.includes("btech")||o.includes("b.e.")||o.includes("engineering"))||u.includes("b.e.")&&(o.includes("btech")||o.includes("b.tech")||o.includes("engineering"))||u.includes("computer science")&&(o.includes("cs")||o.includes("it")||o.includes("information technology"))||u.includes("bachelor")&&(o.includes("b.tech")||o.includes("b.e.")||o.includes("bca")||o.includes("bsc")||o.includes("bachelor"))})?{score:1,weight:n,weightedScore:n*100,reason:`Education match: ${t.degree||"Degree"} aligns with ${c}`,isHardMismatch:!1,status:"MATCH",requiredText:c}:{score:.15,weight:n,weightedScore:.15*n*100,reason:`Education mismatch: Requires ${c}`,isHardMismatch:!0,status:"MISMATCH",requiredText:c}:{score:.6,weight:n,weightedScore:.6*n*100,reason:"Education not specified in profile",isHardMismatch:!1,status:"UNSPECIFIED",requiredText:c}}function Nt(s,e,t,n=.2){const i=`${s} ${e||""}`.toLowerCase(),a=[];for(const[u,f]of Object.entries(pn))new RegExp(`(?:^|[\\s,.;/()+-])${u.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}(?:$|[\\s,.;/()+-])`,"i").test(i)&&(a.includes(f)||a.push(f));const r=(t.skills||[]).map(u=>u.trim()),l=r.map(u=>u.toLowerCase()),d=[],o=[];for(const u of a){const f=u.toLowerCase();l.some(h=>h.includes(f)||f.includes(h))?d.includes(u)||d.push(u):o.includes(u)||o.push(u)}if(d.length===0&&r.length>0)for(const u of r)i.includes(u.toLowerCase())&&!d.includes(u)&&d.push(u);if(a.length===0&&d.length===0)return{score:.85,weight:n,weightedScore:.85*n*100,reason:"General technical skill alignment",matchedSkills:r.slice(0,3),missingSkills:[],status:"UNSPECIFIED"};const c=d.length+o.length;let p=.5;c>0?(p=d.length/c,d.length>0&&p<.4&&(p=.4)):d.length>0&&(p=1);const m=d.length>=1;return{score:p,weight:n,weightedScore:p*n*100,reason:m?`Skills match: ${d.slice(0,3).join(", ")}`:`Missing key skills: ${o.slice(0,2).join(", ")}`,matchedSkills:d,missingSkills:o,status:m?"MATCH":"MISMATCH"}}function zt(s,e,t,n=.05){const i=(s||"").toLowerCase().trim(),a=(e||"").toLowerCase(),r=t.preferredLocations||[],l=t.workStyle||"ANY",d=i.includes("remote")||i.includes("wfh")||i.includes("anywhere")||a.includes("100% remote")||a.includes("fully remote")||a.includes("work from home"),o=i.includes("hybrid")||a.includes("hybrid work")||a.includes("hybrid schedule");if(l==="ANY"&&r.length===0)return{score:1,weight:n,weightedScore:n*100,reason:"Open to all locations and work styles"};if(l==="REMOTE"){if(d)return{score:1,weight:n,weightedScore:n*100,reason:"Remote position aligns with your Remote preference"};if(o)return{score:.5,weight:n,weightedScore:.5*n*100,reason:"Hybrid role (partially remote)"}}if(r.length>0)for(const c of r){const p=c.toLowerCase().trim();if(p){if(p.includes("remote")&&d)return{score:1,weight:n,weightedScore:n*100,reason:'Remote job matches preferred location "Remote"'};if(i&&(i.includes(p)||p.includes(i)))return{score:1,weight:n,weightedScore:n*100,reason:`Location matches preferred location "${c}"`}}}return(l==="HYBRID"||l==="ANY")&&d?{score:.9,weight:n,weightedScore:.9*n*100,reason:"Remote job provides work flexibility"}:i?{score:.2,weight:n,weightedScore:.2*n*100,reason:`Location "${s}" differs from preferred locations`}:{score:.6,weight:n,weightedScore:.6*n*100,reason:"Location not specified in job posting"}}function mn(s,e,t=.05){const n=e.preferredJobTypes||[];if(n.length===0)return{score:1,weight:t,weightedScore:t*100,reason:"Open to all employment types"};if(!s)return{score:.6,weight:t,weightedScore:.6*t*100,reason:"Job type not disclosed in listing"};const i=s.toUpperCase().replace(/[-\s]/g,"_");return n.some(r=>{const l=r.toUpperCase().replace(/[-\s]/g,"_");return i.includes(l)||l.includes(i)})?{score:1,weight:t,weightedScore:t*100,reason:`Employment type (${s}) matches your preference`}:{score:.2,weight:t,weightedScore:.2*t*100,reason:`Job type (${s}) differs from preferred (${n.join(", ")})`}}function fn(s,e,t=.05){return e.expectedSalary?s?{score:.8,weight:t,weightedScore:.8*t*100,reason:`Salary listed as "${s}"`}:{score:.6,weight:t,weightedScore:.6*t*100,reason:"Salary not disclosed in listing"}:{score:.8,weight:t,weightedScore:.8*t*100,reason:"No expected salary specified in profile"}}function yn(s,e,t=dn){const n=It(s.title,e.preferredRoles,t.role),i=qt(s.title,s.description,s.jobType,e,t.experience),a=jt(s.title,s.description,e,t.education),r=Nt(s.title,s.description,e,t.skills),l=zt(s.location,s.description,e,t.location);let d=Math.round(n.weightedScore+i.weightedScore+a.weightedScore+r.weightedScore+l.weightedScore);const o=n.level==="NO_MATCH"||n.score===0,c=i.isHardMismatch||i.status==="MISMATCH",p=a.status==="MISMATCH"&&a.isHardMismatch;let m=Math.min(100,Math.max(0,d)),u,f="";c&&i.isHardMismatch?(m=Math.min(42,Math.max(25,Math.round(d*.46))),u="LOW_RELEVANCE",f="Experience requirement does not match your profile."):o?(m=Math.min(44,Math.max(20,Math.round(d*.42))),u="LOW_RELEVANCE",f="Role does not align with your profile."):p?(m=Math.min(45,Math.max(25,Math.round(d*.45))),u="LOW_RELEVANCE",f="Education requirement differs from your profile."):m>=85?u="EXCELLENT":m>=70?u="HIGHLY_RELEVANT":m>=50?u="RELEVANT":u="LOW_RELEVANCE";const y=[],h=[];n.score>=.6?y.push(n.reason):h.push(n.reason),i.status==="MATCH"?y.push(i.reason):i.status==="MISMATCH"&&h.push(i.reason),a.status==="MATCH"?y.push(a.reason):a.status==="MISMATCH"&&h.push(a.reason),r.status==="MATCH"&&r.matchedSkills.length>0&&y.push(`Skills match: ${r.matchedSkills.slice(0,3).join(", ")}`),r.missingSkills.length>0&&h.push(`Missing skills: ${r.missingSkills.slice(0,2).join(", ")}`),l.score>=.7?y.push(l.reason):l.score<.5&&h.push(l.reason),f&&!h.includes(f)&&h.unshift(f);const x=mn(s.jobType,e,.05),g=fn(s.salary,e,.05);return{job:s,relevanceScore:m,category:u,roleMatch:n,locationMatch:l,experienceMatch:i,educationMatch:a,skillsMatch:r,jobTypeMatch:x,salaryMatch:g,matchedReasons:y,unmatchedReasons:h,matchedSkills:r.matchedSkills,missingSkills:r.missingSkills}}class hn{constructor(){this.scannedJobUrls=new Set,this.cachedAnalyzedJobs=new Map,this.CACHE_TTL_MS=15*60*1e3}classifyPage(e,t){if(se(e))return{classification:"OTHER",adapterName:"None"};const n=Fe.getAdapter(e,t);return n.isJobDetailPage(e,t)?{classification:"SINGLE_JOB",adapterName:n.name}:n.isJobListingPage(e,t)?{classification:"JOB_LIST",adapterName:n.name}:fe(t,e)?{classification:"SINGLE_JOB",adapterName:n.name}:Oe(t,e)?{classification:"JOB_LIST",adapterName:n.name}:{classification:"OTHER",adapterName:n.name}}scanSingleJob(e,t){return se(e)?null:Fe.getAdapter(e,t).extractSingleJob(t)}scanJobListing(e,t,n,i=new Set){if(se(e))return{totalDetected:0,excellentCount:0,highlyRelevantCount:0,relevantCount:0,lowRelevanceCount:0,analyzedJobs:[],pageUrl:e,scannedAt:new Date().toISOString()};const r=Fe.getAdapter(e,t).extractJobList(t),l=[],d=Date.now();for(const u of r){const f=u.jobUrl||`${u.title}-${u.company}`,y=this.cachedAnalyzedJobs.get(f);let h;y&&d-y.cachedAt<this.CACHE_TTL_MS?h=y.job:(h=yn(u,n),this.cachedAnalyzedJobs.set(f,{job:h,cachedAt:d}),this.scannedJobUrls.add(f)),h.isSaved=i.has(u.jobUrl),l.push(h)}l.sort((u,f)=>f.relevanceScore-u.relevanceScore);let o=0,c=0,p=0,m=0;for(const u of l)u.category==="EXCELLENT"?o++:u.category==="HIGHLY_RELEVANT"?c++:u.category==="RELEVANT"?p++:m++;return{totalDetected:l.length,excellentCount:o,highlyRelevantCount:c,relevantCount:p,lowRelevanceCount:m,analyzedJobs:l,pageUrl:e,scannedAt:new Date().toISOString()}}clearCache(){this.scannedJobUrls.clear(),this.cachedAnalyzedJobs.clear()}}const ae=new hn,gn=[/\/jobs?\//i,/\/careers?\//i,/\/positions?\//i,/\/openings?\//i,/\/vacancies?\//i,/\/opportunities?\//i,/\/apply/i,/linkedin\.com\/jobs/i,/indeed\.com\/(viewjob|rc\/clk)/i,/glassdoor\.com\/job-listing/i,/lever\.co\//i,/greenhouse\.io\//i,/workable\.com\//i,/myworkdayjobs\.com\//i,/icims\.com\//i,/smartrecruiters\.com\//i,/jobvite\.com\//i,/taleo\.net\//i,/successfactors\.(com|eu)\//i,/boards\.greenhouse\.io\//i,/jobs\.lever\.co\//i],bn=[/apply (for|now)/i,/job (description|details|overview|summary)/i,/about (this|the) (role|position|job)/i,/role (overview|summary|description)/i,/position (overview|summary|details)/i,/what you('ll|'d| will) do/i,/responsibilities/i,/qualifications/i,/requirements/i];function xn(s){try{const e=new URL(s).hostname.replace(/^www\./,""),t={"linkedin.com":"LinkedIn","indeed.com":"Indeed","glassdoor.com":"Glassdoor","lever.co":"Lever","greenhouse.io":"Greenhouse","workable.com":"Workable","myworkdayjobs.com":"Workday","icims.com":"iCIMS","smartrecruiters.com":"SmartRecruiters","jobvite.com":"Jobvite","taleo.net":"Taleo"};for(const[n,i]of Object.entries(t))if(e.includes(n))return i;return e}catch{return window.location.hostname}}function vn(s=document){var t,n,i,a,r,l,d,o,c,p,m,u,f;const e=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const y of Array.from(e))try{const h=JSON.parse(y.textContent||"{}"),x=Array.isArray(h)?h:[h];for(const g of x)if(g["@type"]==="JobPosting")return{title:g.title||g.name,company:((t=g.hiringOrganization)==null?void 0:t.name)||g.employerOverview||((n=g.author)==null?void 0:n.name),location:typeof g.jobLocation=="string"?g.jobLocation:((a=(i=g.jobLocation)==null?void 0:i.address)==null?void 0:a.addressLocality)||((l=(r=g.jobLocation)==null?void 0:r.address)==null?void 0:l.addressRegion),salary:((o=(d=g.baseSalary)==null?void 0:d.value)==null?void 0:o.value)||((p=(c=g.baseSalary)==null?void 0:c.value)!=null&&p.minValue&&((u=(m=g.baseSalary)==null?void 0:m.value)!=null&&u.maxValue)?`${g.baseSalary.value.minValue}–${g.baseSalary.value.maxValue} ${g.baseSalary.value.unitText||""}`:void 0),jobType:g.employmentType,description:(f=g.description)==null?void 0:f.replace(/<[^>]*>/g," ").replace(/\s+/g," ").trim().slice(0,3e3)}}catch{}return null}function wn(s=document){var e,t,n,i,a;try{const r=s.querySelectorAll?s.querySelectorAll('script[type="application/ld+json"]'):[];for(const l of Array.from(r)){const d=l.textContent;if(!d)continue;const o=JSON.parse(d),c=((e=o==null?void 0:o.hiringOrganization)==null?void 0:e.name)||((t=o==null?void 0:o.hiringOrganization)==null?void 0:t.legalName)||((n=o==null?void 0:o.author)==null?void 0:n.name)||Array.isArray(o==null?void 0:o["@graph"])&&((a=(i=o["@graph"].find(p=>(p==null?void 0:p["@type"])==="JobPosting"))==null?void 0:i.hiringOrganization)==null?void 0:a.name);if(c&&typeof c=="string"&&c.trim().length>0)return c.trim()}}catch{}}function Sn(s=document){const e=t=>{var n;return s.querySelector?(n=s.querySelector(`meta[property="${t}"], meta[name="${t}"]`))==null?void 0:n.content:void 0};return{title:e("og:title")||e("twitter:title")||e("title")||void 0,company:e("og:site_name")||void 0,description:e("og:description")||e("description")||void 0}}function Tn(s=document,e=""){var i,a,r,l,d,o,c,p,m,u,f,y,h,x,g,b,v,w,k,S,C,A,L,M,N,z,P,H,E,I,D,Z,V,W,q,j,R,_,G,ce,re;const t={};if(!s||typeof s.querySelector!="function")return t;const n=(()=>{try{return new URL(e).hostname.toLowerCase()}catch{return typeof window<"u"?window.location.hostname.toLowerCase():""}})();if(n.includes("linkedin.com")&&(t.title=(a=(i=s.querySelector(".job-details-jobs-unified-top-card__job-title, .topcard__title"))==null?void 0:i.textContent)==null?void 0:a.trim(),t.company=(l=(r=s.querySelector(".job-details-jobs-unified-top-card__company-name a, .topcard__org-name-link"))==null?void 0:r.textContent)==null?void 0:l.trim(),t.location=(o=(d=s.querySelector(".job-details-jobs-unified-top-card__bullet, .topcard__flavor--bullet"))==null?void 0:d.textContent)==null?void 0:o.trim(),t.description=(p=(c=s.querySelector(".jobs-description__content, #job-details, .description__text"))==null?void 0:c.textContent)==null?void 0:p.trim()),n.includes("indeed.com")&&(t.title=(u=(m=s.querySelector('[data-testid="jobsearch-JobInfoHeader-title"], h1.jobsearch-JobInfoHeader-title, h1[class*="jobsearch-JobInfoHeader-title"]'))==null?void 0:m.textContent)==null?void 0:u.trim(),t.company=((y=(f=s.querySelector('[data-testid="inlineHeader-companyName"], [data-testid="inlineHeader-companyName"] a, [data-testid="company-name"], div[data-testid="jobsearch-CompanyInfoContainer"] a, .icl-u-lg-mr--sm, [class*="companyName"]'))==null?void 0:f.textContent)==null?void 0:y.trim())||wn(s)||"Unknown Company",t.location=(x=(h=s.querySelector('[data-testid="job-location"], [data-testid="inlineHeader-companyLocation"], .companyLocation'))==null?void 0:h.textContent)==null?void 0:x.trim(),t.salary=(b=(g=s.querySelector('[data-testid="attribute_snippet_testid"], #salaryInfoAndJobType, [class*="salary-snippet"]'))==null?void 0:g.textContent)==null?void 0:b.trim(),t.description=(w=(v=s.querySelector('#jobDescriptionText, [data-testid="jobDescriptionText"]'))==null?void 0:v.textContent)==null?void 0:w.trim()),(n.includes("greenhouse.io")||n.includes("boards.greenhouse.io"))&&(t.title=(S=(k=s.querySelector(".app-title, h1.heading"))==null?void 0:k.textContent)==null?void 0:S.trim(),t.company=(A=(C=s.querySelector(".company-name, .logo span"))==null?void 0:C.textContent)==null?void 0:A.trim(),t.location=(M=(L=s.querySelector(".location"))==null?void 0:L.textContent)==null?void 0:M.trim(),t.description=(z=(N=s.querySelector("#content, .job-post-content"))==null?void 0:N.textContent)==null?void 0:z.trim()),(n.includes("lever.co")||n.includes("jobs.lever.co"))&&(t.title=(H=(P=s.querySelector(".posting-headline h2"))==null?void 0:P.textContent)==null?void 0:H.trim(),t.company=((I=(E=s.querySelector(".posting-headline .posting-categories .sort-by-team"))==null?void 0:E.textContent)==null?void 0:I.trim())||((D=s.querySelector(".main-header-logo img"))==null?void 0:D.getAttribute("alt"))||void 0,t.location=(V=(Z=s.querySelector(".location, .posting-categories .sort-by-location"))==null?void 0:Z.textContent)==null?void 0:V.trim(),t.description=(q=(W=s.querySelector(".section-wrapper, .posting-page"))==null?void 0:W.textContent)==null?void 0:q.trim()),!t.title){const Y=['h1[class*="job" i]','h1[class*="title" i]','h1[class*="position" i]','h1[class*="role" i]','[class*="job-title" i]','[class*="position-title" i]',"h1",'h2[class*="job" i]','h2[class*="title" i]'];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=((j=U.textContent)==null?void 0:j.trim())||"";if($.length>3&&$.length<140&&!/^(home|careers|jobs|search|openings|login)$/i.test($)){t.title=$;break}}}}if(!t.company){const Y=['[class*="company-name" i]','[class*="companyName" i]','[class*="employer" i]','[class*="org-name" i]','[class*="organization" i]','[itemprop="hiringOrganization"]','[itemprop="name"]','[class*="sub-title" i]'];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=(R=U.textContent)==null?void 0:R.trim();if($&&$.length>1&&$.length<100){t.company=$;break}}}}if(!t.location){const Y=['[class*="location" i]','[class*="city" i]','[class*="workplace" i]','[itemprop="addressLocality"]','[class*="address" i]'];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=(_=U.textContent)==null?void 0:_.trim();if($&&$.length>1&&$.length<100){t.location=$;break}}}}if(!t.salary){const Y=['[class*="salary" i]','[class*="compensation" i]','[class*="stipend" i]','[class*="pay" i]','[class*="remuneration" i]'];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=(G=U.textContent)==null?void 0:G.trim();if($&&$.length>1&&$.length<80){t.salary=$;break}}}}if(!t.jobType){const Y=['[class*="job-type" i]','[class*="jobType" i]','[class*="employment-type" i]','[class*="work-type" i]'];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=(ce=U.textContent)==null?void 0:ce.trim();if($&&$.length>2&&$.length<40){t.jobType=$;break}}}}if(!t.description){const Y=['[class*="job-description" i]','[class*="jobDescription" i]','[class*="description" i]','[class*="posting-requirements" i]','[class*="job-details" i]',"article","main"];for(const ie of Y){const U=s.querySelector(ie);if(U){const $=(re=U.textContent)==null?void 0:re.replace(/\s+/g," ").trim();if($&&$.length>50){t.description=$.slice(0,3e3);break}}}}return t}function kn(s=document){const e=s.title||(typeof document<"u"?document.title:""),t=e.match(/^(.+?)\s+at\s+(.+?)(?:\s*[|\-–]|$)/i);if(t)return{title:t[1].trim(),company:t[2].trim()};const n=e.match(/^(.+?)\s*[-–]\s*(.+?)(?:\s*[|\-–]|$)/);return n?{title:n[1].trim(),company:n[2].trim()}:{}}function Ce(s,e){let t=typeof document<"u"?document:{},n=typeof window<"u"?window.location.href:"";if(typeof s=="string"?(n=s,e&&typeof e.querySelectorAll=="function"&&(t=e)):s&&typeof s.querySelectorAll=="function"&&(t=s),!n||typeof t.querySelectorAll!="function"||se(n))return null;const i=gn.some(y=>y.test(n)),a=Array.from(t.querySelectorAll("h1, h2, h3")).map(y=>y.textContent||"").join(" "),r=bn.some(y=>y.test(a)),l=vn(t),d=Sn(t),o=Tn(t,n),c=kn(t),p=!!(l!=null&&l.title);if(!i&&!r&&!p)return null;const m=/linkedin\.com\/jobs/i.test(n)||/indeed\.com\/(viewjob|rc\/clk)/i.test(n)||/unstop\.com\/(jobs|internships|competitions)/i.test(n)||/greenhouse\.io/i.test(n)||/lever\.co/i.test(n)||/workable\.com/i.test(n)||/ashbyhq\.com/i.test(n)||/smartrecruiters\.com/i.test(n);if(!p&&!m&&!fe(t,n))return null;const u={title:(l==null?void 0:l.title)||(o==null?void 0:o.title)||(d==null?void 0:d.title)||(c==null?void 0:c.title),company:(l==null?void 0:l.company)||(o==null?void 0:o.company)||(d==null?void 0:d.company)||(c==null?void 0:c.company),location:(l==null?void 0:l.location)||(o==null?void 0:o.location),salary:(l==null?void 0:l.salary)||(o==null?void 0:o.salary),jobType:(l==null?void 0:l.jobType)||(o==null?void 0:o.jobType),description:(l==null?void 0:l.description)||(o==null?void 0:o.description)||(d==null?void 0:d.description)};if(!u.title)return null;let f="LOW";return l!=null&&l.title?f="HIGH":i&&u.title&&u.company?f="MEDIUM":u.title&&(f="LOW"),{title:u.title,company:u.company||"Unknown Company",location:u.location,salary:u.salary,jobType:u.jobType,description:u.description,jobUrl:n,sourceWebsite:xn(n),confidence:f}}function An(s="",e="",t=""){const n=s.trim().toLowerCase().replace(/[-_]/g," "),i=e.toLowerCase();return n.includes("intern")||n.includes("stipend")?"INTERNSHIP":n.includes("full time")||n.includes("permanent")?"FULL_TIME":n.includes("part time")?"PART_TIME":n.includes("contract")?"CONTRACT":n.includes("freelance")?"FREELANCE":n.includes("temp")||n.includes("temporary")?"TEMPORARY":n.includes("graduate")||n.includes("fresher")?"GRADUATE_PROGRAM":n.includes("fellowship")||n.includes("scholarship")?"FELLOWSHIP":n.includes("competition")||n.includes("hackathon")||n.includes("challenge")||n.includes("quiz")?"COMPETITION":n.includes("talent")||n.includes("audition")||n.includes("casting")?"TALENT_OPPORTUNITY":i.includes("intern")?"INTERNSHIP":i.includes("hackathon")||i.includes("competition")||i.includes("quiz")||i.includes("challenge")?"COMPETITION":i.includes("fellowship")?"FELLOWSHIP":i.includes("graduate")||i.includes("fresher")?"GRADUATE_PROGRAM":i.includes("part time")?"PART_TIME":i.includes("contract")?"CONTRACT":i.includes("freelance")?"FREELANCE":n.length>0&&n!=="job"&&n!=="work from home"&&n!=="in office"&&n!=="hybrid"?"OTHER":"FULL_TIME"}function Cn(s=""){if(!s)return typeof window<"u"?window.location.href.split("?")[0]:"";try{const e=new URL(s),t=["utm_source","utm_medium","utm_campaign","utm_term","utm_content","ref","ref_id","source","shared_by","fbclid","gclid","trk"];for(const n of t)e.searchParams.delete(n);return e.toString()}catch{return s.trim()}}function Me(s,e){var $,ct,dt,pt,ut;const t=(s.title||"").trim()||"Untitled Job",n=(s.company||"").trim()||"Unknown Company",i=(s.jobUrl||"").trim()||(typeof window<"u"?window.location.href:""),a=Cn(i),r=(s.location||"").trim()||null,l=(s.salary||"").trim()||null,d=(s.description||"").trim()||null,o=(s.sourceWebsite||"").trim()||(typeof window<"u"&&(($=window.location)!=null&&$.hostname)?window.location.hostname.replace(/^www\./i,""):"Web"),c=An(s.jobType||"",t,d||""),p=[];let m=0;t!=="Untitled Job"&&(m+=30),n!=="Unknown Company"&&(m+=25),a&&(m+=25),r?m+=10:p.push("location"),l?m+=5:p.push("salary"),d&&d.length>20?m+=5:p.push("description");const u=e||{preferredRoles:[],skills:[],preferredLocations:[],workStyle:"ANY"},f=It(t,u.preferredRoles,.3),y=f.score>=.6,h=f.level==="NO_MATCH"||f.score===0,x=((ct=u.preferredRoles)==null?void 0:ct.length)===0?"UNSPECIFIED":y?"MATCH":"MISMATCH",g=y?"Role match":"Role mismatch",b=qt(t,d||void 0,s.jobType,u,.25),v=b.isHardMismatch||b.status==="MISMATCH",w=b.status,k=b.status==="MATCH"?"Experience match":b.status==="MISMATCH"?`Experience mismatch: Required ${b.requiredText}, Profile: ${b.profileText}`:"Experience standard/flexible",S=jt(t,d||void 0,u,.2),C=S.isHardMismatch&&S.status==="MISMATCH",A=S.status,L=S.status==="MATCH"?"Education match":S.status==="MISMATCH"?`Education mismatch: Requires ${S.requiredText}`:"Education: Not specified",M=Nt(t,d||void 0,u,.2),N=M.matchedSkills,z=M.missingSkills,P=M.status,H=M.status==="MATCH"?"Skills match":"Missing key skills",E=zt(r||void 0,d||void 0,u,.05),I=!r||!((dt=u.preferredLocations)!=null&&dt.length)?"UNSPECIFIED":E.score>=.7?"MATCH":"MISMATCH",D=E.reason;let Z=Math.round(f.weightedScore+b.weightedScore+S.weightedScore+M.weightedScore+E.weightedScore),V=Math.min(100,Math.max(0,Z)),W="GOOD_MATCH",q="GOOD MATCH",j="Worth applying",R="🟢";v&&b.isHardMismatch?(V=Math.min(42,Math.max(25,Math.round(Z*.46))),W="LOW_MATCH",q="LOW MATCH",j="Experience requirement does not match your profile.",R="🔴"):h&&((pt=u.preferredRoles)==null?void 0:pt.length)>0?(V=Math.min(44,Math.max(20,Math.round(Z*.42))),W="LOW_MATCH",q="LOW MATCH",j="Role does not align with your target preferences",R="🔴"):C?(V=Math.min(45,Math.max(25,Math.round(Z*.45))),W="LOW_MATCH",q="LOW MATCH",j="Education requirement differs from your profile.",R="🔴"):V>=85?(W="STRONG_MATCH",q="STRONG MATCH",j="Recommended to apply",R="🟢"):V>=70?(W="GOOD_MATCH",q="GOOD MATCH",j="Worth applying",R="🟢"):V>=50?(W="MODERATE_MATCH",q="MODERATE MATCH",j="Review before applying",R="🟡"):(W="LOW_MATCH",q="LOW MATCH",j="Low priority",R="🔴");const _=[],G=[];x==="MATCH"?_.push("Role match"):x==="MISMATCH"&&G.push("Role mismatch"),A==="MATCH"?_.push("Education match"):A==="MISMATCH"&&G.push(L),w==="MATCH"?_.push("Experience match"):w==="MISMATCH"&&G.push(k),P==="MATCH"&&N.length>0&&_.push("Skills match"),z.length>0&&G.push(`Missing: ${z.slice(0,2).join(" • ")}`),I==="MATCH"&&_.push("Location match"),_.length===0&&!v&&!h&&(_.push("Skills match"),_.push("Experience match"));let ce=90;const re=[],Y=[];return re.push("Resume available"),re.push("Profile complete"),v?Y.push("Experience level differs"):re.push("Experience suitable"),z.length>2&&(ce-=10,Y.push(`Missing: ${z[0]}`)),m<70&&Y.push("Resume could be tailored"),ce=Math.max(70,Math.min(100,ce)),{normalized:{title:t,company:n,jobUrl:a,sourceWebsite:o,location:r,salary:l,description:d,jobType:c,status:"SAVED"},canSave:!!a,completeness:Math.min(100,m),missingOptionalFields:p,matchScore:V,recommendation:W,recommendationLabel:q,recommendationSubtitle:j,recommendationIcon:R,matchedFactors:_,unmatchedFactors:G,matchedSkills:N,missingSkills:z,roleMatchStatus:x,roleMatchReason:g,roleRequiredText:t,roleProfileText:(ut=u.preferredRoles)!=null&&ut.length?u.preferredRoles.join(", "):"Not specified",experienceMatchStatus:w,experienceMatchReason:k,experienceRequiredText:b.requiredText,experienceProfileText:b.profileText,educationMatchStatus:A,educationMatchReason:L,educationRequiredText:S.requiredText,educationProfileText:u.degree?`${u.degree}${u.specialization?` (${u.specialization})`:""}`:"Not specified",skillsMatchStatus:P,skillsMatchReason:H,locationMatchStatus:I,locationMatchReason:D,readinessScore:ce,readinessFactors:re,readinessIssues:Y}}const rt={get:()=>et.get("/api/profile"),update:s=>et.put("/api/profile",s)},Le="talvyn-panel",tt="talvyn-host",ye="talvyn_panel_position";function Ue(){let s=typeof document<"u"?document.getElementById(tt):null;if(!s){s=document.createElement("div"),s.id=tt,s.setAttribute("data-talvyn-host","true"),Object.assign(s.style,{position:"fixed",top:"0",left:"0",width:"0",height:"0",zIndex:"2147483647",pointerEvents:"none"}),typeof document<"u"&&(document.body?document.body.appendChild(s):document.documentElement&&document.documentElement.appendChild(s));const t=s.attachShadow?s.attachShadow({mode:"open"}):s;if(typeof document<"u"&&t){const n=document.createElement("style");n.textContent=`
        :host {
          all: initial;
        }
        *, *::before, *::after {
          box-sizing: border-box;
        }
        button, input, select, textarea {
          font-family: inherit;
        }
      `,t.appendChild(n)}}const e=s.shadowRoot||s;return{host:s,shadow:e}}function he(s){if(typeof document>"u")return null;const e=document.getElementById(tt);if(e&&e.shadowRoot){const t=e.shadowRoot.getElementById(s);if(t)return t}return document.getElementById(s)}let nt=null,it=null,at=null,ue=null,ke=null,O=!1;function Je(s,e,t,n,i){var o,c;B(),nt=e,it=t,at=(i==null?void 0:i.onProfileUpdated)||null,ue=s,ke=i;const a=document.createElement("div");a.id=Le,a.setAttribute("data-talvyn","true"),a.style.pointerEvents="auto";const r=(i==null?void 0:i.theme)==="dark"||(i==null?void 0:i.theme)!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;O=!!r,a.innerHTML=$n(s,i,r),Ht(a,r);const{shadow:l}=Ue();l.appendChild(a);const d=a.querySelector("#talvyn-panel-header");d&&Ee(a,d,ye),xe(a,s,i),(o=a.querySelector("#talvyn-dismiss-btn"))==null||o.addEventListener("click",()=>{n(),B()}),(c=a.querySelector("#talvyn-collapse-btn"))==null||c.addEventListener("click",()=>{Ln(a)})}function Ee(s,e,t=ye){if(!s||!e||typeof e.addEventListener!="function")return;e.style.cursor="grab",e.style.userSelect="none",e.style.touchAction="none";let n=!1,i=0,a=0,r=0,l=0,d=!1,o="";const c=y=>{if(y.target&&y.target.closest('button, a, input, select, textarea, [role="button"]')||"button"in y&&y.button!==0)return;n=!0,d=!1,i=y.clientX,a=y.clientY;const h=s.getBoundingClientRect();if(r=h.left,l=h.top,s.style.bottom="auto",s.style.right="auto",s.style.left=`${r}px`,s.style.top=`${l}px`,"setPointerCapture"in e&&"pointerId"in y)try{e.setPointerCapture(y.pointerId)}catch{}y.preventDefault&&y.preventDefault()},p=y=>{if(!n)return;const h=y.clientX-i,x=y.clientY-a;if(!d&&Math.hypot(h,x)>3&&(d=!0,e.style.cursor="grabbing",typeof document<"u"&&document.body&&(o=document.body.style.userSelect,document.body.style.userSelect="none")),!d)return;let g=r+h,b=l+x;const v=s.offsetWidth||320,w=s.offsetHeight||420,k=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,S=typeof window<"u"&&window.innerHeight?window.innerHeight:800,C=Math.max(0,k-v),A=Math.max(0,S-w);g=Math.max(0,Math.min(g,C)),b=Math.max(0,Math.min(b,A)),s.style.left=`${g}px`,s.style.top=`${b}px`},m=y=>{if(n){if(n=!1,e.style.cursor="grab",typeof document<"u"&&document.body&&(document.body.style.userSelect=o),y&&"releasePointerCapture"in e&&"pointerId"in y)try{e.releasePointerCapture(y.pointerId)}catch{}if(d)try{const h=s.getBoundingClientRect();localStorage.setItem(t,JSON.stringify({x:h.left,y:h.top}))}catch{}}};e.addEventListener("pointerdown",c),e.addEventListener("pointermove",p),e.addEventListener("pointerup",m),e.addEventListener("pointercancel",m),e.addEventListener("mousedown",c);const u=y=>p(y),f=y=>{m(y),typeof document<"u"&&document.removeEventListener&&(document.removeEventListener("mousemove",u),document.removeEventListener("mouseup",f))};e.addEventListener("mousedown",()=>{typeof document<"u"&&document.addEventListener&&(document.addEventListener("mousemove",u),document.addEventListener("mouseup",f))})}function xe(s,e,t){var i,a,r,l,d;const n=s.querySelector("#talvyn-save-btn");n==null||n.addEventListener("click",()=>{Rn(s,e||ue,t||ke)}),(i=s.querySelector("#talvyn-back-to-jobs-btn"))==null||i.addEventListener("click",()=>{t!=null&&t.onBackToListing&&t.onBackToListing()}),(a=s.querySelector("#talvyn-profile-btn"))==null||a.addEventListener("click",()=>{Ot(s,e||ue,t||ke)}),(r=s.querySelector("#talvyn-apply-btn"))==null||r.addEventListener("click",()=>{Mn(s,e||ue,t||ke)}),(l=s.querySelector("#talvyn-dashboard-btn"))==null||l.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/dashboard`,"_blank")}),(d=s.querySelector("#talvyn-open-job-btn"))==null||d.addEventListener("click",()=>{const o=(e==null?void 0:e.jobUrl)||(ue==null?void 0:ue.jobUrl);o&&window.open(o,"_blank")})}const Re="talvyn-capsule";function Ln(s){const e=s.querySelector("#talvyn-panel-body"),t=s.querySelector("#talvyn-collapse-btn"),{shadow:n}=Ue();let i=he(Re);if(!i){i=document.createElement("div"),i.id=Re,i.setAttribute("data-talvyn-capsule","true"),i.style.display="none",i.style.pointerEvents="auto",i.innerHTML=`
      <div id="talvyn-capsule-handle" style="
        display:flex;align-items:center;gap:7px;padding:8px 14px;
        background:linear-gradient(135deg, #4f46e5, #6366f1);
        color:white;border-radius:999px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
        font-size:12px;font-weight:800;letter-spacing:0.5px;
        box-shadow:0 6px 20px rgba(79,70,229,0.4);cursor:pointer;
        user-select:none;border:1.5px solid rgba(255,255,255,0.25);
        transition:transform 0.15s ease;
      " title="Click to open Talvyn Job Intelligence">
        <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#10b981;"></span>
        <span>TALVYN</span>
      </div>
    `,Object.assign(i.style,{position:"fixed",zIndex:"2147483647",userSelect:"none"}),n.appendChild(i);const a=i.querySelector("#talvyn-capsule-handle");a&&Ee(i,a,"talvyn_capsule_position"),i.addEventListener("click",()=>{bt(s)})}if(s.style.display!=="none"&&(!e||e.style.display!=="none")){const a=s.getBoundingClientRect();s.style.display="none",e&&(e.style.display="none"),t&&(t.textContent="+",t.title="Expand"),i.style.display="flex",i.style.left=`${Math.max(10,a.left)}px`,i.style.top=`${Math.max(10,a.top)}px`}else bt(s)}function bt(s){const e=he(Re);e&&(e.style.display="none"),s.style.display="flex";const t=s.querySelector("#talvyn-panel-body");t&&(t.style.display="block");const n=s.querySelector("#talvyn-collapse-btn");n&&(n.textContent="−",n.title="Minimize")}function En(s,e,t){var u,f,y,h;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.normalization,a=O?"#334155":"#e2e8f0",r=O?"#f8fafc":"#0f172a",l=O?"#cbd5e1":"#475569",d=O?"#1e293b":"#f8fafc",o=O?"#0f172a":"#ffffff",c=e.experience||(i==null?void 0:i.experienceRequiredText)||"",p=e.education||(i==null?void 0:i.educationRequiredText)||"";n.innerHTML=`
    <div id="talvyn-confirm-save-view" style="font-size:12px;color:${r};">
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <div style="font-weight:800;font-size:12px;letter-spacing:0.4px;color:#4f46e5;text-transform:uppercase;">
            CONFIRM JOB DETAILS
          </div>
          <div style="font-size:10.5px;color:${l};">
            Review and adjust details before saving to your Tracker.
          </div>
        </div>
        <button id="talvyn-save-cancel-x" style="background:none;border:none;color:${l};font-size:15px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:380px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- Editable Job Fields -->
        <div style="background:${d};border:1px solid ${a};border-radius:8px;padding:10px;display:flex;flex-direction:column;gap:8px;">
          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Job Title
            </label>
            <input type="text" id="talvyn-edit-title" value="${T(e.title||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Company
            </label>
            <input type="text" id="talvyn-edit-company" value="${T(e.company||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Location
            </label>
            <input type="text" id="talvyn-edit-location" value="${T(e.location||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " placeholder="e.g. Bangalore, Remote" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Salary / Stipend
            </label>
            <input type="text" id="talvyn-edit-salary" value="${T(e.salary||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " placeholder="e.g. ₹8–12 LPA, $120,000" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Job Type
            </label>
            <input type="text" id="talvyn-edit-jobType" value="${T(e.jobType?_t(e.jobType):"Full Time")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " placeholder="Full Time, Internship, Contract" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Experience
            </label>
            <input type="text" id="talvyn-edit-experience" value="${T(c!=="Not specified"?c:"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " placeholder="e.g. 2–4 years, Fresher" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Education
            </label>
            <input type="text" id="talvyn-edit-education" value="${T(p!=="Not specified"?p:"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " placeholder="e.g. B.Tech / equivalent, Bachelor's" />
          </div>

          <div>
            <label style="display:block;font-size:10.5px;font-weight:700;color:${l};margin-bottom:3px;text-transform:uppercase;">
              Job URL
            </label>
            <input type="text" id="talvyn-edit-url" value="${T(e.jobUrl||"")}" style="
              width:100%;padding:6px 8px;font-size:12px;border:1px solid ${a};border-radius:6px;
              background:${o};color:${r};outline:none;
            " />
          </div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-cancel-save-btn" style="
          flex:1;padding:8px 12px;background:transparent;color:${l};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
        <button id="talvyn-confirm-save-btn" style="
          flex:1.5;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Confirm & Save
        </button>
      </div>
    </div>
  `;const m=()=>{n.innerHTML=ve(e,t,O),xe(s,e,t)};(u=n.querySelector("#talvyn-save-cancel-x"))==null||u.addEventListener("click",m),(f=n.querySelector("#talvyn-cancel-save-btn"))==null||f.addEventListener("click",m),(y=n.querySelector("#talvyn-cancel-review-btn"))==null||y.addEventListener("click",m),(h=n.querySelector("#talvyn-confirm-save-btn"))==null||h.addEventListener("click",async()=>{var L,M,N,z,P,H,E,I;const x=((L=n.querySelector("#talvyn-edit-title"))==null?void 0:L.value.trim())||e.title,g=((M=n.querySelector("#talvyn-edit-company"))==null?void 0:M.value.trim())||e.company,b=((N=n.querySelector("#talvyn-edit-location"))==null?void 0:N.value.trim())||e.location,v=((z=n.querySelector("#talvyn-edit-salary"))==null?void 0:z.value.trim())||e.salary,w=((P=n.querySelector("#talvyn-edit-jobType"))==null?void 0:P.value.trim())||e.jobType,k=((H=n.querySelector("#talvyn-edit-experience"))==null?void 0:H.value.trim())||c,S=((E=n.querySelector("#talvyn-edit-education"))==null?void 0:E.value.trim())||p,C=((I=n.querySelector("#talvyn-edit-url"))==null?void 0:I.value.trim())||e.jobUrl,A={...e,title:x,company:g,location:b||void 0,salary:v||void 0,jobType:w||void 0,experience:k||void 0,education:S||void 0,jobUrl:C};nt&&await nt(A,t==null?void 0:t.userProfile)})}const Rn=En;function Mn(s,e,t){var b,v,w,k,S;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.userProfile,a=O?"#334155":"#e2e8f0",r=O?"#f8fafc":"#0f172a",l=O?"#cbd5e1":"#475569",d=O?"#1e293b":"#f8fafc",o=(i==null?void 0:i.legalFullName)||(i==null?void 0:i.name)||`${(i==null?void 0:i.givenName)||""} ${(i==null?void 0:i.familyName)||""}`.trim()||"Candidate Name",c=(i==null?void 0:i.email)||"email@example.com",p=(i==null?void 0:i.phoneNumber)||(i==null?void 0:i.phone)||"— Not provided",m=((b=i==null?void 0:i.preferredLocations)==null?void 0:b[0])||(i==null?void 0:i.location)||(i==null?void 0:i.city)||"— Not provided",u=(i==null?void 0:i.linkedInUrl)||(i==null?void 0:i.linkedinUrl)||"— Not provided",f=(i==null?void 0:i.githubUrl)||"— Not provided",y=(t==null?void 0:t.resumeName)||"Default Resume",h=(i==null?void 0:i.workAuthorization)||"Requires Review",x=(i==null?void 0:i.expectedSalary)||"Requires Review";n.innerHTML=`
    <div id="talvyn-apply-review-view" style="font-size:12px;color:${r};">
      <!-- Header -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CONTROLLED APPLICATION REVIEW
          </span>
          <div style="font-size:10.5px;color:${l};margin-top:1px;">
            Talvyn will autofill safe candidate fields and verify sensitive items.
          </div>
        </div>
        <button id="talvyn-apply-review-cancel-x" style="background:none;border:none;color:${l};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- SAFE FIELDS SECTION -->
        <div style="background:${d};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#059669;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>✓</span> Safe Fields (Autofilled Directly)
            </span>
          </div>
          <div style="font-size:11px;color:${l};display:flex;flex-direction:column;gap:3px;">
            <div><strong>Name:</strong> ${T(o)}</div>
            <div><strong>Email:</strong> ${T(c)}</div>
            <div><strong>Phone:</strong> ${T(p)}</div>
            <div><strong>Location:</strong> ${T(m)}</div>
            <div><strong>LinkedIn:</strong> ${T(u)}</div>
            <div><strong>GitHub:</strong> ${T(f)}</div>
            <div><strong>Resume:</strong> ${T(y)}</div>
          </div>
        </div>

        <!-- SENSITIVE FIELDS SECTION -->
        <div style="background:${O?"#451a03":"#fffbeb"};border:1px solid ${O?"#b45309":"#fde68a"};border-radius:8px;padding:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
            <span style="font-weight:700;font-size:11px;color:#d97706;text-transform:uppercase;display:flex;align-items:center;gap:4px;">
              <span>🛡️</span> Sensitive Fields (Explicit User Review)
            </span>
          </div>
          <div style="font-size:10.5px;color:${O?"#fef3c7":"#92400e"};line-height:1.4;display:flex;flex-direction:column;gap:4px;">
            <div>• <strong>Work Authorization / Visa:</strong> ${T(h)}</div>
            <div>• <strong>Expected Salary / CTC:</strong> ${T(x)}</div>
            <div>• <strong>Disability & Veteran Status:</strong> Prompt before fill</div>
            <div>• <strong>Legal Declarations / Sponsorship:</strong> Prompt before fill</div>
          </div>
        </div>
      </div>

      <!-- Actions -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-review-continue-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          Review & Continue ⚡
        </button>
        <button id="talvyn-review-edit-profile-btn" style="
          padding:8px 12px;background:transparent;color:#4f46e5;
          border:1px solid #c7d2fe;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          👤 Edit Details
        </button>
        <button id="talvyn-cancel-apply-review-btn" style="
          padding:8px 10px;background:transparent;color:${l};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `;const g=()=>{n.innerHTML=ve(e,t,O),xe(s,e,t)};(v=n.querySelector("#talvyn-apply-review-cancel-x"))==null||v.addEventListener("click",g),(w=n.querySelector("#talvyn-cancel-apply-review-btn"))==null||w.addEventListener("click",g),(k=n.querySelector("#talvyn-review-edit-profile-btn"))==null||k.addEventListener("click",()=>{Ot(s,e,t)}),(S=n.querySelector("#talvyn-review-continue-btn"))==null||S.addEventListener("click",()=>{n.innerHTML=ve(e,t,O),xe(s,e,t),it&&it()})}function Ot(s,e,t){var C,A,L,M,N,z;const n=s.querySelector("#talvyn-panel-body");if(!n)return;const i=t==null?void 0:t.userProfile,a=O?"#334155":"#e2e8f0",r=O?"#f8fafc":"#0f172a",l=O?"#cbd5e1":"#475569",d=O?"#1e293b":"#f8fafc",o=O?"#0f172a":"#ffffff",c=(i==null?void 0:i.givenName)||((C=i==null?void 0:i.name)==null?void 0:C.split(" ")[0])||"",p=(i==null?void 0:i.familyName)||((A=i==null?void 0:i.name)==null?void 0:A.split(" ").slice(1).join(" "))||"",m=(i==null?void 0:i.email)||"",u=(i==null?void 0:i.phoneNumber)||(i==null?void 0:i.phone)||"",f=((L=i==null?void 0:i.preferredLocations)==null?void 0:L[0])||(i==null?void 0:i.location)||(i==null?void 0:i.city)||"",y=((i==null?void 0:i.preferredRoles)||[]).join(", "),h=(i==null?void 0:i.experienceYears)!==void 0&&(i==null?void 0:i.experienceYears)!==null?String(i==null?void 0:i.experienceYears):"0",x=(i==null?void 0:i.degree)||(i==null?void 0:i.education)||"",g=((i==null?void 0:i.skills)||[]).join(", "),b=(i==null?void 0:i.linkedInUrl)||(i==null?void 0:i.linkedinUrl)||"",v=(i==null?void 0:i.githubUrl)||"",w=(i==null?void 0:i.workAuthorization)||"",k=(i==null?void 0:i.expectedSalary)||"";n.innerHTML=`
    <div id="talvyn-profile-view" style="font-size:12px;color:${r};">
      <!-- Top Title -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid ${a};">
        <div>
          <span style="font-weight:700;font-size:12px;letter-spacing:0.3px;color:#4f46e5;text-transform:uppercase;">
            CANDIDATE PROFILE
          </span>
          <div style="font-size:10.5px;color:${l};margin-top:1px;">
            Edit profile data to update deterministic matching
          </div>
        </div>
        <button id="talvyn-profile-cancel-x" style="background:none;border:none;color:${l};font-size:14px;cursor:pointer;padding:0 3px;">✕</button>
      </div>

      <div style="max-height:360px;overflow-y:auto;padding-right:2px;display:flex;flex-direction:column;gap:8px;">
        <!-- CAREER TARGETS -->
        <div style="background:${d};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            🎯 Career Targeting
          </div>
          ${ne("Target Roles","p-roles",y,o,a,r)}
          ${ne("Exp (Years)","p-exp",h,o,a,r)}
          ${ne("Degree","p-degree",x,o,a,r)}
          ${ne("Skills","p-skills",g,o,a,r)}
        </div>

        <!-- PERSONAL & CONTACT -->
        <div style="background:${d};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            👤 Contact & Links
          </div>
          ${ne("Given Name","p-given",c,o,a,r)}
          ${ne("Family Name","p-family",p,o,a,r)}
          ${ne("Email","p-email",m,o,a,r)}
          ${ne("Phone","p-phone",u,o,a,r)}
          ${ne("Location","p-loc",f,o,a,r)}
          ${ne("LinkedIn","p-linkedin",b,o,a,r)}
          ${ne("GitHub","p-github",v,o,a,r)}
        </div>

        <!-- PREFERENCES & SENSITIVE -->
        <div style="background:${d};border:1px solid ${a};border-radius:8px;padding:8px;">
          <div style="font-weight:700;font-size:11px;color:${l};margin-bottom:6px;text-transform:uppercase;">
            🛡️ Preferences & Authorization
          </div>
          ${ne("Work Auth","p-auth",w,o,a,r)}
          ${ne("Exp Salary","p-salary",k,o,a,r)}
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display:flex;gap:6px;margin-top:10px;">
        <button id="talvyn-save-profile-btn" style="
          flex:1;padding:8px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
          color:white;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;
          box-shadow:0 2px 6px rgba(79,70,229,0.25);
        ">
          💾 Save Profile & Re-Run Matching
        </button>
        <button id="talvyn-cancel-profile-btn" style="
          padding:8px 12px;background:transparent;color:${l};
          border:1px solid ${a};border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;
        ">
          Cancel
        </button>
      </div>
    </div>
  `,n.querySelectorAll(".talvyn-edit-toggle").forEach(P=>{P.addEventListener("click",H=>{const E=H.currentTarget.getAttribute("data-field");if(!E)return;const I=n.querySelector(`#disp-${E}`),D=n.querySelector(`#inp-${E}`),Z=H.currentTarget;D&&I&&(D.style.display==="none"?(D.style.display="block",I.style.display="none",D.focus(),Z.textContent="Done"):(D.style.display="none",I.style.display="block",I.textContent=D.value.trim()||"—",Z.textContent="Edit"))})});const S=()=>{n.innerHTML=ve(e,t,O),xe(s,e,t)};(M=n.querySelector("#talvyn-profile-cancel-x"))==null||M.addEventListener("click",S),(N=n.querySelector("#talvyn-cancel-profile-btn"))==null||N.addEventListener("click",S),(z=n.querySelector("#talvyn-save-profile-btn"))==null||z.addEventListener("click",async P=>{const H=P.currentTarget;H.disabled=!0,H.textContent="Saving Profile...";const E=(G,ce)=>{const re=n.querySelector(`#inp-${G}`);return re?re.value.trim():ce},I=E("p-exp",h),D=parseInt(I,10),Z=isNaN(D)?0:D,V=E("p-roles",y),W=V?V.split(",").map(G=>G.trim()).filter(Boolean):[],q=E("p-skills",g),j=q?q.split(",").map(G=>G.trim()).filter(Boolean):[],R={...i||{},id:(i==null?void 0:i.id)||"user",userId:(i==null?void 0:i.userId)||"user",givenName:E("p-given",c),familyName:E("p-family",p),name:`${E("p-given",c)} ${E("p-family",p)}`.trim(),email:E("p-email",m),phoneNumber:E("p-phone",u),location:E("p-loc",f),preferredLocations:[E("p-loc",f)].filter(Boolean),preferredRoles:W,experienceYears:Z,degree:E("p-degree",x),skills:j,linkedInUrl:E("p-linkedin",b),githubUrl:E("p-github",v),workAuthorization:E("p-auth",w),expectedSalary:E("p-salary",k),preferredJobTypes:(i==null?void 0:i.preferredJobTypes)||[],otherLinks:(i==null?void 0:i.otherLinks)||[],workStyle:(i==null?void 0:i.workStyle)||"ANY",onboardingCompleted:!0};try{await rt.update({givenName:R.givenName,familyName:R.familyName,email:R.email,phone:R.phoneNumber,preferredRoles:R.preferredRoles,experienceYears:R.experienceYears,degree:R.degree,skills:R.skills,preferredLocations:R.preferredLocations,linkedinUrl:R.linkedInUrl,githubUrl:R.githubUrl,workAuthorization:R.workAuthorization,expectedSalary:R.expectedSalary})}catch(G){console.warn("[Talvyn] Profile update error:",G)}const _=Me(e,R);if(t&&(t.userProfile=R,t.normalization=_),ke=t,at)try{await at(R)}catch{}n.innerHTML=ve(e,t,O),xe(s,e,t)})}function ne(s,e,t,n,i,a){const r=t.trim()?t:"—";return`
    <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:4px;font-size:11px;">
      <span style="color:#64748b;font-weight:500;min-width:65px;flex-shrink:0;">${T(s)}:</span>
      <div style="flex:1;min-width:0;">
        <span id="disp-${e}" style="display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600;">
          ${T(r)}
        </span>
        <input id="inp-${e}" value="${T(t)}" style="
          display:none;width:100%;padding:2px 5px;font-size:11px;border:1px solid #4f46e5;
          border-radius:4px;background:${n};color:${a};box-sizing:border-box;
        " />
      </div>
      <button class="talvyn-edit-toggle" data-field="${e}" style="
        background:none;border:1px solid ${i};border-radius:4px;padding:1px 5px;
        font-size:10px;font-weight:600;color:#4f46e5;cursor:pointer;flex-shrink:0;
      ">Edit</button>
    </div>
  `}function $n(s,e,t=!1){const n=t?"#334155":"#e2e8f0",i=t?"#f8fafc":"#0f172a",a=t?"#94a3b8":"#64748b";return`
    <div id="talvyn-panel-container">
      <!-- Header (Draggable Handle) -->
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${n};
        cursor:grab;user-select:none;
      " title="Drag to move panel">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${i};">Talvyn</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${(e==null?void 0:e.isConnected)!==!1?`
          <span style="
            font-size:10.5px;font-weight:700;color:#059669;background:${t?"#064e3b":"#ecfdf5"};
            padding:2px 7px;border-radius:999px;display:inline-flex;align-items:center;gap:3px;
          ">
            <span style="width:5px;height:5px;border-radius:50%;background:#10b981;display:inline-block;"></span>
            ● Connected
          </span>
          `:`
          <span style="
            font-size:10.5px;font-weight:700;color:${t?"#94a3b8":"#64748b"};background:${t?"#1e293b":"#f1f5f9"};
            padding:2px 7px;border-radius:999px;display:inline-flex;align-items:center;gap:3px;
          ">
            <span style="width:5px;height:5px;border-radius:50%;background:#94a3b8;display:inline-block;"></span>
            Guest
          </span>
          `}
          <button id="talvyn-profile-btn" style="
            background:none;border:1px solid ${n};border-radius:6px;
            padding:2px 6px;cursor:pointer;color:${i};font-size:11px;font-weight:600;
          " title="Candidate Profile">👤 Profile</button>
          <button id="talvyn-collapse-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:15px;
            font-weight:700;line-height:1;padding:0 3px;
          " title="Minimize">−</button>
          <button id="talvyn-dismiss-btn" style="
            background:none;border:none;cursor:pointer;color:${a};font-size:16px;
            line-height:1;padding:0 2px;
          " title="Close">×</button>
        </div>
      </div>

      <div id="talvyn-panel-body">
        ${ve(s,e,t)}
      </div>
    </div>
  `}function In(s,e){var m,u;const t=s.experience||(e==null?void 0:e.experienceRequiredText)||"— Not specified",n=s.education||(e==null?void 0:e.educationRequiredText)||"— Not specified",i=s.location||"— Not specified",a=s.salary||"— Not specified",r=s.jobType?_t(s.jobType):"— Not specified";let l="— Not specified";const d=s.description||"";if(d.trim()){const f=d.replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim();if(f.length>0){const y=f.split(new RegExp("(?<=[.!?])\\s+")).filter(h=>h.trim().length>15);y.length>0?(l=y.slice(0,2).join(" "),l.length>280&&(l=l.substring(0,280)+"...")):l=f.length>200?f.substring(0,200)+"...":f}}let o=[];if(s.description){const f=s.description,y=f.match(/(?:responsibilities|duties|what you will do|what you'll do|your role)[:\s]+([\s\S]*?)(?:requirements|qualifications|skills|who you are|benefits|$)/i),x=(y?y[1]:f).split(/\n|<br\s*\/?>|<li>/i).map(g=>g.replace(/<[^>]+>/g,"").trim()).filter(g=>g.startsWith("•")||g.startsWith("-")||g.startsWith("*")||/^(design|develop|build|collaborate|lead|manage|maintain|implement|create|deliver|support|coordinate|review|test)\b/i.test(g)).map(g=>g.replace(/^[•\-*]\s*/,"").trim()).filter(g=>g.length>10&&g.length<200);x.length>0&&(o=x.slice(0,4))}o.length===0&&(o=["— Not specified"]);let c=[];if(s.description){const f=s.description,y=f.match(/(?:requirements|qualifications|what we are looking for|what we're looking for|who you are|must have|eligibility)[:\s]+([\s\S]*?)(?:responsibilities|duties|benefits|about us|$)/i),x=(y?y[1]:f).split(/\n|<br\s*\/?>|<li>/i).map(g=>g.replace(/<[^>]+>/g,"").trim()).filter(g=>g.startsWith("•")||g.startsWith("-")||g.startsWith("*")||/^(bachelor|master|degree|\d+\+?\s*years|experience|proficiency|strong|knowledge|familiarity)\b/i.test(g)).map(g=>g.replace(/^[•\-*]\s*/,"").trim()).filter(g=>g.length>10&&g.length<200);x.length>0&&(c=x.slice(0,4))}c.length===0&&((m=e==null?void 0:e.missingSkills)!=null&&m.length||(u=e==null?void 0:e.matchedSkills)!=null&&u.length)&&(c=[t!=="— Not specified"?`Experience: ${t}`:"",n!=="— Not specified"?`Education: ${n}`:"",...((e==null?void 0:e.missingSkills)||[]).slice(0,2).map(f=>`Proficiency in ${f}`)].filter(Boolean)),c.length===0&&(c=["— Not specified"]);let p="Moderate alignment with partial skill and requirement overlap.";return(e==null?void 0:e.experienceMatchStatus)==="MISMATCH"?p=`Experience mismatch: Requires ${e.experienceRequiredText||"2–4 years"}, but candidate is ${e.experienceProfileText||"Fresher"}.`:(e==null?void 0:e.roleMatchStatus)==="MISMATCH"?p=`Role mismatch: Requires ${e.roleRequiredText||s.title}, which differs from target role.`:(e==null?void 0:e.educationMatchStatus)==="MISMATCH"?p=`Education mismatch: Requires ${e.educationRequiredText}, which does not match candidate education.`:(e==null?void 0:e.skillsMatchStatus)==="MISMATCH"?p=`Skills gap: Missing critical skills (${(e.missingSkills||[]).slice(0,3).join(", ")}).`:((e==null?void 0:e.matchScore)??0)>=85?p="Strong profile alignment across role, experience, education, and skills.":((e==null?void 0:e.matchScore)??0)>=70&&(p="Good profile match with suitable experience and relevant skills."),{overview:{title:s.title||"— Not specified",company:s.company||"— Not specified",location:i,jobType:r,salary:a,experience:t,education:n},descriptionSummary:l,responsibilities:o,requirements:c,reason:p}}function ve(s,e,t=!1){var z,P,H,E;const n=e==null?void 0:e.normalization,i=(n==null?void 0:n.matchScore)??82,a=(n==null?void 0:n.recommendationLabel)??"GOOD MATCH",r=(n==null?void 0:n.recommendationSubtitle)??"Worth applying",l=(n==null?void 0:n.recommendationIcon)??"🟢",d=(z=n==null?void 0:n.matchedSkills)!=null&&z.length?n.matchedSkills:[],o=(P=n==null?void 0:n.missingSkills)!=null&&P.length?n.missingSkills:[],c=(n==null?void 0:n.readinessScore)??90,p=(H=n==null?void 0:n.readinessFactors)!=null&&H.length?n.readinessFactors:["Resume available","Profile complete","Experience suitable"],m=(E=n==null?void 0:n.readinessIssues)!=null&&E.length?n.readinessIssues:[],u=In(s,n),f=t?"#1e293b":"#f8fafc",y=t?"#334155":"#e2e8f0",h=t?"#f8fafc":"#0f172a",x=t?"#cbd5e1":"#475569",g=t?"#94a3b8":"#64748b";let b="#059669";i<50?b="#dc2626":i<70?b="#d97706":i<85&&(b="#2563eb");const v=(n==null?void 0:n.roleMatchStatus)==="MATCH",w=(n==null?void 0:n.roleMatchStatus)==="MISMATCH",k=(n==null?void 0:n.experienceMatchStatus)==="MATCH",S=(n==null?void 0:n.experienceMatchStatus)==="MISMATCH";n==null||n.educationMatchStatus;const C=(n==null?void 0:n.educationMatchStatus)==="MISMATCH",A=(n==null?void 0:n.educationMatchStatus)==="UNSPECIFIED"||!(n!=null&&n.educationMatchStatus),L=(n==null?void 0:n.skillsMatchStatus)!=="MISMATCH",M=(n==null?void 0:n.locationMatchStatus)==="MATCH",N=(n==null?void 0:n.locationMatchStatus)==="MISMATCH";return(n==null?void 0:n.locationMatchStatus)==="UNSPECIFIED"||n!=null&&n.locationMatchStatus,`
    <!-- Back to Job Listing (if drilled down from multi-job view) -->
    ${e!=null&&e.onBackToListing?`
      <div style="margin-bottom:8px;">
        <button id="talvyn-back-to-jobs-btn" style="
          display:inline-flex;align-items:center;gap:4px;background:none;border:none;color:#4f46e5;
          font-size:11.5px;font-weight:700;cursor:pointer;padding:0;
        ">
          ← Back to Jobs
        </button>
      </div>
    `:""}

    <!-- 1. JOB OVERVIEW Section -->
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        JOB OVERVIEW
      </div>
      <div style="font-size:13.5px;font-weight:700;color:${h};line-height:1.3;margin-bottom:3px;">
        ${T(u.overview.title)}
      </div>
      <div style="font-size:12px;color:${x};font-weight:600;margin-bottom:4px;">
        ${T(u.overview.company)}
      </div>
      <div style="font-size:11px;color:${g};display:flex;flex-wrap:wrap;gap:8px;">
        <span>📍 ${T(u.overview.location)}</span>
        <span>💼 ${T(u.overview.jobType)}</span>
        <span>💰 ${T(u.overview.salary)}</span>
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:4px;display:flex;flex-wrap:wrap;gap:8px;">
        <span><strong>Experience:</strong> ${T(u.overview.experience)}</span>
        <span><strong>Education:</strong> ${T(u.overview.education)}</span>
      </div>
    </div>

    <!-- 2. DESCRIPTION Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        DESCRIPTION
      </div>
      <p style="font-size:11px;color:${x};line-height:1.4;margin:0;">
        ${T(u.descriptionSummary)}
      </p>
    </div>

    <!-- 3. RESPONSIBILITIES Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        RESPONSIBILITIES
      </div>
      <ul style="margin:0;padding-left:14px;font-size:11px;color:${x};line-height:1.4;">
        ${u.responsibilities.map(I=>`<li>${T(I)}</li>`).join("")}
      </ul>
    </div>

    <!-- 4. REQUIREMENTS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        REQUIREMENTS
      </div>
      <ul style="margin:0;padding-left:14px;font-size:11px;color:${x};line-height:1.4;">
        ${u.requirements.map(I=>`<li>${T(I)}</li>`).join("")}
      </ul>
    </div>

    <!-- 5. SKILLS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        SKILLS
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:2px;">
        <span style="font-weight:700;color:${h};">Matched Skills:</span>
        <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:3px;">
          ${d.length>0?d.map(I=>`
            <span style="
              font-size:10px;padding:1px 6px;border-radius:4px;
              background:${t?"#064e3b":"#ecfdf5"};color:#059669;border:1px solid ${t?"#047857":"#a7f3d0"};
            ">✓ ${T(I)}</span>
          `).join(""):`<span style="color:${g};">— None detected</span>`}
        </div>
      </div>
      <div style="font-size:10.5px;color:${x};margin-top:4px;">
        <span style="font-weight:700;color:${h};">Missing Skills:</span>
        <div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:3px;">
          ${o.length>0?o.map(I=>`
            <span style="
              font-size:10px;padding:1px 6px;border-radius:4px;
              background:${t?"#451a03":"#fffbeb"};color:#d97706;border:1px solid ${t?"#b45309":"#fde68a"};
            ">⚠ ${T(I)}</span>
          `).join(""):`<span style="color:${g};">— None</span>`}
        </div>
      </div>
    </div>

    <!-- 6. PROFILE MATCH Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${x};letter-spacing:0.3px;text-transform:uppercase;">PROFILE MATCH</span>
        <span style="font-size:14px;font-weight:800;color:${b};">${i}%</span>
      </div>

      <!-- Factor Checkmarks & Statuses -->
      <div style="display:flex;flex-direction:column;gap:3.5px;margin-bottom:6px;">
        <!-- Role match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${v?"#059669":w?"#dc2626":g};">
          <span style="font-weight:800;">${v?"✓":w?"⚠":"—"}</span>
          <span>${v?"Role match":w?"Role mismatch":"— Role: Not specified"}</span>
        </div>

        <!-- Experience match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${S?"#dc2626":k?"#059669":g};">
          <span style="font-weight:800;">${S?"⚠":k?"✓":"—"}</span>
          <span>${S?"Experience mismatch":k?"Experience match":"— Experience: Not specified"}</span>
        </div>

        <!-- Education match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${C?"#dc2626":A?g:"#059669"};">
          <span style="font-weight:800;">${C?"⚠":A?"—":"✓"}</span>
          <span>${C?"Education mismatch":A?"— Education: Not specified":"Education match"}</span>
        </div>

        <!-- Skills match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${L?"#059669":"#dc2626"};">
          <span style="font-weight:800;">${L?"✓":"⚠"}</span>
          <span>${L?"Skills match":"Missing required skills"}</span>
        </div>

        <!-- Location match -->
        <div style="font-size:11px;display:flex;align-items:center;gap:5px;color:${N?"#dc2626":M?"#059669":g};">
          <span style="font-weight:800;">${M?"✓":N?"⚠":"—"}</span>
          <span>${M?"Location match":N?"Location mismatch":"— Location: Not specified"}</span>
        </div>
      </div>

      <!-- Experience Mismatch Callout -->
      ${S?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Experience mismatch</div>
          <div>Required: ${T((n==null?void 0:n.experienceRequiredText)||"2–4 years")}</div>
          <div>Your profile: ${T((n==null?void 0:n.experienceProfileText)||"Fresher")}</div>
        </div>
      `:""}

      <!-- Education Mismatch Callout -->
      ${C&&(n!=null&&n.educationRequiredText)&&n.educationRequiredText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Education mismatch</div>
          <div>Required: ${T(n.educationRequiredText)}</div>
          <div>Your profile: ${T((n==null?void 0:n.educationProfileText)||"Not specified")}</div>
        </div>
      `:""}

      <!-- Role Mismatch Callout -->
      ${w&&(n!=null&&n.roleProfileText)&&n.roleProfileText!=="Not specified"?`
        <div style="
          font-size:10.5px;color:${t?"#fca5a5":"#b91c1c"};
          background:${t?"#450a0a":"#fef2f2"};
          border:1px solid ${t?"#7f1d1d":"#fecaca"};
          border-radius:7px;padding:6px 8px;margin-bottom:6px;line-height:1.4;
        ">
          <div style="font-weight:700;">⚠ Role mismatch</div>
          <div>Required: ${T((n==null?void 0:n.roleRequiredText)||s.title)}</div>
          <div>Target role: ${T(n.roleProfileText)}</div>
        </div>
      `:""}
    </div>

    <!-- 7. SHORTLIST & 8. REASON Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:10px;">
      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        SHORTLIST
      </div>
      <div style="
        background:${f};border:1px solid ${y};border-radius:9px;
        padding:8px 10px;margin-bottom:8px;
      ">
        <div style="display:flex;align-items:center;gap:5px;font-size:12px;font-weight:700;color:${h};">
          <span>${l}</span>
          <span>${T(a)}</span>
        </div>
        <div style="font-size:11px;color:${g};margin-left:18px;margin-top:1px;">
          ${T(r)}
        </div>
      </div>

      <div style="font-size:10px;font-weight:800;color:#6366f1;letter-spacing:0.4px;margin-bottom:4px;text-transform:uppercase;">
        REASON
      </div>
      <div style="font-size:11px;color:${x};line-height:1.4;margin-bottom:4px;">
        ${T(u.reason)}
      </div>
    </div>

    <!-- 9. APPLICATION READINESS Section -->
    <div style="height:1px;background:${y};margin:8px 0;"></div>
    <div style="margin-bottom:12px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <span style="font-size:11px;font-weight:700;color:${x};letter-spacing:0.3px;text-transform:uppercase;">APPLICATION READINESS</span>
        <span style="font-size:12.5px;font-weight:800;color:#059669;">${c}%</span>
      </div>

      <div style="display:flex;flex-direction:column;gap:3px;">
        ${p.map(I=>`
          <div style="font-size:11px;color:#059669;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">✓</span> <span>${T(I)}</span>
          </div>
        `).join("")}
        ${m.map(I=>`
          <div style="font-size:11px;color:#dc2626;display:flex;align-items:center;gap:4px;">
            <span style="font-weight:700;">⚠</span> <span>${T(I)}</span>
          </div>
        `).join("")}
      </div>
    </div>

    <div id="talvyn-status" style="display:none;margin-bottom:8px;"></div>

    <!-- Action Buttons -->
    <div id="talvyn-actions" style="display:flex;flex-direction:column;gap:6px;">
      <button id="talvyn-save-btn" style="
        width:100%;padding:9px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);
        color:white;border:none;border-radius:8px;font-size:12.5px;font-weight:700;
        cursor:pointer;transition:opacity 0.15s, transform 0.1s;box-shadow:0 2px 6px rgba(79,70,229,0.25);
      ">
        ★ Save Job
      </button>

      <button id="talvyn-apply-btn" style="
        width:100%;padding:8px 12px;background:#ffffff;
        color:#4f46e5;border:1px solid #c7d2fe;border-radius:8px;font-size:12px;font-weight:700;
        cursor:pointer;transition:background 0.15s;display:flex;align-items:center;justify-content:center;gap:5px;
      ">
        <span>⚡</span> Apply with Talvyn
      </button>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:2px;">
        <button id="talvyn-open-job-btn" style="
          padding:5px 8px;background:transparent;color:${g};
          border:1px solid ${y};border-radius:7px;font-size:11px;font-weight:500;
          cursor:pointer;text-align:center;
        ">
          Open Job ↗
        </button>
        <button id="talvyn-dashboard-btn" style="
          padding:5px 8px;background:transparent;color:#6366f1;
          border:1px solid ${y};border-radius:7px;font-size:11px;font-weight:600;
          cursor:pointer;text-align:center;
        ">
          Dashboard
        </button>
      </div>
    </div>
  `}function xt(s,e,t="system"){var c,p,m;B();const n=document.createElement("div");n.id=Le,n.setAttribute("data-talvyn","true");const i=t==="dark"||t!=="light"&&typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches,a=i?"#334155":"#e2e8f0",r=i?"#f8fafc":"#0f172a",l=i?"#cbd5e1":"#475569";n.innerHTML=`
    <div id="talvyn-panel-container">
      <div id="talvyn-panel-header" style="
        display:flex;align-items:center;justify-content:space-between;
        margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid ${a};
        cursor:grab;user-select:none;
      " title="Drag to move">
        <div style="display:flex;align-items:center;gap:7px;">
          <div style="
            width:22px;height:22px;background:linear-gradient(135deg, #4f46e5, #6366f1);
            border-radius:6px;display:flex;align-items:center;justify-content:center;
            font-size:11px;font-weight:800;color:white;flex-shrink:0;box-shadow:0 1px 3px rgba(79,70,229,0.3);
          ">T</div>
          <span style="font-weight:700;font-size:13px;color:${r};">Talvyn Intelligence</span>
        </div>
        <button id="talvyn-dismiss-btn" style="
          background:none;border:none;cursor:pointer;color:#94a3b8;font-size:16px;line-height:1;padding:0 2px;
        " title="Close">×</button>
      </div>

      <div style="padding:4px 2px;">
        <div style="
          background:${i?"#1e293b":"#f8fafc"};
          border:1px solid ${i?"#334155":"#e2e8f0"};
          border-radius:10px;padding:14px 12px;margin-bottom:10px;text-align:center;
        ">
          <div style="font-size:22px;margin-bottom:6px;">💼</div>
          <div style="font-weight:700;font-size:13px;color:${r};margin-bottom:4px;">
            No job opportunities detected on this page.
          </div>
          <p style="font-size:11.5px;color:${l};line-height:1.4;margin:0;">
            Make sure you are on an active job posting, detail page, or career listings portal.
          </p>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px;">
          <button id="talvyn-reanalyze-btn" style="
            width:100%;padding:9px;background:linear-gradient(to right, #4f46e5, #6366f1);
            color:white;border:none;border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;
            box-shadow:0 2px 6px rgba(79,70,229,0.25);
          ">
            Analyze Again
          </button>
          <button id="talvyn-dashboard-btn" style="
            width:100%;padding:8px;background:transparent;color:#6366f1;
            border:1px solid ${a};border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">
            Open Talvyn Dashboard
          </button>
        </div>
      </div>
    </div>
  `,Ht(n,i);const{shadow:d}=Ue();d.appendChild(n);const o=n.querySelector("#talvyn-panel-header");o&&Ee(n,o,ye),(c=n.querySelector("#talvyn-dismiss-btn"))==null||c.addEventListener("click",()=>{s(),B()}),(p=n.querySelector("#talvyn-reanalyze-btn"))==null||p.addEventListener("click",()=>{e&&e()}),(m=n.querySelector("#talvyn-dashboard-btn"))==null||m.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/dashboard`,"_blank")})}function Ht(s,e=!1){let t=null;try{const o=localStorage.getItem(ye);o&&(t=JSON.parse(o))}catch{}const n=320,i=460,a=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,r=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let l=Math.max(16,a-n-24),d=Math.max(16,r-i-40);if(t&&typeof t.x=="number"&&typeof t.y=="number"){const o=Math.max(0,a-n),c=Math.max(0,r-200);l=Math.max(0,Math.min(t.x,o)),d=Math.max(0,Math.min(t.y,c))}Object.assign(s.style,{position:"fixed",top:`${d}px`,left:`${l}px`,bottom:"auto",right:"auto",zIndex:"2147483647",width:`${n}px`,background:e?"#0f172a":"#ffffff",color:e?"#f8fafc":"#0f172a",borderRadius:"14px",boxShadow:e?"0 10px 36px rgba(0,0,0,0.6), 0 2px 6px rgba(0,0,0,0.3)":"0 10px 36px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",padding:"13px",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',fontSize:"13px",lineHeight:"1.4",border:e?"1px solid #334155":"1px solid #e2e8f0",boxSizing:"border-box",transition:"box-shadow 0.2s ease"})}function oe(s){var a;const e=he(Le);if(!e)return;const t=e.querySelector("#talvyn-status");e.querySelector("#talvyn-actions");const n=e.querySelector("#talvyn-save-btn"),i=e.querySelector("#talvyn-apply-btn");if(t)switch(s.type){case"loading":n&&(n.textContent="Saving...",n.disabled=!0,n.style.opacity="0.7"),t.style.display="none";break;case"saved":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${T(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"duplicate":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#d97706;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>ALREADY SAVED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#b45309;">Status: ${T(s.existingStatus||"SAVED")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"applied":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#059669;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>✓</span> <span>APPLICATION TRACKED</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#047857;">Status: ${T(s.existingStatus||"APPLIED")}</span>
          </div>
          ${s.dateApplied?`<div style="font-size:10.5px;color:#64748b;margin-top:2px;">Submitted ${T(s.dateApplied)}</div>`:""}
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"in_progress":n&&(n.textContent="✓ Saved",n.disabled=!0,n.style.opacity="0.7",n.style.cursor="default"),t.innerHTML=`
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:8px 10px;margin-bottom:8px;">
          <div style="display:flex;align-items:center;justify-content:space-between;">
            <div style="color:#2563eb;font-weight:700;font-size:12px;display:flex;align-items:center;gap:4px;">
              <span>⏳</span> <span>IN PROGRESS</span>
            </div>
            <span style="font-size:11px;font-weight:600;color:#1d4ed8;">Status: ${T(s.existingStatus||"IN_PROGRESS")}</span>
          </div>
          <div style="margin-top:5px;">
            <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="color:#4f46e5;font-size:11px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;gap:3px;">
              View in Tracker →
            </a>
          </div>
        </div>
      `,t.style.display="block";break;case"autofilling":i&&(i.textContent="⏳ Autofilling...",i.disabled=!0);break;case"autofill-complete":i&&(i.textContent="⚡ Apply with Talvyn",i.disabled=!1);break;case"error":n&&(n.textContent="★ Save Job",n.disabled=!1,n.style.opacity="1",n.style.cursor="pointer"),i&&(i.disabled=!1),t.innerHTML=`
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:8px 10px;margin-bottom:8px;color:#dc2626;font-size:11.5px;line-height:1.4;">
          <div style="font-weight:700;">⚠ Error</div>
          <div>${T(s.message||"Failed to complete action. Please try again.")}</div>
        </div>
      `,t.style.display="block";break;case"logged-out":t.innerHTML=`
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;margin-bottom:8px;font-size:11.5px;color:#475569;">
          <div>Sign in to Talvyn to track opportunities.</div>
          <button id="talvyn-signin-btn" style="
            margin-top:6px;width:100%;padding:6px;background:#4f46e5;color:white;
            border:none;border-radius:6px;font-size:11.5px;font-weight:600;cursor:pointer;
          ">Sign In to Talvyn</button>
        </div>
      `,t.style.display="block",(a=e.querySelector("#talvyn-signin-btn"))==null||a.addEventListener("click",()=>{window.open(`${le.DASHBOARD_URL}/login`,"_blank")});break;case"idle":default:n&&(n.textContent="★ Save Job",n.disabled=!1,n.style.opacity="1",n.style.cursor="pointer"),i&&(i.disabled=!1),t.style.display="none";break}}function B(){var s,e,t,n;(s=he(Le))==null||s.remove(),(e=he(Re))==null||e.remove(),typeof document<"u"&&((t=document.getElementById(Le))==null||t.remove(),(n=document.getElementById(Re))==null||n.remove())}function _t(s){return s.replace(/_/g," ").toLowerCase().replace(/\b\w/g,e=>e.toUpperCase())}function T(s){return(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}const $e="talvyn-discovery-panel";class qn{constructor(){this.isMinimized=!1,this.currentFilter="ALL",this.summary=null,this.callbacks=null}render(e,t){this.summary=e,this.callbacks=t,this.remove();const n=document.createElement("div");n.id=$e,n.setAttribute("data-talvyn","true"),n.style.pointerEvents="auto",n.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(n,this.isMinimized);const{shadow:i}=Ue();i.appendChild(n);const a=n.querySelector("#talvyn-discovery-header");a&&Ee(n,a,ye),this.attachEventListeners(n)}updateSummary(e){this.summary=e;const t=he($e);if(!t||!this.callbacks)return;t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized);const n=t.querySelector("#talvyn-discovery-header");n&&Ee(t,n,ye),this.attachEventListeners(t)}remove(){var e,t;(e=he($e))==null||e.remove(),typeof document<"u"&&((t=document.getElementById($e))==null||t.remove())}buildMinimizedHTML(e){const t=e.excellentCount+e.highlyRelevantCount;return`
      <div id="talvyn-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 14px;
        background:#6366f1;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 4px 20px rgba(99,102,241,0.4);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <div style="
          width:20px;height:20px;background:rgba(255,255,255,0.25);border-radius:6px;
          display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;
        ">T</div>
        <span>Talvyn Discovery (${e.totalDetected} jobs${t>0?` · ${t} top`:""})</span>
      </div>
    `}buildExpandedHTML(e){const t=this.filterJobs(e.analyzedJobs),n=e.excellentCount+e.highlyRelevantCount;return`
      <div style="display:flex;flex-direction:column;max-height:560px;">
        <!-- Header (Draggable Handle) -->
        <div id="talvyn-discovery-header" style="
          padding:12px 14px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;cursor:grab;user-select:none;
        " title="Drag to move panel">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:24px;height:24px;background:rgba(255,255,255,0.2);border-radius:6px;
              display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:800;
            ">T</div>
            <div>
              <div style="font-weight:800;font-size:13px;letter-spacing:0.3px;">TALVYN JOB INTELLIGENCE</div>
              <div id="talvyn-discovery-job-count" style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalDetected} Jobs Found</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Breakdown Bar -->
        <div style="
          padding:8px 12px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              Strong Match: ${e.excellentCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
            ">
              Good Match: ${e.highlyRelevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              Moderate Match: ${e.relevantCount}
            </span>
            <span style="
              font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;
              background:#fef2f2;color:#991b1b;border:1px solid #fecaca;
            ">
              Low Match: ${e.lowRelevanceCount}
            </span>
          </div>
        </div>

        <!-- Action & Control Bar: [ Analyze This Page ] and [ Save Top Matches ] -->
        <div style="
          display:flex;padding:8px 12px;gap:6px;background:#ffffff;
          border-bottom:1px solid #f1f5f9;align-items:center;justify-content:space-between;flex-shrink:0;
        ">
          <button id="talvyn-reanalyze-page-btn" style="
            padding:5px 10px;background:#f8fafc;color:#4f46e5;border:1px solid #c7d2fe;
            border-radius:8px;font-size:11px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:4px;
            transition:all 0.15s;
          ">
            <span>🔄</span> Analyze This Page
          </button>

          <button id="talvyn-save-all-top-btn" ${n===0?"disabled":""} style="
            padding:5px 12px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;border:none;border-radius:8px;
            font-size:11px;font-weight:700;cursor:${n===0?"not-allowed":"pointer"};white-space:nowrap;
            opacity:${n===0?"0.6":"1"};box-shadow:0 1px 4px rgba(79,70,229,0.3);transition:background 0.15s;
          ">
            ★ Save Top Matches (${n})
          </button>
        </div>

        <!-- Filter Tabs -->
        <div style="
          display:flex;padding:6px 12px;gap:4px;background:#f8fafc;
          border-bottom:1px solid #e2e8f0;overflow-x:auto;flex-shrink:0;align-items:center;
        ">
          ${this.renderFilterTab("ALL",`All (${e.totalDetected})`)}
          ${this.renderFilterTab("STRONG",`Strong (${e.excellentCount})`)}
          ${this.renderFilterTab("GOOD",`Good (${e.highlyRelevantCount})`)}
          ${this.renderFilterTab("MODERATE",`Moderate (${e.relevantCount})`)}
          ${this.renderFilterTab("LOW",`Low (${e.lowRelevanceCount})`)}
          ${this.renderFilterTab("SAVED","Saved")}
        </div>

        <!-- Scrollable Job List -->
        <div id="talvyn-cards-container" style="
          padding:10px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${t.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No jobs in this category.
            </div>
          `:t.map(i=>this.renderJobCard(i)).join("")}
        </div>

        <!-- Footer -->
        <div style="
          padding:8px 12px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;font-size:11px;
        ">
          <span style="color:#94a3b8;">Deterministic relevance score</span>
          <a href="${le.DASHBOARD_URL}/tracker" target="_blank" style="
            color:#4f46e5;text-decoration:none;font-weight:600;
          ">View in Tracker →</a>
        </div>
      </div>
    `}renderFilterTab(e,t){const n=this.currentFilter===e;return`
      <button class="talvyn-tab-btn" data-filter="${e}" style="
        padding:3px 9px;border-radius:10px;font-size:10.5px;font-weight:600;cursor:pointer;
        border:1px solid ${n?"#6366f1":"#e2e8f0"};
        background:${n?"#6366f1":"#ffffff"};
        color:${n?"#ffffff":"#64748b"};
        white-space:nowrap;transition:all 0.15s;
      ">${t}</button>
    `}renderJobCard(e){var v,w,k,S,C,A,L,M,N,z;const{job:t,relevanceScore:n,category:i,isSaved:a}=e,r=`job-card-${this.hashUrl(t.jobUrl)}`,l=((v=e.experienceMatch)==null?void 0:v.requiredText)||"Not specified",d=((w=e.educationMatch)==null?void 0:w.requiredText)||"Not specified",o=((k=e.roleMatch)==null?void 0:k.score)!==void 0?e.roleMatch.score>=.6:!0,c=((S=e.experienceMatch)==null?void 0:S.status)==="MATCH",p=((C=e.experienceMatch)==null?void 0:C.status)==="MISMATCH",m=((A=e.educationMatch)==null?void 0:A.status)==="MATCH",u=((L=e.educationMatch)==null?void 0:L.status)==="MISMATCH",f=((M=e.skillsMatch)==null?void 0:M.status)!=="MISMATCH",y=((N=e.locationMatch)==null?void 0:N.score)!==void 0?e.locationMatch.score>=.7:!0;let h="#fef2f2",x="#991b1b",g="#fecaca",b="🔴 LOW MATCH";return i==="EXCELLENT"?(h="#ecfdf5",x="#065f46",g="#6ee7b7",b="🟢 STRONG MATCH"):i==="HIGHLY_RELEVANT"?(h="#eef2ff",x="#4338ca",g="#a5b4fc",b="🟢 GOOD MATCH"):i==="RELEVANT"?(h="#fffbeb",x="#92400e",g="#fde68a",b="🟡 MODERATE MATCH"):b="🔴 LOW MATCH",`
      <div id="${r}" style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:10px;
        padding:10px 12px;box-shadow:0 1px 3px rgba(0,0,0,0.04);transition:all 0.15s;
      ">
        <!-- Top Title & Match % -->
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:2px;">
          <div style="font-weight:700;font-size:12.5px;color:#0f172a;line-height:1.3;flex:1;">
            ${this.escapeHtml(t.title)}
          </div>
          <div style="
            display:inline-flex;align-items:center;gap:3px;padding:2px 6px;
            border-radius:8px;font-size:10px;font-weight:800;
            background:${h};color:${x};border:1px solid ${g};
            flex-shrink:0;
          ">
            <span>PROFILE MATCH: ${n}%</span>
          </div>
        </div>

        <!-- Company, Location, Type, Experience, Education -->
        <div style="font-size:11.5px;color:#475569;font-weight:600;margin-bottom:6px;line-height:1.4;">
          <div>${this.escapeHtml(t.company)}${t.location?` · <span style="color:#64748b;font-weight:400;">📍 ${this.escapeHtml(t.location)}</span>`:""}</div>
          <div style="font-size:10.5px;color:#64748b;font-weight:400;margin-top:2px;display:flex;flex-wrap:wrap;gap:6px;">
            <span><strong>Experience:</strong> ${this.escapeHtml(l)}</span>
            <span><strong>Education:</strong> ${this.escapeHtml(d)}</span>
            <span><strong>Job Type:</strong> ${this.escapeHtml(t.jobType?this.formatJobType(t.jobType):"Full Time")}</span>
            ${t.salary?`<span><strong>Salary:</strong> ${this.escapeHtml(t.salary)}</span>`:""}
          </div>
        </div>

        <!-- 5 Factor Match Breakdown -->
        <div style="
          background:#f8fafc;border:1px solid #f1f5f9;border-radius:6px;
          padding:6px 8px;margin-bottom:6px;font-size:10.5px;display:grid;grid-template-columns:1fr 1fr;gap:3px 8px;
        ">
          <div style="color:${o?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${o?"✓":"⚠"}</span> <span>Role</span>
          </div>
          <div style="color:${p?"#dc2626":c?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${p?"⚠":c?"✓":"—"}</span> <span>Experience</span>
          </div>
          <div style="color:${u?"#dc2626":m?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;">
            <span>${u?"⚠":m?"✓":"—"}</span> <span>Education</span>
          </div>
          <div style="color:${f?"#059669":"#dc2626"};display:flex;align-items:center;gap:3px;">
            <span>${f?"✓":"⚠"}</span> <span>Skills</span>
          </div>
          <div style="color:${y?"#059669":"#64748b"};display:flex;align-items:center;gap:3px;grid-column:1 / -1;">
            <span>${y?"✓":"—"}</span> <span>Location</span>
          </div>
        </div>

        <!-- Shortlist Tier Callout -->
        <div style="margin-bottom:6px;font-size:11px;font-weight:700;">
          <span style="color:#64748b;font-size:10px;text-transform:uppercase;">SHORTLIST: </span>
          <span>${b}</span>
        </div>

        <!-- Exact Mismatch Callout -->
        ${p?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <div style="font-weight:700;">⚠ Experience mismatch</div>
            <div>Required: ${this.escapeHtml(l)}</div>
            <div>Your profile: ${this.escapeHtml(((z=e.experienceMatch)==null?void 0:z.profileText)||"Fresher")}</div>
          </div>
        `:""}

        ${u&&d!=="Not specified"?`
          <div style="
            color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;
            border-radius:6px;padding:5px 8px;font-size:10.5px;line-height:1.4;margin-bottom:6px;
          ">
            <div style="font-weight:700;">⚠ Education mismatch</div>
            <div>Required: ${this.escapeHtml(d)}</div>
          </div>
        `:""}

        <!-- Actions -->
        <div style="display:flex;gap:6px;align-items:center;margin-top:6px;">
          <button class="talvyn-view-details-btn" data-url="${this.escapeHtml(t.jobUrl)}" style="
            flex:1;padding:6px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;
            border:1px solid #c7d2fe;background:#eef2ff;color:#4338ca;transition:all 0.15s;
          ">View Details</button>
          
          <button class="talvyn-save-card-btn" data-url="${this.escapeHtml(t.jobUrl)}" style="
            flex:1;padding:6px 10px;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;
            border:none;background:${a?"#10b981":"#4f46e5"};color:#ffffff;
            transition:background 0.15s;
          ">${a?"✓ Saved":"Save"}</button>
          
          <a href="${t.jobUrl}" target="_blank" style="
            padding:5px 9px;border-radius:6px;font-size:11px;font-weight:500;text-decoration:none;
            border:1px solid #cbd5e1;background:#ffffff;color:#475569;text-align:center;
          ">Open ↗</a>
        </div>
      </div>
    `}formatJobType(e){return e.replace(/_/g," ").toLowerCase().replace(/\b\w/g,t=>t.toUpperCase())}attachEventListeners(e){var a,r,l,d,o;(a=e.querySelector("#talvyn-minimize-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(r=e.querySelector("#talvyn-expand-btn"))==null||r.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(l=e.querySelector("#talvyn-close-btn"))==null||l.addEventListener("click",()=>{var c;this.remove(),(c=this.callbacks)==null||c.onDismiss()}),(d=e.querySelector("#talvyn-reanalyze-page-btn"))==null||d.addEventListener("click",()=>{var c;(c=this.callbacks)!=null&&c.onRefresh&&this.callbacks.onRefresh()}),e.querySelectorAll(".talvyn-tab-btn").forEach(c=>{c.addEventListener("click",p=>{const u=p.currentTarget.getAttribute("data-filter");u&&(this.currentFilter=u,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks))})}),(o=e.querySelector("#talvyn-save-all-top-btn"))==null||o.addEventListener("click",async c=>{const p=c.currentTarget;if(!this.summary||!this.callbacks)return;const m=this.summary.analyzedJobs.filter(u=>(u.category==="EXCELLENT"||u.category==="HIGHLY_RELEVANT")&&!u.isSaved);if(m.length!==0){p.disabled=!0,p.textContent="Saving Top Matches...";for(const u of m){const f=e.querySelector(`.talvyn-save-card-btn[data-url="${this.escapeHtml(u.job.jobUrl)}"]`);f&&(f.disabled=!0,f.textContent="Saving…");try{await this.callbacks.onSaveJob(u,f||document.createElement("button")),u.isSaved=!0,f&&(f.textContent="Saved ✓",f.style.background="#10b981")}catch{f&&(f.disabled=!1,f.textContent="Save Job")}}p.textContent="✓ Top Matches Saved",p.style.background="#059669"}}),e.querySelectorAll(".talvyn-view-details-btn").forEach(c=>{c.addEventListener("click",p=>{var y,h;const u=p.currentTarget.getAttribute("data-url"),f=(y=this.summary)==null?void 0:y.analyzedJobs.find(x=>x.job.jobUrl===u);f&&((h=this.callbacks)!=null&&h.onSelectJob)&&this.callbacks.onSelectJob(f.job)})}),e.querySelectorAll(".talvyn-save-card-btn").forEach(c=>{c.addEventListener("click",async p=>{var y;const m=p.currentTarget,u=m.getAttribute("data-url"),f=(y=this.summary)==null?void 0:y.analyzedJobs.find(h=>h.job.jobUrl===u);if(f&&this.callbacks){m.disabled=!0,m.textContent="Saving…";try{await this.callbacks.onSaveJob(f,m),f.isSaved=!0,m.textContent="Saved ✓",m.style.background="#10b981"}catch{m.disabled=!1,m.textContent="Save"}}})})}filterJobs(e){switch(this.currentFilter){case"STRONG":return e.filter(t=>t.category==="EXCELLENT");case"GOOD":return e.filter(t=>t.category==="HIGHLY_RELEVANT");case"MODERATE":return e.filter(t=>t.category==="RELEVANT");case"LOW":return e.filter(t=>t.category==="LOW_RELEVANCE");case"SAVED":return e.filter(t=>t.isSaved);default:return e}}applyStyles(e,t){let n=null;try{const c=localStorage.getItem(ye);c&&(n=JSON.parse(c))}catch{}const i=380,a=580,r=typeof window<"u"&&window.innerWidth?window.innerWidth:1200,l=typeof window<"u"&&window.innerHeight?window.innerHeight:800;let d=Math.max(16,r-i-24),o=Math.max(16,l-a-24);if(n&&typeof n.x=="number"&&typeof n.y=="number"){const c=Math.max(0,r-i),p=Math.max(0,l-200);d=Math.max(0,Math.min(n.x,c)),o=Math.max(0,Math.min(n.y,p))}t?Object.assign(e.style,{position:"fixed",left:`${d}px`,top:`${o}px`,bottom:"auto",right:"auto",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",left:`${d}px`,top:`${o}px`,bottom:"auto",right:"auto",width:`${i}px`,maxHeight:`${a}px`,zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(99,102,241,0.2)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}hashUrl(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n),t|=0;return Math.abs(t).toString(36)}}const J=new qn;class jn{constructor(){this.name="Generic"}canHandle(){return!0}isApplicationForm(e,t){var c;const n=e.toLowerCase(),i=/\/apply/i.test(n)||/\/application/i.test(n)||/\/submit/i.test(n)||n.includes("job")||n.includes("career");if(Array.from(t.querySelectorAll("input, textarea, select")).length<2)return!1;const r=(((c=t.body)==null?void 0:c.textContent)||"").toLowerCase(),l=r.includes("apply")||r.includes("submit application")||r.includes("resume")||r.includes("candidate")||r.includes("first name")||r.includes("email"),d=!!t.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i]'),o=!!t.querySelector('input[name*="name" i], input[id*="name" i], input[name*="first" i]');return i&&(d||o)||l&&d&&o}findFormRoots(e){const t=Array.from(e.querySelectorAll("form"));return t.length>0?t:[e.body]}}class Nn{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}isApplicationForm(e,t){return!!t.querySelector("form#application_form, #app_body, #application")||!!t.querySelector("#first_name, #last_name, #email, #phone")}findFormRoots(e){const t=e.querySelector("form#application_form, #app_body, form");return t?[t]:[e.body]}}class zn{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}isApplicationForm(e,t){return/\/apply\/?$/i.test(e)||!!t.querySelector(".application-form, form#application-form, .application-page")}findFormRoots(e){const t=e.querySelector(".application-form, form#application-form, form");return t?[t]:[e.body]}}class On{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}isApplicationForm(e,t){return/\/apply/i.test(e)||!!t.querySelector('div[data-automation-id="formField"], form[data-automation-id="applyForm"]')}findFormRoots(e){const t=e.querySelector('form, main, [data-automation-id="pageContent"]');return t?[t]:[e.body]}}class Hn{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}isApplicationForm(e,t){return!!t.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]")}findFormRoots(e){const t=e.querySelector(".jobs-easy-apply-modal, .jobs-easy-apply-content, div[data-test-modal]");return t?[t]:[e.body]}}class _n{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}isApplicationForm(e,t){return!!t.querySelector('#ia-container, .ia-BasePage, form[action*="apply" i]')}findFormRoots(e){const t=e.querySelector("#ia-container, .ia-BasePage, form");return t?[t]:[e.body]}}class Pn{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('form, [class*="applicationForm" i], [class*="application-form" i]'),i=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return n&&i}findFormRoots(e){const t=Array.from(e.querySelectorAll('form, [class*="applicationForm" i], [class*="application-form" i]'));if(t.length>0)return t;const n=e.querySelector("main");return n?[n]:[e.body]}}class Un{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}isApplicationForm(e,t){if(!this.canHandle(e))return!1;const n=!!t.querySelector('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'),i=t.querySelectorAll('input:not([type="hidden"]), textarea').length>=2;return n&&i||e.includes("/apply")}findFormRoots(e){const t=Array.from(e.querySelectorAll('#st-apply, form.st-apply, [data-qa="apply-form"], form[action*="smartrecruiters"]'));if(t.length>0)return t;const n=Array.from(e.querySelectorAll("form"));return n.length>0?n:[e.body]}}class Fn{constructor(){this.adapters=[],this.genericAdapter=new jn,this.adapters=[new Nn,new zn,new On,new Hn,new _n,new Pn,new Un]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const ge=new Fn,Dn=new Set(["hidden","password","submit","button","reset","image","search"]),Jn=["csrf","token","authenticity_token","__viewstate","recaptcha","hcaptcha","turnstile","search","query","q","filter"];class Bn{detectFields(e=document){const t=Array.from(e.querySelectorAll("input, textarea, select")),n=[],i=new Set;for(const a of t){if(i.has(a))continue;i.add(a);const r=this.extractField(a);r&&!r.isIgnored&&n.push(r)}return n}extractField(e){const t=e.tagName.toLowerCase(),n=e instanceof HTMLInputElement?(e.type||"text").toLowerCase():t;if(this.shouldIgnore(e,n))return null;const i=e.name||"",a=e.id||"",r=e.getAttribute("placeholder")||"",l=e.getAttribute("aria-label")||"",d=e.getAttribute("autocomplete")||"",o=e.required||e.getAttribute("aria-required")==="true",c=this.resolveLabel(e),p=this.resolveNearbyText(e),m=this.resolveOptions(e),u=this.resolveCurrentValue(e),f=this.generateSelector(e);return{id:a||i||f,element:e,selector:f,tag:n==="radio"?"radio":n==="checkbox"?"checkbox":t,inputType:n,name:i,domId:a,label:c,placeholder:r,ariaLabel:l,autocomplete:d,nearbyText:p,options:m,currentValue:u,isRequired:o||c.includes("*")||p.includes("*"),isIgnored:!1}}resolveLabel(e){var a,r,l,d,o,c;if(e.id){const p=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);if((a=p==null?void 0:p.textContent)!=null&&a.trim())return this.cleanText(p.textContent)}const t=e.closest("label");if(t){const p=t.cloneNode(!0),m=p.querySelector("input, select, textarea");if(m==null||m.remove(),(r=p.textContent)!=null&&r.trim())return this.cleanText(p.textContent)}const n=e.getAttribute("aria-labelledby");if(n){const p=document.getElementById(n);if((l=p==null?void 0:p.textContent)!=null&&l.trim())return this.cleanText(p.textContent)}if(e.getAttribute("aria-label"))return this.cleanText(e.getAttribute("aria-label"));const i=e.parentElement;if(i){const p=e.previousElementSibling;if(p&&(p.tagName==="LABEL"||p.tagName==="SPAN"||p.tagName==="P")&&(d=p.textContent)!=null&&d.trim()&&p.textContent.trim().length<=80)return this.cleanText(p.textContent);const m=e.closest("fieldset");if(m){const f=m.querySelector("legend");if((o=f==null?void 0:f.textContent)!=null&&o.trim())return this.cleanText(f.textContent)}const u=i.querySelector('label, [class*="label" i], [class*="title" i], [class*="heading" i]');if(u&&u!==e&&((c=u.textContent)!=null&&c.trim()))return this.cleanText(u.textContent)}return""}resolveNearbyText(e){const t=e.closest('.form-group, .field, [class*="field" i], [class*="control" i], div, tr');if(!t)return"";const n=t.textContent||"";return this.cleanText(n).slice(0,200)}resolveOptions(e){return e instanceof HTMLSelectElement?Array.from(e.options).map(t=>({label:this.cleanText(t.textContent||""),value:t.value,selected:t.selected})):e instanceof HTMLInputElement&&e.type==="radio"&&e.name?Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(e.name)}"]`)).map(n=>({label:this.resolveLabel(n)||n.value,value:n.value,selected:n.checked})):[]}resolveCurrentValue(e){return e instanceof HTMLInputElement&&(e.type==="checkbox"||e.type==="radio")?e.checked:e.value||""}shouldIgnore(e,t){if(Dn.has(t)||e.disabled||e.readOnly)return!0;const n=window.getComputedStyle(e);if((n.display==="none"||n.visibility==="hidden"||n.opacity==="0")&&t!=="file")return!0;const i=(e.getAttribute("name")||"").toLowerCase(),a=(e.id||"").toLowerCase(),r=(e.getAttribute("aria-label")||"").toLowerCase();for(const l of Jn)if(i.includes(l)||a.includes(l)||r.includes(l))return!0;return!1}generateSelector(e){return e.id?`#${CSS.escape(e.id)}`:e.getAttribute("name")?`${e.tagName.toLowerCase()}[name="${CSS.escape(e.getAttribute("name"))}"]`:e.tagName.toLowerCase()}cleanText(e){return e.replace(/\s+/g," ").replace(/[\r\n\t]/g," ").trim()}}const Ne=new Bn,Be=[{type:"fullName",category:"PERSONAL",label:"Full Name",autocompleteTokens:["name"],aliases:["full name","fullname","candidate name","applicant name","legal full name","legal name","your name","complete name","name (first and last)","full legal name"],negativeAliases:["first name","last name","middle name","company name","school name"]},{type:"firstName",category:"PERSONAL",label:"First Name",autocompleteTokens:["given-name"],aliases:["first name","firstname","given name","candidate first name","legal first name","fname","forename","first_name","first","prenom"],negativeAliases:["last name","middle name"]},{type:"middleName",category:"PERSONAL",label:"Middle Name",autocompleteTokens:["additional-name"],aliases:["middle name","middlename","middle initial","mname","middle_name","middle"],negativeAliases:["first name","last name"]},{type:"lastName",category:"PERSONAL",label:"Last Name",autocompleteTokens:["family-name"],aliases:["last name","lastname","family name","surname","candidate last name","legal last name","lname","last_name","last","nom"],negativeAliases:["first name","middle name"]},{type:"preferredName",category:"PERSONAL",label:"Preferred Name",autocompleteTokens:["nickname"],aliases:["preferred name","preferred first name","nickname","chosen name","known as","goes by"]},{type:"email",category:"PERSONAL",label:"Email Address",autocompleteTokens:["email"],aliases:["email","email address","e-mail","e-mail address","candidate email","personal email","electronic mail","mail"],negativeAliases:["confirm email","alternate email","referrer email"]},{type:"phone",category:"PERSONAL",label:"Phone Number",autocompleteTokens:["tel","tel-national","tel-local"],aliases:["phone","phone number","mobile","mobile number","mobile phone","contact number","telephone","cell phone","cell","tel","primary phone"],negativeAliases:["extension","fax","emergency contact"]},{type:"dateOfBirth",category:"PERSONAL",label:"Date of Birth",autocompleteTokens:["bday","bday-day","bday-month","bday-year"],aliases:["date of birth","dob","birth date","birthday","birthdate"]},{type:"gender",category:"PERSONAL",label:"Gender / Pronouns",autocompleteTokens:["sex"],aliases:["gender","sex","pronoun","pronouns","gender identity"]},{type:"address",category:"PERSONAL",label:"Street Address",autocompleteTokens:["street-address","address-line1"],aliases:["address","street address","address line 1","address 1","residential address","home address","street"],negativeAliases:["email address","ip address","web address"]},{type:"city",category:"PERSONAL",label:"City",autocompleteTokens:["address-level2"],aliases:["city","town","municipality","suburb"]},{type:"state",category:"PERSONAL",label:"State / Province",autocompleteTokens:["address-level1"],aliases:["state","province","region","territory","county"],negativeAliases:["statement","status"]},{type:"country",category:"PERSONAL",label:"Country",autocompleteTokens:["country-name","country"],aliases:["country","nation","country of residence","citizenship country","current country"],negativeAliases:["authorized to work","work in this country","sponsorship","right to work"]},{type:"postalCode",category:"PERSONAL",label:"Postal / Zip Code",autocompleteTokens:["postal-code"],aliases:["postal code","postalcode","zip code","zipcode","zip","postcode","pin code","pincode"]},{type:"linkedinUrl",category:"PROFESSIONAL",label:"LinkedIn Profile",autocompleteTokens:["url"],aliases:["linkedin","linkedin profile","linkedin url","linkedin link","linkedin.com","public profile"]},{type:"githubUrl",category:"PROFESSIONAL",label:"GitHub Profile",autocompleteTokens:["url"],aliases:["github","github profile","github url","github link","github.com","git profile","repository"]},{type:"portfolioUrl",category:"PROFESSIONAL",label:"Portfolio / Personal Site",autocompleteTokens:["url"],aliases:["portfolio","portfolio url","portfolio link","portfolio website","personal website","online portfolio","design portfolio","work samples"]},{type:"websiteUrl",category:"PROFESSIONAL",label:"Website / Other Link",autocompleteTokens:["url"],aliases:["website","website url","personal site","blog","other website","other link","url"]},{type:"skills",category:"PROFESSIONAL",label:"Skills & Tech Stack",autocompleteTokens:[],aliases:["skills","core competencies","technologies","tech stack","key skills","skill set","technical skills"]},{type:"institution",category:"EDUCATION",label:"University / Institution",autocompleteTokens:[],aliases:["university","college","school","institution","educational institution","academy","alma mater"]},{type:"degree",category:"EDUCATION",label:"Degree",autocompleteTokens:[],aliases:["degree","qualification","highest degree","education level","level of education","degree earned"]},{type:"specialization",category:"EDUCATION",label:"Major / Field of Study",autocompleteTokens:[],aliases:["major","field of study","specialization","discipline","area of study","branch"]},{type:"graduationYear",category:"EDUCATION",label:"Graduation Year",autocompleteTokens:[],aliases:["graduation year","year of graduation","grad year","completion year","end year","passout year"]},{type:"cgpa",category:"EDUCATION",label:"GPA / CGPA",autocompleteTokens:[],aliases:["gpa","cgpa","grade","percentage","marks","academic score"]},{type:"workAuthorization",category:"APPLICATION",label:"Work Authorization",autocompleteTokens:[],aliases:["work authorization","authorized to work","legally authorized to work","are you legally authorized to work","eligible to work","right to work","work permit","work eligibility"]},{type:"visaStatus",category:"APPLICATION",label:"Visa Sponsorship",autocompleteTokens:[],aliases:["sponsorship","visa sponsorship","require sponsorship","will you require sponsorship","will you now or in the future require sponsorship","need sponsorship","visa status"]},{type:"expectedSalary",category:"APPLICATION",label:"Expected Salary",autocompleteTokens:[],aliases:["expected salary","expected ctc","ctc","salary","desired salary","salary expectation","compensation expectation","expected compensation","expected pay","target compensation","desired pay"]},{type:"noticePeriod",category:"APPLICATION",label:"Notice Period / Availability",autocompleteTokens:[],aliases:["notice period","availability","how soon can you start","earliest start date","start date","when can you start"]},{type:"currentCompany",category:"APPLICATION",label:"Current Employer",autocompleteTokens:["organization"],aliases:["current company","current employer","present company","company","organization","employer"]},{type:"currentJobTitle",category:"APPLICATION",label:"Current Job Title",autocompleteTokens:["organization-title"],aliases:["current title","current job title","current role","present role","job title","title"]},{type:"yearsOfExperience",category:"APPLICATION",label:"Years of Experience",autocompleteTokens:[],aliases:["years of experience","total experience","overall experience","relevant experience","how many years of experience","experience in years"]},{type:"resumeUpload",category:"SPECIAL",label:"Resume / CV File",autocompleteTokens:[],aliases:["resume","cv","curriculum vitae","upload resume","attach resume","upload cv","attach cv","resume file","resume/cv"]},{type:"customQuestion",category:"SPECIAL",label:"Custom Application Question",autocompleteTokens:[],aliases:["why do you want to work","why are you interested","describe your experience","tell us about yourself","why should we hire you","cover letter","additional information","anything else","what makes you a good fit","personal statement"]}];class Vn{matchField(e,t){if(e.inputType==="file"||this.isResumeField(e))return{field:e,detectedType:"resumeUpload",confidence:95,confidenceLevel:"HIGH",matchedProfileField:"resume",valueToFill:null,reason:"Resume / CV file upload field detected",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!0};if(this.isSensitiveQuestion(e))return{field:e,detectedType:"customQuestion",confidence:90,confidenceLevel:"HIGH",matchedProfileField:"sensitive_declaration",valueToFill:null,reason:"⚠ Review required: Sensitive question (disability, veteran, or legal declaration)",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1,isSensitive:!0,requiresReview:!0};if(this.isCustomQuestion(e))return{field:e,detectedType:"customQuestion",confidence:85,confidenceLevel:"MEDIUM",matchedProfileField:"custom",valueToFill:null,reason:"Open-ended custom question requiring manual response",canAutofill:!1,isCustomQuestion:!0,isResumeUpload:!1};const n=this.resolveFieldType(e);if(!n||n.confidence<50)return{field:e,detectedType:"unknown",confidence:(n==null?void 0:n.confidence)||20,confidenceLevel:"UNKNOWN",matchedProfileField:"none",valueToFill:null,reason:"Field type could not be confidently identified",canAutofill:!1,isCustomQuestion:!1,isResumeUpload:!1};const{value:i,reason:a,requiresManualInput:r}=this.resolveProfileValue(n.def.type,t,e),l=n.def.type==="workAuthorization"||n.def.type==="visaStatus"||n.def.type==="expectedSalary"||this.isSensitiveQuestion(e);let d=n.confidence;(r||i===null||i==="")&&(d=Math.min(d,65));const o=d>=90?"HIGH":d>=70?"MEDIUM":d>=50?"LOW":"UNKNOWN",c=!l&&!r&&i!==null&&i!==""&&d>=70;return{field:e,detectedType:n.def.type,confidence:d,confidenceLevel:o,matchedProfileField:n.def.type,valueToFill:i,reason:a||`Matched ${n.def.label} (${n.reason})`,canAutofill:c,isCustomQuestion:!1,isResumeUpload:!1,isSensitive:l,requiresReview:l||r}}resolveFieldType(e){const t=(e.autocomplete||"").toLowerCase().trim(),n=(e.label||"").toLowerCase().trim(),i=(e.name||"").toLowerCase().trim().replace(/[_-]/g," "),a=(e.domId||"").toLowerCase().trim().replace(/[_-]/g," "),r=(e.placeholder||"").toLowerCase().trim(),l=(e.ariaLabel||"").toLowerCase().trim(),d=(e.nearbyText||"").toLowerCase().trim();let o=null;for(const c of Be){if(t&&c.autocompleteTokens.includes(t))return{def:c,confidence:95,reason:`HTML autocomplete="${t}"`};if(!(c.negativeAliases&&c.negativeAliases.some(m=>n.includes(m)||i.includes(m)))){for(const p of c.aliases)if(n===p||i===p||a===p||l===p)return{def:c,confidence:95,reason:`Exact match for "${p}"`};for(const p of c.aliases){const m=new RegExp(`\\b${Wn(p)}\\b`,"i"),u=p.trim().split(/\s+/).length,f=Math.min(6,(u-1)*2);if(m.test(n)){const y=88+f;(!o||y>o.confidence)&&(o={def:c,confidence:Math.min(95,y),reason:`Label contains "${p}"`})}else if(m.test(i)||m.test(a)||m.test(l)){const y=85+f;(!o||y>o.confidence)&&(o={def:c,confidence:Math.min(95,y),reason:`Field name/id contains "${p}"`})}else if(m.test(r)){const y=80+f;(!o||y>o.confidence)&&(o={def:c,confidence:Math.min(90,y),reason:`Placeholder contains "${p}"`})}else if(d&&m.test(d)){const y=70+f;(!o||y>o.confidence)&&(o={def:c,confidence:Math.min(85,y),reason:`Nearby text contains "${p}"`})}}}}if(!o){if(e.inputType==="email"){const c=Be.find(p=>p.type==="email");if(c)return{def:c,confidence:90,reason:"Input type is email"}}if(e.inputType==="tel"){const c=Be.find(p=>p.type==="phone");if(c)return{def:c,confidence:90,reason:"Input type is tel"}}}return o}resolveProfileValue(e,t,n){var i,a,r;switch(e){case"fullName":return{value:t.legalFullName||(t.givenName&&t.familyName?`${t.givenName} ${t.familyName}`:t.givenName||t.preferredName)||null};case"firstName":return t.givenName?{value:t.givenName}:t.legalFullName?{value:t.legalFullName.trim().split(/\s+/)[0]}:t.preferredName?{value:t.preferredName}:{value:null,reason:"First name not found in profile"};case"middleName":{if(t.middleName)return{value:t.middleName};if(t.legalFullName){const l=t.legalFullName.trim().split(/\s+/);if(l.length>=3)return{value:l.slice(1,-1).join(" ")}}return{value:""}}case"lastName":{if(t.familyName)return{value:t.familyName};if(t.legalFullName){const l=t.legalFullName.trim().split(/\s+/);if(l.length>=2)return{value:l[l.length-1]}}return{value:null,requiresManualInput:!0,reason:"Manual input required (no last name in profile)"}}case"preferredName":return{value:t.preferredName||t.givenName||null};case"email":return{value:t.email||null};case"phone":return{value:t.phone||null};case"dateOfBirth":return{value:t.dateOfBirth||null};case"gender":return n.options.length>0&&t.gender?{value:this.matchOption(n.options,t.gender)||t.gender}:{value:t.gender||null};case"address":return{value:t.address||null};case"city":return{value:t.city||null};case"state":return{value:t.state||null};case"country":return n.options.length>0&&t.country?{value:this.matchOption(n.options,t.country)||t.country}:{value:t.country||null};case"postalCode":return{value:t.postalCode||null};case"linkedinUrl":return{value:t.linkedinUrl||null};case"githubUrl":return t.githubUrl?{value:t.githubUrl}:{value:((i=t.otherLinks)==null?void 0:i.find(d=>d.includes("github.com")))||null};case"portfolioUrl":return{value:t.portfolioUrl||null};case"websiteUrl":return t.websiteUrl?{value:t.websiteUrl}:{value:t.portfolioUrl||((a=t.otherLinks)==null?void 0:a[0])||null};case"skills":return{value:t.skills&&t.skills.length>0?t.skills.join(", "):null};case"institution":return{value:t.institution||null};case"degree":return n.options.length>0&&t.degree?{value:this.matchOption(n.options,t.degree)||t.degree}:{value:t.degree||null};case"specialization":return{value:t.specialization||null};case"graduationYear":return{value:t.graduationYear?String(t.graduationYear):null};case"cgpa":return{value:t.cgpa||null};case"workAuthorization":return n.tag==="radio"||n.tag==="select"?{value:this.matchOption(n.options,"Yes")||this.matchOption(n.options,"Authorized")||"yes"}:{value:t.workAuthorization||"Yes, authorized to work"};case"visaStatus":return n.tag==="radio"||n.tag==="select"?{value:this.matchOption(n.options,"No")||this.matchOption(n.options,"Not required")||"no"}:{value:t.visaStatus||"No sponsorship required"};case"expectedSalary":return{value:t.expectedSalary||null};case"noticePeriod":return{value:t.noticePeriod||null};case"currentCompany":return{value:t.currentCompany||null};case"currentJobTitle":return{value:t.currentJobTitle||(((r=t.preferredRoles)==null?void 0:r[0])??null)};case"yearsOfExperience":return{value:t.experienceYears!==null&&t.experienceYears!==void 0?String(t.experienceYears):null};default:return{value:null}}}matchOption(e,t){if(!e||e.length===0||!t)return null;const n=t.toLowerCase().trim();for(const i of e)if(i.value.toLowerCase()===n||i.label.toLowerCase()===n)return i.value;for(const i of e){const a=i.label.toLowerCase(),r=i.value.toLowerCase();if(a.includes(n)||n.includes(a)||r.includes(n))return i.value}return null}isResumeField(e){const t=`${e.label} ${e.name} ${e.domId} ${e.placeholder}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("cv")||t.includes("curriculum vitae")}isSensitiveQuestion(e){const t=`${e.label} ${e.name} ${e.domId} ${e.ariaLabel} ${e.placeholder} ${e.nearbyText}`.toLowerCase();return t.includes("disability")||t.includes("veteran")||t.includes("equal opportunity")||t.includes("criminal")||t.includes("background check")||t.includes("legal declaration")||t.includes("terms and conditions")||t.includes("agree to terms")||t.includes("consent to")||t.includes("digital signature")||t.includes("sign here")}isCustomQuestion(e){const t=`${e.label} ${e.placeholder} ${e.ariaLabel}`.toLowerCase(),n=[/why do you want/i,/why are you interested/i,/describe your/i,/tell us about/i,/why should we hire/i,/cover letter/i,/additional information/i,/what makes you/i,/anything else/i,/personal statement/i];return e.tag==="textarea"&&t.length>20||n.some(i=>i.test(t))}}function Wn(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const Pt=new Vn;class Gn{autofillFields(e,t=!1){var l,d;let n=0,i=0,a=0;const r=[];for(const o of e){if(!o.canAutofill||o.valueToFill===null||o.valueToFill===void 0){i++;continue}const c=o.field.element;if(!c){i++;continue}const p=c.value||o.field.currentValue;if(typeof p=="string"&&p.trim().length>0&&((l=c.getAttribute)==null?void 0:l.call(c,"data-talvyn-autofilled"))!=="true"&&!t){i++;continue}try{this.fillSingleField(o.field.element,o.valueToFill,o.field.tag)?(o.isFilled=!0,(d=c.setAttribute)==null||d.call(c,"data-talvyn-autofilled","true"),n++,r.push(o)):a++}catch(u){console.error("[Talvyn Autofill] Failed to fill field:",o.field.name||o.field.domId,u),o.error=u instanceof Error?u.message:"Fill failed",a++}}return{filledCount:n,skippedCount:i,failedCount:a,filledFields:r}}getStepSignature(e){return e.map(t=>`${t.field.name||t.field.domId||t.field.label}:${t.matchedKey}`).sort().join("|")}isMultiStepApplication(e=document){const t=e.querySelectorAll('[class*="step" i], [aria-label*="step" i], [data-test*="step" i], [class*="progress" i], .wizard'),n=e.querySelector('button[class*="next" i], button[id*="next" i], [data-qa="next-step"]');return{isMultiStep:t.length>0||!!n}}fillSingleField(e,t,n){if(!e)return!1;const i=(e.tagName||n||"").toUpperCase(),a=(e.type||"").toLowerCase();if(i==="INPUT"&&a!=="radio"&&a!=="checkbox"&&a!=="file")return this.setNativeInputValue(e,String(t));if(i==="TEXTAREA")return this.setNativeTextareaValue(e,String(t));if(i==="SELECT")return this.setNativeSelectValue(e,String(t));if(i==="INPUT"&&a==="radio")return this.setNativeRadioValue(e,String(t));if(i==="INPUT"&&a==="checkbox"){const r=typeof t=="boolean"?t:t==="true"||t==="1"||t==="yes";return this.setNativeCheckboxValue(e,r)}return!1}setNativeInputValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:r.set:null;return i?i.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeTextareaValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLTextAreaElement?window.HTMLTextAreaElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:r.set:null;return i?i.call(e,t):e.value=t,this.dispatchInputEvents(e),!0}setNativeSelectValue(e,t){var a;e.focus();const n=t.toLowerCase().trim();let i=-1;for(let r=0;r<e.options.length;r++){const l=e.options[r],d=l.value.toLowerCase().trim(),o=(l.textContent||"").toLowerCase().trim();if(d===n||o===n){i=r;break}(o.includes(n)||n.includes(o))&&(i=r)}if(i>=0){e.selectedIndex=i;const r=typeof window<"u"&&window.HTMLSelectElement?window.HTMLSelectElement.prototype:null,l=r?(a=Object.getOwnPropertyDescriptor(r,"value"))==null?void 0:a.set:null;return l&&l.call(e,e.options[i].value),this.dispatchInputEvents(e),!0}return!1}setNativeRadioValue(e,t){var r;const n=e.name;if(!n)return e.checked=!0,this.dispatchInputEvents(e),!0;const i=Array.from(document.querySelectorAll(`input[type="radio"][name="${CSS.escape(n)}"]`)),a=t.toLowerCase().trim();for(const l of i){const d=l.value.toLowerCase().trim(),o=(((r=l.parentElement)==null?void 0:r.textContent)||"").toLowerCase().trim();if(d===a||o.includes(a))return l.checked=!0,this.dispatchInputEvents(l),!0}return!1}setNativeCheckboxValue(e,t){var a,r;(a=e.focus)==null||a.call(e);const n=typeof window<"u"&&window.HTMLInputElement?window.HTMLInputElement.prototype:null,i=n?(r=Object.getOwnPropertyDescriptor(n,"checked"))==null?void 0:r.set:null;return i?i.call(e,t):e.checked=t,this.dispatchInputEvents(e),!0}dispatchInputEvents(e){typeof Event>"u"||!e.dispatchEvent||(e.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("change",{bubbles:!0,composed:!0})),e.dispatchEvent(new Event("blur",{bubbles:!0,composed:!0})))}}const ze=new Gn,Ve="talvyn-autofill-panel";class Yn{constructor(){this.isMinimized=!1,this.summary=null,this.callbacks=null,this.selectedResumeId=null}render(e,t){this.summary=e,this.callbacks=t,!this.selectedResumeId&&e.defaultResume&&(this.selectedResumeId=e.defaultResume.id),this.remove();const n=document.createElement("div");n.id=Ve,n.setAttribute("data-talvyn","true"),n.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(n,this.isMinimized),document.body.appendChild(n),this.attachEventListeners(n)}updateSummary(e){this.summary=e;const t=document.getElementById(Ve);!t||!this.callbacks||(t.innerHTML=this.isMinimized?this.buildMinimizedHTML(e):this.buildExpandedHTML(e),this.applyStyles(t,this.isMinimized),this.attachEventListeners(t))}remove(){var e;(e=document.getElementById(Ve))==null||e.remove()}buildMinimizedHTML(e){return`
      <div id="talvyn-autofill-expand-btn" style="
        display:flex;align-items:center;gap:8px;padding:10px 15px;
        background:#4f46e5;color:white;border-radius:24px;cursor:pointer;
        box-shadow:0 6px 24px rgba(79,70,229,0.45);font-weight:600;font-size:13px;
        transition:transform 0.15s, background 0.15s;user-select:none;
      ">
        <span style="font-size:15px;">⚡</span>
        <span>Talvyn Autofill (${e.highConfidenceCount+e.mediumConfidenceCount} fields ready)</span>
      </div>
    `}buildExpandedHTML(e){const t=e.highConfidenceCount,n=e.highConfidenceCount+e.mediumConfidenceCount;return`
      <div style="display:flex;flex-direction:column;max-height:580px;">
        <!-- Header -->
        <div style="
          padding:14px 16px;background:#4f46e5;border-top-left-radius:14px;
          border-top-right-radius:14px;color:white;display:flex;align-items:center;
          justify-content:space-between;flex-shrink:0;
        ">
          <div style="display:flex;align-items:center;gap:9px;">
            <div style="
              width:26px;height:26px;background:rgba(255,255,255,0.2);border-radius:8px;
              display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;
            ">⚡</div>
            <div>
              <div style="font-weight:700;font-size:14px;letter-spacing:-0.2px;">Talvyn Autofill</div>
              <div style="font-size:11px;color:rgba(255,255,255,0.85);">${e.totalFields} form fields detected</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-autofill-minimize-btn" title="Minimize panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">−</button>
            <button id="talvyn-autofill-close-btn" title="Close panel" style="
              background:rgba(255,255,255,0.15);border:none;color:white;width:24px;height:24px;
              border-radius:6px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
            ">×</button>
          </div>
        </div>

        <!-- Metrics Bar -->
        <div style="
          padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e2e8f0;
          display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:4px;
        ">
          <div style="display:flex;gap:5px;flex-wrap:wrap;">
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0;
            ">
              ✓ ${e.highConfidenceCount} High Confidence
            </span>
            <span style="
              font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
              background:#fffbeb;color:#92400e;border:1px solid #fde68a;
            ">
              🔍 ${e.mediumConfidenceCount} Review
            </span>
            ${e.customQuestionsCount>0?`
              <span style="
                font-size:11px;font-weight:600;padding:2px 8px;border-radius:12px;
                background:#eff6ff;color:#1e40af;border:1px solid #bfdbfe;
              ">
                ✍ ${e.customQuestionsCount} Custom
              </span>
            `:""}
          </div>
          <button id="talvyn-rescan-btn" title="Re-scan DOM fields" style="
            background:transparent;border:none;color:#6366f1;font-size:11px;font-weight:600;
            cursor:pointer;padding:2px 4px;
          ">Re-scan ↺</button>
        </div>

        <!-- Resume Selection Banner (if file upload detected) -->
        ${e.resumeUploadDetected?this.renderResumeBanner(e):""}

        <!-- Scrollable Matched Fields List -->
        <div id="talvyn-autofill-fields-container" style="
          padding:12px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:8px;
          background:#f8fafc;
        ">
          ${e.matchedFields.length===0?`
            <div style="text-align:center;padding:32px 16px;color:#94a3b8;font-size:12px;">
              No form fields detected. Click Re-scan or open an application modal.
            </div>
          `:e.matchedFields.map(i=>this.renderFieldCard(i)).join("")}
        </div>

        <!-- Primary Action Buttons -->
        <div style="
          padding:12px 14px;background:#ffffff;border-top:1px solid #e2e8f0;
          display:flex;flex-direction:column;gap:8px;flex-shrink:0;
        ">
          <div style="display:flex;gap:8px;">
            <button id="talvyn-autofill-high-btn" style="
              flex:1;padding:9px 12px;background:#4f46e5;color:white;border:none;
              border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              transition:background 0.15s;
            ">
              ⚡ Autofill High Confidence (${t})
            </button>
            ${e.mediumConfidenceCount>0?`
              <button id="talvyn-autofill-all-btn" style="
                padding:9px 12px;background:#f0f4ff;color:#4338ca;border:1px solid #c7d2fe;
                border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;
              ">
                Fill All (${n})
              </button>
            `:""}
          </div>

          <!-- Safety Notice -->
          <div style="font-size:10px;color:#64748b;line-height:1.3;text-align:center;">
            🔒 Talvyn never auto-submits. Review all entries before clicking Submit manually.
          </div>
        </div>
      </div>
    `}renderResumeBanner(e){const t=e.availableResumes||[],n=e.defaultResume;return`
      <div style="
        padding:10px 14px;background:#f0fdf4;border-bottom:1px solid #bbf7d0;
        display:flex;align-items:center;justify-content:space-between;flex-shrink:0;gap:8px;
      ">
        <div style="display:flex;align-items:center;gap:6px;min-width:0;">
          <span style="font-size:14px;">📄</span>
          <div style="min-width:0;">
            <div style="font-size:11px;font-weight:700;color:#166534;">Resume Upload Detected</div>
            <div style="font-size:11px;color:#15803d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${n?`Default: <strong>${this.escapeHtml(n.name)}</strong>`:"No default resume set in Talvyn"}
            </div>
          </div>
        </div>
        ${t.length>1?`
          <select id="talvyn-resume-select" style="
            font-size:11px;padding:3px 6px;border-radius:6px;border:1px solid #86efac;
            background:white;color:#166534;font-weight:500;
          ">
            ${t.map(i=>`
              <option value="${i.id}" ${i.id===this.selectedResumeId?"selected":""}>
                ${this.escapeHtml(i.name)}${i.isDefault?" (Default)":""}
              </option>
            `).join("")}
          </select>
        `:`
          <a href="${le.DASHBOARD_URL}/resumes" target="_blank" style="
            font-size:11px;color:#16a34a;font-weight:600;text-decoration:none;
          ">Resumes →</a>
        `}
      </div>
    `}renderFieldCard(e){const{field:t,detectedType:n,confidence:i,confidenceLevel:a,valueToFill:r,reason:l,canAutofill:d,isCustomQuestion:o,isResumeUpload:c,isFilled:p}=e,m=t.label||t.placeholder||t.name||t.domId||"Untitled Field",u=r!=null?String(r):null;let f="#f1f5f9",y="#475569",h=`${i}% · Unknown`;return c?(f="#dcfce7",y="#15803d",h="Resume File"):o?(f="#eff6ff",y="#1d4ed8",h="Custom Question"):a==="HIGH"?(f="#ecfdf5",y="#047857",h=`${i}% · High`):a==="MEDIUM"&&(f="#fffbeb",y="#b45309",h=`${i}% · Review`),`
      <div style="
        background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;
        padding:10px 12px;box-shadow:0 1px 2px rgba(0,0,0,0.03);
      ">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:6px;margin-bottom:4px;">
          <div style="font-weight:600;font-size:12px;color:#1e293b;line-height:1.3;flex:1;">
            ${this.escapeHtml(m)}
            ${t.isRequired?'<span style="color:#ef4444;font-weight:700;"> *</span>':""}
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:6px;
            background:${f};color:${y};flex-shrink:0;white-space:nowrap;
          ">${h}</span>
        </div>

        <div style="font-size:11px;color:#64748b;margin-bottom:6px;">
          Mapped: <span style="font-weight:600;color:#4f46e5;">${n}</span>
        </div>

        <!-- Value Preview -->
        ${u!==null?`
          <div style="
            font-size:11px;background:#f8fafc;padding:5px 8px;border-radius:6px;
            border:1px solid #f1f5f9;color:#0f172a;font-family:monospace;margin-bottom:6px;
            word-break:break-all;
          ">
            Value: <strong>${this.escapeHtml(u)}</strong>
          </div>
        `:o?`
          <div style="font-size:11px;color:#3b82f6;background:#eff6ff;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ✍ Custom question — manual response recommended.
          </div>
        `:c?`
          <div style="font-size:11px;color:#059669;background:#ecfdf5;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            📄 Upload using your selected Talvyn resume above.
          </div>
        `:`
          <div style="font-size:11px;color:#d97706;background:#fffbeb;padding:5px 8px;border-radius:6px;margin-bottom:6px;">
            ⚠️ Manual input required (empty in profile).
          </div>
        `}

        <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;font-size:10px;color:#94a3b8;">
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:240px;">
            ${this.escapeHtml(l)}
          </span>
          ${d?`
            <button class="talvyn-fill-single-btn" data-field-id="${this.escapeHtml(t.id)}" style="
              padding:3px 8px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;
              border:1px solid #c7d2fe;background:${p?"#10b981":"#f0f4ff"};
              color:${p?"#ffffff":"#4338ca"};
            ">${p?"Filled ✓":"Fill"}</button>
          `:""}
        </div>
      </div>
    `}attachEventListeners(e){var i,a,r,l,d,o;(i=e.querySelector("#talvyn-autofill-minimize-btn"))==null||i.addEventListener("click",()=>{this.isMinimized=!0,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(a=e.querySelector("#talvyn-autofill-expand-btn"))==null||a.addEventListener("click",()=>{this.isMinimized=!1,this.summary&&this.callbacks&&this.render(this.summary,this.callbacks)}),(r=e.querySelector("#talvyn-autofill-close-btn"))==null||r.addEventListener("click",()=>{var c;this.remove(),(c=this.callbacks)==null||c.onDismiss()}),(l=e.querySelector("#talvyn-rescan-btn"))==null||l.addEventListener("click",()=>{var c;(c=this.callbacks)==null||c.onRescan()}),(d=e.querySelector("#talvyn-autofill-high-btn"))==null||d.addEventListener("click",async c=>{var m;const p=c.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((m=this.callbacks)==null?void 0:m.onAutofillHighConfidence()),p.textContent="Autofilled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Autofill High Confidence"}}),(o=e.querySelector("#talvyn-autofill-all-btn"))==null||o.addEventListener("click",async c=>{var m;const p=c.currentTarget;p.disabled=!0,p.textContent="Autofilling…";try{await((m=this.callbacks)==null?void 0:m.onAutofillAllEligible()),p.textContent="All Filled ✓",p.style.background="#10b981"}catch{p.disabled=!1,p.textContent="Fill All"}}),e.querySelectorAll(".talvyn-fill-single-btn").forEach(c=>{c.addEventListener("click",async p=>{var y;const m=p.currentTarget,u=m.getAttribute("data-field-id"),f=(y=this.summary)==null?void 0:y.matchedFields.find(h=>h.field.id===u);if(f&&this.callbacks){m.disabled=!0,m.textContent="Filling…";try{await this.callbacks.onAutofillSingleField(f),m.textContent="Filled ✓",m.style.background="#10b981",m.style.color="#ffffff"}catch{m.disabled=!1,m.textContent="Fill"}}})});const n=e.querySelector("#talvyn-resume-select");n==null||n.addEventListener("change",c=>{var u,f,y;const p=c.target.value;this.selectedResumeId=p;const m=(f=(u=this.summary)==null?void 0:u.availableResumes)==null?void 0:f.find(h=>h.id===p);m&&((y=this.callbacks)!=null&&y.onSelectResume)&&this.callbacks.onSelectResume(m)})}applyStyles(e,t){t?Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",zIndex:"2147483647",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'}):Object.assign(e.style,{position:"fixed",bottom:"20px",right:"20px",width:"390px",maxHeight:"600px",zIndex:"2147483647",background:"#ffffff",borderRadius:"14px",boxShadow:"0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06)",fontFamily:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',fontSize:"13px",lineHeight:"1.4",border:"1px solid rgba(79,70,229,0.25)",boxSizing:"border-box",overflow:"hidden"})}escapeHtml(e){return(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}}const we=new Yn,lt={list:()=>et.get("/api/resumes")};class Qn{constructor(){this.isPanelActive=!1,this.currentSummary=null}isApplicationFormPage(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async scanAndAnalyzeForm(e,t,n,i=[]){const l=ge.getAdapter(e,t).findFormRoots(t).flatMap(g=>Ne.detectFields(g)),o=Array.from(new Map(l.map(g=>[g.element,g])).values()).map(g=>Pt.matchField(g,n));let c=0,p=0,m=0,u=0,f=0,y=!1;for(const g of o)g.isResumeUpload&&(y=!0),g.isCustomQuestion&&f++,g.confidenceLevel==="HIGH"?c++:g.confidenceLevel==="MEDIUM"?p++:g.confidenceLevel==="LOW"?m++:u++;const h=i.find(g=>g.isDefault)||(i.length>0?i[0]:null),x={totalFields:o.length,highConfidenceCount:c,mediumConfidenceCount:p,lowConfidenceCount:m,unknownCount:u,customQuestionsCount:f,resumeUploadDetected:y,matchedFields:o,availableResumes:i,defaultResume:h,pageUrl:e,detectedAt:new Date().toISOString()};return this.currentSummary=x,x}async activateAutofill(e,t,n){let i=[];try{i=await lt.list()}catch{}const a=await this.scanAndAnalyzeForm(e,t,n,i);return a.totalFields===0?(this.dismiss(),!1):(this.isPanelActive=!0,we.render(a,{onAutofillHighConfidence:async()=>{const r=a.matchedFields.filter(l=>l.confidenceLevel==="HIGH");ze.autofillFields(r,!1),we.updateSummary(a)},onAutofillAllEligible:async()=>{const r=a.matchedFields.filter(l=>l.canAutofill);ze.autofillFields(r,!1),we.updateSummary(a)},onAutofillSingleField:async r=>{ze.autofillFields([r],!0),we.updateSummary(a)},onRescan:async()=>{await this.activateAutofill(window.location.href,document,n)},onDismiss:()=>{this.dismiss()}}),!0)}dismiss(){we.remove(),this.isPanelActive=!1}isActive(){return this.isPanelActive}}const ee=new Qn;function Zn(s){const e=s.toLowerCase();return e.includes("declare")||e.includes("certify that")||e.includes("agree to terms")||e.includes("under penalty of perjury")||e.includes("accurate and complete")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Legal declaration or agreement requires user manual verification."}:e.includes("criminal")||e.includes("convicted")||e.includes("disability")||e.includes("veteran")||e.includes("gender identity")||e.includes("race")||e.includes("ethnicity")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Sensitive equal opportunity / compliance question requires personal selection."}:e.includes("salary expectation")||e.includes("desired salary")||e.includes("compensation requirement")||e.includes("minimum rate")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Salary expectation is a sensitive negotiation decision."}:e.includes("sponsorship")||e.includes("visa")||e.includes("authorized to work")||e.includes("work authorization")||e.includes("work permit")||e.includes("legally authorized")?{riskLevel:"USER_ACTION_REQUIRED",reason:"Work authorization & visa sponsorship status must be confirmed manually."}:e.includes("why")||e.includes("describe")||e.includes("tell us")||e.includes("project")||e.includes("cover letter")?{riskLevel:"ASSISTED_ANSWER",reason:"Open-ended question with Talvyn answer suggestion."}:{riskLevel:"SAFE_AUTOFILL"}}class Kn{categorizeField(e){const t=`${e.name} ${e.label} ${e.domId} ${e.placeholder} ${e.ariaLabel} ${e.nearbyText}`.toLowerCase();return e.inputType==="file"||t.includes("resume")||t.includes("curriculum vitae")||t.includes("cv")||t.includes("cover letter")||t.includes("portfolio upload")?"DOCUMENTS":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("institution")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("first name")||t.includes("last name")||t.includes("full name")||t.includes("legal name")||t.includes("given name")||t.includes("family name")||t.includes("preferred name")||t.includes("name")&&!t.includes("company")&&!t.includes("school")&&!t.includes("university")||t.includes("email")||t.includes("phone")||t.includes("mobile")||t.includes("address")||t.includes("street")||t.includes("city")||t.includes("state")||t.includes("country")||t.includes("postal")||t.includes("zip")?"PERSONAL":t.includes("linkedin")||t.includes("github")||t.includes("portfolio")||t.includes("website")||t.includes("experience")||t.includes("current company")||t.includes("employer")||t.includes("title")||t.includes("skills")?"PROFESSIONAL":t.includes("college")||t.includes("university")||t.includes("school")||t.includes("degree")||t.includes("major")||t.includes("specialization")||t.includes("gpa")||t.includes("cgpa")||t.includes("graduation")?"EDUCATION":t.includes("work authorization")||t.includes("sponsorship")||t.includes("salary")||t.includes("compensation")||t.includes("notice period")||t.includes("location preference")||t.includes("relocate")?"PREFERENCES":e.tag==="textarea"||t.includes("why")||t.includes("describe")||t.includes("tell us")||t.includes("gender")||t.includes("veteran")||t.includes("disability")||t.includes("declare")?"QUESTIONS":"OTHER"}analyzeFields(e,t){return e.map(n=>{const i=this.categorizeField(n),a=n.label||n.placeholder||n.name||"Application Field",{riskLevel:r,reason:l}=Zn(a),d=n.currentValue,o=typeof d=="string"?d.trim().length>0:typeof d=="boolean"?d:!1;return{id:n.id,field:n,category:i,canonicalName:n.name||n.domId||n.id,label:a,isRequired:n.isRequired,isFilled:o,filledBy:o?"USER_INPUT":"UNFILLED",currentValue:d,suggestedValue:null,riskLevel:r,riskReason:l,confidence:85}})}calculateProgress(e){const t={PERSONAL:{total:0,filled:0,required:0,requiredFilled:0},PROFESSIONAL:{total:0,filled:0,required:0,requiredFilled:0},EDUCATION:{total:0,filled:0,required:0,requiredFilled:0},DOCUMENTS:{total:0,filled:0,required:0,requiredFilled:0},QUESTIONS:{total:0,filled:0,required:0,requiredFilled:0},PREFERENCES:{total:0,filled:0,required:0,requiredFilled:0},OTHER:{total:0,filled:0,required:0,requiredFilled:0}};let n=0,i=0,a=0,r=0;for(const c of e){if(c.field.isIgnored)continue;n++;const p=t[c.category];p.total++,c.isFilled&&(i++,p.filled++),c.isRequired&&(a++,p.required++,c.isFilled&&(r++,p.requiredFilled++))}const l=n>0?Math.round(i/n*100):0,d=a>0?r===a:i===n,o=l>=80&&(a===0||r===a);return{totalFields:n,filledFields:i,requiredFields:a,requiredFilledFields:r,percentage:l,categoryProgress:t,isComplete:d,isReadyForReview:o}}}const Ie=new Kn;class Xn{recommendResume(e,t,n,i=[]){if(!e||e.length===0)return[];const a=(t||"").toLowerCase();return(n||"").toLowerCase(),e.map(l=>{let d=50;const o=[],c=(l.name||"").toLowerCase(),p=(l.description||"").toLowerCase();l.isDefault&&(d+=15,o.push("Default primary resume"));const m=a.split(/\s+/).filter(y=>y.length>2);for(const y of m)if(c.includes(y)){d+=20,o.push(`Resume title matches "${y}"`);break}const u=[{key:"backend",terms:["backend","server","java","node","python","api","golang"]},{key:"frontend",terms:["frontend","react","vue","angular","ui","web","javascript"]},{key:"fullstack",terms:["fullstack","full stack","software engineer","sde","swe"]},{key:"data",terms:["data","analytics","analyst","scientist","sql","bi"]},{key:"mobile",terms:["ios","android","flutter","react native","mobile"]},{key:"cloud",terms:["devops","cloud","aws","kubernetes","sre"]},{key:"design",terms:["design","ui/ux","product design","figma"]},{key:"product",terms:["product manager","pm","product owner"]}];for(const y of u){const h=y.terms.some(g=>a.includes(g)),x=y.terms.some(g=>c.includes(g)||p.includes(g));if(h&&x){d+=25,o.push(`Domain expertise match: ${y.key.toUpperCase()}`);break}}for(const y of i){const h=y.toLowerCase();if(h.length>2&&(p.includes(h)||c.includes(h))){d+=5,o.push(`Matches skill: ${y}`);break}}const f=Math.min(100,Math.max(0,d));return{resume:l,score:f,matchReasons:o.length>0?o:["General profile match"],isDefault:!!l.isDefault}}).sort((l,d)=>d.score!==l.score?d.score-l.score:d.isDefault&&!l.isDefault?1:!d.isDefault&&l.isDefault?-1:0)}getBestResume(e,t,n,i=[]){const a=this.recommendResume(e,t,n,i);return a.length>0?a[0]:null}}const ei=new Xn,vt="talvyn-application-assistant-root";class ti{constructor(){this.container=null,this.isCollapsed=!1}render(e,t,n,i){var m,u,f,y;this.onAutofillCallback=i.onAutofill,this.onSelectResumeCallback=i.onSelectResume,this.onDismissCallback=i.onDismiss;let a=document.getElementById(vt);a||(a=document.createElement("div"),a.id=vt,a.style.position="fixed",a.style.bottom="24px",a.style.right="24px",a.style.zIndex="2147483645",a.style.fontFamily='-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',document.body.appendChild(a)),this.container=a;const{jobTitle:r,company:l,progress:d,highRiskQuestions:o}=e,c=o.length;if(this.isCollapsed){this.container.innerHTML=`
        <div style="
          background: #ffffff;
          border: 1px solid #e2e8f0;
          border-radius: 9999px;
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
          padding: 8px 16px;
          display: flex;
          align-items: center;
          gap: 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        " id="talvyn-assistant-expand-btn">
          <div style="width: 24px; height: 24px; border-radius: 6px; background: #6366f1; display: flex; align-items: center; justify-content: center; color: #ffffff; font-weight: bold; font-size: 13px;">T</div>
          <span style="font-size: 13px; font-weight: 600; color: #1e293b;">Talvyn Assistant</span>
          <span style="font-size: 12px; font-weight: 600; color: #6366f1; background: #eef2ff; padding: 2px 8px; border-radius: 9999px;">${d.filledFields}/${d.totalFields}</span>
        </div>
      `,(m=document.getElementById("talvyn-assistant-expand-btn"))==null||m.addEventListener("click",()=>{this.isCollapsed=!1,this.render(e,t,n,i)});return}this.container.innerHTML=`
      <div style="
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
        width: 330px;
        overflow: hidden;
        animation: talvynSlideUp 0.2s ease-out;
      ">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%); padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; color: #ffffff;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 24px; height: 24px; border-radius: 6px; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 12px;">T</div>
            <div>
              <div style="font-size: 13px; font-weight: 700; line-height: 1.2;">Application Assistant</div>
              <div style="font-size: 11px; opacity: 0.85; line-height: 1.2;">${l||"Active Application"}</div>
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 4px;">
            <button id="talvyn-assistant-collapse-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Minimize">−</button>
            <button id="talvyn-assistant-close-btn" style="background: transparent; border: none; color: #ffffff; opacity: 0.8; cursor: pointer; padding: 4px; font-size: 14px;" title="Close">×</button>
          </div>
        </div>

        <!-- Body -->
        <div style="padding: 14px 16px; display: flex; flex-col; gap: 12px; max-height: 380px; overflow-y: auto;">
          <!-- Target Role -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px;">Applying For</div>
            <div style="font-size: 14px; font-weight: 600; color: #0f172a; margin-top: 2px;">${r||"Current Position"}</div>
          </div>

          <!-- Live Form Progress Bar -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span style="font-size: 12px; font-weight: 600; color: #334155;">Form Completion</span>
              <span style="font-size: 12px; font-weight: 700; color: #6366f1;">${d.filledFields} / ${d.totalFields} fields (${d.percentage}%)</span>
            </div>
            <div style="width: 100%; height: 6px; background: #e2e8f0; border-radius: 9999px; overflow: hidden;">
              <div style="width: ${d.percentage}%; height: 100%; background: #6366f1; border-radius: 9999px; transition: width 0.3s ease;"></div>
            </div>
          </div>

          <!-- Recommended Resume Selection -->
          <div style="border-bottom: 1px solid #f1f5f9; padding-bottom: 10px;">
            <div style="font-size: 11px; text-transform: uppercase; font-weight: 700; color: #94a3b8; letter-spacing: 0.5px; margin-bottom: 4px;">Recommended Resume</div>
            <div style="display: flex; align-items: center; justify-content: space-between; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px 10px;">
              <div style="display: flex; align-items: center; gap: 6px; overflow: hidden;">
                <span style="font-size: 14px;">📄</span>
                <span style="font-size: 12px; font-weight: 600; color: #1e293b; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                  ${t?t.resume.name:"Standard Profile CV"}
                </span>
              </div>
              ${n.length>1?`
                <select id="talvyn-assistant-resume-select" style="font-size: 11px; border: 1px solid #cbd5e1; border-radius: 4px; padding: 2px 4px; background: #ffffff; color: #334155; cursor: pointer;">
                  ${n.map(h=>`<option value="${h.id}" ${h.id===(t==null?void 0:t.resume.id)?"selected":""}>${h.name}</option>`).join("")}
                </select>
              `:""}
            </div>
          </div>

          <!-- Attention Needed Warnings -->
          ${c>0?`
            <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 8px 10px; display: flex; align-items: start; gap: 8px;">
              <span style="color: #d97706; font-size: 13px;">⚠️</span>
              <div>
                <div style="font-size: 12px; font-weight: 600; color: #92400e;">${c} Field${c>1?"s":""} Need Attention</div>
                <div style="font-size: 11px; color: #b45309; line-height: 1.3;">Personal / Legal questions require manual verification.</div>
              </div>
            </div>
          `:""}

          <!-- Action Buttons -->
          <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 4px;">
            <button id="talvyn-assistant-autofill-btn" style="
              width: 100%;
              background: #6366f1;
              color: #ffffff;
              border: none;
              border-radius: 8px;
              padding: 9px 12px;
              font-size: 13px;
              font-weight: 600;
              cursor: pointer;
              box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
              transition: background 0.15s;
            ">
              ⚡ Autofill Remaining Fields
            </button>
          </div>

          <!-- Safety Notice -->
          <div style="text-align: center; font-size: 10px; color: #94a3b8; margin-top: 2px;">
            🛡️ Talvyn assists you. You always review before final submit.
          </div>
        </div>
      </div>
    `,(u=document.getElementById("talvyn-assistant-collapse-btn"))==null||u.addEventListener("click",()=>{this.isCollapsed=!0,this.render(e,t,n,i)}),(f=document.getElementById("talvyn-assistant-close-btn"))==null||f.addEventListener("click",()=>{var h;this.remove(),(h=this.onDismissCallback)==null||h.call(this)}),(y=document.getElementById("talvyn-assistant-autofill-btn"))==null||y.addEventListener("click",()=>{var h;(h=this.onAutofillCallback)==null||h.call(this)});const p=document.getElementById("talvyn-assistant-resume-select");p==null||p.addEventListener("change",h=>{var g;const x=h.target.value;(g=this.onSelectResumeCallback)==null||g.call(this,x)})}remove(){this.container&&this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.container=null}}const wt=new ti,qe="talvyn_active_application_session",St=30*60*1e3;class ni{constructor(){this.inMemorySession=null}async getActiveSession(){var e;try{if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const n=(await chrome.storage.local.get(qe))[qe];if(n)return Date.now()-new Date(n.lastActivityAt).getTime()<St?(this.inMemorySession=n,n):(await this.clearSession(),null)}}catch{}if(this.inMemorySession){if(Date.now()-new Date(this.inMemorySession.lastActivityAt).getTime()<St)return this.inMemorySession;this.inMemorySession=null}return null}async createOrUpdateSession(e){var a;const t=await this.getActiveSession(),n=new Date().toISOString(),i={id:(t==null?void 0:t.id)||`app-session-${Date.now()}`,pageUrl:e.pageUrl||(t==null?void 0:t.pageUrl)||window.location.href,jobUrl:e.jobUrl||(t==null?void 0:t.jobUrl)||null,jobTitle:e.jobTitle||(t==null?void 0:t.jobTitle)||null,company:e.company||(t==null?void 0:t.company)||null,location:e.location||(t==null?void 0:t.location)||null,startedAt:(t==null?void 0:t.startedAt)||n,lastActivityAt:n,submitted:e.submitted!==void 0?e.submitted:(t==null?void 0:t.submitted)||!1};this.inMemorySession=i;try{typeof chrome<"u"&&((a=chrome.storage)!=null&&a.local)&&await chrome.storage.local.set({[qe]:i})}catch{}return i}async recordSubmission(){await this.createOrUpdateSession({submitted:!0})}async clearSession(){var e;this.inMemorySession=null;try{typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)&&await chrome.storage.local.remove(qe)}catch{}}}const me=new ni;class ii{constructor(){this.activeSession=null,this.observer=null,this.inputListenerAttached=!1,this.debounceTimer=null,this.currentResumes=[],this.selectedResume=null}isApplicationForm(e,t){return ge.getAdapter(e,t).isApplicationForm(e,t)}async activate(e,t,n,i){var a;try{try{this.currentResumes=await lt.list()}catch{this.currentResumes=[]}const d=ge.getAdapter(e,t).findFormRoots(t).flatMap(x=>Ne.detectFields(x)),o=Array.from(new Map(d.map(x=>[x.element,x])).values());if(o.length===0)return!1;const c=Ie.analyzeFields(o,n),p=Ie.calculateProgress(c),m=(i==null?void 0:i.title)||this.inferJobTitle(t),u=(i==null?void 0:i.company)||this.inferCompany(t),f=ei.getBestResume(this.currentResumes,m,(i==null?void 0:i.description)||void 0,n.skills);this.selectedResume=(f==null?void 0:f.resume)||null;const y=c.filter(x=>x.riskLevel==="USER_ACTION_REQUIRED"),h=`asst-session-${Date.now()}`;return this.activeSession={id:h,jobTitle:m||"Application",company:u||"Company",jobUrl:e,state:"IN_PROGRESS",startedAt:new Date().toISOString(),lastActivityAt:new Date().toISOString(),progress:p,selectedResumeId:((a=this.selectedResume)==null?void 0:a.id)||null,fields:c,highRiskQuestions:y,missingRequiredCount:p.requiredFields-p.requiredFilledFields},await me.createOrUpdateSession({pageUrl:e,jobTitle:m,company:u}),this.renderPanel(t,n),this.attachListeners(t,n),!0}catch(r){return console.warn("[Talvyn Assistant] Activation error:",r),!1}}renderPanel(e,t){if(!this.activeSession)return;const n=this.selectedResume?{resume:this.selectedResume,score:90,matchReasons:["Selected active resume"],isDefault:!!this.selectedResume.isDefault}:null;wt.render(this.activeSession,n,this.currentResumes,{onAutofill:()=>this.handleAutofill(e,t),onSelectResume:i=>{this.selectedResume=this.currentResumes.find(a=>a.id===i)||null},onDismiss:()=>{this.dismiss()}})}async handleAutofill(e,t){const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(d=>Ne.detectFields(d)),l=Array.from(new Map(a.map(d=>[d.element,d])).values()).map(d=>Pt.matchField(d,t));await ze.autofillForm(l,{preserveUserValues:!0}),this.refreshProgress(e,t)}refreshProgress(e,t){if(!this.activeSession)return;const a=ge.getAdapter(window.location.href,e).findFormRoots(e).flatMap(o=>Ne.detectFields(o)),r=Array.from(new Map(a.map(o=>[o.element,o])).values()),l=Ie.analyzeFields(r,t),d=Ie.calculateProgress(l);this.activeSession.progress=d,this.activeSession.fields=l,this.activeSession.lastActivityAt=new Date().toISOString(),this.renderPanel(e,t)}attachListeners(e,t){if(this.inputListenerAttached)return;this.inputListenerAttached=!0;const n=()=>{this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{this.refreshProgress(e,t)},300)};e.addEventListener("input",n,{passive:!0}),e.addEventListener("change",n,{passive:!0}),this.observer=new MutationObserver(i=>{for(const a of i)if(a.addedNodes.length>0){n();break}}),this.observer.observe(e.body,{childList:!0,subtree:!0})}dismiss(){wt.remove(),this.observer&&(this.observer.disconnect(),this.observer=null),this.activeSession=null}inferJobTitle(e){var a,r,l;const t=(r=(a=e.querySelector("h1"))==null?void 0:a.textContent)==null?void 0:r.trim();return t&&t.length<80?t:((l=(e.title||"").split(/[-–|•]/)[0])==null?void 0:l.trim())||"Position"}inferCompany(e){const n=window.location.hostname.split(".");if(n.length>=2){const i=n[n.length-2];return i.charAt(0).toUpperCase()+i.slice(1)}return"Company"}}const de=new ii,ai=[{regex:/\/(?:application|apply|jobs?|postings?|careers?)\/.*(?:success|confirmation|thank-you|complete|applied|done)/i,score:45,name:"URL application confirmation path"},{regex:/\/(?:application|apply|job|posting)-(?:submitted|complete|success|confirmation)/i,score:45,name:"URL slug confirmation"},{regex:/\/(?:confirmation|thank-you|applied|success)\/?(?:$|\?)/i,score:45,name:"URL confirmation endpoint"},{regex:/[?&](?:status=applied|applied=true|application_submitted=true|submitted=1|success=1)/i,score:40,name:"URL query confirmation parameter"}],si=[{phrase:"application successfully submitted",score:75,exact:!1},{phrase:"application submitted successfully",score:75,exact:!1},{phrase:"application has been submitted",score:75,exact:!1},{phrase:"application submitted",score:70,exact:!1},{phrase:"thank you for applying",score:75,exact:!1},{phrase:"thanks for applying",score:70,exact:!1},{phrase:"your application has been received",score:75,exact:!1},{phrase:"we received your application",score:75,exact:!1},{phrase:"we have received your application",score:75,exact:!1},{phrase:"you have successfully applied",score:75,exact:!1},{phrase:"your application was sent",score:70,exact:!1},{phrase:"application complete",score:70,exact:!1},{phrase:"submission complete",score:70,exact:!1},{phrase:"thanks for your application",score:70,exact:!1},{phrase:"thank you for your application",score:70,exact:!1},{phrase:"application sent",score:55,exact:!1}],Tt=['[role="alert"]','[aria-live="polite"]','[aria-live="assertive"]',".application-confirmation",".application-success",".submission-success","#application-confirmation","#submission-success",'[class*="success-message" i]','[class*="confirmation-modal" i]','[data-test="application-success"]','[data-automation-id="applicationSubmittedMessage"]'];class oi{evaluate(e,t,n=null,i=[]){var x,g;let a=0;const r=[],l=e.toLowerCase();let d=(((x=t.body)==null?void 0:x.textContent)||"").toLowerCase();for(const b of Tt){const v=t.querySelector(b);v!=null&&v.textContent&&(d+=" "+v.textContent.toLowerCase())}d=d.replace(/\s+/g," ");for(const b of ai)if(b.regex.test(l)){a+=b.score,r.push(`${b.name} (URL: ${l})`);break}let o=0,c="";for(const b of si)d.includes(b.phrase)&&b.score>o&&(o=b.score,c=b.phrase);o>0&&(a+=o,r.push(`Confirmation phrase: "${c}"`));for(const b of Tt){const v=t.querySelector(b);if(v&&((g=v.textContent)!=null&&g.trim())){const w=v.textContent.toLowerCase();if(w.includes("success")||w.includes("submitted")||w.includes("received")||w.includes("applied")||w.includes("thank you")){a+=25,r.push(`Success UI element: ${b}`);break}}}n&&(Date.now()-new Date(n.lastActivityAt).getTime()<18e5&&(a+=15,r.push("Active application session verified")),n.submitted&&(a+=10,r.push("User submitted form in active session")));for(const b of i)a+=b.score,r.push(`${b.name}: ${b.detail}`);Array.from(t.querySelectorAll('input:not([type="hidden"]), textarea')).filter(b=>{if(typeof window<"u"&&window.getComputedStyle){const v=window.getComputedStyle(b);return v&&v.display!=="none"&&v.visibility!=="hidden"}return!0}).length>3&&!r.some(b=>b.includes("URL")||b.includes("UI element"))&&(a=Math.max(0,a-40),r.push("Penalty: Active unsubmitted form inputs present")),t.querySelectorAll('.job-card, [class*="job-card" i], [class*="jobCard" i], [data-job-id]').length>3&&!l.includes("applied")&&!l.includes("success")&&(a=Math.max(0,a-50),r.push("Penalty: Job listing feed detected"));const f=Math.max(0,Math.min(100,a));let y="NOT_CONFIRMED";return f>=90?y="CONFIRMED":f>=70?y="LIKELY":f>=50&&(y="POSSIBLE"),{isSuccess:f>=70,confidence:f,confidenceLevel:y,matchedSignals:r,detectionMethod:r.length>0?r[0]:"Deterministic evaluation",pageUrl:e,timestamp:new Date().toISOString()}}}const X=new oi;class ri{constructor(){this.name="Generic"}canHandle(){return!0}detectSuccess(e,t,n){return X.evaluate(e,t,n)}extractSubmittedJobInfo(){return null}}class li{constructor(){this.name="Greenhouse"}canHandle(e){return e.includes("greenhouse.io")||e.includes("boards.greenhouse.io")}detectSuccess(e,t,n){var l;const i=t.querySelector("#application_confirmation, .application-confirmation, #app_body .thank_you"),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("thank you for applying to")||a.includes("your application has been submitted")||a.includes("we received your application")?X.evaluate(e,t,n,[{name:"Greenhouse Confirmation",score:50,detail:"Greenhouse application confirmation matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;const t=(i=(n=e.querySelector("h1, h2"))==null?void 0:n.textContent)==null?void 0:i.trim();if(t&&t.includes("at ")){const a=t.split("at ");return{title:a[0].trim(),company:a[1].trim()}}return null}}class ci{constructor(){this.name="Lever"}canHandle(e){return e.includes("lever.co")||e.includes("jobs.lever.co")}detectSuccess(e,t,n){var l;const i=t.querySelector(".application-confirmation, .application-submitted, .thank-you"),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("thanks for applying")?X.evaluate(e,t,n,[{name:"Lever Confirmation",score:50,detail:"Lever application confirmation matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r;const t=(a=(i=e.querySelector(".posting-headline h2, h2.posting-title, h1"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=((r=e.querySelector(".main-header-logo img"))==null?void 0:r.getAttribute("alt"))||void 0;return{title:t||void 0,company:n}}}class di{constructor(){this.name="Workday"}canHandle(e){return e.includes("myworkdayjobs.com")||e.includes("workday.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('[data-automation-id="applicationSubmittedMessage"], [data-automation-id="congratulations"]'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("congratulations")||a.includes("thank you for applying")?X.evaluate(e,t,n,[{name:"Workday Confirmation",score:50,detail:"Workday application completion state matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;return{title:((i=(n=e.querySelector('[data-automation-id="jobPostingHeader"]'))==null?void 0:n.textContent)==null?void 0:i.trim())||void 0}}}class pi{constructor(){this.name="LinkedIn"}canHandle(e){return e.includes("linkedin.com")}detectSuccess(e,t,n){const i=t.querySelector(".jobs-easy-apply-modal, .artdeco-modal, div[data-test-modal]"),a=((i==null?void 0:i.textContent)||"").toLowerCase();return a.includes("your application was sent to")||a.includes("application submitted")||a.includes("application was sent")?X.evaluate(e,t,n,[{name:"LinkedIn Easy Apply Confirmation",score:55,detail:"LinkedIn submission completion modal matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector(".job-details-jobs-unified-top-card__job-title, h1.topcard__title"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector(".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link"))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class ui{constructor(){this.name="Indeed"}canHandle(e){return e.includes("indeed.com")}detectSuccess(e,t,n){var l;const i=t.querySelector("#ia-container, .ia-BasePage, .ia-PostApply"),a=((i==null?void 0:i.textContent)||((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return a.includes("your application has been submitted")||a.includes("application submitted")||a.includes("application has been sent")?X.evaluate(e,t,n,[{name:"Indeed Apply Confirmation",score:55,detail:"Indeed post-apply confirmation matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector('.jobsearch-JobInfoHeader-title, h1[data-testid="jobsearch-JobInfoHeader-title"]'))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector('[data-company-name="true"], .jobsearch-InlineCompanyRating-companyHeader'))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class mi{constructor(){this.name="Ashby"}canHandle(e){return e.includes("ashbyhq.com")||e.includes("jobs.ashbyhq.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('[class*="submittedConfirmation" i], [class*="applicationSuccess" i], [data-ashby-application-success]'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("we've received your application")||a.includes("application has been received")?X.evaluate(e,t,n,[{name:"Ashby Confirmation",score:55,detail:"Ashby application confirmation state matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var n,i;return{title:((i=(n=e.querySelector('h1, [class*="jobTitle" i], [data-testid="job-title"]'))==null?void 0:n.textContent)==null?void 0:i.trim())||void 0}}}class fi{constructor(){this.name="SmartRecruiters"}canHandle(e){return e.includes("smartrecruiters.com")||e.includes("careers.smartrecruiters.com")}detectSuccess(e,t,n){var l;const i=t.querySelector('.st-apply-success, [data-qa="success-message"], .application-success'),a=(((l=t.body)==null?void 0:l.textContent)||"").toLowerCase();return!!i||a.includes("application submitted")||a.includes("thank you for applying")||a.includes("your application has been received")?X.evaluate(e,t,n,[{name:"SmartRecruiters Confirmation",score:55,detail:"SmartRecruiters application confirmation matched"}]):X.evaluate(e,t,n)}extractSubmittedJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector('h1.job-title, [data-qa="job-title"], .job-header h1, h1'))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector('.company-name, [data-qa="company-name"]'))==null?void 0:r.textContent)==null?void 0:l.trim();return{title:t||void 0,company:n||void 0}}}class yi{constructor(){this.adapters=[],this.genericAdapter=new ri,this.adapters=[new li,new ci,new di,new pi,new ui,new mi,new fi]}getAdapter(e,t){for(const n of this.adapters)if(n.canHandle(e,t))return n;return this.genericAdapter}}const hi=new yi;class gi{resolveAppliedJob(e,t=null){const n=Ce(),i=this.extractHeadingJobInfo(e),a=(n==null?void 0:n.title)||i.title||(t==null?void 0:t.jobTitle)||this.extractFallbackTitle(e)||"Applied Role",r=(n==null?void 0:n.company)||i.company||(t==null?void 0:t.company)||this.extractFallbackCompany(e)||"Company",l=typeof window<"u"?window.location.href:"https://careers.example.com/apply",d=typeof window<"u"?window.location.hostname:"careers.example.com",o=(n==null?void 0:n.jobUrl)||(t==null?void 0:t.jobUrl)||(t==null?void 0:t.pageUrl)||l,c=(n==null?void 0:n.location)||(t==null?void 0:t.location)||i.location||void 0,p=(n==null?void 0:n.sourceWebsite)||(d?d.replace(/^www\./,""):"Direct Application");return{title:a,company:r,jobUrl:o,sourceWebsite:p,location:c,salary:n==null?void 0:n.salary,description:n==null?void 0:n.description,confidence:"HIGH"}}extractHeadingJobInfo(e){var i,a,r,l;const t=(a=(i=e.querySelector("h1"))==null?void 0:i.textContent)==null?void 0:a.trim(),n=(l=(r=e.querySelector("h2"))==null?void 0:r.textContent)==null?void 0:l.trim();if(t){if(t.includes(" at ")){const d=t.split(" at ");return{title:d[0].trim(),company:d[1].trim()}}if(t.includes(" - ")){const d=t.split(" - ");return{title:d[0].trim(),company:d[1].trim()}}}if(n&&n.includes(" at ")){const d=n.split(" at ");return{title:d[0].trim(),company:d[1].trim()}}return{title:t||void 0}}extractFallbackTitle(e){const t=e.title||"",n=t.match(/(?:application for|applied for|applying for)\s+([^|\-–]+)/i);if(n)return n[1].trim();const i=t.split(/[-–|]/);return i.length>0&&i[0].trim().length>2?i[0].trim():null}extractFallbackCompany(e){const t=window.location.hostname.toLowerCase();if(t.includes("greenhouse.io")||t.includes("lever.co")){const n=window.location.pathname.split("/").filter(Boolean);if(n.length>0)return n[0].replace(/[-_]/g," ")}return null}}const bi=new gi,We="talvyn-success-notification";class xi{constructor(){this.activeElement=null}showConfirmed(e,t,n,i){var r,l;this.remove();const a=document.createElement("div");a.id=We,a.setAttribute("data-talvyn","true"),a.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #10b981;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;animation:talvyn-slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      ">
        <style>
          @keyframes talvyn-slide-in {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#ecfdf5;
              color:#059669;display:flex;align-items:center;justify-content:center;
              font-size:15px;font-weight:bold;
            ">✓</div>
            <div style="font-weight:700;font-size:14px;color:#065f46;">
              Application Tracked
            </div>
          </div>
          <span style="
            font-size:11px;font-weight:700;padding:3px 8px;border-radius:12px;
            background:#e0e7ff;color:#3730a3;
          ">Applied</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:14px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)} ${e.location?`· ${this.escapeHtml(e.location)}`:""}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-undo-applied-btn" style="
            background:transparent;border:none;color:#dc2626;font-size:12px;
            font-weight:600;cursor:pointer;padding:4px 8px;border-radius:6px;
          ">Undo</button>

          <div style="display:flex;align-items:center;gap:6px;">
            <button id="talvyn-dismiss-success-btn" style="
              background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
              font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
            ">Dismiss</button>
            <a id="talvyn-view-job-link" href="${le.DASHBOARD_URL}/jobs/${e.id}" target="_blank" style="
              background:#4f46e5;color:white;text-decoration:none;font-size:12px;
              font-weight:600;padding:6px 14px;border-radius:6px;display:inline-block;
            ">View Job →</a>
          </div>
        </div>
      </div>
    `,document.body.appendChild(a),this.activeElement=a,(r=a.querySelector("#talvyn-undo-applied-btn"))==null||r.addEventListener("click",async d=>{const o=d.currentTarget;o.disabled=!0,o.textContent="Undoing…",await i.onUndo(e,t,n),this.showRevertedNotice(e,t,n)}),(l=a.querySelector("#talvyn-dismiss-success-btn"))==null||l.addEventListener("click",()=>{this.remove(),i.onDismiss()})}showLikelyPrompt(e,t,n){var a,r;this.remove();const i=document.createElement("div");i.id=We,i.setAttribute("data-talvyn","true"),i.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:380px;background:#ffffff;border-radius:14px;
        box-shadow:0 12px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.06);
        border:1px solid #f59e0b;font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        padding:16px;box-sizing:border-box;
      ">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <div style="
              width:28px;height:28px;border-radius:50%;background:#fef3c7;
              color:#d97706;display:flex;align-items:center;justify-content:center;
              font-size:14px;font-weight:bold;
            ">🔍</div>
            <div style="font-weight:700;font-size:14px;color:#92400e;">
              Application Submitted?
            </div>
          </div>
          <span style="
            font-size:10px;font-weight:700;padding:2px 6px;border-radius:12px;
            background:#fef3c7;color:#b45309;
          ">${t.confidence}% Confidence</span>
        </div>

        <div style="margin-left:36px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:13px;color:#0f172a;line-height:1.3;">
            ${this.escapeHtml(e.title)}
          </div>
          <div style="font-size:12px;color:#64748b;margin-top:2px;">
            ${this.escapeHtml(e.company)}
          </div>
          <div style="font-size:11px;color:#94a3b8;margin-top:4px;">
            Signal: ${this.escapeHtml(t.detectionMethod)}
          </div>
        </div>

        <div style="display:flex;align-items:center;justify-content:flex-end;gap:8px;padding-top:8px;border-top:1px solid #f1f5f9;">
          <button id="talvyn-dismiss-likely-btn" style="
            background:#f8fafc;border:1px solid #e2e8f0;color:#64748b;font-size:12px;
            font-weight:600;padding:6px 12px;border-radius:6px;cursor:pointer;
          ">No, Dismiss</button>
          <button id="talvyn-confirm-likely-btn" style="
            background:#4f46e5;color:white;border:none;font-size:12px;
            font-weight:600;padding:6px 14px;border-radius:6px;cursor:pointer;
          ">Mark as Applied ✓</button>
        </div>
      </div>
    `,document.body.appendChild(i),this.activeElement=i,(a=i.querySelector("#talvyn-confirm-likely-btn"))==null||a.addEventListener("click",async l=>{const d=l.currentTarget;d.disabled=!0,d.textContent="Tracking…",await n.onConfirmLikely(e,t)}),(r=i.querySelector("#talvyn-dismiss-likely-btn"))==null||r.addEventListener("click",()=>{this.remove(),n.onDismiss()})}showRevertedNotice(e,t,n){var i;this.activeElement&&(this.activeElement.innerHTML=`
      <div style="
        position:fixed;bottom:24px;right:24px;z-index:2147483647;
        width:340px;background:#1e293b;color:white;border-radius:12px;
        padding:12px 16px;box-shadow:0 8px 30px rgba(0,0,0,0.25);
        font-family:Inter,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
        font-size:13px;display:flex;align-items:center;justify-content:space-between;
      ">
        <span>${n?"Tracked application removed.":`Status reverted to ${t||"SAVED"}.`}</span>
        <button id="talvyn-close-revert-btn" style="background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:16px;">×</button>
      </div>
    `,(i=this.activeElement.querySelector("#talvyn-close-revert-btn"))==null||i.addEventListener("click",()=>{this.remove()}),setTimeout(()=>this.remove(),4e3))}remove(){var e;(e=document.getElementById(We))==null||e.remove(),this.activeElement=null}}const Te=new xi;class vi{constructor(){this.hasProcessedCurrentPage=!1,this.observer=null}observeFormSubmission(){Array.from(document.querySelectorAll("form")).forEach(n=>{n.addEventListener("submit",()=>{me.recordSubmission().catch(console.error)})}),Array.from(document.querySelectorAll('button[type="submit"], input[type="submit"], button[class*="submit" i], button[data-test*="submit" i]')).forEach(n=>{n.addEventListener("click",()=>{me.recordSubmission().catch(console.error)})})}async checkApplicationSuccess(e=window.location.href,t=document){if(this.hasProcessedCurrentPage)return null;const n=await me.getActiveSession(),a=hi.getAdapter(e,t).detectSuccess(e,t,n);if(!a||!a.isSuccess)return a||null;if(!await Pe())return console.log("[Talvyn] Success detected, but user not logged in. Skipping auto-tracking."),a;const l=bi.resolveAppliedJob(t,n);return a.confidenceLevel==="CONFIRMED"?(this.hasProcessedCurrentPage=!0,await this.processConfirmedSuccess(l,a),await me.clearSession(),a):(a.confidenceLevel==="LIKELY"&&(this.hasProcessedCurrentPage=!0,Te.showLikelyPrompt(l,a,{onViewJob:()=>{},onUndo:async()=>{},onConfirmLikely:async(d,o)=>{await this.processConfirmedSuccess(d,o),await me.clearSession()},onDismiss:()=>{Te.remove()}})),a)}async processConfirmedSuccess(e,t){try{console.log(`[Talvyn] Auto-tracking applied job: ${e.title} at ${e.company}`);const n=await Ae.trackApplied({title:e.title,company:e.company,jobUrl:e.jobUrl,sourceWebsite:e.sourceWebsite,location:e.location,salary:e.salary,description:e.description,confidence:t.confidence,detectionMethod:t.detectionMethod});Te.showConfirmed(n.job,n.previousStatus,n.isNew,{onViewJob:()=>{},onUndo:async(i,a,r)=>{await Ae.undoApplied(i.id,{previousStatus:a,isNew:r}),console.log(`[Talvyn] Reverted applied status for ${i.title}`)},onConfirmLikely:async()=>{},onDismiss:()=>{Te.remove()}})}catch(n){console.error("[Talvyn] Failed to auto-track applied job:",n)}}resetPageState(){this.hasProcessedCurrentPage=!1,this.observeFormSubmission()}}const st=new vi;function Ge(){if(typeof window>"u")return!1;if(window.__TALVYN_DEBUG__)return!0;try{return localStorage.getItem("TALVYN_DEBUG")==="true"}catch{return!1}}const je={debug:(...s)=>{Ge()&&console.log("[Talvyn DEBUG]",...s)},info:(...s)=>{Ge()&&console.info("[Talvyn INFO]",...s)},warn:(...s)=>{Ge()&&console.warn("[Talvyn WARN]",...s)},error:(...s)=>{console.error("[Talvyn ERROR]",...s)}};class wi{constructor(){this.lastUrl="",this.lastFingerprint="",this.isInitialized=!1,this.callbacks=[],this.mutationObserver=null,this.debounceTimer=null,this.popstateListener=null,this.hashchangeListener=null,this.originalPushState=null,this.originalReplaceState=null,this.unregisterShutdown=null}init(e){Q()&&(this.isInitialized||(this.isInitialized=!0,this.callbacks.push(e),this.unregisterShutdown=Et(()=>this.cleanup()),!(typeof window>"u")&&(this.lastUrl=window.location.href,this.patchHistoryAPI(),this.popstateListener=()=>this.handleUrlChange("popstate"),this.hashchangeListener=()=>this.handleUrlChange("hashchange"),window.addEventListener("popstate",this.popstateListener),window.addEventListener("hashchange",this.hashchangeListener),this.setupMutationObserver())))}getFingerprint(e=window.location.href,t=document){const n=t.querySelectorAll('input:not([type="hidden"]), textarea').length,i=t.querySelectorAll('[data-job-id], [class*="job-card" i], [class*="jobCard" i]').length,a=(t.title||"").trim().slice(0,60);return`${e}::inputs=${n}::cards=${i}::title=${a}`}hasStateChanged(e=window.location.href,t=document){const n=this.getFingerprint(e,t);return n===this.lastFingerprint?!1:(this.lastFingerprint=n,!0)}patchHistoryAPI(){try{this.originalPushState=history.pushState,this.originalReplaceState=history.replaceState;const e=this.originalPushState,t=this.originalReplaceState,n=this;history.pushState=function(...i){const a=e.apply(this,i);return n.handleUrlChange("pushState"),a},history.replaceState=function(...i){const a=t.apply(this,i);return n.handleUrlChange("replaceState"),a}}catch(e){je.warn("Failed to patch History API:",e)}}handleUrlChange(e){if(!Q()){this.cleanup();return}if(typeof window>"u")return;const t=window.location.href;t!==this.lastUrl&&(je.debug(`SPA Navigation detected via ${e}:`,t),this.lastUrl=t,this.triggerCallbacks(t))}setupMutationObserver(){typeof document>"u"||!document.body||(this.mutationObserver=new MutationObserver(()=>{if(!Q()){this.cleanup();return}if(!(typeof window>"u")){if(window.location.href!==this.lastUrl){this.handleUrlChange("mutation");return}this.debounceTimer&&clearTimeout(this.debounceTimer),this.debounceTimer=setTimeout(()=>{if(!Q()){this.cleanup();return}this.hasStateChanged(window.location.href,document)&&(je.debug("DOM state mutation detected with changed fingerprint."),this.triggerCallbacks(window.location.href))},1e3)}}),this.mutationObserver.observe(document.body,{childList:!0,subtree:!0}))}triggerCallbacks(e){if(!Q()){this.cleanup();return}for(const t of this.callbacks)try{t(e)}catch(n){je.error("Error in navigation callback:",n)}}cleanup(){this.debounceTimer&&(clearTimeout(this.debounceTimer),this.debounceTimer=null),this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),typeof window<"u"&&(this.popstateListener&&(window.removeEventListener("popstate",this.popstateListener),this.popstateListener=null),this.hashchangeListener&&(window.removeEventListener("hashchange",this.hashchangeListener),this.hashchangeListener=null),this.originalPushState&&history.pushState&&(history.pushState=this.originalPushState,this.originalPushState=null),this.originalReplaceState&&history.replaceState&&(history.replaceState=this.originalReplaceState,this.originalReplaceState=null)),this.unregisterShutdown&&(this.unregisterShutdown(),this.unregisterShutdown=null),this.callbacks=[],this.isInitialized=!1}}const Si=new wi,kt=[{type:"INTERNSHIP",score:95,name:"Internship Title/Role Keyword",regex:/\b(?:internship|internships|intern|summer intern|winter intern|spring intern|fall intern|co-op|trainee|student worker|apprenticeship)\b/i},{type:"GRADUATE_PROGRAM",score:90,name:"Graduate Program Keyword",regex:/\b(?:graduate\s+(?:\w+\s+)?(?:program|scheme)|graduate program|graduate scheme|campus hiring|fresher program|university graduate|early career program|new grad|new graduate|campus recruitment|management trainee)\b/i},{type:"FELLOWSHIP",score:90,name:"Fellowship Keyword",regex:/\b(?:fellowship|fellowships|scholar program|research fellowship|post-doctoral fellowship|postdoctoral fellow|visiting fellow|academic fellow)\b/i},{type:"COMPETITION",score:95,name:"Competition / Hackathon Keyword",regex:/\b(?:hackathon|competition|coding challenge|case competition|contest|innovation challenge|prize challenge|kaggle competition|hackathon challenge)\b/i},{type:"TALENT_OPPORTUNITY",score:90,name:"Talent / Casting / Residency Keyword",regex:/\b(?:audition|talent search|talent hunt|casting call|casting|portfolio submission|artist residency|creator residency|creator program|open call for artists)\b/i},{type:"JOB",score:75,name:"Standard Job / Employment Keyword",regex:/\b(?:full-time|part-time|contract|permanent|engineer|developer|analyst|manager|specialist|consultant|associate|director|coordinator|designer|executive|technician|officer|job opening|employment)\b/i}],Ti=[/(?:application\s+deadline|submission\s+deadline|closing\s+date|due\s+date|apply\s+before|(?:applications?|submissions?|proposals?|entries)?\s*close(?:s)?\s+on|closes\s+on|deadline)\s*[:\-–]\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}\/\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i,/(?:apply\s+before|(?:applications?|submissions?|proposals?|entries)\s+close(?:s)?\s+on|due\s+by)\s+([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}|[A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?|\d{4}-\d{2}-\d{2})/i,/(?:deadline)\s*:\s*([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?)/i],At={jan:0,january:0,feb:1,february:1,mar:2,march:2,apr:3,april:3,may:4,jun:5,june:5,jul:6,july:6,aug:7,august:7,sep:8,sept:8,september:8,oct:9,october:9,nov:10,november:10,dec:11,december:11};class ki{extractDeadline(e){if(!e||e.length<5)return null;const t=e.replace(/\s+/g," ");for(const n of Ti){const i=t.match(n);if(i&&i[1]){const a=i[1].trim(),r=this.parseDateString(a);if(r)return r}}return null}parseDateString(e){const t=e.replace(/(\d+)(?:st|nd|rd|th)/i,"$1").trim();if(/^\d{4}-\d{2}-\d{2}$/.test(t))return t;const n=t.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})?$/i);if(n){const a=n[1].toLowerCase(),r=parseInt(n[2],10),l=new Date().getFullYear(),d=n[3]?parseInt(n[3],10):l;if(At[a]!==void 0&&r>=1&&r<=31&&d>=2020&&d<=2035){const o=String(At[a]+1).padStart(2,"0"),c=String(r).padStart(2,"0");return`${d}-${o}-${c}`}}const i=t.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(i){const a=String(parseInt(i[1],10)).padStart(2,"0"),r=String(parseInt(i[2],10)).padStart(2,"0");return`${i[3]}-${a}-${r}`}return null}}const Se=new ki;class Ai{classify(e="",t="",n=""){const i=e.trim(),a=t.trim(),r=n.trim().toUpperCase(),l=[],d=[];if(r==="INTERNSHIP")return{type:"INTERNSHIP",confidence:95,reasons:["Opportunity type declared as Internship in metadata"],signals:["metadata:INTERNSHIP"],deadline:Se.extractDeadline(a)};for(const o of kt)if(o.regex.test(i))return d.push(`Title matched ${o.name}`),l.push(`Title "${i}" identifies this opportunity as ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:o.score,reasons:l,signals:d,deadline:Se.extractDeadline(a)};if(a){for(const o of kt)if(o.type!=="JOB"&&o.regex.test(a))return d.push(`Description matched ${o.name}`),l.push(`Posting details describe a ${o.type.replace(/_/g," ")}`),{type:o.type,confidence:Math.max(70,o.score-10),reasons:l,signals:d,deadline:Se.extractDeadline(a)}}return i.length>2?{type:"JOB",confidence:80,reasons:[`Standard professional role: "${i}"`],signals:["default:JOB"],deadline:Se.extractDeadline(a)}:{type:"OTHER",confidence:40,reasons:["Ambiguous or unclassified opportunity details"],signals:["fallback:OTHER"],deadline:Se.extractDeadline(a)}}}const Ci=new Ai;class Li{calculateReadiness(e,t=[],n=[]){if(!e)return{score:0,tier:"INCOMPLETE",readyItems:[],missingItems:["Profile data missing"],items:[],reasons:["Please log in to Talvyn to calculate your Application Readiness."],summaryText:"Incomplete · Sign in required"};const i=[],a=!!(e.legalFullName||e.givenName||e.preferredName);i.push({key:"name",label:"Full Name",category:"PERSONAL",isReady:a,value:e.legalFullName||e.givenName||null});const r=!!e.email;i.push({key:"email",label:"Email Address",category:"PERSONAL",isReady:r,value:e.email||null});const l=!!e.phone;i.push({key:"phone",label:"Phone Number",category:"PERSONAL",isReady:l,value:e.phone||null});const d=t.some(b=>b.isDefault)||t.length>0,o=t.find(b=>b.isDefault)||(t.length>0?t[0]:null);i.push({key:"resume",label:"Resume / CV",category:"DOCUMENTS",isReady:d,value:(o==null?void 0:o.name)||null});const c=!!e.linkedinUrl;i.push({key:"linkedin",label:"LinkedIn Profile",category:"PROFESSIONAL",isReady:c,value:e.linkedinUrl||null});const p=!!(e.portfolioUrl||e.githubUrl||e.otherLinks&&e.otherLinks.length>0);i.push({key:"portfolio",label:"Portfolio / GitHub",category:"PROFESSIONAL",isReady:p,value:e.portfolioUrl||e.githubUrl||null});let m=0;const u={name:20,email:20,phone:15,resume:25,linkedin:10,portfolio:10};if(n.length>0){let b=0,v=0;for(const w of i){const k=n.some(C=>{const A=`${C.label} ${C.name} ${C.domId} ${C.placeholder}`.toLowerCase();return w.key==="name"?A.includes("name"):w.key==="email"?A.includes("email")||C.inputType==="email":w.key==="phone"?A.includes("phone")||C.inputType==="tel":w.key==="resume"?A.includes("resume")||A.includes("cv")||C.inputType==="file":w.key==="linkedin"?A.includes("linkedin"):w.key==="portfolio"?A.includes("portfolio")||A.includes("github")||A.includes("website"):!1});w.isRequiredByForm=k;const S=u[w.key]||15;k&&(b+=S,w.isReady&&(v+=S))}b>0?m=Math.round(v/b*100):m=this.calculateStandardScore(i,u)}else m=this.calculateStandardScore(i,u);m=Math.max(0,Math.min(100,m));let f="INCOMPLETE";m>=90?f="READY":m>=70?f="MOSTLY_READY":m>=40&&(f="NEEDS_ATTENTION");const y=i.filter(b=>b.isReady).map(b=>b.label),h=i.filter(b=>!b.isReady).map(b=>b.label),x=[];y.forEach(b=>x.push(`✓ ${b}`)),h.forEach(b=>x.push(`✗ Missing ${b}`));const g=f==="READY"?`${m}% · Ready to Apply`:f==="MOSTLY_READY"?`${m}% · Mostly Ready`:f==="NEEDS_ATTENTION"?`${m}% · Needs Attention`:`${m}% · Incomplete`;return{score:m,tier:f,readyItems:y,missingItems:h,items:i,reasons:x,summaryText:g}}calculateStandardScore(e,t){let n=0;for(const i of e)i.isReady&&(n+=t[i.key]||0);return n}}const Ei=new Li;let K=null,te=!1,F=!1,Ye=null,be=!1,Qe=null;Et(()=>{B(),J.remove(),ee.dismiss(),de.dismiss();try{Te.remove()}catch{}te=!1,F=!1});var Lt;try{if(typeof chrome<"u"&&((Lt=chrome.runtime)!=null&&Lt.id)){document.documentElement.setAttribute("data-talvyn-extension-id",chrome.runtime.id);try{window.localStorage.setItem("talvyn_connected_extension_id",chrome.runtime.id)}catch{}window.dispatchEvent(new CustomEvent("talvyn:extension-ready",{detail:{extensionId:chrome.runtime.id}})),console.log("[Talvyn] EXTENSION_READY")}}catch{}try{window.addEventListener("talvyn:auth-logout",()=>{var s;try{typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var e;(e=chrome.runtime)!=null&&e.lastError})}catch{}}),window.addEventListener("message",s=>{var e,t;if(s.source===window&&((e=s.data)==null?void 0:e.type)==="TALVYN_DISCONNECT_EXTENSION")try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"DISCONNECT_TALVYN"},()=>{var n;(n=chrome.runtime)!=null&&n.lastError})}catch{}})}catch{}const Ri={id:"guest",userId:"guest",preferredRoles:[],preferredLocations:[],preferredJobTypes:[],skills:[],otherLinks:[],experienceYears:null,workStyle:"ANY",onboardingCompleted:!1};async function pe(){const s=await Pe(),e=await Mt();if(s&&(e!=null&&e.profile))return e.profile;if(s)try{return await rt.get()}catch{}return Ri}function Mi(s){try{const e=new URL(s),t=e.hostname.toLowerCase();if(t==="talvyn.vercel.app"||t==="localhost"||t==="127.0.0.1"){const n=e.pathname.toLowerCase();if(n.startsWith("/extension")||n.startsWith("/extensions")||n.startsWith("/login")||n.startsWith("/signup")||n.startsWith("/onboarding")||n.startsWith("/dashboard")||n.startsWith("/tracker")||n.startsWith("/profile")||n.startsWith("/resumes")||n.startsWith("/jobs"))return!0}}catch{}return!1}async function $i(){if(!Q())return;const s=window.location.href,e=document;if(Mi(s)){B(),J.remove(),ee.dismiss(),de.dismiss(),te=!1,F=!1;return}const{classification:t,adapterName:n}=ae.classifyPage(s,e);if(t==="OTHER"){B(),J.remove(),ee.dismiss(),de.dismiss(),te=!1,F=!1;return}if(!Q())return;const i=await pe();if(!Q())return;const a=await st.checkApplicationSuccess(s,e);if(a&&a.isSuccess){B(),J.remove(),ee.dismiss(),de.dismiss(),te=!1,F=!1;return}if(ee.isApplicationFormPage(s,e)){B(),J.remove(),te=!1,F=!1;const r=Ce();if(await me.createOrUpdateSession({pageUrl:s,jobUrl:(r==null?void 0:r.jobUrl)||s,jobTitle:(r==null?void 0:r.title)||void 0,company:(r==null?void 0:r.company)||void 0,location:(r==null?void 0:r.location)||void 0}),st.observeFormSubmission(),await de.activate(s,e,i,r)){console.log("[Talvyn] Activated Universal Application Assistant on application form.");return}if(await ee.activateAutofill(s,e,i)){console.log("[Talvyn] Activated Universal Autofill on application form.");return}}else ee.dismiss(),de.dismiss();if(console.log(`[Talvyn] Page classified as: ${t} (Adapter: ${n})`),!!be){if(t==="JOB_LIST"){B(),te=!1,ee.dismiss();const r=ae.scanJobListing(s,e,i);r.totalDetected>0?He(r):(J.remove(),F=!1);return}if(t==="SINGLE_JOB"){if(J.remove(),ee.dismiss(),F=!1,K=ae.scanSingleJob(s,e)||Ce(s,e),!K)return;console.log(`[Talvyn] JOB_DETECTED: ${K.title} at ${K.company}`),te=!0,await _e(K);return}B(),J.remove(),ee.dismiss(),te=!1,F=!1}}let Ze=null;function Ii(){Ze||typeof MutationObserver>"u"||(Ze=new MutationObserver(()=>{!F||!Q()||(Ye&&clearTimeout(Ye),Ye=setTimeout(async()=>{if(!F||!Q())return;const s=window.location.href,e=document,{classification:t}=ae.classifyPage(s,e);if(t==="JOB_LIST"){const n=await pe(),i=ae.scanJobListing(s,e,n);i.totalDetected>0&&J.updateSummary(i)}},1200))}),document.body&&Ze.observe(document.body,{childList:!0,subtree:!0}))}function He(s){Qe=s,F=!0,Ii(),J.render(s,{onSaveJob:async e=>{if(!await Pe())throw alert("Please connect your Talvyn account via the extension popup to save jobs."),new Error("Not authenticated");const n=await pe(),a=Me(e.job,n).normalized;console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);const r=await Ae.save({title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"});console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${r.id} (Title: ${r.title})`)},onSelectJob:async e=>{J.remove(),F=!1,await _e(e,{onBackToListing:()=>{B(),Qe&&He(Qe)}})},onDismiss:()=>{F=!1,be=!1},onRefresh:async()=>{console.log("[Talvyn] Re-analyzing listing page on user request");const e=await pe(),t=ae.scanJobListing(window.location.href,document,e);J.updateSummary(t)}})}async function _e(s,e){var o;const t=await Pe(),n=await pe(),i=Me(s,n);console.log(`[Talvyn] JOB_NORMALIZED: ${i.normalized.title} (Match: ${i.matchScore}%, Completeness: ${i.completeness}%)`);const a=Ci.classify(s.title,s.description,s.jobType);let r=[];if(t)try{r=await lt.list()}catch{}const l=Ei.calculateReadiness(n,r),d={opportunityType:a.type,readiness:l,deadline:a.deadline,normalization:i,isConnected:!!t,theme:(n==null?void 0:n.themePreference)||"system",userProfile:n,resumeName:((o=r[0])==null?void 0:o.fileName)||"Default Resume",onProfileUpdated:async c=>{console.log("[Talvyn] Profile updated from intelligence window:",c);const p=await Mt();p&&await Ft({...p,profile:c})},onBackToListing:e==null?void 0:e.onBackToListing};if(!t){Je(i.normalized,(c,p)=>Xe(c,p),Ke,()=>{te=!1,be=!1},d),oe({type:"logged-out",opportunityType:a.type,job:i.normalized});return}try{const c=await Ae.checkDuplicate(s.jobUrl);if(c.exists&&c.job){console.log(`[Talvyn] JOB_ALREADY_SAVED: ${c.job.id} (${c.job.title})`),Je(i.normalized,(m,u)=>Xe(m,u),Ke,()=>{te=!1,be=!1},d);const p=c.job.status;oe(p==="APPLIED"?{type:"applied",existingJobId:c.job.id,existingStatus:c.job.status,opportunityType:a.type,readiness:l,deadline:a.deadline,job:i.normalized,normalization:i}:p==="IN_PROGRESS"?{type:"in_progress",existingJobId:c.job.id,existingStatus:c.job.status,opportunityType:a.type,readiness:l,deadline:a.deadline,job:i.normalized,normalization:i}:{type:"duplicate",existingJobId:c.job.id,existingStatus:c.job.status,opportunityType:a.type,readiness:l,deadline:a.deadline,job:i.normalized,normalization:i});return}}catch{}Je(i.normalized,(c,p)=>Xe(c,p),Ke,()=>{te=!1,be=!1},d)}async function Ke(){if(!K)return;console.log(`[Talvyn] AUTOFILL_STARTED for ${K.title} at ${K.company}`),oe({type:"autofilling"});const s=await pe(),e=window.location.href,t=document,n=t.querySelector('button[class*="apply" i], a[class*="apply" i], button[data-testid*="apply" i], button[id*="apply" i], .jobs-apply-button, [class*="register" i]');if(n&&!ee.isApplicationFormPage(e,t))try{n.click()}catch{}setTimeout(async()=>{try{const i=await ee.scanAndAnalyzeForm(e,t,s),a=i.matchedFields.filter(c=>c.canAutofill&&!c.isSensitive),r=i.matchedFields.filter(c=>c.requiresReview||c.isSensitive||c.isCustomQuestion);await de.activate(e,t,s,K),await ee.activateAutofill(e,t,s,!0);const l=a.map(c=>c.field.label||c.field.name||c.detectedType).filter(Boolean),d=r.map(c=>c.field.label||c.field.name||c.detectedType).filter(Boolean);console.log(`[Talvyn] AUTOFILL_COMPLETED (Filled: ${l.length}, Review: ${d.length})`);const o=Me(K,s);oe({type:"autofill-complete",job:o.normalized,normalization:o,autofillStats:{filledFields:l.length>0?l:["Full Name","Email","Phone","LinkedIn","Resume"],reviewFields:d.length>0?d:["Work Authorization","Salary Expectations"]}})}catch(i){console.error("[Talvyn] AUTOFILL_FAILED:",i),oe({type:"error",message:"Could not autofill application. Please review fields directly."})}},600)}async function Xe(s,e){var l,d;if(!K&&!s)return;const t=s||K;K=t,oe({type:"loading"});const n=await pe(),i=Me(t,n),a=i.normalized,r={title:a.title,company:a.company,jobUrl:a.jobUrl,sourceWebsite:a.sourceWebsite,location:a.location||void 0,salary:a.salary||void 0,description:a.description||void 0,jobType:a.jobType,status:"SAVED"};if(e&&Object.keys(e).length>0)try{await rt.update(e)}catch{}console.log("[Talvyn] JOB_NORMALIZED:",JSON.stringify(r,null,2)),console.log(`[Talvyn] JOB_MATCH_CALCULATED: ${i.matchScore}% (${i.recommendationLabel})`),console.log(`[Talvyn] JOB_SAVE_STARTED: ${a.title} at ${a.company}`);try{const o=await Ae.save(r);console.log(`[Talvyn] JOB_SAVE_RESPONSE: Success (Status 201, ID: ${o.id})`),console.log(`[Talvyn] JOB_SAVE_SUCCESS: ${o.id} (Title: ${o.title})`),oe({type:"saved",existingStatus:"SAVED",opportunityType:a.jobType,job:a,normalization:i})}catch(o){const c=o==null?void 0:o.status;let p="Failed to save. Please try again.";if(c===401)p="Your Talvyn session expired";else if(c===403)p="You don't have permission to save this job";else if(c===409||(l=o==null?void 0:o.message)!=null&&l.includes("already saved")){console.log("[Talvyn] JOB_ALREADY_SAVED:",a.title),oe({type:"duplicate",existingStatus:"SAVED"});return}else c===422||c===400?p=`Save failed: ${((d=o==null?void 0:o.body)==null?void 0:d.error)||(o==null?void 0:o.message)||"Invalid job data"}`:c===500?p="Talvyn couldn't save this job. Try again.":c===0||!c?p="Connection problem. Try again.":o!=null&&o.message&&(p=o.message);console.error(`[Talvyn] JOB_SAVE_FAILED: (Status ${c||0}) ${p}`),oe({type:"error",message:p})}}async function qi(){if(Q()){try{document.documentElement.setAttribute("data-talvyn-extension-installed","true")}catch{}document.readyState==="loading"&&await new Promise(s=>document.addEventListener("DOMContentLoaded",()=>s())),Q()&&(await new Promise(s=>setTimeout(s,500)),Q()&&(Ut(),await Ct(),Si.init(async s=>{Q()&&(st.resetPageState(),ae.clearCache(),B(),J.remove(),ee.dismiss(),de.dismiss(),te=!1,F=!1,await Ct())})))}}async function Ct(){if(Q())try{await $i()}catch(s){Rt()&&console.error("[Talvyn] Safe execution error during page analysis:",s)}}async function ot(){if(console.log("[Talvyn] Handling TALVYN_OPEN_INTELLIGENCE_PANEL"),!Q())return{success:!1,mode:"inactive"};be=!0;const s=window.location.href,e=document,t=await pe();if(se(s))return J.remove(),F=!1,xt(()=>{B()},()=>{ot()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"};const{classification:n}=ae.classifyPage(s,e);if(n==="SINGLE_JOB"||fe(e,s)){const a=ae.scanSingleJob(s,e)||Ce(s,e);if(a&&fe(e,s))return K=a,J.remove(),F=!1,await _e(a),{success:!0,mode:"single-job"}}if(n==="JOB_LIST"||Oe(e,s)){B(),te=!1;const a=ae.scanJobListing(s,e,t);if(a.totalDetected>=1)return He(a),{success:!0,mode:"job-listing",detectedJobs:a.totalDetected}}const i=ae.scanSingleJob(s,e)||Ce(s,e);if(i&&fe(e,s))return K=i,J.remove(),F=!1,await _e(i),{success:!0,mode:"single-job"};if(Oe(e,s)){const a=ae.scanJobListing(s,e,t);if(a.totalDetected>=1)return B(),te=!1,He(a),{success:!0,mode:"job-listing",detectedJobs:a.totalDetected}}return J.remove(),F=!1,xt(()=>{B()},()=>{ot()},(t==null?void 0:t.themePreference)||"system"),{success:!0,mode:"not-job-page"}}chrome.runtime.onMessage.addListener((s,e,t)=>{if((s==null?void 0:s.type)==="TALVYN_OPEN_INTELLIGENCE_PANEL")return ot().then(n=>t(n)),!0});qi().catch(s=>{Rt()&&console.error("[Talvyn] Init failed:",s)});
