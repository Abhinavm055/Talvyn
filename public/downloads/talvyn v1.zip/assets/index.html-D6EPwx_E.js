import{g as z,s as A,c as m,C as a}from"./apiClient-Df5ZH6FE.js";import{a as S}from"./authService-CvGTOx7U.js";import{j as L}from"./jobsService-DYlYgcO3.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))r(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const s of i.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&r(s)}).observe(document,{childList:!0,subtree:!0});function o(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(n){if(n.ep)return;n.ep=!0;const i=o(n);fetch(n.href,i)}})();let l="loading";const d=document.getElementById("app");function c(){var t;try{if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.getURL))return chrome.runtime.getURL("icons/logotalvyn.png")}catch{}return"/icons/logotalvyn.png"}function p(){var t;try{if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.getURL))return chrome.runtime.getURL("icons/icon48.png")}catch{}return"/icons/icon48.png"}function w(){var o,r;const t=typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.id)?chrome.runtime.id:"",e=t?`${a.DASHBOARD_URL}/extension/connect?extId=${encodeURIComponent(t)}`:`${a.DASHBOARD_URL}/extension/connect`;try{if(typeof chrome<"u"&&((r=chrome.tabs)!=null&&r.create)){chrome.tabs.create({url:e});return}}catch{}window.open(e,"_blank")}async function U(){console.log("[Talvyn] POPUP_AUTH_CHECK_STARTED"),j();const t=await z();if(!t||!t.token){l="disconnected",k();return}console.log("[Talvyn] SESSION_FOUND");try{const e=await S.me();console.log("[Talvyn] SESSION_VALID"),await A({token:t.token,user:e,connectedAt:t.connectedAt||new Date().toISOString()}),l="connected",v(e)}catch(e){(e==null?void 0:e.status)===401||(e==null?void 0:e.status)===403?(console.log("[Talvyn] SESSION_EXPIRED"),await m(),l="expired",E()):(console.warn("[Talvyn] Backend offline/cold start during popup auth check, retaining session:",(e==null?void 0:e.message)||e),l="connected",v(t.user,{isOffline:!0}))}}function j(){const t=c(),e=p();d.innerHTML=`
    <div style="padding:24px 18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:360px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
      <img
        src="${t}"
        alt="Talvyn"
        onerror="this.onerror=null;this.src='${e}';"
        style="width:48px;height:48px;border-radius:12px;box-shadow:0 4px 12px rgba(99,102,241,0.25);margin-bottom:16px;object-fit:contain;"
      />
      <div style="font-weight:700;font-size:15px;color:#0f172a;margin-bottom:4px;">Talvyn Extension</div>
      <div style="font-size:12px;color:#64748b;margin-bottom:18px;">Checking connection status...</div>
      <div style="width:24px;height:24px;border:2.5px solid #e2e8f0;border-top-color:#4f46e5;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
      <style>
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
      </style>
    </div>
  `}function k(){const t=c(),e=p();d.innerHTML=`
    <div style="padding:18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:360px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${t}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${e}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn Extension</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#f1f5f9;
            color:#64748b;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#94a3b8;display:inline-block;"></span>
            Disconnected
          </div>
        </div>

        <!-- Hero Card -->
        <div style="
          padding:14px;background:linear-gradient(135deg, #f8fafc 0%, #eef2ff 100%);
          border:1px solid #e0e7ff;border-radius:12px;margin-bottom:16px;text-align:center;
        ">
          <div style="font-size:13px;font-weight:700;color:#1e1b4b;margin-bottom:4px;">
            Connect your Talvyn Account
          </div>
          <div style="font-size:11.5px;color:#475569;line-height:1.45;">
            Authorize the extension to capture jobs with 1 click, autofill applications, and track opportunities seamlessly.
          </div>
        </div>

        <!-- Primary Connect Action Button -->
        <button type="button" id="connect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          <span>Connect your Talvyn account</span>
        </button>

        <div style="font-size:11px;color:#64748b;text-align:center;line-height:1.4;">
          Clicking above will open the Talvyn web app in a browser tab to safely verify your session.
        </div>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Don't have an account?</span>
        <a href="${a.DASHBOARD_URL}/signup" target="_blank" style="
          font-size:10px;color:#4f46e5;text-decoration:none;font-weight:600;
        ">Create Free Account →</a>
      </div>
    </div>
  `;const o=document.getElementById("connect-account-btn");o==null||o.addEventListener("click",()=>{w()})}function E(){const t=c(),e=p();d.innerHTML=`
    <div style="padding:18px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:360px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img
              src="${t}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${e}';"
              style="width:34px;height:34px;border-radius:10px;box-shadow:0 2px 6px rgba(99,102,241,0.25);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:14px;color:#0f172a;letter-spacing:-0.2px;">Talvyn Extension</div>
              <div style="font-size:11px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:#fef3c7;
            color:#b45309;font-size:10px;font-weight:600;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:#f59e0b;display:inline-block;"></span>
            Expired
          </div>
        </div>

        <!-- Expired Notice Box -->
        <div style="
          margin-bottom:14px;padding:12px;background:#fffbeb;
          border:1px solid #fef3c7;border-radius:10px;font-size:11.5px;color:#b45309;
          display:flex;align-items:flex-start;gap:8px;line-height:1.45;
        ">
          <span style="font-size:14px;">⚠️</span>
          <div>
            <div style="font-weight:700;margin-bottom:2px;">Session Expired</div>
            Your Talvyn account session timed out. Please reconnect your account to continue capturing jobs and autofilling applications.
          </div>
        </div>

        <!-- Reconnect Action Button -->
        <button type="button" id="reconnect-account-btn" style="
          width:100%;padding:12px 14px;background:linear-gradient(to right, #4f46e5, #6366f1);color:white;
          border:none;border-radius:10px;font-size:13px;font-weight:700;
          display:flex;align-items:center;justify-content:center;gap:8px;
          cursor:pointer;margin-bottom:14px;box-shadow:0 3px 8px rgba(79,70,229,0.3);transition:all 0.15s;
        ">
          <svg style="width:16px;height:16px;flex-shrink:0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>Reconnect Account</span>
        </button>
      </div>

      <!-- Footer Action -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <span style="font-size:10px;color:#64748b;">Need help?</span>
        <a href="${a.DASHBOARD_URL}" target="_blank" style="
          font-size:10px;color:#4f46e5;text-decoration:none;font-weight:600;
        ">Open Dashboard →</a>
      </div>
    </div>
  `;const o=document.getElementById("reconnect-account-btn");o==null||o.addEventListener("click",()=>{w()})}function v(t,e={}){var f,x,g,u,b,y,h;const o=c(),r=p(),n=((f=t.profile)==null?void 0:f.preferredName)||((x=t.profile)==null?void 0:x.givenName)||((g=t.profile)==null?void 0:g.legalFullName)||t.email.split("@")[0],i=(u=t.profile)==null?void 0:u.avatarUrl;d.innerHTML=`
    <div style="padding:16px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#ffffff;color:#0f172a;min-height:360px;display:flex;flex-direction:column;justify-content:space-between;">
      <div>
        <!-- Top Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <img
              src="${o}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${r}';"
              style="width:30px;height:30px;border-radius:8px;box-shadow:0 2px 4px rgba(99,102,241,0.2);flex-shrink:0;object-fit:contain;"
            />
            <div>
              <div style="font-weight:700;font-size:13px;color:#0f172a;">Talvyn Extension</div>
              <div style="font-size:10px;color:#64748b;">From Potential to Offer.</div>
            </div>
          </div>


          <div style="
            display:inline-flex;align-items:center;gap:5px;
            padding:3px 8px;border-radius:999px;background:${e.isOffline?"#fef3c7":"#ecfdf5"};
            color:${e.isOffline?"#b45309":"#059669"};font-size:10px;font-weight:700;
          ">
            <span style="width:6px;height:6px;border-radius:50%;background:${e.isOffline?"#f59e0b":"#10b981"};display:inline-block;"></span>
            ${e.isOffline?"Offline":"✓ Connected"}
          </div>
        </div>

        <!-- User Profile Card -->
        <div style="
          display:flex;align-items:center;gap:10px;padding:10px 12px;
          background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:12px;
        ">
          ${i?`<img src="${i}" alt="${n}" style="width:34px;height:34px;border-radius:50%;object-fit:cover;border:1px solid #cbd5e1;flex-shrink:0;" />`:`<div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg, #6366f1, #8b5cf6);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex-shrink:0;">${(b=n[0])==null?void 0:b.toUpperCase()}</div>`}
          <div style="min-width:0;flex:1;">
            <div style="font-weight:700;font-size:12.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${n}</div>
            <div style="font-size:11px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${t.email}</div>
          </div>
        </div>

        <!-- Navigation Links Grid -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;">
          <button type="button" id="open-dashboard-btn" style="
            padding:9px 10px;background:#f1f5f9;color:#334155;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Dashboard</span>
            <svg style="width:12px;height:12px;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
          </button>

          <button type="button" id="open-tracker-btn" style="
            padding:9px 10px;background:#f1f5f9;color:#334155;border:1px solid #e2e8f0;
            border-radius:8px;font-size:11.5px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:5px;transition:all 0.15s;
          ">
            <span>Tracker</span>
            <svg style="width:12px;height:12px;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
          </button>
        </div>

        <!-- Recent Saved Jobs Section -->
        <div>
          <div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">
            Recent Saved Jobs
          </div>
          <div id="recent-jobs" style="min-height:70px;">
            <div style="font-size:11px;color:#94a3b8;text-align:center;padding:16px 0;">Loading jobs...</div>
          </div>
        </div>
      </div>

      <!-- Footer / Disconnect -->
      <div style="margin-top:14px;padding-top:10px;border-top:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
        <button type="button" id="disconnect-btn" style="
          background:none;border:none;color:#94a3b8;font-size:11px;cursor:pointer;padding:0;
          font-weight:500;transition:color 0.15s;
        ">
          Disconnect Account
        </button>

        <a href="${a.DASHBOARD_URL}/extensions" target="_blank" style="
          font-size:11px;color:#6366f1;text-decoration:none;font-weight:600;
        ">
          Extension Settings →
        </a>
      </div>
    </div>
  `,(y=document.getElementById("open-dashboard-btn"))==null||y.addEventListener("click",()=>{window.open(`${a.DASHBOARD_URL}/dashboard`,"_blank")}),(h=document.getElementById("open-tracker-btn"))==null||h.addEventListener("click",()=>{window.open(`${a.DASHBOARD_URL}/tracker`,"_blank")});const s=document.getElementById("disconnect-btn");s==null||s.addEventListener("click",async()=>{confirm("Disconnect extension from your Talvyn account?")&&(await m(),l="disconnected",k())}),T()}async function T(){const t=document.getElementById("recent-jobs");if(t)try{const e=await L.getJobs();if(!e||e.length===0){t.innerHTML=`
        <div style="padding:12px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:8px;text-align:center;">
          <div style="font-size:11px;color:#64748b;margin-bottom:2px;">No jobs saved yet</div>
          <div style="font-size:10px;color:#94a3b8;">Browse any job board to capture listings with 1 click.</div>
        </div>
      `;return}const o=e.slice(0,3);t.innerHTML=o.map(r=>`
        <div style="
          display:flex;align-items:center;justify-content:space-between;
          padding:7px 10px;background:#f8fafc;border:1px solid #f1f5f9;border-radius:8px;margin-bottom:4px;
        ">
          <div style="min-width:0;flex:1;">
            <div style="font-weight:600;font-size:11.5px;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${r.title}
            </div>
            <div style="font-size:10.5px;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              ${r.company}
            </div>
          </div>
          <span style="
            font-size:9.5px;padding:2px 6px;border-radius:999px;font-weight:600;text-transform:capitalize;
            background:${r.status==="APPLIED"?"#e0f2fe":"#f1f5f9"};
            color:${r.status==="APPLIED"?"#0369a1":"#475569"};
          ">
            ${r.status.toLowerCase()}
          </span>
        </div>
      `).join("")}catch{t.innerHTML=`
      <div style="font-size:11px;color:#94a3b8;text-align:center;padding:12px 0;">
        Saved jobs will appear here
      </div>
    `}}U().catch(console.error);
