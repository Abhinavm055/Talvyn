import{j as $}from"./jobsService-BuEU-K8d.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))o(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&o(a)}).observe(document,{childList:!0,subtree:!0});function n(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function o(i){if(i.ep)return;i.ep=!0;const r=n(i);fetch(i.href,r)}})();let d="loading",J=null,H=!1,p="dark",x="",s="analyze";const g=document.getElementById("app");async function Q(){var e;try{if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const t=await chrome.storage.local.get("talvyn_extension_theme");(t.talvyn_extension_theme==="light"||t.talvyn_extension_theme==="dark")&&(p=t.talvyn_extension_theme)}else{const t=localStorage.getItem("talvyn_extension_theme");(t==="light"||t==="dark")&&(p=t)}}catch{}V(p)}function V(e){var t;p=e,document.body.classList.remove("theme-dark","theme-light"),document.body.classList.add(`theme-${e}`);try{typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)&&chrome.storage.local.set({talvyn_extension_theme:e}),localStorage.setItem("talvyn_extension_theme",e)}catch{}}function ee(){const e=p==="dark"?"light":"dark";V(e);const t=document.getElementById("celestial-theme-toggle");if(t){const n=e==="light";t.innerHTML=n?`
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color: #F59E0B;">
          <circle cx="12" cy="12" r="4"></circle>
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path>
        </svg>
      `:`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color: #818CF8;">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
        </svg>
      `}}function f(){return`
    <button
      type="button"
      id="celestial-theme-toggle"
      class="round-theme-toggle"
      title="Toggle Light / Dark Mode"
      aria-label="Toggle Sun/Moon Theme"
    >
      ${p==="light"?`
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color: #F59E0B;">
          <circle cx="12" cy="12" r="4"></circle>
          <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path>
        </svg>
      `:`
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color: #818CF8;">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>
        </svg>
      `}
    </button>
  `}function h(){var e;(e=document.getElementById("celestial-theme-toggle"))==null||e.addEventListener("click",t=>{t.preventDefault(),ee()})}function b(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/logotalvyn.png")}catch{}return"/icons/logotalvyn.png"}function v(){var e;try{if(typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.getURL))return chrome.runtime.getURL("icons/icon48.png")}catch{}return"/icons/icon48.png"}async function te(){var e,t;try{if(typeof chrome<"u"&&((e=chrome.tabs)!=null&&e.query)){const n=await chrome.tabs.query({active:!0,currentWindow:!0});if((t=n[0])!=null&&t.url&&n[0].url.startsWith("http"))return n[0].url}}catch{}return""}async function u(e){var t;if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage))try{return await chrome.runtime.sendMessage(e)}catch(n){throw console.warn("[Talvyn Popup] Background message failed:",n),n}throw new Error("Chrome runtime unavailable")}async function c(e){try{await u({type:"OPEN_DASHBOARD_ROUTE",route:e})}catch{const t={dashboard:"https://talvyn.vercel.app/dashboard",profile:"https://talvyn.vercel.app/profile",tracker:"https://talvyn.vercel.app/tracker",settings:"https://talvyn.vercel.app/extensions"};window.open(t[e]||"https://talvyn.vercel.app/dashboard","_blank")}}async function m(){var e;try{await u({type:"CONNECT_TALVYN"})}catch{const t=typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.id)?chrome.runtime.id:"",n=t?`https://talvyn.vercel.app/extension/connect?extId=${encodeURIComponent(t)}`:"https://talvyn.vercel.app/extension/connect";window.open(n,"_blank")}}async function ne(){try{await u({type:"DISCONNECT_TALVYN"})}catch(e){console.warn("[Talvyn Popup] Failed to disconnect via background:",e)}d="disconnected",J=null,W()}async function oe(){var e,t,n;console.log("[Talvyn Popup] Triggering floating intelligence panel on active tab...");try{let o=null;if(typeof chrome<"u"&&((e=chrome.tabs)!=null&&e.query)){const a=await chrome.tabs.query({active:!0,lastFocusedWindow:!0});if((t=a[0])!=null&&t.id)o=a[0];else{const l=await chrome.tabs.query({active:!0,currentWindow:!0});(n=l[0])!=null&&n.id&&(o=l[0])}}if(!(o!=null&&o.id)){await u({type:"TRIGGER_ACTIVE_TAB_PANEL"});return}const i=o.url||"",r=o.title||"";try{await chrome.tabs.sendMessage(o.id,{type:"TALVYN_OPEN_INTELLIGENCE_PANEL",tabUrl:i,tabTitle:r})}catch{await u({type:"TRIGGER_ACTIVE_TAB_PANEL",tabId:o.id,tabUrl:i,tabTitle:r})}}catch(o){console.error("[Talvyn Popup] Failed to trigger active tab floating window:",(o==null?void 0:o.message)||o)}}async function q(){console.log("[Talvyn] POPUP_AUTH_CHECK_STARTED"),await Q(),ie(),x=await te();try{const e=await u({type:"GET_AUTH_STATUS"});if(!e||!e.success){d="error",D((e==null?void 0:e.error)||"Could not verify connection status.");return}e.state==="connected"&&e.user?(console.log("[Talvyn] SESSION_FOUND"),console.log("[Talvyn] SESSION_VALID"),d="connected",J=e.user,H=!!e.isOffline,ae(e.user,{isOffline:H})):e.state==="expired"?(console.log("[Talvyn] SESSION_EXPIRED"),d="expired",re()):(d="disconnected",W())}catch(e){console.error("[Talvyn Popup] Error communicating with background worker:",e),d="error",D((e==null?void 0:e.message)||"Unable to connect to extension service worker.")}}function ie(){const e=b(),t=v();g.innerHTML=`
    <div style="padding: 28px 18px; min-height: 480px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; background: var(--bg-main); color: var(--text-primary);">
      <img
        src="${e}"
        alt="Talvyn"
        onerror="this.onerror=null;this.src='${t}';"
        style="width: 46px; height: 46px; border-radius: 12px; filter: drop-shadow(0 0 16px rgba(80,84,234,0.45)); margin-bottom: 16px; object-fit: contain;"
      />
      <div style="font-weight: 700; font-size: 16px; color: var(--text-primary); margin-bottom: 4px;">Talvyn</div>
      <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 22px;">Connecting...</div>
      <div style="width: 28px; height: 28px; border: 2.5px solid var(--border-color); border-top-color: #5054EA; border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
    </div>
  `}function W(){var n,o;const e=b(),t=v();g.innerHTML=`
    <div style="padding: 16px; min-height: 480px; display: flex; flex-direction: column; justify-content: space-between; background: var(--bg-main); color: var(--text-primary);">
      <div>
        <!-- Brand Header with Sun/Moon Toggle -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
          <div style="display: flex; align-items: center; gap: 9px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width: 32px; height: 32px; border-radius: 9px; filter: drop-shadow(0 0 12px rgba(80,84,234,0.4)); flex-shrink: 0; object-fit: contain;"
            />
            <div>
              <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); letter-spacing: -0.2px;">Talvyn</div>
              <div style="font-size: 10.5px; color: var(--text-muted);">From Potential to Offer.</div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="
              display: inline-flex; align-items: center; gap: 5px;
              padding: 3px 8px; border-radius: 999px; background: var(--chip-bg, rgba(255,255,255,0.05));
              color: var(--text-muted); font-size: 10px; font-weight: 600; border: 1px solid var(--border-color);
            ">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: #94A3B8; display: inline-block;"></span>
              Not connected
            </div>
            ${f()}
          </div>
        </div>

        <!-- Connection Notice Card -->
        <div style="
          padding: 18px 14px; background: var(--bg-card);
          border: 1px solid var(--border-color); border-radius: 14px; margin-bottom: 16px; text-align: center;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        ">
          <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(80,84,234,0.15); border: 1px solid rgba(80,84,234,0.3); color: #8B8DF8; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px auto;">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
          </div>
          <div style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 5px;">
            Connect your Talvyn Account
          </div>
          <div style="font-size: 11.5px; color: var(--text-secondary); line-height: 1.5;">
            Authorize the extension to capture jobs, analyze requirements, and auto-fill applications seamlessly.
          </div>
        </div>

        <!-- Primary Connect Action Button -->
        <button type="button" id="connect-account-btn" style="
          width: 100%; padding: 12px 14px; background: #5054EA; color: white;
          border: none; border-radius: 11px; font-size: 13px; font-weight: 700;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          cursor: pointer; margin-bottom: 12px; box-shadow: 0 0 20px rgba(80,84,234,0.4);
          transition: all 0.2s ease;
        ">
          <svg style="width: 16px; height: 16px; flex-shrink: 0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          <span>Connect Talvyn</span>
        </button>

        <div style="font-size: 11px; color: var(--text-muted); text-align: center; line-height: 1.4;">
          Opens your Talvyn dashboard to link your session securely.
        </div>
      </div>

      <!-- Footer Action -->
      <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 10.5px; color: var(--text-muted);">Don't have an account?</span>
        <button type="button" id="signup-btn" style="
          background: none; border: none; padding: 0; font-size: 11px; color: #8B8DF8; font-weight: 600; cursor: pointer;
        ">Create Free Account →</button>
      </div>
    </div>
  `,h(),(n=document.getElementById("connect-account-btn"))==null||n.addEventListener("click",()=>{m()}),(o=document.getElementById("signup-btn"))==null||o.addEventListener("click",()=>{m()})}function re(){var n,o;const e=b(),t=v();g.innerHTML=`
    <div style="padding: 16px; min-height: 480px; display: flex; flex-direction: column; justify-content: space-between; background: var(--bg-main); color: var(--text-primary);">
      <div>
        <!-- Brand Header with Sun/Moon Toggle -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
          <div style="display: flex; align-items: center; gap: 9px;">
            <img
              src="${e}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${t}';"
              style="width: 32px; height: 32px; border-radius: 9px; filter: drop-shadow(0 0 12px rgba(80,84,234,0.4)); flex-shrink: 0; object-fit: contain;"
            />
            <div>
              <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); letter-spacing: -0.2px;">Talvyn</div>
              <div style="font-size: 10.5px; color: var(--text-muted);">From Potential to Offer.</div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="
              display: inline-flex; align-items: center; gap: 5px;
              padding: 3px 8px; border-radius: 999px; background: rgba(245,158,11,0.15);
              color: #FBBF24; font-size: 10px; font-weight: 700; border: 1px solid rgba(245,158,11,0.3);
            ">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: #F59E0B; display: inline-block;"></span>
              Session expired
            </div>
            ${f()}
          </div>
        </div>

        <!-- Expired Notice Box -->
        <div style="
          margin-bottom: 16px; padding: 14px; background: rgba(245,158,11,0.08);
          border: 1px solid rgba(245,158,11,0.25); border-radius: 12px; font-size: 11.5px; color: var(--text-secondary);
          display: flex; align-items: flex-start; gap: 10px; line-height: 1.5;
        ">
          <span style="font-size: 16px;">⚠️</span>
          <div>
            <div style="font-weight: 700; color: #FBBF24; margin-bottom: 3px;">Session Expired</div>
            Your Talvyn session has expired. Reconnect your account to continue capturing and tracking jobs.
          </div>
        </div>

        <!-- Reconnect Action Button -->
        <button type="button" id="reconnect-account-btn" style="
          width: 100%; padding: 12px 14px; background: #5054EA; color: white;
          border: none; border-radius: 11px; font-size: 13px; font-weight: 700;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          cursor: pointer; margin-bottom: 14px; box-shadow: 0 0 20px rgba(80,84,234,0.4);
          transition: all 0.2s ease;
        ">
          <svg style="width: 16px; height: 16px; flex-shrink: 0;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>Reconnect Talvyn</span>
        </button>
      </div>

      <!-- Footer Action -->
      <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 10px; color: var(--text-muted);">Need help?</span>
        <button type="button" id="open-dash-footer-btn" style="
          background: none; border: none; padding: 0; font-size: 10.5px; color: #8B8DF8; font-weight: 600; cursor: pointer;
        ">Open Dashboard →</button>
      </div>
    </div>
  `,h(),(n=document.getElementById("reconnect-account-btn"))==null||n.addEventListener("click",()=>{m()}),(o=document.getElementById("open-dash-footer-btn"))==null||o.addEventListener("click",()=>{c("dashboard")})}function D(e){var o,i;const t=b(),n=v();g.innerHTML=`
    <div style="padding: 16px; min-height: 480px; display: flex; flex-direction: column; justify-content: space-between; background: var(--bg-main); color: var(--text-primary);">
      <div>
        <!-- Brand Header with Sun/Moon Toggle -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
          <div style="display: flex; align-items: center; gap: 9px;">
            <img
              src="${t}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${n}';"
              style="width: 32px; height: 32px; border-radius: 9px; filter: drop-shadow(0 0 12px rgba(80,84,234,0.4)); flex-shrink: 0; object-fit: contain;"
            />
            <div>
              <div style="font-weight: 700; font-size: 14px; color: var(--text-primary); letter-spacing: -0.2px;">Talvyn</div>
              <div style="font-size: 10.5px; color: var(--text-muted);">From Potential to Offer.</div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="
              display: inline-flex; align-items: center; gap: 5px;
              padding: 3px 8px; border-radius: 999px; background: rgba(239,68,68,0.15);
              color: #F87171; font-size: 10px; font-weight: 700; border: 1px solid rgba(239,68,68,0.3);
            ">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: #EF4444; display: inline-block;"></span>
              Connection issue
            </div>
            ${f()}
          </div>
        </div>

        <!-- Error Notice Box -->
        <div style="
          margin-bottom: 16px; padding: 14px; background: rgba(239,68,68,0.08);
          border: 1px solid rgba(239,68,68,0.25); border-radius: 12px; font-size: 11.5px; color: var(--text-secondary);
          display: flex; align-items: flex-start; gap: 10px; line-height: 1.5;
        ">
          <span style="font-size: 16px;">⚠️</span>
          <div>
            <div style="font-weight: 700; color: #F87171; margin-bottom: 3px;">Connection Issue</div>
            ${e}
          </div>
        </div>

        <!-- Retry Button -->
        <button type="button" id="retry-btn" style="
          width: 100%; padding: 11px 14px; background: var(--bg-card); color: var(--text-primary);
          border: 1px solid var(--border-color); border-radius: 10px; font-size: 12.5px; font-weight: 700;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          cursor: pointer; margin-bottom: 10px; transition: all 0.15s;
        ">
          <span>Try Again</span>
        </button>

        <button type="button" id="connect-fallback-btn" style="
          width: 100%; padding: 11px 14px; background: #5054EA; color: white;
          border: none; border-radius: 10px; font-size: 12.5px; font-weight: 700;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          cursor: pointer; box-shadow: 0 0 16px rgba(80,84,234,0.4); transition: all 0.15s;
        ">
          <span>Connect Talvyn</span>
        </button>
      </div>

      <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--border-color); text-align: center;">
        <span style="font-size: 10px; color: var(--text-muted);">Ensure your Talvyn app is running.</span>
      </div>
    </div>
  `,h(),(o=document.getElementById("retry-btn"))==null||o.addEventListener("click",()=>{q()}),(i=document.getElementById("connect-fallback-btn"))==null||i.addEventListener("click",()=>{m()})}function ae(e,t={}){var a;const n=b(),o=v();g.innerHTML=`
    <div style="padding: 16px; min-height: 480px; display: flex; flex-direction: column; justify-content: space-between; background: var(--bg-main); color: var(--text-primary);">
      <div>
        <!-- Top Bar: Logo, Tagline, Connection Status, and Round Sun/Moon Toggle -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px;">
          <div style="display: flex; align-items: center; gap: 9px;">
            <img
              src="${n}"
              alt="Talvyn"
              onerror="this.onerror=null;this.src='${o}';"
              style="width: 32px; height: 32px; border-radius: 9px; object-fit: contain; flex-shrink: 0;"
            />
            <div>
              <div style="font-weight: 700; font-size: 14.5px; color: var(--text-primary); letter-spacing: -0.2px; line-height: 1.2;">Talvyn</div>
              <div style="font-size: 10.5px; color: var(--text-muted); line-height: 1.2;">From Potential to Offer.</div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="
              display: inline-flex; align-items: center; gap: 5px;
              padding: 3px 9px; border-radius: 999px;
              background: ${t.isOffline?"var(--badge-offline-bg)":"var(--badge-connected-bg)"};
              color: ${t.isOffline?"var(--badge-offline-text)":"var(--badge-connected-text)"};
              font-size: 10.5px; font-weight: 600;
              border: 1px solid var(--border-color);
            ">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: ${t.isOffline?"var(--badge-offline-dot)":"var(--badge-connected-dot)"}; display: inline-block;"></span>
              <span>${t.isOffline?"Offline":"Connected"}</span>
            </div>
            ${f()}
          </div>
        </div>

        <!-- Top Two Action Buttons: Analyze This Page & Save Job Manually (Mutually Exclusive Modes) -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px;">
          <button
            type="button"
            id="btn-analyze-page"
            class="popup-mode-btn ${s==="analyze"?"active":"inactive"}"
          >
            <svg style="width: 14px; height: 14px; flex-shrink: 0;" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
            <span>Analyze This Page</span>
          </button>

          <button
            type="button"
            id="btn-manual-save-mode"
            data-testid="toggle-manual-save-btn"
            class="popup-mode-btn ${s==="manual-save"?"active":"inactive"}"
          >
            <span style="font-size: 15px; font-weight: 700; line-height: 1;">+</span>
            <span>Save Job Manually</span>
          </button>
        </div>

        <!-- Mode Content Container: Explicitly renders ONLY Analyze OR Manual Save -->
        <div id="mode-content-container"></div>
      </div>

      <!-- Footer / Disconnect Action -->
      <div style="margin-top: 14px; padding-top: 10px; border-top: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
        <button type="button" id="disconnect-btn" style="
          background: none; border: none; color: var(--text-muted); font-size: 11.5px; cursor: pointer; padding: 0;
          font-weight: 500; transition: color 0.15s;
        ">
          Disconnect Account
        </button>

        <span style="font-size: 11px; color: var(--text-muted);">Talvyn v1.1</span>
      </div>
    </div>
  `,h();const i=document.getElementById("btn-analyze-page");i==null||i.addEventListener("click",async()=>{if(s!=="analyze"){s="analyze",A();return}const l=i.innerHTML;i.disabled=!0,i.style.opacity="0.85",i.innerHTML=`
      <svg style="width:14px;height:14px;" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2.5" stroke-dasharray="14" stroke-dashoffset="5"></circle></svg>
      <span>Analyzing Page...</span>
    `;try{await oe(),i.innerHTML=`
        <svg style="width:14px;height:14px;" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
        <span>✓ Intelligence Active</span>
      `}catch{i.innerHTML=l}finally{setTimeout(()=>{i.disabled=!1,i.style.opacity="1",i.innerHTML=l},2500)}});const r=document.getElementById("btn-manual-save-mode");r==null||r.addEventListener("click",()=>{s!=="manual-save"&&(s="manual-save",A())}),(a=document.getElementById("disconnect-btn"))==null||a.addEventListener("click",async()=>{confirm("Disconnect extension from your Talvyn account?")&&await ne()}),A()}function A(){const e=document.getElementById("mode-content-container");if(!e)return;const t=document.getElementById("btn-analyze-page"),n=document.getElementById("btn-manual-save-mode");t&&(t.className=`popup-mode-btn ${s==="analyze"?"active":"inactive"}`),n&&(n.className=`popup-mode-btn ${s==="manual-save"?"active":"inactive"}`),s==="analyze"?(e.innerHTML=le(),se(),pe()):(e.innerHTML=de(),ce())}function le(){return`
    <div id="analyze-mode-view">
      <!-- 4 Core Navigation Icon Buttons: Dashboard, Profile, Tracker, Settings -->
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 16px;">
        <button type="button" id="btn-open-dashboard" class="popup-nav-btn" style="
          padding: 10px 4px; background: var(--bg-card); color: var(--text-primary);
          border: 1px solid var(--border-color); border-radius: 10px; cursor: pointer;
          display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px;
          transition: all 0.15s ease;
        ">
          <svg style="width: 16px; height: 16px; color: var(--text-secondary);" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <rect x="3" y="3" width="7" height="7" rx="1.5"></rect>
            <rect x="14" y="3" width="7" height="7" rx="1.5"></rect>
            <rect x="14" y="14" width="7" height="7" rx="1.5"></rect>
            <rect x="3" y="14" width="7" height="7" rx="1.5"></rect>
          </svg>
          <span style="font-size: 11px; font-weight: 600;">Dashboard</span>
        </button>

        <button type="button" id="btn-open-profile" class="popup-nav-btn" style="
          padding: 10px 4px; background: var(--bg-card); color: var(--text-primary);
          border: 1px solid var(--border-color); border-radius: 10px; cursor: pointer;
          display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px;
          transition: all 0.15s ease;
        ">
          <svg style="width: 16px; height: 16px; color: var(--text-secondary);" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span style="font-size: 11px; font-weight: 600;">Profile</span>
        </button>

        <button type="button" id="btn-open-tracker" class="popup-nav-btn" style="
          padding: 10px 4px; background: var(--bg-card); color: var(--text-primary);
          border: 1px solid var(--border-color); border-radius: 10px; cursor: pointer;
          display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px;
          transition: all 0.15s ease;
        ">
          <svg style="width: 16px; height: 16px; color: var(--text-secondary);" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
            <path stroke-linecap="round" stroke-linejoin="round" d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"></path>
          </svg>
          <span style="font-size: 11px; font-weight: 600;">Tracker</span>
        </button>

        <button type="button" id="btn-open-settings" class="popup-nav-btn" style="
          padding: 10px 4px; background: var(--bg-card); color: var(--text-primary);
          border: 1px solid var(--border-color); border-radius: 10px; cursor: pointer;
          display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px;
          transition: all 0.15s ease;
        ">
          <svg style="width: 16px; height: 16px; color: var(--text-secondary);" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="3"></circle>
            <path stroke-linecap="round" stroke-linejoin="round" d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
          <span style="font-size: 11px; font-weight: 600;">Settings</span>
        </button>
      </div>

      <!-- Recent Saved Jobs Section -->
      <div>
        <div style="font-size: 10.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.6px; margin-bottom: 8px;">
          RECENT SAVED JOBS
        </div>
        <div id="recent-jobs" style="min-height: 50px;">
          <div style="font-size: 11px; color: var(--text-muted); text-align: center; padding: 12px 0;">Loading jobs...</div>
        </div>
      </div>
    </div>
  `}function se(){var e,t,n,o;(e=document.getElementById("btn-open-dashboard"))==null||e.addEventListener("click",()=>{c("dashboard")}),(t=document.getElementById("btn-open-profile"))==null||t.addEventListener("click",()=>{c("profile")}),(n=document.getElementById("btn-open-tracker"))==null||n.addEventListener("click",()=>{c("tracker")}),(o=document.getElementById("btn-open-settings"))==null||o.addEventListener("click",()=>{c("settings")})}function de(){return`
    <div id="manual-save-mode-view">
      <form id="form-manual-job" style="display: flex; flex-direction: column; gap: 9px;">
        <!-- Row 1: Job Title * & Company Name * -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div>
            <label class="manual-label" for="manual-job-title">Job Title *</label>
            <input
              type="text"
              id="manual-job-title"
              name="title"
              required
              class="manual-input"
              placeholder="e.g. Software Engineer"
            />
          </div>
          <div>
            <label class="manual-label" for="manual-job-company">Company Name *</label>
            <input
              type="text"
              id="manual-job-company"
              name="company"
              required
              class="manual-input"
              placeholder="e.g. Acme Corp"
            />
          </div>
        </div>

        <!-- Row 2: Location & Job Type -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div>
            <label class="manual-label" for="manual-job-location">Location</label>
            <input
              type="text"
              id="manual-job-location"
              name="location"
              class="manual-input"
              placeholder="e.g. Bengaluru, Bangalore, Remote, or Hybrid"
            />
          </div>
          <div>
            <label class="manual-label" for="manual-job-type">Job Type</label>
            <select id="manual-job-type" name="jobType" class="manual-select">
              <option value="" selected>Select type...</option>
              <option value="FULL_TIME">Full-time</option>
              <option value="PART_TIME">Part-time</option>
              <option value="CONTRACT">Contract</option>
              <option value="INTERNSHIP">Internship</option>
              <option value="FREELANCE">Freelance</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        </div>

        <!-- Row 3: Application Status & Salary / Compensation -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div>
            <label class="manual-label" for="manual-job-status">Application Status</label>
            <select id="manual-job-status" name="status" class="manual-select">
              <option value="SAVED" selected>Saved</option>
              <option value="APPLIED">Applied</option>
              <option value="INTERVIEW">Interview</option>
              <option value="OFFER">Offer</option>
              <option value="REJECTED">Rejected</option>
            </select>
          </div>
          <div>
            <label class="manual-label" for="manual-job-salary">Salary / Compensation</label>
            <input
              type="text"
              id="manual-job-salary"
              name="salary"
              class="manual-input"
              placeholder="e.g. $120,000 - $140,000 or 15-20 LPA"
            />
          </div>
        </div>

        <!-- Row 4: Job Posting URL & Source Website -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          <div>
            <label class="manual-label" for="manual-job-url">Job Posting URL</label>
            <input
              type="url"
              id="manual-job-url"
              name="jobUrl"
              class="manual-input"
              placeholder="https://company.com/jobs/..."
              value="${x&&x.startsWith("http")?x:""}"
            />
          </div>
          <div>
            <label class="manual-label" for="manual-job-source">Source Website</label>
            <input
              type="text"
              id="manual-job-source"
              name="sourceWebsite"
              class="manual-input"
              placeholder="e.g. LinkedIn, Indeed, Company Site"
            />
          </div>
        </div>

        <!-- Row 5: Date Applied -->
        <div>
          <label class="manual-label" for="manual-job-date-applied">Date Applied</label>
          <input
            type="date"
            id="manual-job-date-applied"
            name="dateApplied"
            class="manual-input"
            placeholder="dd-mm-yyyy"
          />
          <div style="font-size: 10px; color: var(--text-muted); margin-top: 2.5px;">
            Leave blank if you haven't applied yet
          </div>
        </div>

        <!-- Row 6: Job Description -->
        <div>
          <label class="manual-label" for="manual-job-description">Job Description</label>
          <textarea
            id="manual-job-description"
            name="description"
            rows="3"
            class="manual-textarea"
            placeholder="Paste or review the job description, responsibilities, and requirements here..."
            style="resize: vertical; min-height: 54px;"
          ></textarea>
        </div>

        <!-- Validation / Submission Feedback -->
        <div id="manual-save-feedback" style="display: none; font-size: 11px; padding: 7px 10px; border-radius: 7px; line-height: 1.4;"></div>

        <!-- Final Action Button: Exactly 'Save Job' -->
        <button
          type="submit"
          id="btn-submit-manual-job"
          style="
            margin-top: 2px; height: 36px; width: 100%; background: #5054EA; color: white;
            border: none; border-radius: 9px; font-size: 12.5px; font-weight: 700;
            cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 7px;
            box-shadow: 0 2px 10px rgba(80,84,234,0.35); transition: all 0.15s ease;
          "
        >
          <span>Save Job</span>
        </button>
      </form>
    </div>
  `}function ce(){const e=document.getElementById("form-manual-job"),t=document.getElementById("btn-submit-manual-job"),n=document.getElementById("manual-save-feedback");e==null||e.addEventListener("submit",async o=>{var S,R,F,P,N,O,_,U;o.preventDefault();const i=document.getElementById("manual-job-title"),r=document.getElementById("manual-job-company"),a=document.getElementById("manual-job-location"),l=document.getElementById("manual-job-type"),w=document.getElementById("manual-job-status"),k=document.getElementById("manual-job-salary"),T=document.getElementById("manual-job-url"),E=document.getElementById("manual-job-source"),j=document.getElementById("manual-job-date-applied"),B=document.getElementById("manual-job-description"),z=((S=i==null?void 0:i.value)==null?void 0:S.trim())||"",I=((R=r==null?void 0:r.value)==null?void 0:R.trim())||"",G=((F=a==null?void 0:a.value)==null?void 0:F.trim())||"",Y=(l==null?void 0:l.value)||void 0,K=(w==null?void 0:w.value)||"SAVED",Z=((P=k==null?void 0:k.value)==null?void 0:P.trim())||"",L=((N=T==null?void 0:T.value)==null?void 0:N.trim())||"";let y=((O=E==null?void 0:E.value)==null?void 0:O.trim())||"";const C=((_=j==null?void 0:j.value)==null?void 0:_.trim())||"",X=((U=B==null?void 0:B.value)==null?void 0:U.trim())||"";if(!z||!I){n&&(n.style.display="block",n.style.background="rgba(239, 68, 68, 0.12)",n.style.border="1px solid rgba(239, 68, 68, 0.25)",n.style.color="#F87171",n.innerText="Job Title and Company Name are required.");return}if(!y&&L)try{y=new URL(L).hostname.replace(/^www\./,"")}catch{y="web"}t&&(t.disabled=!0,t.style.opacity="0.85",t.innerHTML=`
        <div style="width: 14px; height: 14px; border: 2px solid rgba(255,255,255,0.4); border-top-color: white; border-radius: 50%; animation: spin 0.7s linear infinite;"></div>
        <span>Saving...</span>
      `);try{await $.save({title:z,company:I,location:G||void 0,jobType:Y||void 0,status:K,salary:Z||void 0,jobUrl:L||void 0,sourceWebsite:y||void 0,dateApplied:C?new Date(C).toISOString():null,description:X||void 0}),n&&(n.style.display="block",n.style.background="rgba(16, 185, 129, 0.12)",n.style.border="1px solid rgba(16, 185, 129, 0.25)",n.style.color="#34D399",n.innerText="✓ Job saved successfully!"),e.reset(),setTimeout(()=>{n&&(n.style.display="none")},4e3)}catch(M){n&&(n.style.display="block",n.style.background="rgba(239, 68, 68, 0.12)",n.style.border="1px solid rgba(239, 68, 68, 0.25)",n.style.color="#F87171",n.innerText=(M==null?void 0:M.message)||"Failed to save job. Try again.")}finally{t&&(t.disabled=!1,t.style.opacity="1",t.innerHTML="<span>Save Job</span>")}})}async function pe(){const e=document.getElementById("recent-jobs");if(e)try{const t=await $.getJobs();if(!t||t.length===0){e.innerHTML=`
        <div style="padding: 10px; background: var(--bg-card); border: 1px dashed var(--border-color); border-radius: 8px; text-align: center;">
          <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 2px;">No jobs saved yet</div>
          <div style="font-size: 10px; color: var(--text-muted);">Browse any job board to capture or save manually above.</div>
        </div>
      `;return}const n=t.slice(0,3);e.innerHTML=n.map(o=>`
        <div style="
          display: flex; align-items: center; justify-content: space-between;
          padding: 10px 12px; background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 10px; margin-bottom: 6px;
          transition: border-color 0.15s ease;
        ">
          <div style="min-width: 0; flex: 1; padding-right: 8px;">
            <div style="font-weight: 700; font-size: 12.5px; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${o.title}
            </div>
            <div style="font-size: 11px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px;">
              ${o.company}
            </div>
          </div>
          <button type="button" class="recent-job-pill" style="
            display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px;
            border-radius: 999px; font-size: 11px; font-weight: 600;
            background: var(--bg-card-subtle); color: var(--text-secondary);
            border: 1px solid var(--border-color); cursor: pointer; flex-shrink: 0;
            transition: all 0.15s ease;
          " data-url="${o.jobUrl||""}">
            <span>${o.status==="APPLIED"?"Applied":"Saved"}</span>
            <span style="font-size: 13px; line-height: 1; color: var(--text-muted);">&rsaquo;</span>
          </button>
        </div>
      `).join(""),e.querySelectorAll(".recent-job-pill").forEach(o=>{o.addEventListener("click",i=>{i.stopPropagation();const r=o.getAttribute("data-url");r&&r.startsWith("http")?window.open(r,"_blank"):c("tracker")})})}catch{e.innerHTML=`
      <div style="font-size: 11px; color: var(--text-muted); text-align: center; padding: 10px 0;">
        Saved jobs will appear here
      </div>
    `}}q().catch(console.error);
